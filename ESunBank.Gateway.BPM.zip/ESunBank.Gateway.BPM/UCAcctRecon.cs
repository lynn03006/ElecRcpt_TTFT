﻿using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Net;
using System.IO;

using System.Data;

using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using Bankpro.EAI.Utility;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Transactions;
using ESunBank.Gateway.BPM.Util;

namespace ESunBank.Gateway.BPM
{
    class UCAcctRecon : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("ESunBank.Gateway.BPM.UCAcctRecon");
        private static readonly string allowSign = "1";
        private static readonly string allowCancel = "1";
        BATCH batch = new BATCH();
        Common com = new Common();
        UCCommonUtil ucComUtil = new UCCommonUtil();

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            switch (txID)
            {
                case "2020605"://查詢帳戶的簽約／解約訊息
                    return Do_2020605_Process(context, correlationID, txID, txDef, requestXml);

                case "2020529"://企網後台簽約 / 解約
                case "2020606"://企網前台簽約 / 解約
                    return Do_2020529_2020606_Process(context, correlationID, txID, txDef, requestXml);

                case "2020530"://企網後台餘額對帳單查詢
                case "2020641"://企網前台餘額對帳單查詢
                    return Do_2020530_2020641_Process(context, correlationID, txID, txDef, requestXml);

                case "2020607"://餘額對帳交易
                    return Do_2020607_Process(context, correlationID, txID, txDef, requestXml);

                case "2020642"://餘額對賬詳情查詢
                    return Do_2020642_Process(context, correlationID, txID, txDef, requestXml);

                case "2020637"://帳戶交易明細查詢
                    return Do_2020637_Process(context, correlationID, txID, txDef, requestXml);

                case "2020638"://帳戶交易明細對帳
                    return Do_2020638_Process(context, correlationID, txID, txDef, requestXml);

                case "2020639"://帳戶明細對帳查詢
                    return Do_2020639_Process(context, correlationID, txID, txDef, requestXml);

                case "2020640"://帳戶明細對帳詳情查詢
                    return Do_2020640_Process(context, correlationID, txID, txDef, requestXml);
            }
            EaiResponse eaiRs = null;
            XmlDocument responseXml = null;
            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }

        private AppXmlExecResult Do_2020640_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);

                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(ucData);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string custNo = string.Empty, lotNo = string.Empty;
                rqBodyDic.TryGetValue("4001", out custNo);
                rqBodyDic.TryGetValue("4113", out lotNo);
                #endregion 1.分析報文

                #region 2.撈取資訊
                string acctNo = string.Empty, startDate = string.Empty, endDate = string.Empty;
                DataSet dsIBTxnRecChk = DBLog.SelIBTxnRecChk(txID, custNo, acctNo, startDate, endDate, lotNo);
                List<Dictionary<string, string>> dicListIBTxnRecChk = batch.DatasetToDiclist(dsIBTxnRecChk);
                #endregion 2.撈取資訊

                #region 3.撈取明細資訊並且產生FileContentList落檔上傳FTP
                List<string> fileContentLst = new List<string>();
                fileContentLst = GetFileContentList_2020640(dicListIBTxnRecChk);
                //FileContentList落檔 上傳FTP
                uCcontroler.CreateEnqFileToUC(fileContentLst, true);
                #endregion 3.撈取明細資訊並且產生FileContentList落檔上傳FTP

                #region 4.回覆結果
                Dictionary<string, string> totalDic = new Dictionary<string, string>();
                totalDic.Add("2028", "CO1M0000");
                totalDic.Add("zzzx", uCcontroler.enqFileName);//文件名
                totalDic.Add("4305", fileContentLst.Count.ToString());//總筆數
                string rsString = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, totalDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);
                #endregion 4.回覆結果
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2020640_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
            throw new NotImplementedException();
        }

        private AppXmlExecResult Do_2020639_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);

                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(ucData);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string custNo = string.Empty, acctNo = string.Empty, status = string.Empty, startDate = string.Empty, endDate = string.Empty;
                rqBodyDic.TryGetValue("4001", out custNo);
                rqBodyDic.TryGetValue("4300", out acctNo);
                rqBodyDic.TryGetValue("4669", out status);
                rqBodyDic.TryGetValue("4119", out startDate);
                rqBodyDic.TryGetValue("4120", out endDate);
                #endregion 1.分析報文

                #region 2.撈取資訊
                DataSet dsIBTxnRecLotNo = DBLog.SelIBTxnRecLotNo(txID, custNo, acctNo, status, startDate, endDate);
                List<Dictionary<string, string>> dicListIBTxnRecLotNo = batch.DatasetToDiclist(dsIBTxnRecLotNo);
                #endregion 2.撈取資訊

                #region 3.撈取明細資訊並且產生FileContentList落檔上傳FTP
                List<string> fileContentLst = new List<string>();
                fileContentLst = GetFileContentList_2020639(dicListIBTxnRecLotNo);
                //FileContentList落檔 上傳FTP
                uCcontroler.CreateEnqFileToUC(fileContentLst, true);
                #endregion 3.撈取明細資訊並且產生FileContentList落檔上傳FTP

                #region 4.回覆結果
                Dictionary<string, string> totalDic = new Dictionary<string, string>();
                totalDic.Add("2028", "CO1M0000");
                totalDic.Add("zzzx", uCcontroler.enqFileName);//文件名
                totalDic.Add("4305", fileContentLst.Count.ToString());//總筆數
                string rsString = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, totalDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);
                #endregion 4.回覆結果
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2020639_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        private AppXmlExecResult Do_2020638_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);

                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(ucData);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string file = string.Empty, custNo = string.Empty, ipAddress = string.Empty;
                rqBodyDic.TryGetValue("4001", out custNo);
                rqBodyDic.TryGetValue("zzzx", out file);
                rqBodyDic.TryGetValue("4111", out ipAddress);
                #endregion 1.分析報文

                #region 2.根據「zzzx」欄位值抓取城商FTP上檔的文件。將內容解析，SELECT出對應的「IBTxnRec」項目並撈取明細資訊
                String fileCont = String.Empty;
                TransactionOptions options = new TransactionOptions();
                options.IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted;
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, options))
                {
                    try
                    {
                        m_log.Info("DownloadFTP : [{0}]!!", file);

                        string recId = string.Empty, acctNo = string.Empty, txnDate = string.Empty, result = string.Empty, dateMax = string.Empty, 
                                    dateMin = string.Empty, status = string.Empty, ucString = string.Empty, startDate = string.Empty, endDate = string.Empty,
                                    D_recId = string.Empty, D_custNo = string.Empty, D_acctNo = string.Empty, D_txnDate = string.Empty,
                                    D_cashFlag = string.Empty, D_dbtAmt = string.Empty, D_cdtAmt = string.Empty, D_balance = string.Empty,
                                    D_remark = string.Empty, D_txnId = string.Empty, D_createDate = string.Empty;
                        int matchCnt = 0, notMatchCnt = 0;
                        String[] fileContArr = new String[] { };
                        String[] lineCont = new String[] { };
                        List<string> acct = new List<string>();
                        List<string> datelist = new List<string>();
                        List<string> resultlist = new List<string>();

                        string savePath = Environment.ExpandEnvironmentVariables(ProjectConfig.GetInstance().DropFilesPath) + file;
                        fileCont = com.DownloadFTP(file);
                        com.CreateEnqFile(savePath, fileCont);
                        fileContArr = fileCont.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

                        #region 2-1.INSERT至「IBTxnRecLotNo」並SELECT取LotNo欄位值
                        foreach (var f in fileContArr)
                        {
                            lineCont = f.Split('|');
                            recId = lineCont[0];
                            acctNo = lineCont[1];
                            txnDate = lineCont[3];
                            result = lineCont[9];

                            acct.Add(acctNo);
                            datelist.Add(txnDate);

                            //判斷對帳結果的「1」有幾筆
                            if (result == "1")
                                matchCnt += 1;
                            //判斷對帳結果的「2」有幾筆
                            if (result == "2")
                                notMatchCnt += 1;
                        }

                        //欄位設定
                        if (acct.Count() > 1)//若帳號兩組以上，以「;」隔開
                        {
                            HashSet<string> accths = new HashSet<string>(acct);
                            acctNo = string.Join(";", accths.ToArray());
                        }
                        //取最前最後日期
                        datelist.Sort();
                        dateMin = datelist[0].ToString();
                        dateMax = datelist[datelist.ToArray().Length - 1].ToString();
                        //整筆城商電文存入
                        ucString = requestXml.InnerXml;

                        int InsIBTxnRecLotNo_Result = DBLog.InsIBTxnRecLotNo(custNo, acctNo, dateMin, dateMax,
                                                                                                            matchCnt, notMatchCnt, ipAddress, ucString);
                        #region 新增資料失敗
                        if (InsIBTxnRecLotNo_Result == 0)
                        {
                            Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string,string>();
                            rs_fail_otherBodyDic.Add("2028", "CO1MD999");
                            rs_fail_otherBodyDic.Add("2038", "对帐失败");
                            string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                            m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                            XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                            return base.BuildExecResult(context, rs);
                        }
                        #endregion 新增資料失敗

                        DataSet dsIBTxnRecLotNo = DBLog.SelIBTxnRecLotNo(txID, custNo, acctNo, status, dateMin, dateMax);
                        List<Dictionary<string, string>> dicListIBTxnRecLotNo = batch.DatasetToDiclist(dsIBTxnRecLotNo);
                        #region 撈取資訊失敗
                        if (dicListIBTxnRecLotNo.Count() == 0)
                        {
                            Dictionary<string, string> rs_fail_otherBodyDic = ErrorMsg(txID, dicListIBTxnRecLotNo);

                            string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                            m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                            XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                            return base.BuildExecResult(context, rs);
                        }
                        #endregion 撈取資訊失敗

                        string D_lotNo = string.Empty;
                        foreach (Dictionary<string, string> dicIBTxnRecLotNo in dicListIBTxnRecLotNo)
                        {
                            dicIBTxnRecLotNo.TryGetValue("LotNo", out D_lotNo);
                        }
                        #endregion 2-1.INSERT至「IBTxnRecLotNo」並SELECT取LotNo欄位值

                        #region 2-2.SELECT出對應的「IBTxnRec」, INSERT至「IBTxnRecChk」, DELETE 「IBTxnRec」
                        foreach (var f in fileContArr)
                        {
                            lineCont = f.Split('|');
                            recId = lineCont[0];
                            acctNo = lineCont[1];
                            result = lineCont[9];

                            #region SELECT出對應的「IBTxnRec」
                            DataSet dsIBTxnRec = DBLog.SelIBTxnRec(txID, custNo, acctNo, startDate, endDate, recId);
                            List<Dictionary<string, string>> dicListIBTxnRec = batch.DatasetToDiclist(dsIBTxnRec);
                            #region 撈取資訊失敗
                            if (dicListIBTxnRec.Count() == 0)
                            {
                                Dictionary<string, string> rs_fail_otherBodyDic = ErrorMsg(txID, dicListIBTxnRec);

                                string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                                return base.BuildExecResult(context, rs);
                            }
                            #endregion 撈取資訊失敗
                            #endregion SELECT出對應的「IBTxnRec」

                            foreach (Dictionary<string, string> dicIBTxnRec in dicListIBTxnRec)
                            {
                                dicIBTxnRec.TryGetValue("RecId", out D_recId); dicIBTxnRec.TryGetValue("CustNo", out D_custNo);
                                dicIBTxnRec.TryGetValue("AcctNo", out D_acctNo); dicIBTxnRec.TryGetValue("TxnDate", out D_txnDate);
                                dicIBTxnRec.TryGetValue("CashFlag", out D_cashFlag); dicIBTxnRec.TryGetValue("DbtAmt", out D_dbtAmt);
                                dicIBTxnRec.TryGetValue("CdtAmt", out D_cdtAmt); dicIBTxnRec.TryGetValue("Balance", out D_balance);
                                dicIBTxnRec.TryGetValue("Remark", out D_remark); dicIBTxnRec.TryGetValue("TxnId", out D_txnId);
                                dicIBTxnRec.TryGetValue("CreateDate", out D_createDate);

                                #region INSERT至「IBTxnRecChk」
                                int InsIBTxnRecChk_Result = DBLog.InsIBTxnRecChk(D_recId, D_custNo, D_acctNo, D_txnDate, D_cashFlag, D_dbtAmt, D_cdtAmt,
                                                                                                                    D_balance, D_remark, D_txnId, D_createDate, D_lotNo, result);
                                #region 新增資料失敗
                                if (InsIBTxnRecChk_Result == 0)
                                {
                                    Dictionary<string, string> rs_fail_otherBodyDic = ErrorMsg(txID, dicListIBTxnRecLotNo);

                                    string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                                    m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                                    XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                                    return base.BuildExecResult(context, rs);
                                }
                                #endregion 新增資料失敗
                                #endregion INSERT至「IBTxnRecChk」

                                #region DELETE 「IBTxnRec」
                                int DelIBTxnRec_Result = DBLog.DelIBTxnRec(D_recId, D_acctNo);
                                #region 刪除資料失敗
                                if (DelIBTxnRec_Result == 0)
                                {
                                    Dictionary<string, string> rs_fail_otherBodyDic = ErrorMsg(txID, dicListIBTxnRec);

                                    string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                                    m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                                    XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                                    return base.BuildExecResult(context, rs);
                                }
                                #endregion 刪除資料失敗
                                #endregion DELETE 「IBTxnRec」
                            }
                        }
                        #endregion 2-2.SELECT出對應的「IBTxnRec」, INSERT至「IBTxnRecChk」, DELETE 「IBTxnRec」

                        scope.Complete();
                    }
                    catch (WebException ex)
                    {
                        m_log.ErrorException(string.Format("Do_2020638_Process DownloadFTPError TxID=[{0}] ", txID) + ex.ToString(), ex);

                        #region FTP取檔失敗
                        if (fileCont.Count() == 0)
                        {
                            Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
                            rs_fail_otherBodyDic.Add("2028", "CO1MD999");
                            rs_fail_otherBodyDic.Add("2038", "对帐失败");
                            string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                            m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                            XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                            return base.BuildExecResult(context, rs);
                        }
                        #endregion FTP取檔失敗
                    }
                    catch (Exception ex)
                    {
                        m_log.ErrorException(string.Format("Do_2020638_Process TransactionError TxID=[{0}] ", txID) + ex.ToString(), ex);
                    }
                }
                #endregion 2.根據「zzzx」欄位值抓取城商FTP上檔的文件。將內容解析，SELECT出對應的「IBTxnRec」項目並撈取明細資訊

                #region 3.回覆結果
                Dictionary<string, string> totalDic = new Dictionary<string, string>();
                totalDic.Add("2028", "CO1M0000");
                string rsString = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, totalDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rss = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rss);
                #endregion 3.回覆結果
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2020638_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
            throw new NotImplementedException();
        }

        private AppXmlExecResult Do_2020637_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);

                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(ucData);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string custNo = string.Empty, acctNo = string.Empty, startDate = string.Empty, endDate = string.Empty, recId = string.Empty,
                            reAcctNo = string.Empty;
                rqBodyDic.TryGetValue("4001", out custNo);
                rqBodyDic.TryGetValue("4619", out acctNo);
                rqBodyDic.TryGetValue("4119", out startDate);
                rqBodyDic.TryGetValue("4120", out endDate);

                rqBodyDic.TryGetValue("4300", out reAcctNo);

                //拆分多筆帳戶
                if (acctNo != null && acctNo.Length > 15)
                {
                    string acctNore = acctNo.Replace(";", ",");
                    acctNo = acctNore.Substring(0, acctNore.Length - 1);
                }
                #endregion 1.分析報文

                #region 2.撈取資訊並且產生FileContentList落檔上傳FTP
                List<string> fileContentLst = new List<string>();
                string lotNo = string.Empty;

                if (acctNo == null)//帳戶餘額對帳
                {
                    DataSet dsIBTxnRec = DBLog.SelIBTxnRec(txID, custNo, reAcctNo, startDate, endDate, recId);
                    List<Dictionary<string, string>> dicListIBTxnRec = batch.DatasetToDiclist(dsIBTxnRec);

                    DataSet dsIBTxnRecChk = DBLog.SelIBTxnRecChk(txID, custNo, reAcctNo, startDate, endDate, lotNo);
                    List<Dictionary<string, string>> dicListIBTxnRecChk = batch.DatasetToDiclist(dsIBTxnRecChk);

                    if (dicListIBTxnRec.Count() > 0 || dicListIBTxnRecChk.Count() > 0)
                        fileContentLst = GetFileContentList_2020637_All(dicListIBTxnRec, dicListIBTxnRecChk);

                    //FileContentList落檔 上傳FTP
                    uCcontroler.CreateEnqFileToUC(fileContentLst, true);
                }
                else //交易明細對帳
                {
                    DataSet dsIBTxnRec = DBLog.SelIBTxnRec(txID, custNo, acctNo, startDate, endDate, recId);
                    List<Dictionary<string, string>> dicListIBTxnRec = batch.DatasetToDiclist(dsIBTxnRec);

                    fileContentLst = GetFileContentList_2020637(dicListIBTxnRec);
                    //FileContentList落檔 上傳FTP
                    uCcontroler.CreateEnqFileToUC(fileContentLst, true);
                }

                #endregion 2.撈取資訊並且產生FileContentList落檔上傳FTP

                #region 3.回覆結果
                Dictionary<string, string> totalDic = new Dictionary<string, string>();
                totalDic.Add("2028", "CO1M0000");
                totalDic.Add("zzzx", uCcontroler.enqFileName);//文件名
                totalDic.Add("4305", fileContentLst.Count.ToString());//總筆數
                string rsString = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, totalDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);
                #endregion 3.回覆結果
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2020637_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        private AppXmlExecResult Do_2020642_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);

                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(ucData);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string custNo = string.Empty, acctNo = string.Empty, year = string.Empty, volumn = string.Empty,
                          hasAdj = string.Empty, result = string.Empty, status = string.Empty;
                rqBodyDic.TryGetValue("4001", out custNo);
                rqBodyDic.TryGetValue("4300", out acctNo);
                rqBodyDic.TryGetValue("4664", out year);
                rqBodyDic.TryGetValue("4072", out volumn);
                #endregion 1.分析報文

                #region 2.撈取資訊
                DataSet dsIBBalRecChk = DBLog.SelIBBalRecChk(txID, custNo, acctNo, status, result, year, volumn);
                List<Dictionary<string, string>> dicListIBBalRecChk = batch.DatasetToDiclist(dsIBBalRecChk);
                #endregion 2.撈取資訊

                #region 3.撈取明細資訊並且產生FileContentList落檔上傳FTP
                string acctTitle = string.Empty, acctCompNm = string.Empty, acctComp = string.Empty, startDate = string.Empty,
                          endDate = string.Empty, openBal = string.Empty, endBal = string.Empty, companyBal = string.Empty, remark = string.Empty,
                          adjId = string.Empty;
                foreach (Dictionary<string, string> dicIBBalRecChk in dicListIBBalRecChk)
                {
                    dicIBBalRecChk.TryGetValue("AcctNo", out acctNo); dicIBBalRecChk.TryGetValue("AcctTitle", out acctTitle);
                    dicIBBalRecChk.TryGetValue("CustNo", out custNo); dicIBBalRecChk.TryGetValue("AcctCompNm", out acctCompNm);
                    dicIBBalRecChk.TryGetValue("AcctComp", out acctComp); dicIBBalRecChk.TryGetValue("Year", out year);
                    dicIBBalRecChk.TryGetValue("Volumn", out volumn); dicIBBalRecChk.TryGetValue("StartDate", out startDate);
                    dicIBBalRecChk.TryGetValue("EndDate", out endDate); dicIBBalRecChk.TryGetValue("OpenBal", out openBal);
                    dicIBBalRecChk.TryGetValue("EndBal", out endBal); dicIBBalRecChk.TryGetValue("CompanyBal", out companyBal);
                    dicIBBalRecChk.TryGetValue("Status", out status); dicIBBalRecChk.TryGetValue("Result", out result);
                    dicIBBalRecChk.TryGetValue("Remark", out remark); dicIBBalRecChk.TryGetValue("HasAdj", out hasAdj);
                    dicIBBalRecChk.TryGetValue("AdjId", out adjId);
                }

                if (string.IsNullOrEmpty(status))
                {
                    status = "0";
                }
                //抓出調節數據落檔，傳至FTP
                List<string> fileContentLst = new List<string>();
                fileContentLst = GetFileContentList_2020642(dicListIBBalRecChk, adjId);
                //FileContentList落檔 上傳FTP
                uCcontroler.CreateEnqFileToUC(fileContentLst, true);
                #endregion 3.撈取明細資訊並且產生FileContentList落檔上傳FTP
                
                #region 4.回覆結果
                Dictionary<string, string> totalDic = new Dictionary<string, string>();
                totalDic.Add("2028", "CO1M0000");
                totalDic.Add("zzzx", uCcontroler.enqFileName);//文件名
                totalDic.Add("4305", fileContentLst.Count.ToString());//總筆數
                totalDic.Add("4300", acctNo);//帳號
                totalDic.Add("4900", acctTitle);//帳戶名稱
                totalDic.Add("4001", custNo);//客戶號
                totalDic.Add("4813", acctCompNm);//開戶行名稱
                totalDic.Add("4812", acctComp);//開戶行行號
                totalDic.Add("4664", year);//年份
                totalDic.Add("4072", volumn);//期數
                totalDic.Add("4119", startDate);//期始日期
                totalDic.Add("4120", endDate);//期末日期
                totalDic.Add("4666", openBal);//期始餘額
                totalDic.Add("4667", endBal);//期末餘額
                totalDic.Add("4679", companyBal);//企業餘額
                totalDic.Add("4668", status);//對帳狀態
                totalDic.Add("4669", result);//對帳結果
                totalDic.Add("4355", remark);//備註
                string rsString = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, totalDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);
                #endregion 4.回覆結果
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2020642_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        private AppXmlExecResult Do_2020607_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
            String fileCont = String.Empty;

            XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
            string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
            m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);
            UcControler uCcontroler = new UcControler();
            UcBody ucBody = new UcBody();
            Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(ucData);
            Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

            try
            {
                #region 1.分析報文
                string custNo = string.Empty, acctNo = string.Empty, year = string.Empty, volumn = string.Empty,
                          hasAdj = string.Empty, file = string.Empty, result = string.Empty, companyBal = string.Empty, iPAddress = string.Empty,
                          remark = string.Empty;
                rqBodyDic.TryGetValue("4001", out custNo);
                rqBodyDic.TryGetValue("4300", out acctNo);
                rqBodyDic.TryGetValue("4664", out year);
                rqBodyDic.TryGetValue("4072", out volumn);
                rqBodyDic.TryGetValue("4665", out hasAdj);
                rqBodyDic.TryGetValue("zzzx", out file);

                rqBodyDic.TryGetValue("4679", out companyBal);
                rqBodyDic.TryGetValue("4111", out iPAddress);
                rqBodyDic.TryGetValue("4668", out result);
                rqBodyDic.TryGetValue("4355", out remark);
                #endregion 1.分析報文
            
                #region 2.撈取資訊
                string status = string.Empty, balRecPKey = string.Empty;
                DataSet dsIBBalRecChk = DBLog.SelIBBalRecChk(txID, custNo, acctNo, status, result, year, volumn);
                List<Dictionary<string, string>> dicListIBBalRecChk = batch.DatasetToDiclist(dsIBBalRecChk);
                #region 撈取資訊失敗
                if (dicListIBBalRecChk.Count() == 0)
                {
                    Dictionary<string, string> rss_fail_otherBodyDic = ErrorMsg(txID, dicListIBBalRecChk);

                    string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rss_fail_otherBodyDic);

                    m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                    XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                    return base.BuildExecResult(context, rs);
                }
                #endregion 撈取資訊失敗

                foreach (Dictionary<string, string> dicIBBalRecChk in dicListIBBalRecChk)
                {
                    dicIBBalRecChk.TryGetValue("BalRecPKey", out balRecPKey);
                }
                #endregion 2.撈取資訊

                #region 3.將「zzzx」欄位值相同的文件內容解析並更新新增明細資訊
                TransactionOptions options = new TransactionOptions();
                options.IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted;

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, options))
                {
                    try
                    {
                        m_log.Info("DownloadFTPfile : [{0}]!!", file);

                        string comRecDbtDate = string.Empty, comRecDbtAmt = string.Empty, comRecCdtDate = string.Empty,
                                    comRecCdtAmt = string.Empty, bnkRecDbtDate = string.Empty, bnkRecDbtAmt = string.Empty,
                                    bnkRecCdtDate = string.Empty, bnkRecCdtAmt = string.Empty;
                        String[] fileContArr = new String[] { };
                        String[] lineCont = new String[] { };

                        string ucString = requestXml.InnerXml;
                        string savePath = Environment.ExpandEnvironmentVariables(ProjectConfig.GetInstance().DropFilesPath) + file;
                        fileCont = com.DownloadFTP(file);
                        com.CreateEnqFile(savePath, fileCont);
                        fileContArr = fileCont.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (var f in fileContArr)
                        {
                            lineCont = f.Split('|');
                            comRecDbtDate = lineCont[0];
                            comRecDbtAmt = lineCont[1];
                            comRecCdtDate = lineCont[2];
                            comRecCdtAmt = lineCont[3];
                            bnkRecDbtDate = lineCont[4];
                            bnkRecDbtAmt = lineCont[5];
                            bnkRecCdtDate = lineCont[6];
                            bnkRecCdtAmt = lineCont[7];

                            if (comRecDbtAmt == "") { comRecDbtAmt = "0.00"; }
                            if (comRecCdtAmt == "") { comRecCdtAmt = "0.00"; }
                            if (bnkRecDbtAmt == "") { bnkRecDbtAmt = "0.00"; }
                            if (bnkRecCdtAmt == "") { bnkRecCdtAmt = "0.00"; }


                            #region  3-1.當檔案不為空檔時更新IBBalRecChk與新增IBBalRecAdj
                            if (hasAdj == "1")
                            {
                                rs_fail_otherBodyDic.Add("2028", "CO1MF999");
                                rs_fail_otherBodyDic.Add("2038", "对帐失败");
                                string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                                return base.BuildExecResult(context, rs);
                            }

                            else if (hasAdj == "2")
                            {
                                int UpdIBBalRecChk_Result = DBLog.UpdIBBalRecChk(acctNo, companyBal, iPAddress, result, remark, hasAdj, ucString, year, volumn);

                                int InsIBBalRecAdj_Result = DBLog.InsIBBalRecAdj(balRecPKey, comRecDbtDate, comRecDbtAmt, comRecCdtDate,
                                                                                                                    comRecCdtAmt, bnkRecDbtDate, bnkRecDbtAmt, bnkRecCdtDate,
                                                                                                                    bnkRecCdtAmt);
                                #region 更新資料或新增資料失敗
                                if (UpdIBBalRecChk_Result == 0 || InsIBBalRecAdj_Result == 0)
                                {
                                    rs_fail_otherBodyDic = ErrorMsg(txID, dicListIBBalRecChk);

                                    string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                                    m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                                    XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                                    return base.BuildExecResult(context, rs);
                                }
                                #endregion 更新資料或新增資料失敗
                            }
                            #endregion 3-1.當檔案不為空檔時更新IBBalRecChk與新增IBBalRecAdj
                        }
                        #region 3-2.檔案為空檔時更新IBBalRecChk
                        if (fileCont.Count() == 0)
                        {
                            if (hasAdj == "1")
                            {
                                int UpdIBBalRecChk_Result = DBLog.UpdIBBalRecChk(acctNo, companyBal, iPAddress, result, remark, hasAdj, ucString, year, volumn);
                                #region 更新資料失敗
                                if (UpdIBBalRecChk_Result == 0)
                                {
                                    rs_fail_otherBodyDic = ErrorMsg(txID, dicListIBBalRecChk);

                                    string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                                    m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                                    XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                                    return base.BuildExecResult(context, rs);
                                }
                                #endregion 更新資料失敗
                            }
                            else if (hasAdj == "2")
                            {
                                rs_fail_otherBodyDic.Add("2028", "CO1MF999");
                                rs_fail_otherBodyDic.Add("2038", "对帐失败");
                                string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                                return base.BuildExecResult(context, rs);
                            }
                        }
                        #endregion 3-2.當檔案為空檔時更新IBBalRecChk

                        scope.Complete();
                    }
                    catch (WebException ex)
                    {
                        m_log.ErrorException(string.Format("Do_2020607_Process DownloadFTPError TxID=[{0}] ", txID) + ex.ToString(), ex);

                        #region FTP取檔失敗
                        if (fileCont.Count() == 0)
                        {
                            rs_fail_otherBodyDic.Add("2028", "CO1MD999");
                            rs_fail_otherBodyDic.Add("2038", "对帐失败");
                            string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                            m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                            XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                            return base.BuildExecResult(context, rs);
                        }
                        #endregion FTP取檔失敗
                    }                    
                    catch (Exception ex)
                    {
                        m_log.ErrorException(string.Format("Do_2020607_Process TransactionError TxID=[{0}] ", txID) + ex.ToString(), ex);
                    }
                }
                #endregion 3.將「zzzx」欄位值相同的文件內容解析並更新新增明細資訊

                #region 4.回覆結果
                Dictionary<string, string> expendDic = new Dictionary<string, string>();
                    expendDic.Add("2028", "CO1M0000");
                    string rs_succ_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, expendDic);

                    m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_String);
                    XmlDocument rss = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_String);
                    return base.BuildExecResult(context, rss);
                #endregion 4.回覆結果
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2020607_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        private AppXmlExecResult Do_2020605_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);

                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(ucData);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string custNo = string.Empty, acctNo = string.Empty,
                           acctTitle = string.Empty, acctComp = string.Empty,
                           acctCompNm = string.Empty, status = string.Empty,
                           contractNo = string.Empty, statusChgDate = string.Empty;
                rqBodyDic.TryGetValue("4001", out custNo);
                rqBodyDic.TryGetValue("4300", out acctNo);
                #endregion 1.分析報文

                #region 2.撈取資訊
                DataSet dsAcctRec = DBLog.SelAccRec(custNo, acctNo);
                List<Dictionary<string, string>> dicListAcctRec = batch.DatasetToDiclist(dsAcctRec);
                #endregion 2.撈取資訊

                #region 3.撈取明細資訊
                string D_custNo = string.Empty, D_acctNo = string.Empty,
                           D_acctTitle = string.Empty, D_acctComp = string.Empty,
                           D_acctCompNm = string.Empty, D_status = string.Empty,
                           D_contractNo = string.Empty, D_statusChgDate = string.Empty;
                DateTime statusChgDate_d;

                foreach (Dictionary<string, string> dicAcctRec in dicListAcctRec)
                {
                    dicAcctRec.TryGetValue("CustNo", out D_custNo); dicAcctRec.TryGetValue("AcctNo", out D_acctNo);
                    dicAcctRec.TryGetValue("AcctTitle", out D_acctTitle); dicAcctRec.TryGetValue("AcctComp", out D_acctComp);
                    dicAcctRec.TryGetValue("AcctCompNm", out D_acctCompNm); dicAcctRec.TryGetValue("Status", out D_status);
                    dicAcctRec.TryGetValue("ContractNo", out D_contractNo); dicAcctRec.TryGetValue("StatusChgDate", out D_statusChgDate);
                }

                #region 3-1.資料庫沒有資料往T24撈資料
                string ipAddress = string.Empty, Date = string.Empty;
                if (string.IsNullOrEmpty(D_custNo) || string.IsNullOrEmpty(D_acctNo))
                {
                    return DoACIProcess(context, uCcontroler, xmlHelper, requestXml, rqHeadDic, rqBodyDic, txID, Date, custNo, acctNo, contractNo, status, ipAddress);
                }
                #endregion 3-1.資料庫沒有資料往T24撈資料

                //欄位條件設定
                custNo = D_custNo;
                acctNo = D_acctNo;
                acctTitle = D_acctTitle;
                acctComp = D_acctComp;
                acctCompNm = D_acctCompNm;
                contractNo = D_contractNo;
                if (string.IsNullOrEmpty(D_status))
                {
                    status = "1";
                }
                else
                {
                    status = D_status;
                }

                if (D_status == "0")
                {
                    if (DateTime.TryParse(D_statusChgDate, out statusChgDate_d))
                    {
                        statusChgDate = statusChgDate_d.ToString("yyyyMMdd");
                    }
                    else
                    {
                        statusChgDate = string.Empty;
                    }
                }
                #endregion 3.撈取明細資訊

                #region 4.回覆結果
                Dictionary<string, string> expendDic = Get_2020605_Expend(custNo, acctNo, acctTitle, acctCompNm, acctComp, status, contractNo,
                                                                                                                statusChgDate, allowSign, allowCancel);
                string rs_succ_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, expendDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_String);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_String);
                return base.BuildExecResult(context, rs);
                #endregion 4.回覆結果

            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2020605_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        private AppXmlExecResult Do_2020529_2020606_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {

            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);
                
                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(ucData);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string Date = string.Empty, custNo = string.Empty, acctNo = string.Empty, ipAddress = string.Empty, status = string.Empty;
                rqBodyDic.TryGetValue("2006", out Date);
                rqBodyDic.TryGetValue("4001", out custNo);
                rqBodyDic.TryGetValue("4300", out acctNo);
                if (txID == "2020529")
                {
                    rqBodyDic.TryGetValue("4178", out status);
                }
                else //2020606
                {
                    rqBodyDic.TryGetValue("4038", out status);
                    rqBodyDic.TryGetValue("4111", out ipAddress);
                }
                #endregion 1.分析報文

                #region 2.撈取資訊
                DataSet dsAcctRec = DBLog.SelAccRec(custNo, acctNo);
                List<Dictionary<string, string>> dicListAcctRec = batch.DatasetToDiclist(dsAcctRec);
                #endregion 2.撈取資訊

                #region 3.撈取明細資訊
                string D_custNo = string.Empty, D_acctNo = string.Empty, D_status = string.Empty;
                foreach (Dictionary<string, string> dicAcctRec in dicListAcctRec)
                {
                    dicAcctRec.TryGetValue("CustNo", out D_custNo);
                    dicAcctRec.TryGetValue("AcctNo", out D_acctNo);
                    dicAcctRec.TryGetValue("Status", out D_status);
                }
                string contractNo = acctNo.ToString() + Date.ToString();

                #region 3-2.請求簽約
                if (status == "1")
                {
                    #region 資料庫沒有資料
                    if (string.IsNullOrEmpty(D_custNo) || string.IsNullOrEmpty(D_acctNo))
                    {
                        //往T24撈資訊
                        return DoACIProcess(context, uCcontroler, xmlHelper, requestXml, rqHeadDic, rqBodyDic, txID, Date, custNo, acctNo, 
                                                            contractNo, status, ipAddress);
                    }
                    #endregion 資料庫沒有資料

                    if (D_status == "0")
                    {
                        status = "3";
                    }
                    else if (D_status == "1" || D_status == "")
                    {
                        int UpdAccRecStatus_Result = DBLog.UpdAccRecStatus(acctNo, D_status, ipAddress, contractNo);
                        if (UpdAccRecStatus_Result == 0)
                        {
                            m_log.Error("UpdAccRecStatusByAcctNo Fail !!! Status=[{0}]", D_status);
                            new SendMail().Send(string.Format("UpdAccRecStatus Fail !!! Status=[{0}] txIX=[{1}]", D_status, txID), ""
                                , string.Format("UpdAccRecStatus Error, PLS Check Status:[{0}] AcctNo:[{1}] RQ:[{2}]"
                                                                 , D_status, acctNo, context.RequestXml.OuterXml));
                        }
                        status = "1";
                    }
                }
                #endregion 3-2.請求簽約

                #region 3-3.請求解約
                if (status == "0")
                {
                    #region 資料庫沒有資料
                    if (string.IsNullOrEmpty(D_custNo) || string.IsNullOrEmpty(D_acctNo))
                    {
                        Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
                        rs_fail_otherBodyDic.Add("2028", "CO1MA999");
                        rs_fail_otherBodyDic.Add("2038", "签约信息不存在");
                        string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                        m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                        XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                        return base.BuildExecResult(context, rs);
                    }
                    #endregion 資料庫沒有資料

                    if (D_status == "0")
                    {
                        int UpdAccRecStatus_Result = DBLog.UpdAccRecStatus(acctNo, D_status, ipAddress, contractNo);
                        if (UpdAccRecStatus_Result == 0)
                        {
                            m_log.Error("UpdAccRecStatusByAcctNo Fail !!! Status=[{0}]", D_status);
                            new SendMail().Send(string.Format("UpdAccRecStatus Fail !!! Status=[{0}] txIX=[{1}]", D_status, txID), ""
                                , string.Format("UpdAccRecStatus Error, PLS Check Status:[{0}] AcctNo:[{1}] RQ:[{2}]"
                                                                 , D_status, acctNo, context.RequestXml.OuterXml));
                        }
                        status = "0";
                    }
                    else if (D_status == "1" || D_status == "")
                    {
                        status = "2";
                    }
                }
                #endregion 3-3.請求解約
                #endregion 3.撈取明細資訊

                #region 4.回覆結果
                Dictionary<string, string> rs_succ_otherBodyDic = Get_2020529_2020606_Expend(txID, acctNo, status);
                string rs_succ_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_String);
                XmlDocument rss = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_String);
                return base.BuildExecResult(context, rss);
                #endregion 4.回覆結果

            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2020529_2020606_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        private AppXmlExecResult Do_2020530_2020641_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);

                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(ucData);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string Date = string.Empty, custNo = string.Empty, year = string.Empty, acctNo = string.Empty, status = string.Empty,
                           result = string.Empty, volumn = string.Empty;
                rqBodyDic.TryGetValue("4001", out custNo);
                rqBodyDic.TryGetValue("4664", out year);
                rqBodyDic.TryGetValue("4668", out status);
                rqBodyDic.TryGetValue("4669", out result);
                if (txID == "2020530")
                {
                    rqBodyDic.TryGetValue("4300", out acctNo);
                }
                else //2020641
                {
                    rqBodyDic.TryGetValue("4619", out acctNo);
                }
                //多筆帳戶
                if (acctNo != null && acctNo.Length > 15)
                {
                    string acctNore = acctNo.Replace(";", ",");
                    acctNo = acctNore.Substring(0, acctNore.Length - 1);
                }
                #endregion 1.分析報文

                #region 2.撈取資訊
                DataSet dsIBBalRecChk = DBLog.SelIBBalRecChk(txID, custNo, acctNo, status, result, year, volumn);
                List<Dictionary<string, string>> dicListIBBalRecChk = batch.DatasetToDiclist(dsIBBalRecChk);
                #endregion 2.撈取資訊

                #region 3.撈取明細資訊並且產生FileContentList落檔上傳FTP
                string D_custNo = string.Empty, D_year = string.Empty, custName = string.Empty, custCompNm = string.Empty, custComp = string.Empty;
                foreach (Dictionary<string, string> dicIBBalRecChk in dicListIBBalRecChk)
                {
                    dicIBBalRecChk.TryGetValue("CustNo", out D_custNo); dicIBBalRecChk.TryGetValue("Year", out D_year);
                    dicIBBalRecChk.TryGetValue("CustName", out custName); dicIBBalRecChk.TryGetValue("CustCompNm", out custCompNm);
                    dicIBBalRecChk.TryGetValue("CustComp", out custComp);
                }

                List<string> fileContentLst = new List<string>();
                fileContentLst = GetFileContentList_2020530_2020641(dicListIBBalRecChk, txID);
                uCcontroler.CreateEnqFileToUC(fileContentLst, true);
                #endregion 3.撈取明細資訊並且產生FileContentList落檔上傳FTP

                #region 4.回覆結果
                Dictionary<string, string> totalDic = new Dictionary<string, string>();
                totalDic.Add("2028", "CO1M0000");
                totalDic.Add("zzzx", uCcontroler.enqFileName);//文件名
                totalDic.Add("4305", fileContentLst.Count.ToString());//總筆數
                totalDic.Add("4001", D_custNo);//客戶號
                totalDic.Add("4664", D_year);//年份
                if (txID == "2020641")
                {
                    totalDic.Add("4339", custName);//客戶名稱
                    totalDic.Add("4813", custCompNm);//開戶行名稱
                    totalDic.Add("4812", custComp);//開戶行行號
                }
                string rsString = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, totalDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);
                #endregion 4.回覆結果
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2020530_2020641_Process Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
            throw new NotImplementedException();
        }

        private AppXmlExecResult DoACIProcess(EaiContext context, UcControler uCcontroler, XmlHelper xmlHelper, XmlDocument requestXml,
                                                                          Dictionary<string, string> rqHeadDic, Dictionary<string, string> rqBodyDic, string txID,
                                                                          string Date, string custNo, string acctNo, string contractNo, string status, string ipAddress)
        {
            //往t24發ACC.CUST.INFO.ENQ查資料
            string bodyFT = GetT24_ACIENQ_Content(acctNo);
            AppXmlExecResult t24Enq_result = SendMsgToEAIProcess(context, bodyFT, "ACC.CUST.INFO.ENQ");
            XmlHelper xmlHelperT24Enq = XmlHelper.GetInstance(t24Enq_result.ResponseXml);
            string proc_ret = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//RSP_PROC_RET");
            string ucwebcustId = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//UCWebCustId");
            string acct_no = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//ACCOUNT_NO");
            string ucwebacctNm = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//UCWebAcctNm");
            string ucwebacctCom = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//UCWebAcctCom");
            string ucwebacctComCn = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//UCWebAcctComCN");

            string custName = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//UCWebCustNm");
            string custComp = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//CUSTOMER_OP_COMP");
            string custCompNm = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//CUSTOMER_OP_COMP_NAME");
            string acctType = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//UCWebAcctType");

            //欄位條件設定
            string acctTitle = ucwebacctNm;
            string acctComp = ucwebacctCom;
            string acctCompNm = ucwebacctComCn;
            string contractNO = contractNo;
            string statusChgDate = string.Empty;
            custNo = ucwebcustId;
            acctNo = acct_no;

            #region 查無資料
            if (ucwebcustId == "" || proc_ret != "SUCC" || acct_no == "")
            {
                Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
                rs_fail_otherBodyDic.Add("2028", "CO1MA999");
                rs_fail_otherBodyDic.Add("2038", "查无账户");
                string rs_fail_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_fail_String);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_String);
                return base.BuildExecResult(context, rs);
            }
            #endregion 查無資料

            #region 請求簽約
            if (status == "1")
            {
                if (acctType == "2")
                { 
                    acctType = "01";
                }
                else if (acctType == "3")
                {
                    acctType = "02";
                }            

                //新增資料到資料表
                int tbAccRec_Result = DBLog.InsAccRec(custNo, custName, custComp, custCompNm, acctNo, acctTitle, acctType, acctComp,
                                                                                    acctCompNm, contractNO, ipAddress);
                if (tbAccRec_Result == 0)//若無法寫入DB
                {
                    #region SendErrorMail
                    new SendMail().Send(string.Format("{0} InsertAccRecData Error", txID), "", string.Format("{0} InsertAccRecData Error, PLS Check RQ:[{1}]", txID, context.RequestXml.OuterXml));
                    #endregion SendErrorMail
                    m_log.Error("InsertAccRecData Fail !!! CustNo=[{0}] AcctNo=[{1}]", custNo, acctNo);

                    #region 新增失敗 回覆失敗報文
                    Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
                    rs_fail_otherBodyDic.Add("2028", "CO1MD005");
                    rs_fail_otherBodyDic.Add("2038", "INSERT失败");
                    string rs_fail_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);

                    XmlDocument rs_fail = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_string);
                    return base.BuildExecResult(context, rs_fail);
                    #endregion 新增失敗 回覆失敗報文
                }

                Dictionary<string, string> expendDic_529_606 = Get_2020529_2020606_Expend(txID, acctNo, "1");
                string rs_succ_529_606_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, expendDic_529_606);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_529_606_String);
                XmlDocument rss = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_529_606_String);
                return base.BuildExecResult(context, rss);
            }
            #endregion 請求簽約

            Dictionary<string, string> expendDic = Get_2020605_Expend(custNo, acctNo, acctTitle, acctCompNm, acctComp, "1", contractNo,
                                                                                                            statusChgDate, allowSign, allowCancel);
            string rs_succ_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, expendDic);

            m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_String);
            XmlDocument rsss = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_String);
            return base.BuildExecResult(context, rsss);
        }

        private Dictionary<string, string> Get_2020605_Expend(string custNo, string acctNo, string acctTitle,
                                                                                                string acctCompNm, string acctComp, string status,
                                                                                                string contractNo, string statusChgDate, string allowSign, string allowCancel)
        {
            Dictionary<string, string> expendDic = new Dictionary<string, string>();

            expendDic.Add("2028", "CO1M0000");
            expendDic.Add("4001", custNo);  //客户号
            expendDic.Add("4300", acctNo);  //账号
            expendDic.Add("4900", acctTitle);  //账户名称
            expendDic.Add("4813", acctCompNm);  //开户行名称
            expendDic.Add("4812", acctComp);  //开户行行号
            expendDic.Add("4178", status);  //签约状态
            expendDic.Add("4111", contractNo);  //签约编号
            expendDic.Add("4120", statusChgDate);  //签约日期
            expendDic.Add("4665", allowSign);  //是否允许签约标志
            expendDic.Add("4668", allowCancel);  //是否允许解约标志

            return expendDic;
        }

        private Dictionary<string, string> Get_2020529_2020606_Expend(string txID, string acctNo, string status)
        {
            Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
            rs_succ_otherBodyDic.Add("2028", "CO1M0000");
            rs_succ_otherBodyDic.Add("4300", acctNo);//账号
            if (txID == "2020529")
            {
                rs_succ_otherBodyDic.Add("4178", status); //签约状态
            }
            else //2020606
            {
                rs_succ_otherBodyDic.Add("4038", status); //签约状态
                //rs_succ_otherBodyDic.Add("4835", "");//說明
            }
            return rs_succ_otherBodyDic;
        }

        private List<string> GetFileContentList_2020530_2020641(List<Dictionary<string, string>> dicListIBBalRecChk, string txID)
        {
            List<string> fileContentLst = new List<string>();
            StringBuilder fileContentSB;
            dicListIBBalRecChk = dicListIBBalRecChk.OrderBy(p => p["AcctNo"]).ThenBy(p => p["Volumn"]).ToList();
            
            foreach (Dictionary<string, string> D in dicListIBBalRecChk)
            {
                fileContentSB = new StringBuilder();
                string tempString = string.Empty, msgkey = string.Empty, status = string.Empty;

                D.TryGetValue("AcctNo", out tempString);
                fileContentSB.Append(tempString).Append("|");//账戶

                if (txID == "2020641")
                {
                    D.TryGetValue("AcctTitle", out tempString);
                    fileContentSB.Append(tempString).Append("|");//账戶名稱

                    D.TryGetValue("AcctType", out tempString);
                    fileContentSB.Append(tempString).Append("|");//账戶性質
                }

                D.TryGetValue("Volumn", out tempString);
                fileContentSB.Append(tempString).Append("|");//期數

                D.TryGetValue("StartDate", out tempString);
                fileContentSB.Append(tempString).Append("|");//起始日期

                D.TryGetValue("EndDate", out tempString);
                fileContentSB.Append(tempString).Append("|");//結束日期

                D.TryGetValue("OpenBal", out tempString);
                fileContentSB.Append(tempString).Append("|");//期始餘額

                D.TryGetValue("EndBal", out tempString);
                fileContentSB.Append(tempString).Append("|");//期末餘額

                D.TryGetValue("CompanyBal", out tempString);
                fileContentSB.Append(tempString).Append("|");//企業餘額

                if (txID == "2020641")
                {
                    D.TryGetValue("Result", out tempString);
                    fileContentSB.Append(tempString).Append("|");//對帳結果
                }

                D.TryGetValue("Status", out status);
                fileContentSB.Append(status).Append("|");//對帳狀態

                if (status == null)
                {
                    status = "0";
                }

                if (txID == "2020530")
                {
                    if (status == "1")//1-已对账
                    {
                        D.TryGetValue("BalRecPKey", out tempString);
                        fileContentSB.Append(tempString).Append("|");//原交易流水號   
                    }
                    D.TryGetValue("Result", out tempString);
                    fileContentSB.Append(tempString).Append("|");//對帳結果
                }
                //若IBBalRecChk查無資料，落檔文件內容為空
                if (D == null)
                {
                    fileContentSB.Append("").Append("");//留空
                }
                fileContentLst.Add(fileContentSB.ToString());
            }
            return fileContentLst;
        }

        private List<string> GetFileContentList_2020642(List<Dictionary<string, string>> dicListIBBalRecChk, string adjId)
        {
            List<string> fileContentLst = new List<string>();
            StringBuilder fileContentSB;
            foreach (Dictionary<string, string> D in dicListIBBalRecChk)
            {
                fileContentSB = new StringBuilder();
                string tempString = string.Empty;

                //若IBBalRecChk查無資料，落檔文件內容為空
                if (D == null || adjId == "")
                {
                    fileContentSB.Append("").Append("");//留空
                }
                else
                {
                    D.TryGetValue("ComRecDbtDate", out tempString);
                    fileContentSB.Append(tempString).Append("|");//銀行已列賬企業未列帳借方日期

                    D.TryGetValue("ComRecDbtAmt", out tempString);
                    fileContentSB.Append(tempString).Append("|");//銀行已列賬企業未列帳借方金額

                    D.TryGetValue("ComRecCdtDate", out tempString);
                    fileContentSB.Append(tempString).Append("|");//銀行已列賬企業未列帳貸方日期

                    D.TryGetValue("ComRecCdtAmt", out tempString);
                    fileContentSB.Append(tempString).Append("|");//銀行已列賬企業未列帳貸方金額

                    D.TryGetValue("BnkRecDbtDate", out tempString);
                    fileContentSB.Append(tempString).Append("|");//企業已列賬銀行未列帳借方日期

                    D.TryGetValue("BnkRecDbtAmt", out tempString);
                    fileContentSB.Append(tempString).Append("|");//企業已列賬銀行未列帳借方金額

                    D.TryGetValue("BnkRecCdtDate", out tempString);
                    fileContentSB.Append(tempString).Append("|");//企業已列賬銀行未列帳貸方日期

                    D.TryGetValue("BnkRecCdtAmt", out tempString);
                    fileContentSB.Append(tempString).Append("|");//企業已列賬銀行未列帳貸方金額
                }

                fileContentLst.Add(fileContentSB.ToString());
            }
            return fileContentLst;
        }

        private List<string> GetFileContentList_2020637(List<Dictionary<string, string>> dicListIBTxnRec)
        {
            List<string> fileContentLst = new List<string>();
            StringBuilder fileContentSB;
            //dicListIBTxnRec = dicListIBTxnRec.OrderBy(p => p["RecId"]).ThenBy(p => p["AcctNo"]).ToList();

            foreach (Dictionary<string, string> D in dicListIBTxnRec)
            {
                fileContentSB = new StringBuilder();
                string tempString = string.Empty;

                D.TryGetValue("RecId", out tempString);
                fileContentSB.Append(tempString).Append("|");//憑證號

                D.TryGetValue("AcctNo", out tempString);
                fileContentSB.Append(tempString).Append("|");//帳號

                D.TryGetValue("AcctType", out tempString);
                fileContentSB.Append(tempString).Append("|");//帳戶性質

                D.TryGetValue("TxnDate", out tempString);
                fileContentSB.Append(tempString).Append("|");//交易日期

                D.TryGetValue("CashFlag", out tempString);
                fileContentSB.Append(tempString).Append("|");//現轉標誌

                D.TryGetValue("DbtAmt", out tempString);
                fileContentSB.Append(tempString).Append("|");//借方發生額

                D.TryGetValue("CdtAmt", out tempString);
                fileContentSB.Append(tempString).Append("|");//貸方發生額

                D.TryGetValue("Balance", out tempString);
                fileContentSB.Append(tempString).Append("|");//餘額

                D.TryGetValue("Remark", out tempString);
                fileContentSB.Append(tempString).Append("|");//摘要

                D.TryGetValue("TxnId", out tempString);
                fileContentSB.Append(tempString).Append("|");//交易流水號

                fileContentLst.Add(fileContentSB.ToString());
            }
            return fileContentLst;
        }

        private List<string> GetFileContentList_2020637_All(List<Dictionary<string, string>> dicListIBTxn, List<Dictionary<string, string>> dicListIBTxnRec)
        {
            List<string> fileContentLst = new List<string>();
            StringBuilder fileContentSB;

            foreach (Dictionary<string, string> D in dicListIBTxn)
            {
                string tempString = string.Empty;
                fileContentSB = new StringBuilder();

                D.TryGetValue("RecId", out tempString);
                fileContentSB.Append(tempString).Append("|");//憑證號

                D.TryGetValue("AcctNo", out tempString);
                fileContentSB.Append(tempString).Append("|");//帳號

                D.TryGetValue("AcctType", out tempString);
                fileContentSB.Append(tempString).Append("|");//帳戶性質

                D.TryGetValue("TxnDate", out tempString);
                fileContentSB.Append(tempString).Append("|");//交易日期

                D.TryGetValue("CashFlag", out tempString);
                fileContentSB.Append(tempString).Append("|");//現轉標誌

                D.TryGetValue("DbtAmt", out tempString);
                fileContentSB.Append(tempString).Append("|");//借方發生額

                D.TryGetValue("CdtAmt", out tempString);
                fileContentSB.Append(tempString).Append("|");//貸方發生額

                D.TryGetValue("Balance", out tempString);
                fileContentSB.Append(tempString).Append("|");//餘額

                D.TryGetValue("Remark", out tempString);
                fileContentSB.Append(tempString).Append("|");//摘要

                D.TryGetValue("TxnId", out tempString);
                fileContentSB.Append(tempString).Append("|");//交易流水號

                fileContentLst.Add(fileContentSB.ToString());
            }
            foreach (Dictionary<string, string> D in dicListIBTxnRec)
            {
                string recid = string.Empty;
                string tempString = string.Empty;
                fileContentSB = new StringBuilder();

                D.TryGetValue("RecId", out recid);
                fileContentSB.Append(recid).Append("|");//憑證號

                D.TryGetValue("AcctNo", out tempString);
                fileContentSB.Append(tempString).Append("|");//帳號

                D.TryGetValue("AcctType", out tempString);
                fileContentSB.Append(tempString).Append("|");//帳戶性質

                D.TryGetValue("TxnDate", out tempString);
                fileContentSB.Append(tempString).Append("|");//交易日期

                D.TryGetValue("CashFlag", out tempString);
                fileContentSB.Append(tempString).Append("|");//現轉標誌

                D.TryGetValue("DbtAmt", out tempString);
                fileContentSB.Append(tempString).Append("|");//借方發生額

                D.TryGetValue("CdtAmt", out tempString);
                fileContentSB.Append(tempString).Append("|");//貸方發生額

                D.TryGetValue("Balance", out tempString);
                fileContentSB.Append(tempString).Append("|");//餘額

                D.TryGetValue("Remark", out tempString);
                fileContentSB.Append(tempString).Append("|");//摘要

                D.TryGetValue("TxnId", out tempString);
                fileContentSB.Append(tempString).Append("|");//交易流水號

                fileContentLst.Add(fileContentSB.ToString());
            }
            fileContentLst = fileContentLst.OrderBy(p => Convert.ToInt32(p.Split('|')[0])).ToList();
            return fileContentLst;
        }

        private List<string> GetFileContentList_2020639(List<Dictionary<string, string>> dicListIBTxnRecLotNo)
        {
            List<string> fileContentLst = new List<string>();
            StringBuilder fileContentSB;
            foreach (Dictionary<string, string> D in dicListIBTxnRecLotNo)
            {
                fileContentSB = new StringBuilder();
                string tempString = string.Empty;

                D.TryGetValue("LotNo", out tempString);
                fileContentSB.Append(tempString).Append("|");//對帳流水號

                D.TryGetValue("LotDate", out tempString);
                tempString = Convert.ToDateTime(tempString).ToString("yyyyMMdd");
                fileContentSB.Append(tempString).Append("|");//對帳操作日期

                D.TryGetValue("StartDate", out tempString);
                fileContentSB.Append(tempString).Append("|");//明細開始日期

                D.TryGetValue("EndDate", out tempString);
                fileContentSB.Append(tempString).Append("|");//明細結束日期

                D.TryGetValue("MatchCnt", out tempString);
                fileContentSB.Append(tempString).Append("|");//對帳相符

                D.TryGetValue("NotMatchCnt", out tempString);
                fileContentSB.Append(tempString).Append("|");//對帳不符

                D.TryGetValue("Remark", out tempString);
                fileContentSB.Append(tempString).Append("|");//備註

                //若IBBalRecChk查無資料，落檔文件內容為空
                if (D == null)
                {
                    fileContentSB.Append("").Append("");//留空
                }
                fileContentLst.Add(fileContentSB.ToString());
            }
            return fileContentLst;
        }

        private List<string> GetFileContentList_2020640(List<Dictionary<string, string>> dicListIBTxnRecChk)
        {
            List<string> fileContentLst = new List<string>();
            StringBuilder fileContentSB;
            foreach (Dictionary<string, string> D in dicListIBTxnRecChk)
            {
                fileContentSB = new StringBuilder();
                string tempString = string.Empty;

                D.TryGetValue("RecId", out tempString);
                fileContentSB.Append(tempString).Append("|");//憑證號

                D.TryGetValue("TxnDate", out tempString);
                fileContentSB.Append(tempString).Append("|");//交易日期

                D.TryGetValue("AcctNo", out tempString);
                fileContentSB.Append(tempString).Append("|");//帳號

                D.TryGetValue("AcctType", out tempString);
                fileContentSB.Append(tempString).Append("|");//帳戶性質

                D.TryGetValue("CashFlag", out tempString);
                fileContentSB.Append(tempString).Append("|");//現轉標誌

                D.TryGetValue("DbtAmt", out tempString);
                fileContentSB.Append(tempString).Append("|");//借方發生額

                D.TryGetValue("CdtAmt", out tempString);
                fileContentSB.Append(tempString).Append("|");//貸方發生額

                D.TryGetValue("Balance", out tempString);
                fileContentSB.Append(tempString).Append("|");//餘額

                D.TryGetValue("Remark", out tempString);
                fileContentSB.Append(tempString).Append("|");//摘要

                D.TryGetValue("Result", out tempString);
                fileContentSB.Append(tempString).Append("|");//對帳結果

                fileContentSB.Append("").Append("|");//備用字段

                //若IBBalRecChk查無資料，落檔文件內容為空
                if (D == null)
                {
                    fileContentSB.Append("").Append("");//留空
                }
                fileContentLst.Add(fileContentSB.ToString());
            }
            return fileContentLst;
        }

        private string GetT24_ACIENQ_Content(string acctNo)
        {
            StringBuilder sb = new StringBuilder();
            #region ACC.CUST.INFO.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ACC.CUST.INFO.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0043");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<FIELD.1 op='EQ'>{0}</FIELD.1>", acctNo);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey)
        {
            string msgContent = base.SendToEAIProcess(body, eAI_MsgKey, "GW", "GW");
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, msgContent);

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(msgContent);
            XmlDocument subRqXml = CopyToNewDocument(rq, "GW", "GW", eAI_MsgKey, Guid.NewGuid().ToString());
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml, true);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }

        private Dictionary<string, string> ErrorMsg(string txID, List<Dictionary<string, string>> sel)
        {
            Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
            if (txID == "2020607")
            {
                if (sel.Count() == 0)//SELECT
                {
                    rs_fail_otherBodyDic.Add("2028", "CO1MA999");
                }
                else//UPDATE或INSERT
                {
                    rs_fail_otherBodyDic.Add("2028", "CO1MD999");
                }
                rs_fail_otherBodyDic.Add("2038", "对帐失败");
            }
            if (txID == "2020638")
            {
                if (sel.Count() == 0)//SELECT
                {
                    rs_fail_otherBodyDic.Add("2028", "CO1MF999");
                    rs_fail_otherBodyDic.Add("2038", "对帐资料不符");
                }
                else//INSERT或DELETE
                {
                    rs_fail_otherBodyDic.Add("2028", "CO1MD999");
                    rs_fail_otherBodyDic.Add("2038", "对帐失败");
                }
            }
            return rs_fail_otherBodyDic;
        }

    }
}
