﻿using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using Bankpro.EAI.Utility;
using System.Data;
using System.Xml.Linq;
using ESunBank.Gateway.BPM.Util;

namespace ESunBank.Gateway.BPM
{
    public class NDA : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("ESUNBank.Gateway.BPM.NDA");
        private const string spN_GW = "GW";
        private const string custId_GW = "GW";
        /// <summary>
        /// timeout standard status code = 6005
        /// </summary>
        /// <param name="context"></param>
        /// <param name="correlationID"></param>
        /// <param name="txID"></param>
        /// <param name="txDef"></param>
        /// <param name="requestXml"></param>
        /// <returns></returns>
        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {            
            switch (txID)
            {
                case "9010766":
                case "9010767":
                case "9020579":
                case "9020580":
                    TxSettings txSettings = txDef.TITA.Settings;
                    string ucPWBaseCol = txSettings.GetString("UCPWBase", "");
                    m_log.Info("DoNDABeforeTxnProcess txID = [{0}] ucPWBaseCol = [{1}]", txID, ucPWBaseCol);
                    if (!String.IsNullOrEmpty(ucPWBaseCol))
                    {
                        //對應可能的密碼檢核
                        TxPWChk txPWChk = new TxPWChk();
                        AppXmlExecResult pwResultXml = txPWChk.Run(context, correlationID, txID, txDef, requestXml);
                        if (pwResultXml == null)
                            return DoNDABeforeTxnProcess(context, correlationID, txID, txDef, requestXml);
                        else
                        {
                            XmlHelper xmlHelperRS = XmlHelper.GetInstance(pwResultXml.ResponseXml);
                            string result = xmlHelperRS.GetXPath(pwResultXml.ResponseXml, "//T24_DATA").Trim();
                            m_log.Info("DoNDABeforeTxnProcess pwChk error=" + result);
                            string newRs = result;
                            if (result.Contains("2001179010766"))
                                newRs = result.Replace("2001179010766", "2001172010766");
                            else if(result.Contains("2001179010767"))
                                newRs = result.Replace("2001179010767", "2001172010767");
                            XmlDocument rs_UCERR = base.TransformCommMsg("0", "Info", "交易完成", newRs);
                            return pwResultXml = base.BuildExecResult(context, rs_UCERR);
                        }         
                    }
                    return DoNDABeforeTxnProcess(context, correlationID, txID, txDef, requestXml);
                case "2010991"://轉帳交易撤銷查詢 - 個人
                case "2020655"://轉帳交易撤銷查詢 - 企業
                case "2010991BE"://轉帳交易撤銷查詢 - 個人
                case "2020655BE"://轉帳交易撤銷查詢 - 企業
                    return DoNDAQueryProcess(context, correlationID, txID, txDef, requestXml);
                case "2010992"://轉帳撤銷 - 個人
                case "2020656"://轉帳撤銷 - 企業
                    return DoNDACancelProcess(context, correlationID, txID, txDef, requestXml);
                case "2010992BE"://轉帳撤銷 - 個人
                case "2020656BE"://轉帳撤銷 - 企業
                    return DoIBNDACancelProcess(context, correlationID, txID, txDef, requestXml);
            }
            EaiResponse eaiRs = null;
            XmlDocument responseXml = null;
            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }



        #region 9010766 9010767 9020579 9020580
        AppXmlExecResult DoNDABeforeTxnProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("RunImpl DoNDABeforeTxnProcess txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

                string newucString = string.Format("<T24_DATA>{0}</T24_DATA>", rq_t24_data);
                AppXmlExecResult BalEnq_result = SendMsgToEAIProcess(context, newucString, txID + "_ENQ", true);
                return BalEnq_result;
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("NDABeforeTxnProcess Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        #endregion 9010766 9010767 9020579 9020580



        #region Query 2010991 2020655
        AppXmlExecResult DoNDAQueryProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                Dictionary<string, string> rqBodyDiy = new Dictionary<string, string>();
                string txnType = string.Empty;
                string beginDate = string.Empty;
                string endDate = string.Empty;
                UcControler rqUcControler = new UcControler();

                //當BE時，將XML T24_DATA的內容組成Dictionary
                switch (txID)
                {
                    case "2010991":
                    case "2020655":
                        XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                        string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                        m_log.Info("RunImpl DoNDAQueryProcess txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

                        rqUcControler.UC2T24(rq_t24_data);
                        rqBodyDiy = rqUcControler.m_ucBodyDiy;
                        break;
                    case "2010991BE":
                    case "2020655BE":
                        m_log.Info("RunImpl DoNDAQueryProcess txID = [{0}] UC_Request = [{1}]", txID, requestXml.InnerXml);
                        rqBodyDiy = XDocument.Parse(requestXml.InnerXml).Descendants()
                                                                         .Where(p => p.Name.LocalName == "T24_DATA")
                                                                         .Descendants()
                                                                         .ToDictionary(p => p.Name.LocalName.Substring(2), p => p.Value);

                        //組成UC HEAD for 新櫃面
                        rqUcControler.UC2T24_Head(UcHead.GetInstance().GetUCWebHeadContent("20", "529584000006", "999999999998", "06"));
                        rqUcControler.m_ucBodyDiy = rqBodyDiy;
                        break;
                }

                rqBodyDiy.TryGetValue("4172", out txnType);
                rqBodyDiy.TryGetValue("4119", out beginDate);
                rqBodyDiy.TryGetValue("4120", out endDate);

                DataSet ds = DBLog.SelectValidNdaByDate(beginDate, endDate);
                //先將現有未經篩選之Dataset轉換為Dictionary<欄位,值> 之 List
                List<Dictionary<string, string>> RqNDADicLst = DatasetToDiclist(ds);
                RqNDADicLst = RqNDADicLst.OrderBy(p => p.ContainsKey("CreateDate") ? p["CreateDate"] : string.Empty).ToList();
                List<Dictionary<string, string>> finalLst = new List<Dictionary<string, string>>();
                List<string> fileContentLst = new List<string>();//宣告落檔的檔案內容List<string>

                Dictionary<string, string> comp_bankCodeDic = new Dictionary<string, string>();
                Dictionary<string, string> bnkCodeNameDic = new Dictionary<string, string>();
                foreach (Dictionary<string, string> D in RqNDADicLst)//D為Status為999且日期落在查詢區間之各筆交易
                {
                    string msmqBody = string.Empty;
                    D.TryGetValue("MSMQ_Body", out msmqBody);

                    XmlDocument msmqBody_xdoc = new XmlDocument();
                    msmqBody_xdoc.LoadXml(msmqBody);
                    XmlHelper msmqBody_xhelper = XmlHelper.GetInstance(msmqBody_xdoc);
                    string mq_t24_data = msmqBody_xhelper.GetXPath(msmqBody_xdoc, "//T24_DATA").Trim();

                    Dictionary<string, string> ucMsmqHeadDic = new Dictionary<string, string>();
                    Dictionary<string, string> ucMsmqBodyDic = new Dictionary<string, string>();
                    ParseUcToDic(mq_t24_data, out ucMsmqHeadDic, out ucMsmqBodyDic);
                    bool t_flag = UcMapping(rqBodyDiy, ucMsmqBodyDic, txnType, txID);
                    if (t_flag)
                    {
                        finalLst.Add(D);
                        if (txnType == "01")//跨行
                        {
                            #region 查詢跨行 撈出2010767/2020580帶入之開戶行行號bankCode 以此查出開戶行名稱 並置入Dictionary 查過的不重複查
                            string bankCode = string.Empty; string bankName = string.Empty;
                            if (txID.Contains("2010991"))//個人跨行
                            { ucMsmqBodyDic.TryGetValue("4112", out bankCode); }
                            else if (txID.Contains("2020655"))//企業跨行
                            { ucMsmqBodyDic.TryGetValue("4186", out bankCode); }
                            if (!bnkCodeNameDic.ContainsKey(bankCode))//若未查過 以bankCode至T24查詢bankName
                            {
                                #region 以bankCode查詢bankName
                                string newT24RqString = GetT24_SeeBankName_Content(bankCode);
                                AppXmlExecResult rsResult = SendMsgToEAIProcess(context, newT24RqString, "ESCN.FIN.BANK.CODE", true);

                                XmlHelper xHelper = XmlHelper.GetInstance(rsResult.ResponseXml);
                                bankName = xHelper.GetXPath(rsResult.ResponseXml, "//DESCRIPTION").Trim();
                                bnkCodeNameDic.Add(bankCode, bankName);
                                m_log.Info("DoNDAQueryProcess - Add bnkCodeNameDic - Key:[{0}] Value:[{1}] Total:[{2}]Pairs", bankCode, bankName, bnkCodeNameDic.Count);
                                #endregion 以bankCode查詢bankName
                            }
                            else//若已查過 則直接從Dictionary取
                            { bnkCodeNameDic.TryGetValue(bankCode, out bankName); }
                            #endregion 查詢跨行 撈出2010767/2020580帶入之開戶行行號bankCode 以此查出開戶行名稱 並置入Dictionary 查過的不重複查
                            if (txID.Contains("2010991"))//個人跨行
                            { fileContentLst.Add(CreateFile_2010767to2010991(D, ucMsmqBodyDic, rqBodyDiy, bankName)); }
                            else if (txID.Contains("2020655"))//企業跨行
                            { fileContentLst.Add(CreateFile_2020580to2020655(D, ucMsmqBodyDic, rqBodyDiy, bankName)); }
                        }
                        else if (txnType == "02")//本行
                        {
                            #region 查詢本行 撈出2010766/2020579帶入之付款人帳號pyeAcnt 以此查出開戶行行號(9碼、12碼).開戶行名稱 並置入Dictionary 查過的不重複查
                            string pyeAcnt = string.Empty; string compCode = string.Empty; string bankCode = string.Empty; string bankName = string.Empty;
                            if (txID.Contains("2010991")) { ucMsmqBodyDic.TryGetValue("4161", out pyeAcnt); }//個人本行
                            else if (txID.Contains("2020655")) { ucMsmqBodyDic.TryGetValue("4324", out pyeAcnt); }//企業本行

                            if (pyeAcnt.Length > 15)//個人本行-卡
                            {
                                #region 以pyeAcnt查詢compCode.bankCode.bankName
                                string newT24RqString = GetT24_AcntInfoEnq_Content(pyeAcnt);
                                AppXmlExecResult rsResult = SendMsgToEAIProcess(context, newT24RqString, "ESCN.BP.ACCT.ENQ", true);

                                XmlHelper xHelper = XmlHelper.GetInstance(rsResult.ResponseXml);
                                compCode = xHelper.GetXPath(rsResult.ResponseXml, "//CO_CODE").Trim();
                                bankCode = xHelper.GetXPath(rsResult.ResponseXml, "//CO_NUM").Trim();
                                bankName = xHelper.GetXPath(rsResult.ResponseXml, "//CO_NAME").Trim();
                                m_log.Info("DoNDAQueryProcess - Query Card - Card:[{0}] compCode:[{1}] bankCode:[{2}] bankName:[{3}]",
                                            pyeAcnt, compCode, bankCode, bankName);
                                if (!string.IsNullOrEmpty(compCode) && !string.IsNullOrEmpty(bankCode) && !string.IsNullOrEmpty(bankName))
                                {
                                    if (!comp_bankCodeDic.ContainsKey(compCode))//若是第一次查 置入Dictionary
                                    {
                                        comp_bankCodeDic.Add(compCode, bankCode);
                                        if (!bnkCodeNameDic.ContainsKey(bankCode))
                                        { bnkCodeNameDic.Add(bankCode, bankName); }
                                        m_log.Info("DoNDAQueryProcess - Add bnkCodeNameDic -CompanyCode:[{0}] Key:[{1}] Value:[{2}] Total:[{3}]Pairs",
                                                    compCode, bankCode, bankName, bnkCodeNameDic.Count);
                                    }
                                }
                                else
                                { compCode = string.Empty; bankCode = string.Empty; bankName = string.Empty; }
                                #endregion 以pyeAcnt查詢compCode.bankCode.bankName
                            }
                            else//個人本行.企業本行-帳
                            {
                                compCode = string.Format("CN001{0}", pyeAcnt.Substring(0, 4));
                                if (!comp_bankCodeDic.ContainsKey(compCode))//若未查過
                                {
                                    #region 以pyeAcnt查詢bankCode.bankName
                                    string newT24RqString = GetT24_AcntInfoEnq_Content(pyeAcnt);
                                    AppXmlExecResult rsResult = SendMsgToEAIProcess(context, newT24RqString, "ESCN.BP.ACCT.ENQ", true);

                                    XmlHelper xHelper = XmlHelper.GetInstance(rsResult.ResponseXml);
                                    bankCode = xHelper.GetXPath(rsResult.ResponseXml, "//CO_NUM").Trim();
                                    bankName = xHelper.GetXPath(rsResult.ResponseXml, "//CO_NAME").Trim();
                                    m_log.Info("DoNDAQueryProcess - Query Acct - Acct:[{0}] compCode:[{1}] bankCode:[{2}] bankName:[{3}]",
                                                pyeAcnt, compCode, bankCode, bankName);
                                    if (!string.IsNullOrEmpty(compCode) && !string.IsNullOrEmpty(bankCode) && !string.IsNullOrEmpty(bankName))
                                    {
                                        comp_bankCodeDic.Add(compCode, bankCode);
                                        if (!bnkCodeNameDic.ContainsKey(bankCode))
                                        { bnkCodeNameDic.Add(bankCode, bankName); }
                                        m_log.Info("DoNDAQueryProcess - Add bnkCodeNameDic -CompanyCode:[{0}] Key:[{1}] Value:[{2}] Total:[{3}]Pairs",
                                                    compCode, bankCode, bankName, bnkCodeNameDic.Count);
                                    }
                                    else
                                    { compCode = string.Empty; bankCode = string.Empty; bankName = string.Empty; }
                                    #endregion 以pyeAcnt查詢bankCode.bankName
                                }
                                else//若已查過 則直接從Dictionary取
                                { comp_bankCodeDic.TryGetValue(compCode, out bankCode); bnkCodeNameDic.TryGetValue(bankCode, out bankName); }
                            }//個人本行-帳
                            #endregion 查詢本行 撈出2010766/2020579帶入之付款人帳號pyeAcnt 以此查出開戶行行號(9碼、12碼).開戶行名稱 並置入Dictionary 查過的不重複查
                            if (txID.Contains("2010991"))//個人本行
                            { fileContentLst.Add(CreateFile_2010766to2010991(D, ucMsmqBodyDic, rqBodyDiy, bankCode, bankName)); }
                            else if (txID.Contains("2020655"))//企業本行
                            { fileContentLst.Add(CreateFile_2020579to2020655(D, ucMsmqBodyDic, rqBodyDiy, bankCode, bankName)); }
                        }
                    }
                }
                Dictionary<string, string> totalDic = new Dictionary<string, string>();
                //FileContentList中 每一筆資料皆往T24送一筆查詢 查出手續費 再寫回FileContentList
                fileContentLst = GetChargeAmt(rqUcControler, fileContentLst, context);
                //if (txnType == "02")//02為本行   跨行不用做，跨行取交易時帶入的值即可
                //{
                //    //FileContentList中 每一筆資料皆查出收款人行號(或許往T24查) 再寫回FileContentList
                //    fileContentLst = GetBankCode(fileContentLst, context);
                //}
                //FileContentList中 每一筆資料皆往T24送一筆查詢 查出行名 再寫回FileContentList
                //fileContentLst = GetBankName(fileContentLst, context);

                string ucRS = string.Empty;
                switch (txID)
                {
                    case "2010991":
                    case "2020655":
                        //FileContentList落檔 上傳FTP
                        rqUcControler.CreateEnqFileToUC(fileContentLst, true);
                        ////計算總筆數
                        totalDic.Add("4305", fileContentLst.Count.ToString());
                        ////文件名
                        totalDic.Add("zzzx", rqUcControler.enqFileName);
                        ucRS = rqUcControler.GetToUCRS(totalDic);
                        break;
                    case "2010991BE":
                    case "2020655BE":
                        //組成Response XML
                        ucRS = Get_2010991_2020665_Xml(finalLst, fileContentLst, txID);
                        break;
                }

                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", ucRS);
                return base.BuildExecResult(context, rs);
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("DoNDAQueryProcess Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        #region mapping
        string Mapping2010766To2010991(string code)
        {
            //code為查詢條件域代碼 來自2010991報文，m_code為對應的2010766域代碼，對應到存在MSMQTALK TABLE裡的2010766報文
            //若2010991 code的值與2010766 m_code的值相符，則表示條件成立
            string m_code = string.Empty;
            switch (code)
            {
                case "4102"://柜员号
                    break;
                case "4052"://客户类型
                    break;
                case "4157"://付款账户
                    m_code = "4157";
                    break;
                case "4900"://付款人名称
                    break;
                case "4172"://交易类型
                    break;
                case "4119"://开始日期
                    m_code = "2006";
                    break;
                case "4120"://结束日期
                    m_code = "2006";
                    break;
                case "4111"://IP地址
                    break;
                case "4835"://通用备用字段
                    break;
            }
            return m_code;
        }
        string Mapping2010767To2010991(string code)
        {
            //code為查詢條件域代碼 來自2010991報文，m_code為對應的2010767域代碼，對應到存在MSMQTALK TABLE裡的2010767報文
            //若2010991 code的值與2010767 m_code的值相符，則表示條件成立
            string m_code = string.Empty;
            switch (code)
            {
                case "4102"://柜员号
                    break;
                case "4052"://客户类型
                    break;
                case "4157"://付款账户
                    m_code = "4157";
                    break;
                case "4900"://付款人名称
                    //m_code = "4900";
                    break;
                case "4172"://交易类型
                    break;
                case "4119"://开始日期
                    m_code = "2006";
                    break;
                case "4120"://结束日期
                    m_code = "2006";
                    break;
                case "4111"://IP地址
                    break;
                case "4835"://通用备用字段
                    break;
            }
            return m_code;
        }
        string Mapping2020579To2020655(string code)
        {
            //code為查詢條件域代碼 來自2020655報文，m_code為對應的2020579域代碼，對應到存在MSMQTALK TABLE裡的2020579報文
            //若2020655 code的值與2020579 m_code的值相符，則表示條件成立
            string m_code = string.Empty;
            switch (code)
            {
                case "4102"://柜员号
                    break;
                case "4052"://客户类型
                    break;
                case "4157"://付款账户
                    m_code = "4323";
                    break;
                case "4900"://付款人名称
                    break;
                case "4172"://交易类型
                    break;
                case "4119"://开始日期
                    m_code = "2006";
                    break;
                case "4120"://结束日期
                    m_code = "2006";
                    break;
                case "4111"://IP地址
                    break;
                case "4835"://通用备用字段
                    break;
            }
            return m_code;
        }
        string Mapping2020580To2020655(string code)
        {
            //code為查詢條件域代碼 來自2020655報文，m_code為對應的2020580域代碼，對應到存在MSMQTALK TABLE裡的2020580報文
            //若2020655 code的值與2020580 m_code的值相符，則表示條件成立
            string m_code = string.Empty;
            switch (code)
            {
                case "4102"://柜员号
                    break;
                case "4052"://客户类型
                    break;
                case "4157"://付款账户
                    m_code = "4157";
                    break;
                case "4900"://付款人名称
                    //m_code = "4900";
                    break;
                case "4172"://交易类型
                    break;
                case "4119"://开始日期
                    m_code = "2006";
                    break;
                case "4120"://结束日期
                    m_code = "2006";
                    break;
                case "4111"://IP地址
                    break;
                case "4835"://通用备用字段
                    break;
            }
            return m_code;
        }
        #endregion mapping
        #region createfile
        private string CreateFile_2010767to2010991(Dictionary<string, string> mqDic, Dictionary<string, string> mqUcBodyDic, Dictionary<string, string> rqUcBodyDic, string bankName)
        {
            string tempString = string.Empty;
            StringBuilder sb = new StringBuilder();

            mqUcBodyDic.TryGetValue("2039", out tempString);
            sb.Append(tempString).Append("|");//交易序号

            mqDic.TryGetValue("CreateDate", out tempString);
            tempString = DateTime.Parse(tempString).ToString("yyyyMMddHHmmss");
            sb.Append(tempString).Append("|");//交易時間

            sb.Append("01").Append("|");//交易類型

            mqUcBodyDic.TryGetValue("4100", out tempString);
            sb.Append(tempString).Append("|");//轉帳金額

            mqUcBodyDic.TryGetValue("4118", out tempString);
            sb.Append(tempString).Append("|");//轉帳幣種

            sb.Append("4165.CHG.AMT").Append("|");//手續費

            mqUcBodyDic.TryGetValue("4157", out tempString);
            sb.Append(tempString).Append("|");//付款人帳戶

            mqUcBodyDic.TryGetValue("4900", out tempString);
            sb.Append(tempString).Append("|");//付款人名稱

            mqUcBodyDic.TryGetValue("4161", out tempString);
            sb.Append(tempString).Append("|");//收款人帳戶

            mqUcBodyDic.TryGetValue("4733", out tempString);
            sb.Append(tempString).Append("|");//收款人名稱

            string bankCode = string.Empty;
            mqUcBodyDic.TryGetValue("4112", out bankCode);
            sb.Append(bankCode).Append("|");//收款人行號

            mqUcBodyDic.TryGetValue("2021", out tempString);
            sb.Append(tempString).Append("|");//收款人聯行號

            //ucBodyDic.TryGetValue("4658", out tempString);
            //sb.Append("&GetBankName&").Append("|");
            sb.Append(bankName).Append("|");//收款人網點名稱

            mqUcBodyDic.TryGetValue("4026", out tempString);
            sb.Append(tempString).Append("|");//轉帳方式

            mqUcBodyDic.TryGetValue("4897", out tempString);
            sb.Append(tempString).Append("|");//轉帳用途

            mqUcBodyDic.TryGetValue("4734", out tempString);
            sb.Append(tempString).Append("|");//交易附言

            mqDic.TryGetValue("Status", out tempString);
            sb.Append(tempString == "999" ? "0" : "1").Append("|");//是否允許撤銷


            return sb.ToString();
        }
        private string CreateFile_2010766to2010991(Dictionary<string, string> mqDic, Dictionary<string, string> mqUcBodyDic, Dictionary<string, string> rqUcBodyDic, string bankCode, string bankName)
        {
            string tempString = string.Empty;
            StringBuilder sb = new StringBuilder();

            mqUcBodyDic.TryGetValue("2039", out tempString);
            sb.Append(tempString).Append("|");//交易序号

            mqDic.TryGetValue("CreateDate", out tempString);
            tempString = DateTime.Parse(tempString).ToString("yyyyMMddHHmmss");
            sb.Append(tempString).Append("|");//交易時間

            sb.Append("02").Append("|");//交易類型

            mqUcBodyDic.TryGetValue("4100", out tempString);
            sb.Append(tempString).Append("|");//轉帳金額

            mqUcBodyDic.TryGetValue("4118", out tempString);
            sb.Append(tempString).Append("|");//轉帳幣種

            sb.Append("4165.CHG.AMT").Append("|");//手續費

            mqUcBodyDic.TryGetValue("4157", out tempString);
            sb.Append(tempString).Append("|");//付款人帳戶

            rqUcBodyDic.TryGetValue("4900", out tempString);
            sb.Append(tempString).Append("|");//付款人名稱

            mqUcBodyDic.TryGetValue("4161", out tempString);
            sb.Append(tempString).Append("|");//收款人帳戶

            mqUcBodyDic.TryGetValue("4900", out tempString);
            sb.Append(tempString).Append("|");//收款人名稱

            //sb.Append("&GetBankCode&").Append("|"); //已改GetBankCode
            sb.Append(bankCode).Append("|");//收款人行號

            sb.Append("").Append("|");//收款人聯行號

            //sb.Append("&GetBankName&").Append("|");
            sb.Append(bankName).Append("|");//收款人網點名稱

            sb.Append("2").Append("|");//轉帳方式

            mqUcBodyDic.TryGetValue("4732", out tempString);
            sb.Append(tempString).Append("|");//轉帳用途

            mqUcBodyDic.TryGetValue("4658", out tempString);
            sb.Append(tempString).Append("|");//交易附言

            mqDic.TryGetValue("Status", out tempString);
            sb.Append(tempString == "999" ? "0" : "1").Append("|");//是否允許撤銷

            return sb.ToString();
        }
        private string CreateFile_2020580to2020655(Dictionary<string, string> mqDic, Dictionary<string, string> mqUcBodyDic, Dictionary<string, string> rqUcBodyDic, string bankName)
        {
            string tempString = string.Empty;
            StringBuilder sb = new StringBuilder();

            mqUcBodyDic.TryGetValue("2039", out tempString);
            sb.Append(tempString).Append("|");//交易序号

            mqDic.TryGetValue("CreateDate", out tempString);
            tempString = DateTime.Parse(tempString).ToString("yyyyMMddHHmmss");
            sb.Append(tempString).Append("|");//交易時間

            sb.Append("01").Append("|");//交易類型

            mqUcBodyDic.TryGetValue("4100", out tempString);
            sb.Append(tempString).Append("|");//轉帳金額

            mqUcBodyDic.TryGetValue("4118", out tempString);
            sb.Append(tempString).Append("|");//轉帳幣種

            sb.Append("4165.CHG.AMT").Append("|");//手續費

            mqUcBodyDic.TryGetValue("4157", out tempString);
            sb.Append(tempString).Append("|");//付款人帳戶

            mqUcBodyDic.TryGetValue("4900", out tempString);
            sb.Append(tempString).Append("|");//付款人名稱

            mqUcBodyDic.TryGetValue("4161", out tempString);
            sb.Append(tempString).Append("|");//收款人帳戶

            mqUcBodyDic.TryGetValue("4732", out tempString);
            sb.Append(tempString).Append("|");//收款人名稱

            string bankCode = string.Empty;
            mqUcBodyDic.TryGetValue("4186", out bankCode);
            sb.Append(bankCode).Append("|");//收款人行號

            mqUcBodyDic.TryGetValue("2021", out tempString);
            sb.Append(tempString).Append("|");//收款人聯行號

            //ucBodyDic.TryGetValue("4658", out tempString);
            //sb.Append("&GetBankName&").Append("|");
            sb.Append(bankName).Append("|");//收款人網點名稱

            mqUcBodyDic.TryGetValue("4026", out tempString);
            sb.Append(tempString).Append("|");//轉帳方式

            mqUcBodyDic.TryGetValue("4349", out tempString);
            sb.Append(tempString).Append("|");//轉帳用途

            sb.Append("").Append("|");//交易渠道

            mqUcBodyDic.TryGetValue("4658", out tempString);
            sb.Append(tempString).Append("|");//交易附言

            mqDic.TryGetValue("Status", out tempString);
            sb.Append(tempString == "999" ? "0" : "1").Append("|");//是否允許撤銷


            return sb.ToString();
        }
        private string CreateFile_2020579to2020655(Dictionary<string, string> mqDic, Dictionary<string, string> mqUcBodyDic, Dictionary<string, string> rqUcBodyDic, string bankCode, string bankName)
        {
            string tempString = string.Empty;
            StringBuilder sb = new StringBuilder();

            mqUcBodyDic.TryGetValue("2039", out tempString);
            sb.Append(tempString).Append("|");//交易序号

            mqDic.TryGetValue("CreateDate", out tempString);
            tempString = DateTime.Parse(tempString).ToString("yyyyMMddHHmmss");
            sb.Append(tempString).Append("|");//交易時間

            sb.Append("02").Append("|");//交易類型

            mqUcBodyDic.TryGetValue("4100", out tempString);
            sb.Append(tempString).Append("|");//轉帳金額

            mqUcBodyDic.TryGetValue("4118", out tempString);
            sb.Append(tempString).Append("|");//轉帳幣種

            sb.Append("4165.CHG.AMT").Append("|");//手續費

            mqUcBodyDic.TryGetValue("4323", out tempString);
            sb.Append(tempString).Append("|");//付款人帳戶

            rqUcBodyDic.TryGetValue("4900", out tempString);
            sb.Append(tempString).Append("|");//付款人名稱

            mqUcBodyDic.TryGetValue("4324", out tempString);
            sb.Append(tempString).Append("|");//收款人帳戶

            mqUcBodyDic.TryGetValue("4897", out tempString);
            sb.Append(tempString).Append("|");//收款人名稱

            //sb.Append("&GetBankCode&").Append("|"); //已改GetBankCode
            sb.Append(bankCode).Append("|");//收款人行號

            sb.Append("").Append("|");//收款人聯行號

            //sb.Append("&GetBankName&").Append("|");
            sb.Append(bankName).Append("|");//收款人網點名稱

            sb.Append("2").Append("|");//轉帳方式

            mqUcBodyDic.TryGetValue("4349", out tempString);
            sb.Append(tempString).Append("|");//轉帳用途

            sb.Append("").Append("|");//交易渠道

            mqUcBodyDic.TryGetValue("4658", out tempString);
            sb.Append(tempString).Append("|");//交易附言

            mqDic.TryGetValue("Status", out tempString);
            sb.Append(tempString == "999" ? "0" : "1").Append("|");//是否允許撤銷


            return sb.ToString();
        }
        #endregion createfile
        //private List<string> GetBankCode(List<string> fileContentLst, EaiContext context)
        //{
        //    List<string> newFileContentLst = new List<string>();
        //    foreach (string s in fileContentLst)
        //    {
        //        string bankCode = string.Empty;
        //        string companyCode = string.Empty;//CN001XXXX
        //        string pyeAcnt = s.Split('|')[8];
        //        if (pyeAcnt.Length > 15) //CARD
        //        {
        //            string newT24RqString = GetT24_CardCustDataEnq_Content(pyeAcnt);
        //            AppXmlExecResult bankNameResult = SendMsgToEAIProcess(context, newT24RqString, "ESCN.CARD.CUSDATA.ENQ", true);
        //            XmlHelper xHelper = XmlHelper.GetInstance(bankNameResult.ResponseXml);
        //            companyCode = xHelper.GetXPath(bankNameResult.ResponseXml, "//CUS_CO_CODE").Trim();
        //        }
        //        else//T24 ACCT 
        //        {
        //            companyCode = string.Format("CN001{0}", pyeAcnt.Substring(0, 4));
        //        }
        //        bankCode = MappingBankCode(companyCode);

        //        string newDataString = s;
        //        if (s.Split('|')[10] == "&GetBankCode&")
        //        {
        //            if (!string.IsNullOrEmpty(bankCode))
        //                newDataString = s.Replace("&GetBankCode&", bankCode);
        //            else
        //                newDataString = s.Replace("&GetBankCode&", string.Empty);
        //        }
        //        newFileContentLst.Add(newDataString);
        //    }
        //    return newFileContentLst;
        //}
        //private string GetT24_CardCustDataEnq_Content(string cardNo)
        //{
        //    StringBuilder sbXmlCardCompanyCodeEnq = new StringBuilder();
        //    sbXmlCardCompanyCodeEnq.Append("<T24_DATA>");
        //    sbXmlCardCompanyCodeEnq.Append("<T24_EAI>");
        //    sbXmlCardCompanyCodeEnq.Append("<T24_EAI_HDR>");
        //    sbXmlCardCompanyCodeEnq.Append("<MSG_SYS_ID/>");
        //    sbXmlCardCompanyCodeEnq.Append("<HDR_MD5_DES/>");
        //    sbXmlCardCompanyCodeEnq.Append("</T24_EAI_HDR>");
        //    sbXmlCardCompanyCodeEnq.Append("<T24_EAI_MSG>");
        //    sbXmlCardCompanyCodeEnq.Append("<REQ_MSG_GRP>");
        //    sbXmlCardCompanyCodeEnq.Append("<REQ_MSG_OPT>");
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
        //    sbXmlCardCompanyCodeEnq.Append("</REQ_MSG_OPT>");
        //    sbXmlCardCompanyCodeEnq.Append("<REQ_MSG_DATA>");
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.CARD.CUSDATA.ENQ");
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "CUP001.0001");
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
        //    sbXmlCardCompanyCodeEnq.AppendFormat("<CARD_NO op='EQ'>{0}</CARD_NO>", cardNo);
        //    sbXmlCardCompanyCodeEnq.Append("</REQ_MSG_DATA>");
        //    sbXmlCardCompanyCodeEnq.Append("</REQ_MSG_GRP>");
        //    sbXmlCardCompanyCodeEnq.Append("<REQ_PROC_INFO>");
        //    sbXmlCardCompanyCodeEnq.Append("<UNQ_REF_ID/>");
        //    sbXmlCardCompanyCodeEnq.Append("<REQ_PROC_SYS/>");
        //    sbXmlCardCompanyCodeEnq.Append("</REQ_PROC_INFO>");
        //    sbXmlCardCompanyCodeEnq.Append("</T24_EAI_MSG>");
        //    sbXmlCardCompanyCodeEnq.Append("</T24_EAI>");
        //    sbXmlCardCompanyCodeEnq.Append("</T24_DATA>");
        //    return sbXmlCardCompanyCodeEnq.ToString();
        //}
        //private string MappingBankCode(string companyCode)
        //{
        //    switch (companyCode)
        //    {
        //        case "CN0010001":
        //            return "529584000006";
        //        case "CN0010002":
        //            return "529602000017";
        //        case "CN0010003":
        //            return "529602001010";
        //        case "CN0010004":
        //            return "529584000047";
        //        default:
        //            m_log.Error("MappingBankCode Error !!! companyCode:[{0}] default bankCode:[{1}]", companyCode, "529584000006");
        //            return "529584000006";
        //    }
        //}
        //private List<string> GetBankName(List<string> fileContentLst, EaiContext context)
        //{
        //    List<string> newFileContentLst = new List<string>();
        //    Dictionary<string, string> bnkCodeNamePair = new Dictionary<string, string>();
        //    foreach (string s in fileContentLst)
        //    {
        //        string bankName = string.Empty;
        //        string bankCode = s.Split('|')[10];
        //        if (!bnkCodeNamePair.ContainsKey(bankCode))
        //        {
        //            //string newT24RqString = GetT24_BankNameEnq_Content(bankCode);
        //            //AppXmlExecResult bankNameResult = SendMsgToEAIProcess(context, newT24RqString, "ESCN.IB.BANK.CODE.ENQ", true);
        //            string newT24RqString = GetT24_SeeBankName_Content(bankCode);
        //            AppXmlExecResult bankNameResult = SendMsgToEAIProcess(context, newT24RqString, "ESCN.FIN.BANK.CODE", true);

        //            XmlHelper xHelper = XmlHelper.GetInstance(bankNameResult.ResponseXml);
        //            bankName = xHelper.GetXPath(bankNameResult.ResponseXml, "//DESCRIPTION").Trim();
        //            bnkCodeNamePair.Add(bankCode, bankName);
        //            m_log.Info("GetBankNameByAcct - Add bnkCodeNamePair - Key:[{0}] Value:[{1}] Total:[{2}]Pairs", bankCode, bankName, bnkCodeNamePair.Count);
        //        }
        //        else
        //        { bnkCodeNamePair.TryGetValue(bankCode, out bankName); }
        //        string newDataString = s;
        //        if (s.Split('|')[12] == "&GetBankName&")
        //        {
        //            if (!string.IsNullOrEmpty(bankName))
        //                newDataString = s.Replace("&GetBankName&", bankName);
        //            else
        //                newDataString = s.Replace("&GetBankName&", string.Empty);
        //            newFileContentLst.Add(newDataString);
        //        }
        //    }
        //    return newFileContentLst;
        //}
        private string GetT24_SeeBankName_Content(string finCodde)
        {
            StringBuilder sbXmlBankNameEnq = new StringBuilder();
            sbXmlBankNameEnq.Append("<T24_DATA>");
            sbXmlBankNameEnq.Append("<T24_EAI>");
            sbXmlBankNameEnq.Append("<T24_EAI_HDR>");
            sbXmlBankNameEnq.Append("<MSG_SYS_ID/>");
            sbXmlBankNameEnq.Append("<HDR_MD5_DES/>");
            sbXmlBankNameEnq.Append("</T24_EAI_HDR>");
            sbXmlBankNameEnq.Append("<T24_EAI_MSG>");
            sbXmlBankNameEnq.Append("<REQ_MSG_GRP>");
            sbXmlBankNameEnq.Append("<REQ_MSG_OPT>");
            sbXmlBankNameEnq.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sbXmlBankNameEnq.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sbXmlBankNameEnq.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sbXmlBankNameEnq.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", "S");
            sbXmlBankNameEnq.Append("</REQ_MSG_OPT>");
            sbXmlBankNameEnq.Append("<REQ_MSG_DATA>");
            sbXmlBankNameEnq.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "ESCN.FIN.BANK.CODE");
            sbXmlBankNameEnq.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "");
            sbXmlBankNameEnq.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", finCodde);
            sbXmlBankNameEnq.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "IB001.0013");
            sbXmlBankNameEnq.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sbXmlBankNameEnq.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sbXmlBankNameEnq.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sbXmlBankNameEnq.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sbXmlBankNameEnq.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sbXmlBankNameEnq.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sbXmlBankNameEnq.Append("</REQ_MSG_DATA>");
            sbXmlBankNameEnq.Append("</REQ_MSG_GRP>");
            sbXmlBankNameEnq.Append("<REQ_PROC_INFO>");
            sbXmlBankNameEnq.Append("<UNQ_REF_ID/>");
            sbXmlBankNameEnq.Append("<REQ_PROC_SYS/>");
            sbXmlBankNameEnq.Append("</REQ_PROC_INFO>");
            sbXmlBankNameEnq.Append("</T24_EAI_MSG>");
            sbXmlBankNameEnq.Append("</T24_EAI>");
            sbXmlBankNameEnq.Append("</T24_DATA>");
            string sXmlFeeEnq = sbXmlBankNameEnq.ToString();
            return sXmlFeeEnq;
        }
        private List<string> GetChargeAmt(UcControler ucControler, List<string> fileContentLst, EaiContext context)
        {
            List<string> newFileContentLst = new List<string>();
            foreach (string s in fileContentLst)
            {
                string txnType = Convert.ToInt32(s.Split('|')[2]).ToString();
                string txnAmount = s.Split('|')[3];
                string txnCurr = s.Split('|')[4];
                string chg_msg_key = string.Empty;
                if (context.TxID.Contains("2010991"))//轉帳交易撤銷查詢 個人
                    chg_msg_key = "2010776";//個人查手續費
                if (context.TxID.Contains("2020655"))//轉帳交易撤銷查詢 企業
                    chg_msg_key = "2020587";//企業查手續費

                Dictionary<string, string> newBodyDic = new Dictionary<string, string>(ucControler.m_ucBodyDiy);
                newBodyDic["2001"] = chg_msg_key;
                newBodyDic.Add("4949", txnType);//交易類型 01->跨行 02->行內
                newBodyDic.Add("4100", txnAmount);//金額
                newBodyDic.Add("4118", txnCurr);//幣種

                string newUcString = newUcString = ucControler.MakeNewUcString(ucControler.m_healDataDiy, newBodyDic);
                newUcString = string.Format("<T24_DATA>{0}</T24_DATA>", newUcString);
                AppXmlExecResult chgAmtResult = SendMsgToEAIProcess(context, newUcString, chg_msg_key, true);

                XmlHelper xHelper = XmlHelper.GetInstance(chgAmtResult.ResponseXml);
                string chargeRsString = xHelper.GetXPath(chgAmtResult.ResponseXml, "//T24_DATA").Trim();

                Dictionary<string, string> chgHeadDic = new Dictionary<string, string>();
                Dictionary<string, string> chgBodyDic = new Dictionary<string, string>();
                ParseUcToDic(chargeRsString, out chgHeadDic, out chgBodyDic);

                string chgAmt = string.Empty;
                chgBodyDic.TryGetValue("4165", out chgAmt);
                string newDataString = s;
                if (!string.IsNullOrEmpty(chgAmt))
                    newDataString = s.Replace("4165.CHG.AMT", chgAmt);
                else
                    newDataString = s.Replace("4165.CHG.AMT", string.Empty);
                newFileContentLst.Add(newDataString);
            }
            return newFileContentLst;
        }
        internal string GetT24_AcntInfoEnq_Content(string acnt)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.BP.ACCT.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "UPC001.0005");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<ACCOUNT_NUMBER op='EQ'>{0}</ACCOUNT_NUMBER>", acnt);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            return sb.ToString();
        }

        private string Get_2010991_2020665_Xml(List<Dictionary<string, string>> finalLst, List<string> fileContentLst, string txID)
        {

            int dataCnt = fileContentLst.Count;
            //確認finalList和fileContentList筆數是否一致
            if (finalLst.Count != dataCnt) dataCnt = 0;
            #region 範例
            //<Rsp_Msg>
            //    <RspCode>SUCC</RspCode>
            //    <RspMsg>交易成功</RspMsg>
            //    <RspCnt>2</RspCnt>
            //    <Rsps row=”1”>
            //        <BTID>19195152-79CB-430F-99BB-6AE41E1EC7CD</BTID>
            //        <TxnID>000038935771</TxnID>
            //        <TxnTime>2018-02-22 18:32:00.993</TxnTime>
            //        <PayAcct>000251000013048</PayAcct>
            //        <PayAcctNm>王小明</PayAcctNm>
            //        <PayeeAcct>000251000000267</PayeeAcct>
            //        <PayeeAcctNm>王大華</PayeeAcctNm>
            //        <PayeeAcctComp>玉山银行(中国)东莞分行</PayeeAcctComp>
            //        <PayCur>CNY</PayCur>
            //        <PayAmt>12.00</PayAmt>
            //        <PayChg>0.00</PayChg>
            //        <PayDesc>货款</PayDesc>
            //        <PayRemark></PayRemark>
            //        <Status>0</Status>
            //    <Rsps>
            //    <Rsps row=”2”>
            //        <BTID>19195152-79CB-430F-99BB-6AE41E1EC7CE</BTID>
            //        <TxnID>000038935772</TxnID>
            //        <TxnTime>2018-02-22 18:33:00.993</TxnTime>
            //        <PayAcct>000251000013048</PayAcct>
            //        <PayAcctNm>王小明</PayAcctNm>
            //        <PayeeAcct>000251000000267</PayeeAcct>
            //        <PayeeAcctNm>王大華</PayeeAcctNm>
            //        <PayeeAcctComp>玉山银行(中国)东莞分行</PayeeAcctComp>
            //        <PayCur>CNY</PayCur>
            //        <PayAmt>13.00</PayAmt>
            //        <PayChg>0.00</PayChg>
            //        <PayDesc>往來款</PayDesc>
            //        <PayRemark>TEST</PayRemark>
            //        <Status>0</Status>
            //    <Rsps>
            //</Rsp_Msg>
            #endregion

            XElement xDoc =
                   new XElement("Rsp_Msg",
                       new XElement("RspCode", "SUCC"),
                       new XElement("RspMsg", "交易成功"),
                       new XElement("RspCnt", dataCnt.ToString())
                   );

            for (int i = 0; i <= dataCnt - 1; i++)
            {
                string[] fileContentStr = fileContentLst[i].Split('|');

                xDoc.Add(new XElement("Rsps", new XAttribute("row", i + 1),
                            new XElement("BTID", finalLst[i]["BTID"]),
                            new XElement("TxnID", fileContentStr[0]),   //交易序號
                            new XElement("TxnTime", fileContentStr[1]),   //交易時間
                            new XElement("TxnType", fileContentStr[2]),   //交易類型
                            new XElement("PayAmt", fileContentStr[3]),   //轉帳金額
                            new XElement("PayCur", fileContentStr[4]),   //轉帳幣種
                            new XElement("PayChg", fileContentStr[5]),   //手續費
                            new XElement("PayAcct", fileContentStr[6]),   //付款人帳戶
                            new XElement("PayAcctNm", fileContentStr[7]),   //付款人名稱
                            new XElement("PayeeAcct", fileContentStr[8]),   //收款人帳戶
                            new XElement("PayeeAcctNm", fileContentStr[9]),   //收款人名稱
                            new XElement("PayeeBkCode", fileContentStr[10]),   //收款人行號
                            new XElement("PayeeBkLinkCode", fileContentStr[11]),   //收款人聯行號
                            new XElement("PayeeAcctComp", fileContentStr[12]),   //收款人網點名稱
                            new XElement("PayMethod", fileContentStr[13]),   //轉帳方式
                            new XElement("PayDesc", fileContentStr[14]),   //轉帳用途
                            new XElement("PayRemark", txID == "2010991BE" ? fileContentStr[15] : fileContentStr[16]),   //交易附言
                            new XElement("Status", txID == "2010991BE" ? fileContentStr[16] : fileContentStr[17])   //是否允許撤銷
                    ));
            }

            return xDoc.ToString();
        }

        #endregion Query 2010991 2020655


        #region Cancel 2010992 2020656
        AppXmlExecResult DoNDACancelProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("RunImpl DoNDACancelProcess txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

                string txnType = string.Empty;
                UcControler rqUcControler = new UcControler();
                rqUcControler.UC2T24(rq_t24_data);
                rqUcControler.m_ucBodyDiy.TryGetValue("4172", out txnType);

                DataSet ds = DBLog.SelectValidNda();
                //先將現有未經篩選之Dataset轉換為Dictionary<欄位,值> 之 List
                List<Dictionary<string, string>> RqNDADicLst = DatasetToDiclist(ds);
                RqNDADicLst = RqNDADicLst.OrderBy(p => p.ContainsKey("CreateDate") ? p["CreateDate"] : string.Empty).ToList();

                int execRows = 0;
                foreach (Dictionary<string, string> D in RqNDADicLst)
                {
                    string msmqBody = string.Empty;
                    D.TryGetValue("MSMQ_Body", out msmqBody);

                    XmlDocument msmqBody_xdoc = new XmlDocument();
                    msmqBody_xdoc.LoadXml(msmqBody);
                    XmlHelper msmqBody_xhelper = XmlHelper.GetInstance(msmqBody_xdoc);
                    string mq_t24_data = msmqBody_xhelper.GetXPath(msmqBody_xdoc, "//T24_DATA").Trim();

                    Dictionary<string, string> ucMsmqHeadDic = new Dictionary<string, string>();
                    Dictionary<string, string> ucMsmqBodyDic = new Dictionary<string, string>();
                    ParseUcToDic(mq_t24_data, out ucMsmqHeadDic, out ucMsmqBodyDic);

                    bool t_flag = UcMapping(rqUcControler.m_ucBodyDiy, ucMsmqBodyDic, txnType, txID);

                    if (t_flag)
                    {
                        string BTID = string.Empty;
                        D.TryGetValue("BTID", out BTID);

                        m_log.Info("DoNDACancelProcess - Cancel NDA, BTID:[{0}]", BTID);

                        execRows = DBLog.CancelNda(BTID, 999, 990);
                    }
                }
                Dictionary<string, string> totalDic = new Dictionary<string, string>();
                string ucRS = string.Empty;
                if (execRows == 0)
                {
                    ucRS = rqUcControler.GetFailUcRS(totalDic, "CO1MO102", "无法撤销");
                    m_log.Error("DoNDACancelProcess - Cancel NDA FAIL! UCSTRING:[{0}]", rq_t24_data);
                }
                else if (execRows == 1)
                {
                    ucRS = rqUcControler.GetToUCRS(totalDic);
                    m_log.Info("DoNDACancelProcess - Cancel NDA SUCC! UCSTRING:[{0}]", rq_t24_data);
                }
                else
                {
                    ucRS = rqUcControler.GetFailUcRS(totalDic, "CO1MD999", "数据库其他错误");
                    m_log.Error("DoNDACancelProcess - Cancel TWO NDAs! UCSTRING:[{0}]", rq_t24_data);
                }
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", ucRS);
                return base.BuildExecResult(context, rs);
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("DoNDACancelProcess Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        AppXmlExecResult DoIBNDACancelProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string BTID = rq_XmlHelper.GetXPath(requestXml, "//BTID").Trim();
                string txnID = rq_XmlHelper.GetXPath(requestXml, "//TxnID").Trim();
                m_log.Info("RunImpl DoIBNDACancelProcess txID = [{0}] BTID = [{1}] txnID = [{2}]", txID, BTID, txnID);

                int execRows = 0;
                string ucRS = string.Empty;
                if (!string.IsNullOrEmpty(BTID) && !string.IsNullOrEmpty(txnID))
                {
                    //取得該筆BTID的MSMQ_Body的TxnID(2039)，並與傳入值比較
                    DataSet ds = DBLog.SelectValidNdaByBTID(BTID);
                    string msmqBody = string.Empty;
                    string msmqTxnID = string.Empty;
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        msmqBody = ds.Tables[0].Rows[0]["MSMQ_Body"].ToString();

                        XmlDocument msmqBody_xdoc = new XmlDocument();
                        msmqBody_xdoc.LoadXml(msmqBody);
                        XmlHelper msmqBody_xhelper = XmlHelper.GetInstance(msmqBody_xdoc);
                        string mq_t24_data = msmqBody_xhelper.GetXPath(msmqBody_xdoc, "//T24_DATA").Trim();

                        Dictionary<string, string> ucMsmqHeadDic = new Dictionary<string, string>();
                        Dictionary<string, string> ucMsmqBodyDic = new Dictionary<string, string>();
                        ParseUcToDic(mq_t24_data, out ucMsmqHeadDic, out ucMsmqBodyDic);
                        ucMsmqBodyDic.TryGetValue("2039", out msmqTxnID);

                        m_log.Info("DoIBNDACancelProcess - Cancel NDA, txnID:[{0}] msmqTxnID:[{1}]", txnID, msmqTxnID);

                        if (txnID.Equals(msmqTxnID))
                        {
                            m_log.Info("DoIBNDACancelProcess - Cancel NDA, BTID:[{0}]", BTID);
                            execRows = DBLog.CancelNda(BTID, 999, 990);
                        }
                    }
                    else { m_log.Error("DoIBNDACancelProcess - Cancel NDA FAIL! TxnID(2039) NOT FOUND. BTID:[{0}]", BTID); }
                }

                if (execRows == 0)
                {
                    ucRS = Get_2010992_2020656_Xml("FAIL", "无法撤销", BTID, txnID);
                    m_log.Error("DoIBNDACancelProcess - Cancel NDA FAIL! BTID:[{0}]", BTID);
                }
                else if (execRows == 1)
                {
                    ucRS = Get_2010992_2020656_Xml("SUCC", "交易成功", BTID, txnID);
                    m_log.Info("DoIBNDACancelProcess - Cancel NDA SUCC! BTID:[{0}]", BTID);
                }
                else
                {
                    ucRS = Get_2010992_2020656_Xml("FAIL", "数据库其他错误", BTID, txnID);
                    m_log.Error("DoIBNDACancelProcess - Cancel More than one NDAs! BTID:[{0}]", BTID);
                }

                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", ucRS);
                return base.BuildExecResult(context, rs);

            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("DoIBNDACancelProcess Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        private string Get_2010992_2020656_Xml(string rspCode, string rspMsg, string BTID, string txnID)
        {

            #region 範例
            //<T24_DATA>
            //    <Rsp_Msg>
            //        <RspCode>SUCC</RspCode>
            //        <RspMsg>交易成功</RspMsg>
            //        <BTID>19195152-79CB-430F-99BB-6AE41E1EC7CE</BTID>
            //    </Rsp_Msg>
            //  </T24_DATA>
            #endregion

            XElement xDoc =
                   new XElement("Rsp_Msg",
                       new XElement("RspCode", rspCode),
                       new XElement("RspMsg", rspMsg),
                       new XElement("BTID", BTID),
                       new XElement("TxnID", txnID)
                   );

            return xDoc.ToString();
        }

        #region mapping
        string Mapping2010767To2010992(string code)
        {
            //code為查詢條件域代碼 來自2010992報文，m_code為對應的2010767域代碼，對應到存在MSMQTALK TABLE裡的2010767報文
            //若2010992 code的值與2010767 m_code的值相符，則表示條件成立
            string m_code = string.Empty;
            switch (code)
            {
                case "4102"://柜员号
                    break;
                case "4052"://客户类型
                    break;
                case "4027"://交易序号
                    m_code = "2039";
                    break;
                case "4172"://交易类型
                    break;
                case "4157"://付款账户
                    m_code = "4157";
                    break;
                case "4900"://付款人名称
                    m_code = "4900";
                    break;
                case "4161"://收款人账户
                    m_code = "4161";
                    break;
                case "4732"://收款人名称
                    m_code = "4733";
                    break;
                case "4186"://收款人行号
                    m_code = "4112";
                    break;
                case "2021"://收款人联行号
                    m_code = "2021";
                    break;
                case "4100"://转账金额
                    m_code = "4100";
                    break;
                case "4026"://转账方式
                    //m_code = "4026";
                    break;
                case "4349"://转账用途
                    //m_code = "4897";
                    break;
                case "4658"://交易附言
                    break;
                case "4107"://交易密码
                    break;
                case "4111"://IP地址
                    break;
                case "4835"://通用备用字段
                    break;
            }
            return m_code;
        }
        string Mapping2010766To2010992(string code)
        {
            //code為查詢條件域代碼 來自2010992報文，m_code為對應的2010766域代碼，對應到存在MSMQTALK TABLE裡的2010766報文
            //若2010992 code的值與2010766 m_code的值相符，則表示條件成立
            string m_code = string.Empty;
            switch (code)
            {
                case "4102"://柜员号
                    break;
                case "4052"://客户类型
                    break;
                case "4027"://交易序号
                    m_code = "2039";
                    break;
                case "4172"://交易类型
                    break;
                case "4157"://付款账户
                    m_code = "4157";
                    break;
                case "4900"://付款人名称
                    break;
                case "4161"://收款人账户
                    m_code = "4161";
                    break;
                case "4732"://收款人名称
                    m_code = "4900";
                    break;
                case "4186"://收款人行号
                    break;
                case "2021"://收款人联行号
                    break;
                case "4100"://转账金额
                    m_code = "4100";
                    break;
                case "4026"://转账方式
                    //m_code = "4026";
                    break;
                case "4349"://转账用途
                    //m_code = "4897";
                    break;
                case "4658"://交易附言
                    break;
                case "4107"://交易密码
                    break;
                case "4111"://IP地址
                    break;
                case "4835"://通用备用字段
                    break;
            }
            return m_code;
        }
        string Mapping2020579To2020656(string code)
        {
            //code為查詢條件域代碼 來自2020656報文，m_code為對應的2020579域代碼，對應到存在MSMQTALK TABLE裡的2020579報文
            //若2020656 code的值與2020579 m_code的值相符，則表示條件成立
            string m_code = string.Empty;
            switch (code)
            {
                case "4102"://柜员号
                    break;
                case "4052"://客户类型
                    break;
                case "4027"://交易序号
                    m_code = "2039";
                    break;
                case "4172"://交易类型
                    break;
                case "4157"://付款账户
                    m_code = "4323";
                    break;
                case "4900"://付款人名称
                    //m_code = "4900";
                    break;
                case "4161"://收款人账户
                    m_code = "4324";
                    break;
                case "4732"://收款人名称
                    m_code = "4897";
                    break;
                case "4186"://收款人行号
                    //m_code = "4112";
                    break;
                case "2021"://收款人联行号
                    //m_code = "2021";
                    break;
                case "4100"://转账金额
                    m_code = "4100";
                    break;
                case "4026"://转账方式
                    //m_code = "4026";
                    break;
                case "4349"://转账用途
                    //m_code = "4897";
                    break;
                case "4345"://交易渠道
                    break;
                case "4658"://交易附言
                    break;
                case "4107"://交易密码
                    break;
                case "4111"://IP地址
                    break;
                case "4835"://通用备用字段
                    break;
            }
            return m_code;
        }
        string Mapping2020580To2020656(string code)
        {
            //code為查詢條件域代碼 來自2020656報文，m_code為對應的2020580域代碼，對應到存在MSMQTALK TABLE裡的2020580報文
            //若2020656 code的值與2020580 m_code的值相符，則表示條件成立
            string m_code = string.Empty;
            switch (code)
            {
                case "4102"://柜员号
                    break;
                case "4052"://客户类型
                    break;
                case "4027"://交易序号
                    m_code = "2039";
                    break;
                case "4172"://交易类型
                    break;
                case "4157"://付款账户
                    m_code = "4157";
                    break;
                case "4900"://付款人名称
                    m_code = "4900";
                    break;
                case "4161"://收款人账户
                    m_code = "4161";
                    break;
                case "4732"://收款人名称
                    m_code = "4732";
                    break;
                case "4186"://收款人行号
                    m_code = "4186";
                    break;
                case "2021"://收款人联行号
                    m_code = "2021";
                    break;
                case "4100"://转账金额
                    m_code = "4100";
                    break;
                case "4026"://转账方式
                    //m_code = "4026";
                    break;
                case "4349"://转账用途
                    //m_code = "4349";
                    break;
                case "4345"://交易渠道
                    break;
                case "4658"://交易附言
                    break;
                case "4107"://交易密码
                    break;
                case "4111"://IP地址
                    break;
                case "4835"://通用备用字段
                    break;
            }
            return m_code;
        }
        #endregion mapping
        #endregion Cancel 2010992 2020656



        private bool UcMapping(Dictionary<string, string> ucRqBodyDic, Dictionary<string, string> ucMqBodyDic, string txnType, string txID)
        {
            Dictionary<string, string> mappingDic = new Dictionary<string, string>();//宣告域代碼對照Dictionary
            List<Dictionary<string, string>> finalMqDicLst = new List<Dictionary<string, string>>();//宣告最後取得的資料Dictionary List

            //取得域代碼對照Dictionary
            foreach (KeyValuePair<string, string> rqKV in ucRqBodyDic)
            {
                string rqKey = rqKV.Key;
                string mqKey = string.Empty;
                if (txnType == "01")//跨行
                {
                    if (txID.Contains("2010991"))//個人 查詢
                    { mqKey = Mapping2010767To2010991(rqKey); }
                    else if (txID == "2010992")//個人 撤銷
                    { mqKey = Mapping2010767To2010992(rqKey); }
                    else if (txID.Contains("2020655"))//企業 查詢
                    { mqKey = Mapping2020580To2020655(rqKey); }
                    else if (txID == "2020656")//企業 撤銷
                    { mqKey = Mapping2020580To2020656(rqKey); }
                }
                else if (txnType == "02")//行內
                {
                    if (txID.Contains("2010991"))//個人 查詢
                    { mqKey = Mapping2010766To2010991(rqKey); }
                    else if (txID == "2010992")//個人 撤銷
                    { mqKey = Mapping2010766To2010992(rqKey); }
                    else if (txID.Contains("2020655"))//企業 查詢
                    { mqKey = Mapping2020579To2020655(rqKey); }
                    else if (txID == "2020656")//企業 撤銷
                    { mqKey = Mapping2020579To2020656(rqKey); }
                }
                if (!string.IsNullOrEmpty(mqKey))
                    mappingDic.Add(rqKey, mqKey);
            }

            string mq_MsgKey = string.Empty;
            ucMqBodyDic.TryGetValue("2001", out mq_MsgKey);
            bool c_flag = true;
            if ((txnType == "01" && (mq_MsgKey == "2010767" || mq_MsgKey == "2020580")) || (txnType == "02" && (mq_MsgKey == "2010766" || mq_MsgKey == "2020579")))
            {
                //比對相對域代碼的值，若全符合，表示資料相符
                foreach (KeyValuePair<string, string> x in mappingDic)//key為查詢條件域代碼，value為查詢目標域代碼
                {
                    string ucRqValue = string.Empty;
                    string ucMqValue = string.Empty;
                    ucRqBodyDic.TryGetValue(x.Key, out ucRqValue);
                    ucMqBodyDic.TryGetValue(x.Value, out ucMqValue);
                    if ((txID.Contains("2010991") || txID.Contains("2020655")) && (x.Key == "4119" || x.Key == "4120"))
                    {
                        if (x.Key == "4119" && DateTime.ParseExact(ucRqValue, "yyyyMMdd", null) > DateTime.ParseExact(ucMqValue, "yyyyMMdd", null))
                        { c_flag = false; }
                        if (x.Key == "4120" && DateTime.ParseExact(ucRqValue, "yyyyMMdd", null) < DateTime.ParseExact(ucMqValue, "yyyyMMdd", null))
                        { c_flag = false; }
                    }
                    else if (ucRqValue != ucMqValue)
                    { c_flag = false; }
                    if (c_flag == false)
                        break;
                }
            }
            else
            { c_flag = false; }
            return c_flag;
        }

        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey, bool SendToEAI)
        {
            string msgContent = string.Empty;
            if (SendToEAI)
            { msgContent = base.SendToEAIProcess(body, eAI_MsgKey, spN_GW, custId_GW); }
            else
            { msgContent = base.SendToEAIProcess(body, eAI_MsgKey); }

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(msgContent);
            XmlDocument subRqXml = null;
            if (SendToEAI)
            { subRqXml = CopyToNewDocument(rq, spN_GW, custId_GW, eAI_MsgKey, Guid.NewGuid().ToString()); }
            else
            { subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString()); }
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, subRqXml.InnerXml);
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml, SendToEAI);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }

        void ParseUcToDic(string rsString, out Dictionary<string, string> ucHeadDic, out Dictionary<string, string> ucBodyDic)
        {
            if (string.IsNullOrEmpty(rsString))
            {
                ucHeadDic = new Dictionary<string, string>();
                ucBodyDic = new Dictionary<string, string>();
                return;
            }
            UcControler uCcontroler = new UcControler();
            UcBody ucBody = new UcBody();
            ucHeadDic = uCcontroler.UC2T24_Head(rsString);
            ucBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);
            m_log.Debug("ParseUcToDic rsString = [{0}]", rsString);
            foreach (KeyValuePair<string, string> kv in ucHeadDic)
            { m_log.Debug("ucHead = [{0}][{1}]", kv.Key, kv.Value); }
            foreach (KeyValuePair<string, string> kv in ucBodyDic)
            { m_log.Debug("ucBody = [{0}][{1}]", kv.Key, kv.Value); }
        }

        public List<Dictionary<string, string>> DatasetToDiclist(DataSet dataset)
        {
            List<Dictionary<string, string>> lstdata = new List<Dictionary<string, string>>();

            foreach (DataRow drow in dataset.Tables[0].Rows)
            {
                Dictionary<string, string> tempData = new Dictionary<string, string>();

                for (int i = 0; i <= drow.ItemArray.Length - 1; i++)
                {
                    tempData.Add(dataset.Tables[0].Columns[i].ColumnName, drow.ItemArray[i].ToString());
                }
                lstdata.Add(tempData);
            }
            return lstdata;
        }

    }
}
