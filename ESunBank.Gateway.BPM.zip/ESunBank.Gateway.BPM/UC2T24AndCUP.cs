﻿using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using Bankpro.EAI.Utility;
using ESunBank.Gateway.BPM.Util;
using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace ESunBank.Gateway.BPM
{
    public class UC2T24AndCUP : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.Gateway.BPM.UC2T24AndCUP");
        private const string spN_GW = "GW";
        private const string custId_GW = "GW";
        UCCommonUtil ucComUtil = new UCCommonUtil();

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            switch (txID)
            {
                //case "2010504"://子帳戶信息查詢 --> 180927移動到EAI.BPM
                //    return Do_2010504_Process(context, correlationID, txID, txDef, requestXml);

            }
            EaiResponse eaiRs = null;
            XmlDocument responseXml = null;
            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }

        //private AppXmlExecResult Do_2010504_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        //{
        //    try
        //    {
        //        XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
        //        string rq_t24_data = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
        //        m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", rq_t24_data);

        //        #region 分析報文
        //        UcControler uCcontroler = new UcControler();
        //        UcBody ucBody = new UcBody();
        //        Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(rq_t24_data);
        //        Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

        //        string AccNo = string.Empty;
        //        rqBodyDic.TryGetValue("4300", out AccNo);
        //        #endregion 分析報文

        //        if (AccNo.Length > 15)//Card
        //        {
        //            return DoCUSTOACCTProcess(context, uCcontroler, xmlHelper, requestXml, rqHeadDic, rqBodyDic, txID, AccNo);
        //        }
        //        else //ACC
        //        {
        //            string newucString = string.Format("<T24_DATA>{0}</T24_DATA>", rq_t24_data);
        //            return ucpw.SendMsgToEAIProcess(context, newucString, txID, true);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        m_log.ErrorException(string.Format("Do_2010504_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
        //        XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
        //        return base.BuildExecResult(context, responseXml);
        //    }
        //}

        //private AppXmlExecResult DoCUSTOACCTProcess(EaiContext context, UcControler uCcontroler, XmlHelper xmlHelper, XmlDocument requestXml, Dictionary<string, string> rqHeadDic, Dictionary<string, string> rqBodyDic, string txID, string AccNo)
        //{
        //    #region 1. 5001
        //    string bodyCUP = Get5001_ENQ_Content(AccNo);
        //    AppXmlExecResult cup_result = ucpw.SendMsgToEAIProcess(context, bodyCUP, "5001", true);
        //    XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
        //    string retCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RETCODE");
        //    string cardStat = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//CARD_STAT");
        //    string frzType = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FRZTYPE");
        //    m_log.Info("DoES_2010504Process CARD STATUS: Card id=" + AccNo + ", statusCode=" + retCode + ", Stat=" + cardStat + ", FrzType=" + frzType);
        //    #endregion 1. 5001

        //    #region 2. CUS.TOACCT.ENQ.DTL
        //    string bodyCardEnq = GetT24_CardENQ_Content(AccNo);
        //    AppXmlExecResult cardEnq_result = ucpw.SendMsgToEAIProcess(context, bodyCardEnq, "CUS.TOACCT.ENQ.DTL", true);

        //    XmlHelper xmlHelperCardEnq = XmlHelper.GetInstance(cardEnq_result.ResponseXml);
        //    string acct_No = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//ACCT_NO").Trim();
        //    #endregion 2. CUS.TOACCT.ENQ.DTL

        //    #region 3. 產生FileContentList落檔上傳FTP並回覆結果
        //    List<string> fileContentList = new List<string>();
        //    Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
        //    rs_succ_otherBodyDic.Add("2028", "CO1M0000");

        //    //retCode為000000代表「正常」(以排除卡號不存在)，cardStat為空代表「正常」
        //    if (!retCode.Equals("000000") || !cardStat.Equals("") && string.IsNullOrEmpty(acct_No))
        //    {
        //        fileContentList.Add("");
        //        rs_succ_otherBodyDic.Add("4305", "0");//總筆數
        //    }
        //    else//查有資料
        //    {
        //        fileContentList = CreateFileContentList(xmlHelperCUPRS, cup_result.ResponseXml, cardEnq_result.ResponseXml,
        //                                                                     fileContentList, AccNo, retCode, cardStat, acct_No);
        //        rs_succ_otherBodyDic.Add("4305", fileContentList.Count.ToString());//總筆數
        //    }
        //    uCcontroler.CreateEnqFileToUC(fileContentList, true);
        //    rs_succ_otherBodyDic.Add("zzzx", uCcontroler.enqFileName);//文件名
        //    string rs_succ_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

        //    m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_String);
        //    XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_String);
        //    return base.BuildExecResult(context, rs);
        //    #endregion 3. 產生FileContentList落檔上傳FTP並回覆結果
        //}

        private List<string> CreateFileContentList(XmlHelper xmlHelperCUPRS, XmlDocument CardxmlDocument,
                                                                         XmlDocument xmlDocument, List<string> fileContentList, string AccNo,
                                                                         string retCode, string cardStat, string acct_No)
        {
            try
            {
                #region 銀聯Response
                string car_acct_Seno = AccNo.Substring(AccNo.Length - 10);
                string car_acct_No = AccNo;
                string car_Currency = "CNY";
                string car_acct_Title = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//NAME");
                string car_acct_Type = "02";
                string car_Term = "D0";
                string car_c_Rollover_Amt = "";
                string car_c_Fcy_Type = "3";
                string car_opening_Date = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//OPEN_DATE");
                string car_c_Maturity_Date = "";
                string car_val_Date = "";
                string car_c_Dep_Amt = "";
                string car_y_Interest = "";
                string car_y_Tax = "";
                string car_working_Bal = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//BALANCE2");
                string car_onl_Cleared_Bal = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//BALANCE1");
                string car_account_Type = "1";
                string card_acct_Status = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//CARD_STAT");
                string car_acct_Status = Get_Acct_Status(card_acct_Status);
                string car_c_Int_Rate = "";
                string car_ac_Company = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//BRN_NO");
                string car_company_Name = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//BRN_NO");
                string car_ntc_Status = "";
                string car_c_Remark = "";
                string car_ntc_Amt = "";
                string car_ntc_Bal = "";
                string car_ntc_Prsv_Amt = "";

                if (!retCode.Equals("000000") || !cardStat.Equals(""))
                {
                    fileContentList.Add("");
                }
                else
                {
                    StringBuilder sb_car = new StringBuilder();
                    sb_car.Append(car_acct_Seno).Append("|");//子账户序号
                    sb_car.Append(car_acct_No).Append("|");//子帐号账号
                    sb_car.Append(car_Currency).Append("|");//币种
                    sb_car.Append(car_acct_Title).Append("|");//账户名称
                    sb_car.Append(car_acct_Type).Append("|");//储种
                    sb_car.Append(car_Term).Append("|");//存期ㄍ
                    sb_car.Append(car_c_Rollover_Amt).Append("|");//转存标志
                    sb_car.Append(car_c_Fcy_Type).Append("|");//钞汇标志
                    sb_car.Append(car_opening_Date).Append("|");//开户日期
                    sb_car.Append(car_c_Maturity_Date).Append("|");//到期日期
                    sb_car.Append(car_val_Date).Append("|");//起息日期
                    sb_car.Append(car_c_Dep_Amt).Append("|");//本金
                    sb_car.Append(car_y_Interest).Append("|");//利息
                    sb_car.Append(car_y_Tax).Append("|");//利息税
                    sb_car.Append(car_working_Bal).Append("|");//可用余额
                    sb_car.Append(car_onl_Cleared_Bal).Append("|");//账户余额
                    sb_car.Append(car_account_Type).Append("|");//账户类型
                    sb_car.Append(car_acct_Status).Append("|");//账户状态
                    sb_car.Append(car_c_Int_Rate).Append("|");//利率
                    sb_car.Append(car_ac_Company).Append("|");//开户机构号
                    sb_car.Append(car_company_Name).Append("|");//开户机构名
                    sb_car.Append(car_ntc_Status).Append("|");//通知状态
                    sb_car.Append(car_c_Remark).Append("|");//摘要
                    sb_car.Append(car_ntc_Amt).Append("|");//已通知金额
                    sb_car.Append(car_ntc_Bal).Append("|");//未通知余额
                    sb_car.Append(car_ntc_Prsv_Amt).Append("|");//预约支取金额
                    fileContentList.Add(sb_car.ToString());
                }
                #endregion 銀聯Response

                #region T24Response
                XDocument xDocument = XDocument.Parse(xmlDocument.InnerXml);
                var enqDataLst = xDocument.Root
                                          .DescendantNodes().OfType<XElement>()
                                          .Where(p => p.Name.LocalName == "RSP_MSG_ROW")
                                          .ToList();

                if (string.IsNullOrEmpty(acct_No))
                {
                    fileContentList.Add("");
                }
                else 
                {
                    foreach (XElement xE in enqDataLst)
                    {
                        StringBuilder sb = new StringBuilder();
                        IEnumerable<XElement> subXE = xE.DescendantNodes().OfType<XElement>();

                        string acct_Seno = subXE.Where(p => p.Name.LocalName == "ACCT_SENO").SingleOrDefault().Value.Trim();
                        sb.Append(acct_Seno).Append("|");//子账户序号

                        acct_No = subXE.Where(p => p.Name.LocalName == "ACCT_NO").SingleOrDefault().Value.Trim();
                        sb.Append(acct_No).Append("|");//子帐号账号

                        string Currency = subXE.Where(p => p.Name.LocalName == "CURRENCY").SingleOrDefault().Value.Trim();
                        sb.Append(Currency).Append("|");//币种

                        string acct_Title = subXE.Where(p => p.Name.LocalName == "ACCT_TITLE").SingleOrDefault().Value.Trim();
                        sb.Append(acct_Title).Append("|");//账户名称

                        string acct_Type = subXE.Where(p => p.Name.LocalName == "ACCT_TYPE").SingleOrDefault().Value.Trim();
                        sb.Append(acct_Type).Append("|");//储种

                        string Term = subXE.Where(p => p.Name.LocalName == "TERM").SingleOrDefault().Value.Trim();
                        sb.Append(Term).Append("|");//存期

                        string c_Rollover_Amt = subXE.Where(p => p.Name.LocalName == "C_ROLLOVER_AMT").SingleOrDefault().Value.Trim();
                        sb.Append(c_Rollover_Amt).Append("|");//转存标志

                        string c_Fcy_Type = subXE.Where(p => p.Name.LocalName == "C_FCY_TYPE").SingleOrDefault().Value.Trim();
                        sb.Append(c_Fcy_Type).Append("|");//钞汇标志

                        string opening_Date = subXE.Where(p => p.Name.LocalName == "OPENING_DATE").SingleOrDefault().Value.Trim();
                        sb.Append(opening_Date).Append("|");//开户日期

                        string c_Maturity_Date = subXE.Where(p => p.Name.LocalName == "C_MATURITY_DATE").SingleOrDefault().Value.Trim();
                        sb.Append(c_Maturity_Date).Append("|");//到期日期

                        string val_Date = subXE.Where(p => p.Name.LocalName == "VAL_DATE").SingleOrDefault().Value.Trim();
                        sb.Append(val_Date).Append("|");//起息日期

                        string c_Dep_Amt = subXE.Where(p => p.Name.LocalName == "C_DEP_AMT").SingleOrDefault().Value.Trim();
                        sb.Append(c_Dep_Amt).Append("|");//本金

                        string y_Interest = subXE.Where(p => p.Name.LocalName == "Y_INTEREST").SingleOrDefault().Value.Trim();
                        sb.Append(y_Interest).Append("|");//利息

                        string y_Tax = subXE.Where(p => p.Name.LocalName == "Y_TAX").SingleOrDefault().Value.Trim();
                        sb.Append(y_Tax).Append("|");//利息税

                        string working_Bal = subXE.Where(p => p.Name.LocalName == "WORKING_BAL").SingleOrDefault().Value.Trim();
                        sb.Append(working_Bal).Append("|");//可用余额

                        string onl_Cleared_Bal = subXE.Where(p => p.Name.LocalName == "ONL_CLEARED_BAL").SingleOrDefault().Value.Trim();
                        sb.Append(onl_Cleared_Bal).Append("|");//账户余额

                        string account_Type = subXE.Where(p => p.Name.LocalName == "ACCOUNT_TYPE").SingleOrDefault().Value.Trim();
                        sb.Append(account_Type).Append("|");//账户类型

                        string acct_Status = subXE.Where(p => p.Name.LocalName == "ACCT_STATUS").SingleOrDefault().Value.Trim();
                        sb.Append(acct_Status).Append("|");//账户状态

                        string c_Int_Rate = subXE.Where(p => p.Name.LocalName == "C_INT_RATE").SingleOrDefault().Value.Trim();
                        sb.Append(c_Int_Rate).Append("|");//利率

                        string ac_Company = subXE.Where(p => p.Name.LocalName == "AC_COMPANY").SingleOrDefault().Value.Trim();
                        sb.Append(ac_Company).Append("|");//开户机构号

                        string company_Name = subXE.Where(p => p.Name.LocalName == "COMPANY_NAME").SingleOrDefault().Value.Trim();
                        sb.Append(company_Name).Append("|");//开户机构名

                        string ntc_Status = subXE.Where(p => p.Name.LocalName == "NTC_STATUS").SingleOrDefault().Value.Trim();
                        sb.Append(ntc_Status).Append("|");//通知状态

                        string c_Remark = subXE.Where(p => p.Name.LocalName == "C_REMARK").SingleOrDefault().Value.Trim();
                        sb.Append(c_Remark).Append("|");//摘要

                        string ntc_Amt = subXE.Where(p => p.Name.LocalName == "NTC_AMT").SingleOrDefault().Value.Trim();
                        sb.Append(ntc_Amt).Append("|");//已通知金额

                        string ntc_Bal = subXE.Where(p => p.Name.LocalName == "NTC_BAL").SingleOrDefault().Value.Trim();
                        sb.Append(ntc_Bal).Append("|");//未通知余额

                        string ntc_Prsv_Amt = subXE.Where(p => p.Name.LocalName == "NTC_PRSV_AMT").SingleOrDefault().Value.Trim();
                        sb.Append(ntc_Prsv_Amt).Append("|");//预约支取金额

                        fileContentList.Add(sb.ToString());
                    }
                }
                #endregion T24Response

                return fileContentList;
            }
            catch (Exception ex)
            {
                m_log.ErrorException("CreateFileContentList Error!!!" + ex.ToString(), ex);
                return null;
            }
        }

        private string Get_Acct_Status(string card_acct_Status)
        {
            switch (card_acct_Status) 
            {
                case "":
                    return "0";
                case "Q":
                    return "6";
                case "C":
                    return "5";
                default:
                    return card_acct_Status;
            }
        }

        private string Get5001_ENQ_Content(string AccNo)
        {
            StringBuilder sb = new StringBuilder();
            #region 5001 ACC BAL XML MSG

            sb.AppendFormat("<TRXTYPE>{0}</TRXTYPE>", "5001");
            sb.AppendFormat("<RETCODE>{0}</RETCODE>", "");
            sb.AppendFormat("<BNKNBR>{0}</BNKNBR>", "0345");
            sb.AppendFormat("<SOURCE>{0}</SOURCE>", "CT");
            sb.AppendFormat("<BRN_NO>{0}</BRN_NO>", "010002");
            sb.AppendFormat("<OPE_NO>{0}</OPE_NO>", "000001");
            sb.AppendFormat("<SEQNO>{0}</SEQNO>", "100921");
            sb.AppendFormat("<CARDNO>{0}</CARDNO>", AccNo);
            sb.AppendFormat("<PINFLAG>{0}</PINFLAG>", "0");
            sb.AppendFormat("<PIN>{0}</PIN>", "");

            #endregion
            return sb.ToString();
        }

        private string GetT24_CardENQ_Content(string AccNo)
        {
            StringBuilder sb = new StringBuilder();
            #region CUS.TOACCT.ENQ.DTL XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "CUS.TOACCT.ENQ.DTL");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0052");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<_x0040_ID op='EQ'>{0}</_x0040_ID>", AccNo);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

    }
}
