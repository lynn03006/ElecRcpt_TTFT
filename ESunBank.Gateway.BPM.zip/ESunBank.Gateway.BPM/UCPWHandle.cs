﻿using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using Bankpro.EAI.Utility;
using ESunBank.Gateway.BPM.Util;
using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace ESunBank.Gateway.BPM
{
    public class UCPWHandle : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.Gateway.BPM.UCPWHandle");
        private const string spN_GW = "GW";
        private const string custId_GW = "GW";

        public UCPWHandle()
        {
        }

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                AppXmlExecResult pwResultXml = null;

                TxPWChk txPWChk = new TxPWChk();
                pwResultXml = txPWChk.Run(context, correlationID, txID, txDef, requestXml);

                
                //若檢核正確，將電文往EAI發；否則回覆「交易密碼錯誤」訊息
                if (pwResultXml == null)
                {

                    //檢核密碼
                    TxSettings txSettings = txDef.TITA.Settings;
                    string afterPW = txSettings.GetString("AfterPW", "");
                    
                    //若為ES開頭，則需去掉「ES_」後往GW內部再打一次
                    //->為避免如2010766等，需帶著ES走往EAI BPM的交易，改成判斷AfterPW，來檢查是否是重打GW
                    if (afterPW.Contains("GW"))
                    {
                        //若為ES開頭，則需去掉「ES_」後往GW內部再打一次，FOR BPM在GW的交易
                        XmlDocument subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                        return Send1Recv1(m_log, context, subRqXml, false);
                    }
                    else
                    {
                        string newucString = string.Format("<T24_DATA>{0}</T24_DATA>", txPWChk.rq_t24_data);
                        return SendMsgToEAIProcess(context, newucString, txID, spN_GW, custId_GW, true);
                    }
                    
                }
                else
                {
                    return pwResultXml;
                }

            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("PWHandle Error TxID=[{0}]", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
   
        }

    }
}
