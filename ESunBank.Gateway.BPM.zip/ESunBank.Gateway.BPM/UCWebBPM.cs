﻿using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using Bankpro.EAI.Utility;
using ESunBank.Gateway.BPM.Util;
using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace ESunBank.Gateway.BPM
{
    public class UCWebBPM : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.Gateway.BPM.UCWebBPM");
        private const string spN_GW = "GW";
        private const string custId_GW = "GW";
        Common com = new Common();
        UCCommonUtil ucComUtil = new UCCommonUtil();

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            switch (txID)
            {
                case "2040502"://查询电子回单详细
                    return Do_2040502_Process(context, correlationID, txID, txDef, requestXml);

            }
            EaiResponse eaiRs = null;
            XmlDocument responseXml = null;
            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }

        private AppXmlExecResult Do_2040502_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", rq_t24_data);

                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(rq_t24_data);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string AllCount = string.Empty, FileName = string.Empty;
                rqBodyDic.TryGetValue("4305", out AllCount);
                rqBodyDic.TryGetValue("zzzx", out FileName);
                #endregion 1.分析報文

                #region 2.下載ftp檔案並取ftNo組成字串
                String fileCont = String.Empty, ftNo = String.Empty, FtNo = String.Empty;
                String[] fileContArr = new String[] { };
                String[] lineCont = new String[] { };

                if (AllCount != "0")
                {
                    m_log.Info("DownloadFTP : [{0}]!!", FileName);

                    string savePath = Environment.ExpandEnvironmentVariables(ProjectConfig.GetInstance().DropFilesPath) + FileName;
                    fileCont = com.DownloadFTP(FileName);
                    com.CreateEnqFile(savePath, fileCont);
                    fileContArr = fileCont.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

                    foreach (var f in fileContArr)
                    {
                        lineCont = f.Split('|');
                        ftNo = lineCont[0];

                        FtNo += ftNo + ",";
                    }
                }
                #endregion 2.下載ftp檔案並取ftNo組成字串

                #region 3. ESCN.IB.TXN.DTL.ENQ
                string bodyEnq = GetT24_ENQ_Content(FtNo);
                AppXmlExecResult Enq_result = SendMsgToEAIProcess(context, bodyEnq, "ESCN.IB.TXN.DTL.ENQ", spN_GW, custId_GW, true);

                XmlHelper xmlHelperEnq = XmlHelper.GetInstance(Enq_result.ResponseXml);
                #endregion 3. ESCN.IB.TXN.DTL.ENQ

                #region 4. 產生FileContentList落檔上傳FTP並回覆結果
                List<string> fileContentList = new List<string>();
                fileContentList = CreateFileContentList(Enq_result.ResponseXml, fileContentList);
                uCcontroler.CreateEnqFileToUC(fileContentList, true);

                Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
                rs_succ_otherBodyDic.Add("2028", "CO1M0000");
                rs_succ_otherBodyDic.Add("4305", fileContentList.Count.ToString());//總筆數
                rs_succ_otherBodyDic.Add("zzzx", uCcontroler.enqFileName);//文件名
                string rs_succ_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_String);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_String);
                return base.BuildExecResult(context, rs);
                #endregion 4. 產生FileContentList落檔上傳FTP並回覆結果
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2040502_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        private List<string> CreateFileContentList(XmlDocument xmlDocument, List<string> fileContentList)
        {
            XDocument xDocument = XDocument.Parse(xmlDocument.InnerXml);
            var enqDataLst = xDocument.Root
                                      .DescendantNodes().OfType<XElement>()
                                      .Where(p => p.Name.LocalName == "RSP_MSG_ROW")
                                      .ToList();
            foreach (XElement xE in enqDataLst)
            {
                StringBuilder sb = new StringBuilder();
                IEnumerable<XElement> subXE = xE.DescendantNodes().OfType<XElement>();

                string debit_Acct_No = subXE.Where(p => p.Name.LocalName == "DEBIT_ACCT_NO").SingleOrDefault().Value.Trim();
                sb.Append(debit_Acct_No).Append("|");//付款账号

                string debit_Name = subXE.Where(p => p.Name.LocalName == "DEBIT_NAME").SingleOrDefault().Value.Trim();
                sb.Append(debit_Name).Append("|");//付款人

                string credit_Acct_No = subXE.Where(p => p.Name.LocalName == "CREDIT_ACC_NO").SingleOrDefault().Value.Trim();
                sb.Append(credit_Acct_No).Append("|");//收款人账号

                string credit_Name = subXE.Where(p => p.Name.LocalName == "C_PAYEE_NAME").SingleOrDefault().Value.Trim();
                sb.Append(credit_Name).Append("|");//收款人名称

                string credit_Com_No = subXE.Where(p => p.Name.LocalName == "CREDIT_COM_CO").SingleOrDefault().Value.Trim();
                sb.Append(credit_Com_No).Append("|");//收款人行号

                string credit_Com_Name = subXE.Where(p => p.Name.LocalName == "CREDIT_COM_NAME").SingleOrDefault().Value.Trim();
                sb.Append(credit_Com_Name).Append("|");//收款人行名

                string debit_Amt = subXE.Where(p => p.Name.LocalName == "DEBIT_AMOUNT").SingleOrDefault().Value.Trim();
                sb.Append(debit_Amt).Append("|");//付款金额

                string Currency = subXE.Where(p => p.Name.LocalName == "DEBIT_CURRENCY").SingleOrDefault().Value.Trim();
                sb.Append(Currency).Append("|");//币种

                string Charge = subXE.Where(p => p.Name.LocalName == "CHARGE").SingleOrDefault().Value.Trim();
                sb.Append(Charge).Append("|");//手续费

                string debit_Ref = subXE.Where(p => p.Name.LocalName == "DEBIT_THEIR_REF").SingleOrDefault().Value.Trim();
                sb.Append(debit_Ref).Append("|");//付款用途

                string c_Remarks = subXE.Where(p => p.Name.LocalName == "C_REMARKS").SingleOrDefault().Value.Trim();
                sb.Append(c_Remarks).Append("|");//交易附言

                string trans_Ref = subXE.Where(p => p.Name.LocalName == "TRANS_REF").SingleOrDefault().Value.Trim();
                sb.Append(trans_Ref).Append("|");//交易流水

                string ver_Code = subXE.Where(p => p.Name.LocalName == "VERIFICATION_CODE").SingleOrDefault().Value.Trim();
                sb.Append(ver_Code).Append("|");//授权码

                string print_Count = subXE.Where(p => p.Name.LocalName == "PRINT_COUNT").SingleOrDefault().Value.Trim();
                sb.Append(print_Count).Append("|");//打印次數

                string print_Person = subXE.Where(p => p.Name.LocalName == "PRINT_PERSON").SingleOrDefault().Value.Trim();
                sb.Append(print_Person).Append("|");//打印人員

                string debit_Com_No = subXE.Where(p => p.Name.LocalName == "DEBIT_COM_CO").SingleOrDefault().Value.Trim();
                sb.Append(debit_Com_No).Append("|");//付款人行號

                string debit_Com_Name = subXE.Where(p => p.Name.LocalName == "DEBIT_COM_NAME").SingleOrDefault().Value.Trim();
                sb.Append(debit_Com_Name).Append("|");//付款人行名

                fileContentList.Add(sb.ToString());
            }
            return fileContentList;
        }

        private string GetT24_ENQ_Content(string FtNo)
        {
            StringBuilder sb = new StringBuilder();
            #region CUS.TOACCT.ENQ.DTL XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.IB.TXN.DTL.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "IB001.0007");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<FT_NO op='EQ'>{0}</FT_NO>", FtNo);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }


    }
}
