﻿using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using ESunBank.Gateway.BPM;
using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

using Bankpro.EAI.Utility;

namespace Bankpro.EAI.BPM.UCMobile
{
    public class UCMobileExe : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.Gateway.BPM.UCMobileExe");

        public UCMobileExe()
        {
        }

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            switch (txID)
            {
                case "2010585": //(开销户)网银/移动银行自助签约/解约
                    return Do2010585Process(context, correlationID, txID, txDef, requestXml);
                case "2011026": //云证通签约/解约
                    return Do2011026Process(context, correlationID, txID, txDef, requestXml);
                case "2010586": //网银移动银行自助开户
                    return Do2010586Process(context, correlationID, txID, txDef, requestXml);
                case "2010810" : //帳戶掛失
                    return Do2010810Process(context, correlationID, txID, txDef, requestXml);
                default:
                    return DoDefaultProcess(context, correlationID, txID, txDef, requestXml);

            }
        }

        /// <summary>
        /// 网银移动银行自助开户
        /// </summary>
        private AppXmlExecResult Do2010586Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            XmlDocument responseXml = null; 
            string rsString = string.Empty;
            try
            {
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

                Dictionary<string, string> headDic; 
                Dictionary<string, string> bodyDic;
                string acctId_4300 = string.Empty;
                ParseUcToDic(rq_t24_data, out headDic, out bodyDic);
                if (bodyDic.TryGetValue("4300", out acctId_4300))
                {
                    string rq_t24_enq = GetT24_AcntInfoEnq_Content(acctId_4300);
                    AppXmlExecResult t24Enq_result = SendMsgToEAIProcess(context, rq_t24_enq, "ACC.CUST.INFO.ENQ");
                    
                    Dictionary<string, string> rsDic = Check2010586_4300(context, bodyDic, t24Enq_result.ResponseXml);

                    m_log.Debug("rq_t24_enq = [{0}] ", rq_t24_enq);
                    m_log.Debug("t24Enq_result.ResponseXml.OuterXml = [{0}]", t24Enq_result.ResponseXml.OuterXml);

                    rsString = this.GetRsStringFromRqDic(headDic, bodyDic, rsDic);
                }
                responseXml = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, responseXml);
            }
            catch(Exception ex)
            {
                m_log.ErrorException(string.Format("Do2010586Process Error TxID=[{0}]", txID) + ex.ToString(), ex);
                responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        /// <summary>
        /// 以域代碼4300(帳號)查詢ACC.CUST.INFO.ENQ
        /// [客戶訊息正確]：將域代碼4107存入T24，並將查詢得到的欄位組成2010586回覆電文
        /// [例外狀況]：1.查無此帳戶 2.欄位檢核不相符 3.交易密碼寫入失敗
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, string> Check2010586_4300(EaiContext context, Dictionary<string, string> ucbody_dic, XmlDocument t24_xmlDocument)
        {
            string ucwebcustId, password_4107, acct_4300, errorMsg = string.Empty;
            Dictionary<string, string> ucRsdic = new Dictionary<string, string>();

            XmlHelper xmlHelperT24Enq = XmlHelper.GetInstance(t24_xmlDocument);
            ucwebcustId = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebCustId");

            if (!string.IsNullOrEmpty(ucwebcustId))
            {
                #region 域代碼4300 有從ACC.CUST.INFO.ENQ查回資料
                string compareMsg = string.Empty;
                bool matchFlag = Compare2010586_T24RS(ucbody_dic, t24_xmlDocument, out compareMsg);
                if (matchFlag)
                {
                    ucbody_dic.TryGetValue("4107", out password_4107);
                    string ofs_rq = Build_ESCN_IB_IDENCHK_OFS(ucwebcustId, password_4107);
                    AppXmlExecResult rsResult = SendMsgToEAIProcess(context, ofs_rq, "OFS");                 
                    XmlHelper xHelper = XmlHelper.GetInstance(rsResult.ResponseXml);
                    string ofs_rs = xHelper.GetXPath(rsResult.ResponseXml, "//T24_DATA").Trim();
                    m_log.Debug("ESCN.IB.IDEN.RECO.CHK Response =[{0}]", ofs_rs);
                    bool rsSucc = ofs_rs.StartsWith(ucwebcustId + "//1");
                    bool rsFail = ofs_rs.StartsWith(ucwebcustId + "//-1");                 
                    bool rsNotChanged = ofs_rs.Contains("LIVE RECORD NOT CHANGED");

                    if ((rsFail && rsNotChanged) || rsSucc)
                    {
                        #region 若密碼4107儲存成功，則將ENQ回覆的欄位組成2010586的dictionary
                        ucbody_dic.TryGetValue("4300", out acct_4300);
                        string ucwebcustnm, ucwebgender, ucweblegtype, ucweblegid, ucwebacctnm,
                               ucwebaccttype, ucwebcurr, ucwebbc, ucwebacctcom, ucwebacctcomcn,
                               ucwebphone, ucwebmail, ucwebmobile, ucwebpostal, ucwebaddr = string.Empty;

                        ucwebcustnm = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebCustNm");
                        ucwebgender = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebGender");
                        ucweblegtype = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebLegType");
                        ucweblegid = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebLegId");
                        ucwebacctnm = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebAcctNm");
                        ucwebaccttype = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebAcctType");
                        ucwebcurr = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebCurr");
                        ucwebbc = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebBC");
                        ucwebacctcom = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebAcctCom");
                        ucwebacctcomcn = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebAcctComCN");
                        ucwebphone = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebPhone");
                        ucwebmail = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebMail");
                        ucwebmobile = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebMobile");
                        ucwebpostal = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebPostal");
                        ucwebaddr = xmlHelperT24Enq.GetXPath(t24_xmlDocument, "//UCWebAddr");
                                              
                        ucRsdic = new Dictionary<string, string>()
                        {
                            {"2028", "CO1M0000" },
                            {"4001",ucwebcustId},
                            {"4732",ucwebcustnm},
                            {"4002",ucwebgender},
                            {"4105",ucweblegtype},
                            {"4106",ucweblegid},
                            {"4300",acct_4300},
                            {"4733",ucwebacctnm},
                            {"4306",ucwebaccttype},
                            {"4118",ucwebcurr},
                            {"4011",ucwebbc},
                            {"4112",ucwebacctcom},
                            {"4658",ucwebacctcomcn},
                            {"4006",ucwebphone},
                            {"4004",ucwebmail},
                            {"4005",ucwebmobile},
                            {"4036",ucwebpostal},
                            {"4734",ucwebaddr}
                        };
                        return ucRsdic;
                        #endregion
                    }
                    else
                    {
                        errorMsg = ErrorCodeMapping("BPM", "E-PWDINSERR");
                        return new Dictionary<string, string>() { { "2028", "CO1MA999" }, { "2038", errorMsg } };
                    }
                }
                else
                {
                    errorMsg = ErrorCodeMapping("BPM", "E-INFNOTMATCH") + ": " + compareMsg;
                    return new Dictionary<string, string>() { { "2028", "CO1MA999" }, { "2038", errorMsg } };
                }
                #endregion
            }
            else
            {
                errorMsg = ErrorCodeMapping("BPM", "E-NOACCT");
                return new Dictionary<string, string>() { { "2028", "CO1M0101" }, { "2038", errorMsg } };
            }
        }
        /// <summary>
        /// 檢核2010586城商代碼的值是否跟ACC.CUST.INFO.ENQ查回來的五個欄位相符
        /// </summary>
        private bool Compare2010586_T24RS(Dictionary<string, string> ucbody_dic, XmlDocument t24_xmlDocument, out string nomatchMsg)
        {
            string[] ucwebArray = new string[] { "//UCWebAcctType", "//UCWebCustNm", "//UCWebLegType", "//UCWebLegId", "//UCWebMobile" };
            string[] userInputArray = new string[] { "4306", "4658", "4105", "4106", "4005" };
            string ucwebValue, userInput = string.Empty;
            bool compareFlag = true;
            nomatchMsg = string.Empty;
            XmlHelper xmlHelperT24Enq = XmlHelper.GetInstance(t24_xmlDocument);
            for (int i = 0; i < ucwebArray.Length; i++)
            {
                ucwebValue = xmlHelperT24Enq.GetXPath(t24_xmlDocument, ucwebArray[i]);
                ucbody_dic.TryGetValue(userInputArray[i], out userInput);
                if (!userInput.Equals(ucwebValue))
                {
                    compareFlag = false;
                    nomatchMsg = userInput;
                    break;
                }
            }            
            return compareFlag;
        }
        /// <summary>
        /// 組ESCN.IB.IDEN.RECO.CHK,INPUT的OFS
        /// </summary>
        /// <param name="ucwebcustId">RECID及INPUSER</param>
        /// <param name="acctpwd_4107">IDEN</param>
        /// <returns></returns>
        private string Build_ESCN_IB_IDENCHK_OFS(string ucwebcustId, string acctpwd_4107)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<T24_DATA>");
            sb.AppendFormat("ESCN.IB.IDEN.RECO.CHK,INPUT/I/PROCESS,{0}/{1},{2},",
                             ProjectConfig.GetInstance().OfsUser,
                             ProjectConfig.GetInstance().OfsPwd,
                             ucwebcustId);
            sb.AppendFormat("ITF.MSGKEY:1:1={0},", "IB001.0003");
            sb.AppendFormat("CHANNEL.ID:1:1={0},", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("TERM.NO:1:1={0},", System.Environment.MachineName);
            sb.AppendFormat("EXT.BUSS.DATE:1:1={0},", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("EXT.REFERENCE:1:1={0},", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("EXT.TXN.TIME:1:1={0},", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("IDEN:1:1={0},", acctpwd_4107);
            sb.AppendFormat("INPUSER:1:1={0}", ucwebcustId);
            sb.Append("</T24_DATA>");

            m_log.Debug("ESCN.IB.IDEN.RECO.CHK Request =[{0}]", sb.ToString());
            return sb.ToString();
        }

        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string t24_xml, string eAI_MsgKey)
        {
            string msgContent = base.SendToEAIProcess(t24_xml, eAI_MsgKey, "GW", "GW");
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, msgContent);

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(msgContent);
            XmlDocument subRqXml = CopyToNewDocument(rq, "GW", "GW", eAI_MsgKey, Guid.NewGuid().ToString());
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml, true);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }

        private string GetT24_AcntInfoEnq_Content(string acctNo)
        {
            StringBuilder sb = new StringBuilder();
            #region ACC.CUST.INFO.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ACC.CUST.INFO.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0043");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<FIELD.1 op='EQ'>{0}</FIELD.1>", acctNo);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        /// <summary>
        /// 网银/移动银行自助签约/解约
        /// </summary>
        private AppXmlExecResult Do2010585Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            XmlDocument responseXml = null; string rsString = string.Empty;
            try
            {
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

                Dictionary<string, string> headDic; Dictionary<string, string> bodyDic;
                string custId_4001 = string.Empty; string actType_4070 = string.Empty;
                ParseUcToDic(rq_t24_data, out headDic, out bodyDic);

                if (bodyDic.TryGetValue("4070", out actType_4070) && bodyDic.TryGetValue("4001", out custId_4001))
                {
                    string qyFlag = (actType_4070 == "1" || actType_4070 == "3") ? "1"
                                  : (actType_4070 == "2" || actType_4070 == "4") ? "4"
                                  : null;
                    if (!string.IsNullOrEmpty(qyFlag))
                    { rsString = this.GetRsStringFromRqDic(headDic, bodyDic, new Dictionary<string, string>() { { "2028", "CO1M0000" }, { "4001", custId_4001 }, { "4178", qyFlag } }); }
                }
                responseXml = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, responseXml);
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do2010585Process Error TxID=[{0}]", txID) + ex.ToString(), ex);
                responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        /// <summary>
        /// 云证通签约/解约
        /// </summary>
        private AppXmlExecResult Do2011026Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            XmlDocument responseXml = null; string rsString = string.Empty;
            try
            {
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

                Dictionary<string, string> headDic; Dictionary<string, string> bodyDic;
                string actType_4012 = string.Empty;
                ParseUcToDic(rq_t24_data, out headDic, out bodyDic);

                if (bodyDic.TryGetValue("4012", out actType_4012) )
                {
                    string qyFlag = (actType_4012 == "0") ? "0"
                                  : (actType_4012 == "1") ? "2"
                                  : null;
                    if (!string.IsNullOrEmpty(qyFlag))
                    { rsString = this.GetRsStringFromRqDic(headDic, bodyDic, new Dictionary<string, string>() { { "2028", "CO1M0000" }, { "4012", qyFlag } }); }
                }
                responseXml = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, responseXml);
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do2011026Process Error TxID=[{0}]", txID) + ex.ToString(), ex);
                responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }


        private AppXmlExecResult Do2010810Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            //直接回覆錯誤訊息
            XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
            string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
            m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

            Dictionary<string, string> headDic;
            Dictionary<string, string> bodyDic;
            ParseUcToDic(rq_t24_data, out headDic, out bodyDic);

            string errorMsg = ErrorCodeMapping("BPM", "E-NOLOSSFUNC");
            Dictionary<string, string> rsDic = new Dictionary<string, string>() { { "2028", "CO1MA999" }, { "2038", errorMsg } };
            string rsString = this.GetRsStringFromRqDic(headDic, bodyDic, rsDic);

            XmlDocument responseXml = base.TransformCommMsg("0", "Info", "交易完成", rsString);
            return base.BuildExecResult(context, responseXml);

        }


        private AppXmlExecResult DoDefaultProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            EaiResponse eaiRs = null;
            XmlDocument responseXml = null;
            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }

        private string ErrorCodeMapping(string sourceName, string sourceStatus)
        {
            Bankpro.EAI.Component.StatusData status = Bankpro.EAI.Component.ProjectCache.GetInstance().GetStatusData(sourceName, sourceStatus);

            if (status != null)
                return status.m_statusDesc;
            else
                return sourceStatus;

        }








        /// <summary>
        /// 傳入UcString，回傳Head、Body Dictionary
        /// </summary>
        /// <param name="rsString">UcString</param>
        /// <param name="ucHeadDic">Head Dictionary</param>
        /// <param name="ucBodyDic">Body Dictionary</param>
        void ParseUcToDic(string rsString, out Dictionary<string, string> ucHeadDic, out Dictionary<string, string> ucBodyDic)
        {
            if (string.IsNullOrEmpty(rsString))
            {
                ucHeadDic = new Dictionary<string, string>();
                ucBodyDic = new Dictionary<string, string>();
                return;
            }
            UcControler uCcontroler = new UcControler();
            UcBody ucBody = new UcBody();
            ucHeadDic = uCcontroler.UC2T24_Head(rsString);
            ucBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);
        }
        /// <summary>
        /// 傳入UcRq HeadDictionary、BodyDictionary、其餘資訊Dictionary，回傳 UcRsString
        /// </summary>
        /// <param name="rqHeadDic"></param>
        /// <param name="rqBodyDic"></param>
        /// <param name="otherBodyDic"></param>
        /// <returns></returns>
        string GetRsStringFromRqDic(Dictionary<string, string> rqHeadDic, Dictionary<string, string> rqBodyDic, Dictionary<string, string> otherBodyDic)
        {
            UcControler rs_uccontroler = new UcControler();
            UcHead rs_uchead = new UcHead();
            UcBody rs_ucbody = new UcBody();
            Dictionary<string, string> newBodyDic = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> kv in rqBodyDic)
            {
                switch (kv.Key)
                {
                    case "2001":
                    case "2002":
                    case "2003":
                    case "2004":
                    case "2005":
                    case "2006":
                    case "2039":
                        newBodyDic.Add(kv.Key, kv.Value);
                        break;
                }
            }
            foreach (KeyValuePair<string, string> kv in otherBodyDic)
            {
                newBodyDic.Add(kv.Key, kv.Value);
            }
            string rs_head = rs_uchead.GetRSHeadString(rqHeadDic, "");
            string rs_body = rs_ucbody.GetUcStringFromDic(newBodyDic);
            return rs_head + rs_body;
        }
    }
}
