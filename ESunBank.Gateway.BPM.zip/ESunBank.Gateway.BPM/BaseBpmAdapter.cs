using System;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;

using Microsoft.Service;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;
using Microsoft.EAIServer;


namespace ESunBank.Gateway.BPM
{



    /// <summary>
    /// 1.�N�D���tita�令�h�Ӥl�����TITA, �ק�KEY FIELDS( MsgId, RqUID, SPName, CustLoginID) ->CopyToNewDocument()
    /// 2.���l���
    ///     a.��1��      ->Send1Recv1()
    ///     b.���楴�h�� ->BuildProcDataList(), ParellelSendRecv()
    /// 
    /// 3.�P�_�l��������浲�G�A�ç@�A���B�z
    /// 4.���ͥD�����TOTA, (�Y�Ѥl����ӡA�n�ץ�key fields�����M�D����@��)
    /// </summary>
    public abstract class BaseBpmAdapter : IAppAdapter, IDisposable {
        private const string BPM_CH_ID = "EAI";

        private const int DEFAULT_TIMEOUT_SECONDS = 180;

        private int m_timeoutMilliseconds = DEFAULT_TIMEOUT_SECONDS*1000;
        private string m_name = "";



        public int TimeoutMilliseconds { get { return m_timeoutMilliseconds; } }




        public BaseBpmAdapter() { 
        
        }

        ~BaseBpmAdapter() {
            Dispose();
        }

        public virtual void Dispose() {
            if (m_name == null) {
                return;//already disposed
            }

            m_name = null;
        }


        #region IAppAdapter Members

        public string Name { get { return m_name; } }


        public abstract bool IsXmlVersionImplemented { get;}

        public abstract bool IsBinaryVersionImplemented { get;}


        public void Init(Microsoft.Service.Config.ComponentConfig config) {
            m_name = config.Name;
            m_timeoutMilliseconds = config.Parameters.GetInt("timeoutSeconds", DEFAULT_TIMEOUT_SECONDS) * 1000;
        }




        public virtual AppBinaryExecResult Run(EaiContext context, string correlationID, string txID, HostTxDef txDef, HostMessage requestMsg) {
            throw new Exception("The method or operation is not implemented.");
        }



        public virtual AppXmlExecResult Run(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml) {
            throw new Exception("The method or operation is not implemented.");
        }


        #endregion


    }
}
