using System;
using System.IO;
using System.Xml;
using System.Text;
using System.Net;
using System.Collections.Generic;

namespace ESunBank.Gateway.BPM
{

    /// <summary>
    /// this class is stateless
    /// </summary>
    public class EaiClient : IDisposable {
        private string m_url = ProjectConfig.GetInstance().Send_URL;
        private int m_timeoutMilliseconds=ProjectConfig.GetInstance().PostTimerOut*1000;


        public EaiClient(int timeoutMilliseconds) {
            m_timeoutMilliseconds = timeoutMilliseconds;
        }

        ~EaiClient() {
            Dispose();
        }

        public void Dispose() {
            //
        }



        /// <summary>
        /// �@�h�@�^�A�O�����Ǧ^exception, �qTransportResult.IsTransportOK�P�_�O�_�����`���e�H
        /// </summary>
        /// <param name="requestXml"></param>
        /// <returns></returns>
        public TransportResult Send1Recv1(XmlDocument requestXml) {
            return HttpPost(m_url, requestXml.DocumentElement.OuterXml, m_timeoutMilliseconds);
        }




        //public XmlDocument[] SendxRecvx(XmlDocument requestXml) {
        //    System.Net.WebClient wc = new System.Net.WebClient();
        //    List<XmlDocument> respList = new List<XmlDocument>();
        //    bool isSuccess = true;

        //    while (true) {
        //        XmlDocument responseXml;
        //        isSuccess = HttpPost(wc, requestXml, out responseXml);
        //        respList.Add(responseXml);
        //        if (isSuccess == false) {
        //            break;
        //        }

        //        string strHRETRN = XmlUtil.GetXPath(responseXml, "/Tx/TxHead/HRETRN");
        //        if (strHRETRN == "E") {
        //            break;
        //        }
        //        XmlUtil.SetXPath(requestXml, "/Tx/TxHead/HRETRN", "C");
        //        //string strHSTANO = XmlUtil.GetXPath(responseXml, "/Tx/TxHead/HSTANO");
        //        //XmlUtil.SetXPath(requestXml, "/Tx/TxHead/HSTANO", strHSTANO);
        //    }
        //    return respList.ToArray();
        //}




        ///// <summary>
        ///// �W��RequestXML�A�ñ����h�ӤU�Ǫ�ResponseXML�A�N�U�Ǫ�XML�]��Tx-TxHead-TxBody-TxHead-TxBody-...-Tx
        ///// </summary>
        ///// <param name="requestXml"></param>
        ///// <returns></returns>
        //public XmlDocument Send1MergeRecvAllHeadBody(XmlDocument requestXml) {
        //    XmlDocument[] respList = SendxRecvx(requestXml);
        //    StringBuilder sb = new StringBuilder();
        //    for (int i = 0, count = respList.Length; i < count; ++i) {
        //        XmlNode txN = respList[i].SelectSingleNode("/Tx");
        //        sb.Append(txN.InnerXml);
        //    }
        //    XmlDocument respXml = respList[respList.Length - 1];
        //    XmlNode tx = respXml.SelectSingleNode("/Tx");
        //    tx.InnerXml = sb.ToString();
        //    return respXml;
        //}


        ///// <summary>
        ///// �W��RequestXML�A�ñ����h�ӤU�Ǫ�ResponseXML�A�N�U�Ǫ�XML�]��Tx-TxBody-TxRepeat-TxRepeat...-TxBody-Tx�C</br>
        ///// TxHead�βĤ@�Ӧ^�Ǫ�XML��TxHead�C
        ///// </summary>
        ///// <param name="requestXml"></param>
        ///// <returns></returns>
        //public XmlDocument Send1MergeRecvTo1Body(XmlDocument requestXml) {
        //    XmlDocument[] respList = SendxRecvx(requestXml);
        //    return MergeTo1Body(respList);
        //}



        //public static XmlDocument MergeTo1Body(params XmlDocument[] xmls) {
        //    StringBuilder sb = new StringBuilder();
        //    for (int i = 0, count = xmls.Length; i < count; ++i) {
        //        XmlNode txBodyN = xmls[i].SelectSingleNode("/Tx/TxBody");
        //        sb.Append(txBodyN.InnerXml);
        //    }
        //    XmlDocument respXml = xmls[xmls.Length - 1];
        //    XmlNode txBody = respXml.SelectSingleNode("/Tx/TxBody");
        //    txBody.InnerXml = sb.ToString();
        //    return respXml;
        //}



        ///// <summary>
        ///// �W��RequestXML�A�ñ����h�ӤU�Ǫ�ResponseXML�A�N�U�Ǫ�XML�]��Tx-TxBody-TxBody-TxBody-...-TxBody-Tx�C</br>
        ///// TxHead�βĤ@�Ӧ^�Ǫ�XML��TxHead�C
        ///// </summary>
        ///// <param name="requestXml"></param>
        ///// <returns></returns>
        //public XmlDocument Send1MergeRecvToMultiBody(XmlDocument requestXml) {
        //    XmlDocument[] respList = SendxRecvx(requestXml);
        //    return MergeToMultiBody(respList);
        //}



        //public static XmlDocument MergeToMultiBody(params XmlDocument[] xmls) {
        //    StringBuilder sb = new StringBuilder();
        //    XmlDocument respXml = xmls[xmls.Length - 1];
        //    //last txhead
        //    sb.Append(respXml.SelectSingleNode("/Tx/TxHead").OuterXml);
        //    for (int i = 0, count = xmls.Length; i < count; ++i) {
        //        XmlNodeList txBodyList = xmls[i].SelectNodes("/Tx/TxBody");
        //        foreach (XmlNode txBodyN in txBodyList) {
        //            sb.Append(txBodyN.OuterXml);
        //        }
        //    }
        //    XmlNode txNode = respXml.SelectSingleNode("/Tx");
        //    txNode.InnerXml  = sb.ToString();
        //    return respXml;
        //}



        private XmlDocument GetErrResponseXml( XmlDocument requestXml, string errCode, string errText) {
            //return EAIMessage.GetErrResponseXml(errCode, errText, requestXml);
            //return error directly.
            return null;
        }


        /// <summary>
        /// �����O����Ǧ^XML, �s�u���Ѥ]�n�Ǧ^���~�y�z��XML
        /// </summary>
        /// <param name="requestXml"></param>
        /// <returns></returns>
        private XmlDocument HttpPost(XmlDocument requestXml) {
            TransportResult result = HttpPost(m_url, requestXml.DocumentElement.OuterXml, m_timeoutMilliseconds);
            if (result.IsTransportOK) {
                return result.GetXml();
            } else {
                return GetErrResponseXml(requestXml, "TPXX",  result.ErrText);
            }
        }



        /// <summary>
        /// send request and get response
        /// </summary>
        /// <param name="url"></param>
        /// <param name="requestText"></param>
        /// <param name="timeoutMilliseconds"></param>
        /// <returns>responseText</returns>
        private TransportResult HttpPost(string url, string requestText, int timeoutMilliseconds) {
            WebRequest webRequest = WebRequest.Create(url);
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.Method = "POST";
            webRequest.Timeout = timeoutMilliseconds;

            try {
                using (StreamWriter sw = new StreamWriter(webRequest.GetRequestStream())) {
                    sw.Write(requestText);
                }
            } catch (WebException ex) {
                return TransportResult.GetInstance(TransportStatus.ConnectTimeout, "", string.Format("HttpPost: Request error:{0}", ex.Message));
            }

            try {
                WebResponse webResponse = webRequest.GetResponse();
                if (webResponse == null) {
                    return TransportResult.GetInstance(TransportStatus.ResponseTimeout, "", string.Format("HttpPost: Unable to get WebResponse"));
                }
                using (StreamReader sr = new StreamReader(webResponse.GetResponseStream(), Encoding.UTF8)) {
                    string responseText= sr.ReadToEnd().Trim();
                    TransportResult ret = TransportResult.GetInstance(TransportStatus.Transported, responseText);
                    ret.GetXml();
                    return ret;
                }
            } catch (WebException ex) {
                return TransportResult.GetInstance(TransportStatus.ResponseTimeout, "", string.Format("HttpPost: Unable to get WebResponse:{0} URL = {1}", ex.Message, url));
            }
        }


    }



    /// <summary>
    /// �s�u���A
    /// </summary>
    public enum TransportStatus { 
        Connected=0,
        ConnectTimeout,
        ResponseTimeout,
        Transported,
        ResponseXmlIsInvalid,
    }

    /// <summary>
    /// �ΨӮi�{�qEAI Server �ݶǦ^�����G
    /// </summary>
    public class TransportResult : IDisposable {
        private bool m_isDisposed = false;
        private TransportStatus m_status;
        private string m_data;
        private string m_errText;
        private XmlDocument m_xml=null;

        private TransportResult(TransportStatus status, string data, string errText) {
            m_status = status;
            m_data = data;
            m_errText = errText;
        }


        /// <summary>
        /// destructor
        /// </summary>
        ~TransportResult() {
            Dispose();
        }

        /// <summary>
        /// determined finalization
        /// </summary>
        public void Dispose() {
            if (m_isDisposed) {
                return;//already disposed
            }
            m_isDisposed = true;
            //m_status = null;
            m_data = null;
            m_errText = null;
            m_xml = null;
        }

        /// <summary>
        /// get an instance of TransportResult
        /// </summary>
        /// <param name="status"></param>
        /// <param name="data"></param>
        /// <param name="errText"></param>
        /// <returns></returns>
        public static TransportResult GetInstance(TransportStatus status, string data, string errText) {
            return new TransportResult(status, data, errText);
        }


        /// <summary>
        /// get an instance of TransportResult
        /// </summary>
        /// <param name="status"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public static TransportResult GetInstance(TransportStatus status, string data) {
            return new TransportResult(status, data, "");
        }




        /// <summary>
        /// set error text
        /// </summary>
        /// <param name="errText"></param>
        public void SetError(string errText) {
            m_errText = errText;
        }


        /// <summary>
        /// parsed response status
        /// </summary>
        public TransportStatus Status { get { return m_status; } }

        /// <summary>
        /// Does tx send/recv successfully?
        /// </summary>
        public bool IsTransportOK { get { return m_status == TransportStatus.Transported; } }


        /// <summary>
        /// response data
        /// </summary>
        public string Data { get { return m_data; } }

        /// <summary>
        /// error description
        /// </summary>
        public string ErrText { get { return m_errText; } }



        public XmlDocument GetXml() {
            if (m_xml != null) {
                return m_xml;
            }

            XmlDocument xml = new XmlDocument();
            try {
                xml.LoadXml(m_data);
                m_xml = xml;
            } catch (Exception ex) {
                m_errText= string.Format("Error parsing response xml:{0}.\r\nOrignal response text is:{1}", ex.Message, m_data);
                m_status = TransportStatus.ResponseXmlIsInvalid;
            }
            return m_xml;
        
        }
    }

}
