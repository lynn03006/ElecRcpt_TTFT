﻿//using Bankpro.EAI.Component.Xml;
//using Bankpro.EAI.Component;
//using Microsoft.Service;
//using Microsoft.Service.Xml;
//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Linq;
//using System.Text;
//using System.Xml;
//using Microsoft.EAIServer;

//namespace ESunBank.Gateway.BPM
//{
//    public class NDAControler
//    {
//        private static readonly Logger m_log = LogManager.GetLogger("ESUNBank.Gateway.BPM.NDAControler");

//        private string m_DataBase = "Middleware_TxLog";
//        public string m_MsgKey;

//        private Dictionary<string, object> m_sqlParams = new Dictionary<string, object>();

//        public UcControler m_UcRqControler;

//        private DataSet m_RqNDADataset;
//        private int m_RqNDAExecRows;
//        private List<MsmqtalkDefine> m_RqNDADataList = new List<MsmqtalkDefine>();

//        private string m_RqUcString;
//        private bool m_IsSuccSqlCmd;

//        public List<string> m_FileContentList = new List<string>();



//        private string m_TxnType;
//        /// <summary>
//        /// 執行帶參數之SLQ Command及參數Dictionary
//        /// </summary>
//        /// <param name="sqlCMD"></param>
//        /// <param name="parameters"></param>
//        /// <returns></returns>
//        public bool ExecuteSqlCmd(string DataBase, string sqlCMD, Dictionary<string, object> parameters)
//        {
//            Database db = DatabaseManager.CreateDatabase(DataBase);
//            if (sqlCMD.ToUpper().StartsWith("SELECT"))
//            {
//                m_RqNDADataset = db.ExecuteDataSet(sqlCMD, parameters);
//                m_IsSuccSqlCmd = true;
//            }
//            else if (sqlCMD.ToUpper().StartsWith("UPDATE"))
//            {
//                m_RqNDAExecRows = db.ExecuteNonQuery(sqlCMD, parameters);
//                if (m_RqNDAExecRows == 1)
//                    m_IsSuccSqlCmd = true;
//            }
//            return m_IsSuccSqlCmd;
//        }
//        public List<Dictionary<string, string>> DatasetToDiclist(DataSet dataset)
//        {
//            List<Dictionary<string, string>> lstdata = new List<Dictionary<string, string>>();

//            foreach (DataRow drow in dataset.Tables[0].Rows)
//            {
//                Dictionary<string, string> tempData = new Dictionary<string, string>();

//                for (int i = 0; i <= drow.ItemArray.Length - 1; i++)
//                {
//                    tempData.Add(dataset.Tables[0].Columns[i].ColumnName, drow.ItemArray[i].ToString());
//                }
//                lstdata.Add(tempData);
//            }
//            return lstdata;
//        }
//        public List<MsmqtalkDefine> DatasetToDefineList(DataSet dataset)
//        {
//            List<MsmqtalkDefine> mqtkDefineLst = new List<MsmqtalkDefine>();
//            foreach (DataRow drow in dataset.Tables[0].Rows)
//            {
//                MsmqtalkDefine mqtkDefine = new MsmqtalkDefine();
//                mqtkDefine.BTID = Convert.ToString(drow["BTID"]);
//                mqtkDefine.MSMQ_Label = Convert.ToString(drow["MSMQ_Label"]);
//                mqtkDefine.MSMQ_Body = Convert.ToString(drow["MSMQ_Body"]);
//                mqtkDefine.MSMQ_Priority = Convert.ToString(drow["MSMQ_Priority"]);
//                mqtkDefine.MSMQ_Type = Convert.ToString(drow["MSMQ_Type"]);
//                mqtkDefine.MSMQ_Size = Convert.ToString(drow["MSMQ_Size"]);
//                mqtkDefine.MSMQ_Path = Convert.ToString(drow["MSMQ_Path"]);
//                mqtkDefine.MachineName = Convert.ToString(drow["MachineName"]);
//                mqtkDefine.URL = Convert.ToString(drow["URL"]);
//                mqtkDefine.Status = Convert.ToString(drow["Status"]);
//                mqtkDefine.RetryCount = Convert.ToString(drow["RetryCount"]);
//                mqtkDefine.LastStatus = Convert.ToString(drow["LastStatus"]);
//                mqtkDefine.LastDescription = Convert.ToString(drow["LastDescription"]);
//                mqtkDefine.CreateDate = Convert.ToDateTime(drow["CreateDate"]);
//                mqtkDefine.CreateUser = Convert.ToString(drow["CreateUser"]);
//                mqtkDefine.UpdateDate = Convert.ToDateTime(drow["UpdateDate"]);
//                mqtkDefine.UpdateUser = Convert.ToString(drow["UpdateUser"]);
//                mqtkDefineLst.Add(mqtkDefine);
//            }
//            return mqtkDefineLst;
//        }

//        public string GetMsmqdataT24NodeValue(string MsmqXmlString)
//        {
//            XmlDocument xDoc = new XmlDocument();
//            xDoc.LoadXml(MsmqXmlString);
//            XmlHelper xHelper = XmlHelper.GetInstance(xDoc);
//            string dataString = xHelper.SelectSingleNode(xDoc, "//T24_DATA").InnerText;
//            return dataString;
//        }


//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="UcString">UC報文</param>
//        public string ParseRqUcString(string UcString)
//        {
//            m_UcRqControler = new UcControler();
//            m_UcRqControler.UC2T24(UcString);

//            string msgkey;
//            m_UcRqControler.m_ucBodyDiy.TryGetValue("2001", out msgkey);

//            m_MsgKey = msgkey;
//            return m_MsgKey;
//        }

//        private bool UcMapping(Dictionary<string, string> ucRqBodyDic, Dictionary<string, string> ucMqBodyDic)
//        {
//            m_TxnType = string.Empty;
//            ucRqBodyDic.TryGetValue("4172", out m_TxnType);
//            Dictionary<string, string> mappingDic = new Dictionary<string, string>();//宣告域代碼對照Dictionary
//            List<Dictionary<string, string>> finalMqDicLst = new List<Dictionary<string, string>>();//宣告最後取得的資料Dictionary List

//            //取得域代碼對照Dictionary
//            foreach (KeyValuePair<string, string> x in ucRqBodyDic)
//            {
//                string m_code = string.Empty;
//                if (m_TxnType == "01")//跨行
//                {
//                    if (m_MsgKey == "2010991")//個人 查詢
//                        m_code = Mapping2010767To2010991(x.Key);
//                    else if (m_MsgKey == "2010992")//個人 撤銷
//                        m_code = Mapping2010767To2010992(x.Key);
//                    else if (m_MsgKey == "2020655")//企業 查詢
//                    {
//                        m_code = Mapping2020580To2020655(x.Key);
//                    }
//                    else if (m_MsgKey == "2020656")//企業 撤銷
//                    {
//                        m_code = Mapping2020580To2020656(x.Key);
//                    }
//                }
//                else if (m_TxnType == "02")//行內
//                {
//                    if (m_MsgKey == "2010991")//個人 查詢
//                        m_code = Mapping2010766To2010991(x.Key);
//                    else if (m_MsgKey == "2010992")//個人 撤銷
//                        m_code = Mapping2010766To2010992(x.Key);
//                    else if (m_MsgKey == "2020655")//企業 查詢
//                    {
//                        m_code = Mapping2020579To2020655(x.Key);
//                    }
//                    else if (m_MsgKey == "2020656")//企業 撤銷
//                    {
//                        m_code = Mapping2020579To2020656(x.Key);
//                    }
//                }
//                if (!string.IsNullOrEmpty(m_code))
//                    mappingDic.Add(x.Key, m_code);
//            }

//            string msgkey = string.Empty;
//            ucMqBodyDic.TryGetValue("2001", out msgkey);
//            bool c_flag = true;
//            if ((m_TxnType == "01" && (msgkey == "2010767" || msgkey == "2020580")) || (m_TxnType == "02" && (msgkey == "2010766" || msgkey == "2020579")))
//            {
//                //比對相對域代碼的值，若全符合，表示資料相符
//                foreach (KeyValuePair<string, string> x in mappingDic)
//                {
//                    string ucRqValue = string.Empty;
//                    string ucMqValue = string.Empty;
//                    ucRqBodyDic.TryGetValue(x.Key, out ucRqValue);
//                    ucMqBodyDic.TryGetValue(x.Value, out ucMqValue);
//                    if ((m_MsgKey == "2010991" || m_MsgKey == "2020655") && (x.Key == "4119" || x.Key == "4120"))
//                    {
//                        if (x.Key == "4119" && DateTime.ParseExact(ucRqValue, "yyyyMMdd", null) > DateTime.ParseExact(ucMqValue, "yyyyMMdd", null))
//                        { c_flag = false; }
//                        if (x.Key == "4120" && DateTime.ParseExact(ucRqValue, "yyyyMMdd", null) < DateTime.ParseExact(ucMqValue, "yyyyMMdd", null))
//                        { c_flag = false; }
//                    }
//                    else if (ucRqValue != ucMqValue)
//                        c_flag = false;
//                }
//            }
//            else
//            { c_flag = false; }

//            return c_flag;
//        }

//        #region 2010991 域代碼
//        string Mapping2010766To2010991(string code)
//        {
//            string m_code = string.Empty;
//            switch (code)
//            {
//                case "4102":
//                    break;
//                case "4052":
//                    break;
//                case "4157":
//                    m_code = "4157";
//                    break;
//                case "4900":
//                    break;
//                case "4172":
//                    break;
//                case "4119":
//                    m_code = "2006";
//                    break;
//                case "4120":
//                    m_code = "2006";
//                    break;
//                case "4111":
//                    break;
//                case "4835":
//                    break;
//            }
//            return m_code;
//        }
//        string Mapping2010767To2010991(string code)
//        {
//            string m_code = string.Empty;
//            switch (code)
//            {
//                case "4102":
//                    break;
//                case "4052":
//                    break;
//                case "4157":
//                    m_code = "4157";
//                    break;
//                case "4900":
//                    m_code = "4900";
//                    break;
//                case "4172":
//                    break;
//                case "4119":
//                    m_code = "2006";
//                    break;
//                case "4120":
//                    m_code = "2006";
//                    break;
//                case "4111":
//                    break;
//                case "4835":
//                    break;
//            }
//            return m_code;
//        }
//        private string CreateFile_2010767to2010991(Dictionary<string, string> mqDic, Dictionary<string, string> ucBodyDic)
//        {
//            string tempString = string.Empty;
//            StringBuilder sb = new StringBuilder();

//            ucBodyDic.TryGetValue("2039", out tempString);
//            sb.Append(tempString).Append("|");//交易序号

//            mqDic.TryGetValue("CreateDate", out tempString);
//            tempString = DateTime.Parse(tempString).ToString("yyyyMMddHHmmss");
//            sb.Append(tempString).Append("|");//交易時間

//            sb.Append(m_TxnType).Append("|");//交易類型

//            ucBodyDic.TryGetValue("4100", out tempString);
//            sb.Append(tempString).Append("|");//轉帳金額

//            ucBodyDic.TryGetValue("4118", out tempString);
//            sb.Append(tempString).Append("|");//轉帳幣種

//            sb.Append("4165.CHG.AMT").Append("|");//手續費

//            ucBodyDic.TryGetValue("4157", out tempString);
//            sb.Append(tempString).Append("|");//付款人帳戶

//            ucBodyDic.TryGetValue("4900", out tempString);
//            sb.Append(tempString).Append("|");//付款人名稱

//            ucBodyDic.TryGetValue("4161", out tempString);
//            sb.Append(tempString).Append("|");//收款人帳戶

//            ucBodyDic.TryGetValue("4733", out tempString);
//            sb.Append(tempString).Append("|");//收款人名稱

//            ucBodyDic.TryGetValue("4112", out tempString);
//            sb.Append(tempString).Append("|");//收款人行號

//            ucBodyDic.TryGetValue("2021", out tempString);
//            sb.Append(tempString).Append("|");//收款人聯行號

//            //ucBodyDic.TryGetValue("4658", out tempString);
//            sb.Append("&PyeBankName&").Append("|");//收款人網點名稱

//            ucBodyDic.TryGetValue("4026", out tempString);
//            sb.Append(tempString).Append("|");//轉帳方式

//            ucBodyDic.TryGetValue("4897", out tempString);
//            sb.Append(tempString).Append("|");//轉帳用途

//            ucBodyDic.TryGetValue("4734", out tempString);
//            sb.Append(tempString).Append("|");//交易附言

//            mqDic.TryGetValue("Status", out tempString);
//            sb.Append(tempString == "999" ? "0" : "1").Append("|");//是否允許撤銷


//            return sb.ToString();
//        }
//        private string CreateFile_2010766to2010991(Dictionary<string, string> mqDic, Dictionary<string, string> ucBodyDic)
//        {
//            string tempString = string.Empty;
//            StringBuilder sb = new StringBuilder();

//            ucBodyDic.TryGetValue("2039", out tempString);
//            sb.Append(tempString).Append("|");//交易序号

//            mqDic.TryGetValue("CreateDate", out tempString);
//            tempString = DateTime.Parse(tempString).ToString("yyyyMMddHHmmss");
//            sb.Append(tempString).Append("|");//交易時間

//            sb.Append(m_TxnType).Append("|");//交易類型

//            ucBodyDic.TryGetValue("4100", out tempString);
//            sb.Append(tempString).Append("|");//轉帳金額

//            ucBodyDic.TryGetValue("4118", out tempString);
//            sb.Append(tempString).Append("|");//轉帳幣種

//            sb.Append("4165.CHG.AMT").Append("|");//手續費

//            ucBodyDic.TryGetValue("4157", out tempString);
//            sb.Append(tempString).Append("|");//付款人帳戶

//            m_UcRqControler.m_ucBodyDiy.TryGetValue("4900", out tempString);
//            sb.Append(tempString).Append("|");//付款人名稱

//            ucBodyDic.TryGetValue("4161", out tempString);
//            sb.Append(tempString).Append("|");//收款人帳戶

//            ucBodyDic.TryGetValue("4900", out tempString);
//            sb.Append(tempString).Append("|");//收款人名稱

//            sb.Append("529584000006").Append("|");//收款人行號 寫死玉山中國營業部

//            sb.Append("").Append("|");//收款人聯行號

//            sb.Append("&PyeBankName&").Append("|");//收款人網點名稱

//            sb.Append("2").Append("|");//轉帳方式

//            ucBodyDic.TryGetValue("4732", out tempString);
//            sb.Append(tempString).Append("|");//轉帳用途

//            ucBodyDic.TryGetValue("4658", out tempString);
//            sb.Append(tempString).Append("|");//交易附言

//            mqDic.TryGetValue("Status", out tempString);
//            sb.Append(tempString == "999" ? "0" : "1").Append("|");//是否允許撤銷

//            return sb.ToString();
//        }
//        #endregion  2010991 域代碼

//        #region 2010992 域代碼
//        string Mapping2010767To2010992(string code)
//        {
//            string m_code = string.Empty;
//            switch (code)
//            {
//                case "4102":
//                    break;
//                case "4052":
//                    break;
//                case "4027":
//                    m_code = "2039";
//                    break;
//                case "4172":
//                    break;
//                case "4157":
//                    m_code = "4157";
//                    break;
//                case "4900":
//                    m_code = "4900";
//                    break;
//                case "4161":
//                    m_code = "4161";
//                    break;
//                case "4732":
//                    m_code = "4733";
//                    break;
//                case "4186":
//                    m_code = "4112";
//                    break;
//                case "2021":
//                    m_code = "2021";
//                    break;
//                case "4100":
//                    m_code = "4100";
//                    break;
//                case "4026":
//                    //m_code = "4026";
//                    break;
//                case "4349":
//                    //m_code = "4897";
//                    break;
//                case "4658":
//                    break;
//                case "4107":
//                    break;
//                case "4111":
//                    break;
//                case "4835":
//                    break;
//            }
//            return m_code;
//        }
//        string Mapping2010766To2010992(string code)
//        {
//            string m_code = string.Empty;
//            switch (code)
//            {
//                case "4102":
//                    break;
//                case "4052":
//                    break;
//                case "4027":
//                    m_code = "2039";
//                    break;
//                case "4172":
//                    break;
//                case "4157":
//                    m_code = "4157";
//                    break;
//                case "4900":
//                    break;
//                case "4161":
//                    m_code = "4161";
//                    break;
//                case "4732":
//                    m_code = "4900";
//                    break;
//                case "4186":
//                    break;
//                case "2021":
//                    break;
//                case "4100":
//                    m_code = "4100";
//                    break;
//                case "4026":
//                    //m_code = "4026";
//                    break;
//                case "4349":
//                    //m_code = "4897";
//                    break;
//                case "4658":
//                    break;
//                case "4107":
//                    break;
//                case "4111":
//                    break;
//                case "4835":
//                    break;
//            }
//            return m_code;
//        }
//        #endregion 2010992 域代碼

//        #region 2020655 域代碼
//        string Mapping2020579To2020655(string code)
//        {
//            string m_code = string.Empty;
//            switch (code)
//            {
//                case "4102"://柜员号
//                    break;
//                case "4052"://客户类型
//                    break;
//                case "4157"://付款账户
//                    m_code = "4323";
//                    break;
//                case "4900"://付款人名称
//                    break;
//                case "4172"://交易类型
//                    break;
//                case "4119"://开始日期
//                    m_code = "2006";
//                    break;
//                case "4120"://结束日期
//                    m_code = "2006";
//                    break;
//                case "4111"://IP地址
//                    break;
//                case "4835"://通用备用字段
//                    break;
//            }
//            return m_code;
//        }
//        string Mapping2020580To2020655(string code)
//        {
//            string m_code = string.Empty;
//            switch (code)
//            {
//                case "4102"://柜员号
//                    break;
//                case "4052"://客户类型
//                    break;
//                case "4157"://付款账户
//                    m_code = "4157";
//                    break;
//                case "4900"://付款人名称
//                    break;
//                case "4172"://交易类型
//                    break;
//                case "4119"://开始日期
//                    m_code = "2006";
//                    break;
//                case "4120"://结束日期
//                    m_code = "2006";
//                    break;
//                case "4111"://IP地址
//                    break;
//                case "4835"://通用备用字段
//                    break;
//            }
//            return m_code;
//        }
//        private string CreateFile_2020580to2020655(Dictionary<string, string> mqDic, Dictionary<string, string> ucBodyDic)
//        {
//            string tempString = string.Empty;
//            StringBuilder sb = new StringBuilder();

//            ucBodyDic.TryGetValue("2039", out tempString);
//            sb.Append(tempString).Append("|");//交易序号

//            mqDic.TryGetValue("CreateDate", out tempString);
//            tempString = DateTime.Parse(tempString).ToString("yyyyMMddHHmmss");
//            sb.Append(tempString).Append("|");//交易時間

//            sb.Append(m_TxnType).Append("|");//交易類型

//            ucBodyDic.TryGetValue("4100", out tempString);
//            sb.Append(tempString).Append("|");//轉帳金額

//            ucBodyDic.TryGetValue("4118", out tempString);
//            sb.Append(tempString).Append("|");//轉帳幣種

//            sb.Append("4165.CHG.AMT").Append("|");//手續費

//            ucBodyDic.TryGetValue("4157", out tempString);
//            sb.Append(tempString).Append("|");//付款人帳戶

//            ucBodyDic.TryGetValue("4900", out tempString);
//            sb.Append(tempString).Append("|");//付款人名稱

//            ucBodyDic.TryGetValue("4161", out tempString);
//            sb.Append(tempString).Append("|");//收款人帳戶

//            ucBodyDic.TryGetValue("4732", out tempString);
//            sb.Append(tempString).Append("|");//收款人名稱

//            ucBodyDic.TryGetValue("4186", out tempString);
//            sb.Append(tempString).Append("|");//收款人行號

//            ucBodyDic.TryGetValue("2021", out tempString);
//            sb.Append(tempString).Append("|");//收款人聯行號

//            //ucBodyDic.TryGetValue("4658", out tempString);
//            sb.Append("&PyeBankName&").Append("|");//收款人網點名稱

//            ucBodyDic.TryGetValue("4026", out tempString);
//            sb.Append(tempString).Append("|");//轉帳方式

//            ucBodyDic.TryGetValue("4349", out tempString);
//            sb.Append(tempString).Append("|");//轉帳用途

//            sb.Append("").Append("|");//交易渠道

//            ucBodyDic.TryGetValue("4658", out tempString);
//            sb.Append(tempString).Append("|");//交易附言

//            mqDic.TryGetValue("Status", out tempString);
//            sb.Append(tempString == "999" ? "0" : "1").Append("|");//是否允許撤銷


//            return sb.ToString();
//        }
//        private string CreateFile_2020579to2020655(Dictionary<string, string> mqDic, Dictionary<string, string> ucBodyDic)
//        {
//            string tempString = string.Empty;
//            StringBuilder sb = new StringBuilder();

//            ucBodyDic.TryGetValue("2039", out tempString);
//            sb.Append(tempString).Append("|");//交易序号

//            mqDic.TryGetValue("CreateDate", out tempString);
//            tempString = DateTime.Parse(tempString).ToString("yyyyMMddHHmmss");
//            sb.Append(tempString).Append("|");//交易時間

//            sb.Append(m_TxnType).Append("|");//交易類型

//            ucBodyDic.TryGetValue("4100", out tempString);
//            sb.Append(tempString).Append("|");//轉帳金額

//            ucBodyDic.TryGetValue("4118", out tempString);
//            sb.Append(tempString).Append("|");//轉帳幣種

//            sb.Append("4165.CHG.AMT").Append("|");//手續費

//            ucBodyDic.TryGetValue("4323", out tempString);
//            sb.Append(tempString).Append("|");//付款人帳戶

//            m_UcRqControler.m_ucBodyDiy.TryGetValue("4900", out tempString);
//            sb.Append(tempString).Append("|");//付款人名稱

//            ucBodyDic.TryGetValue("4324", out tempString);
//            sb.Append(tempString).Append("|");//收款人帳戶

//            ucBodyDic.TryGetValue("4897", out tempString);
//            sb.Append(tempString).Append("|");//收款人名稱

//            sb.Append("529584000006").Append("|");//收款人行號 寫死玉山中國營業部

//            sb.Append("").Append("|");//收款人聯行號

//            sb.Append("&PyeBankName&").Append("|");//收款人網點名稱

//            sb.Append("2").Append("|");//轉帳方式

//            ucBodyDic.TryGetValue("4349", out tempString);
//            sb.Append(tempString).Append("|");//轉帳用途

//            sb.Append("").Append("|");//交易渠道

//            ucBodyDic.TryGetValue("4658", out tempString);
//            sb.Append(tempString).Append("|");//交易附言

//            mqDic.TryGetValue("Status", out tempString);
//            sb.Append(tempString == "999" ? "0" : "1").Append("|");//是否允許撤銷


//            return sb.ToString();
//        }
//        #endregion 2020655 域代碼

//        #region 2020656 域代碼
//        string Mapping2020579To2020656(string code)
//        {
//            string m_code = string.Empty;
//            switch (code)
//            {
//                case "4102"://柜员号
//                    break;
//                case "4052"://客户类型
//                    break;
//                case "4027"://交易序号
//                    m_code = "2039";
//                    break;
//                case "4172"://交易类型
//                    break;
//                case "4157"://付款账户
//                    m_code = "4323";
//                    break;
//                case "4900"://付款人名称
//                    //m_code = "4900";
//                    break;
//                case "4161"://收款人账户
//                    m_code = "4324";
//                    break;
//                case "4732"://收款人名称
//                    m_code = "4897";
//                    break;
//                case "4186"://收款人行号
//                    //m_code = "4112";
//                    break;
//                case "2021"://收款人联行号
//                    //m_code = "2021";
//                    break;
//                case "4100"://转账金额
//                    m_code = "4100";
//                    break;
//                case "4026"://转账方式
//                    //m_code = "4026";
//                    break;
//                case "4349"://转账用途
//                    //m_code = "4897";
//                    break;
//                case "4345"://交易渠道
//                    break;
//                case "4658"://交易附言
//                    break;
//                case "4107"://交易密码
//                    break;
//                case "4111"://IP地址
//                    break;
//                case "4835"://通用备用字段
//                    break;
//            }
//            return m_code;
//        }
//        string Mapping2020580To2020656(string code)
//        {
//            string m_code = string.Empty;
//            switch (code)
//            {
//                case "4102"://柜员号
//                    break;
//                case "4052"://客户类型
//                    break;
//                case "4027"://交易序号
//                    m_code = "2039";
//                    break;
//                case "4172"://交易类型
//                    break;
//                case "4157"://付款账户
//                    m_code = "4157";
//                    break;
//                case "4900"://付款人名称
//                    m_code = "4900";
//                    break;
//                case "4161"://收款人账户
//                    m_code = "4161";
//                    break;
//                case "4732"://收款人名称
//                    m_code = "4732";
//                    break;
//                case "4186"://收款人行号
//                    m_code = "4186";
//                    break;
//                case "2021"://收款人联行号
//                    m_code = "2021";
//                    break;
//                case "4100"://转账金额
//                    m_code = "4100";
//                    break;
//                case "4026"://转账方式
//                    //m_code = "4026";
//                    break;
//                case "4349"://转账用途
//                    //m_code = "4349";
//                    break;
//                case "4345"://交易渠道
//                    break;
//                case "4658"://交易附言
//                    break;
//                case "4107"://交易密码
//                    break;
//                case "4111"://IP地址
//                    break;
//                case "4835"://通用备用字段
//                    break;
//            }
//            return m_code;
//        }
//        #endregion 2020656 域代碼

//        public bool GetRsData()
//        {
//            //先將現有未經篩選之Dataset轉換為Dictionary<欄位,值> 之 List
//            List<Dictionary<string, string>> RqNDADicLst = DatasetToDiclist(m_RqNDADataset);
//            //TODO MAYBE先用DB欄位做第一階段篩選出
//            bool t_flag = false;//比對成功flag
//            UcBody temp_UcBody = new UcBody();

//            if (m_MsgKey == "2010991" || m_MsgKey == "2020655")
//            {
//                List<Dictionary<string, string>> finalLst = new List<Dictionary<string, string>>();
//                List<string> file_content = new List<string>();//宣告落檔的檔案內容List<string>
//                foreach (Dictionary<string, string> D in RqNDADicLst)
//                {
//                    string msmq_data = string.Empty;
//                    D.TryGetValue("MSMQ_Body", out msmq_data);

//                    XmlDocument temp_xdoc = new XmlDocument();
//                    temp_xdoc.LoadXml(msmq_data);
//                    XmlHelper temp_xhelper = XmlHelper.GetInstance(temp_xdoc);
//                    string t24Data = temp_xhelper.SelectSingleNode(temp_xdoc, "//T24_DATA").InnerXml;

//                    UcControler temp_ucControler = new UcControler();
//                    temp_ucControler.UC2T24_Head(t24Data);//m_healDataDiy, m_ucbody
//                    temp_ucControler.m_ucBodyDiy = temp_UcBody.ParserString(temp_ucControler.m_ucbody);

//                    t_flag = UcMapping(m_UcRqControler.m_ucBodyDiy, temp_ucControler.m_ucBodyDiy);

//                    if (t_flag)
//                    {
//                        finalLst.Add(D);
//                        if (m_TxnType == "01")//跨行
//                        {
//                            if (m_MsgKey == "2010991")
//                                file_content.Add(CreateFile_2010767to2010991(D, temp_ucControler.m_ucBodyDiy));
//                            else//2020655
//                            {
//                                file_content.Add(CreateFile_2020580to2020655(D, temp_ucControler.m_ucBodyDiy));
//                            }
//                        }
//                        else if (m_TxnType == "02")//本行
//                        {
//                            if (m_MsgKey == "2010991")
//                                file_content.Add(CreateFile_2010766to2010991(D, temp_ucControler.m_ucBodyDiy));
//                            else//2020655
//                            {
//                                file_content.Add(CreateFile_2020579to2020655(D, temp_ucControler.m_ucBodyDiy));
//                            }
//                        }
//                    }
//                }
//                //--------------------------
//                m_FileContentList = file_content;
//                //--------------------------
//                return true;
//            }
//            else if (m_MsgKey == "2010992" || m_MsgKey == "2020656")
//            {
//                bool updateSqlCmdSucc = false;
//                foreach (Dictionary<string, string> D in RqNDADicLst)
//                {
//                    string msmq_data = string.Empty;
//                    D.TryGetValue("MSMQ_Body", out msmq_data);

//                    XmlDocument temp_xdoc = new XmlDocument();
//                    temp_xdoc.LoadXml(msmq_data);
//                    XmlHelper temp_xhelper = XmlHelper.GetInstance(temp_xdoc);
//                    string t24Data = temp_xhelper.SelectSingleNode(temp_xdoc, "//T24_DATA").InnerXml;

//                    UcControler temp_ucControler = new UcControler();
//                    temp_ucControler.UC2T24_Head(t24Data);//m_healDataDiy, m_ucbody
//                    temp_ucControler.m_ucBodyDiy = temp_UcBody.ParserString(temp_ucControler.m_ucbody);

//                    t_flag = UcMapping(m_UcRqControler.m_ucBodyDiy, temp_ucControler.m_ucBodyDiy);

//                    if (t_flag)
//                    {
//                        if (m_TxnType == "01" || m_TxnType == "02")
//                        {
//                            //update SQL
//                            string BTID = string.Empty;
//                            D.TryGetValue("BTID", out BTID);

//                            string cmd = "UPDATE BroadcastMSMQTalk SET {0} WHERE 1=1 {1}";
//                            cmd = string.Format(cmd
//                                                , "[Status]=@STATUS2, [UpdateDate]=@UpdateDate "
//                                                , "AND [BTID] = @BTID AND [Status] = @STATUS1");
//                            Dictionary<string, object> pa = new Dictionary<string, object>();
//                            pa.Add("@STATUS2", 990);
//                            pa.Add("@UpdateDate", DateTime.Now);
//                            pa.Add("@BTID", BTID);
//                            pa.Add("@STATUS1", 999);

//                            updateSqlCmdSucc = ExecuteSqlCmd(m_DataBase, cmd, pa);
//                        }
//                    }
//                }

//                //Dictionary<string, string> totalDic = new Dictionary<string, string>();
//                //string returnString = string.Empty;
//                if (updateSqlCmdSucc)
//                    return true;
//                //    returnString = m_UcRqControler.GetToUCRS(totalDic);
//                //return returnString;

//            }
//            return false;
//        }


//        //List<Dictionary<string, string>> UcMapping_2010991(Dictionary<string, string> ucRqBodyDic, List<Dictionary<string, string>> ucMqBodyDicLst)
//        //{
//        //    string txnType = string.Empty;
//        //    ucRqBodyDic.TryGetValue("4172", out txnType);
//        //    Dictionary<string, string> mappingDic = new Dictionary<string, string>();//宣告域代碼對照Dictionary
//        //    List<Dictionary<string, string>> s_ucMqBodyDicLst = new List<Dictionary<string, string>>();//宣告特定報文號的Dictionary List
//        //    List<Dictionary<string, string>> finalMqDicLst = new List<Dictionary<string, string>>();//宣告最後取得的資料Dictionary List

//        //    //取得域代碼對照Dictionary
//        //    foreach (KeyValuePair<string, string> x in ucRqBodyDic)
//        //    {
//        //        string m_code = string.Empty;
//        //        if (txnType == "01")
//        //        {
//        //            m_code = Mapping2010766To2010991(x.Key);
//        //        }
//        //        else if (txnType == "02")
//        //        {
//        //            m_code = Mapping2010767To2010991(x.Key);
//        //        }
//        //        if (!string.IsNullOrEmpty(m_code))
//        //            mappingDic.Add(x.Key, m_code);
//        //    }

//        //    //依照交易類型(跨行轉帳or行內轉帳)篩選ucMqBodyDicLst的資料，組成s_ucMqBodyDicLst
//        //    foreach (Dictionary<string, string> d in ucMqBodyDicLst)
//        //    {
//        //        string msgkey = string.Empty;
//        //        d.TryGetValue("2001", out msgkey);
//        //        if (txnType == "01" && msgkey == "2010767")
//        //            s_ucMqBodyDicLst.Add(d);
//        //        else if (txnType == "02" && msgkey == "2010766")
//        //            s_ucMqBodyDicLst.Add(d);
//        //    }

//        //    //比對相對域代碼的值，若全符合，表示資料相符
//        //    foreach (Dictionary<string, string> d in s_ucMqBodyDicLst)
//        //    {
//        //        bool c_flag = true;
//        //        foreach (KeyValuePair<string, string> x in mappingDic)
//        //        {
//        //            string ucRqValue = string.Empty;
//        //            string ucMqValue = string.Empty;
//        //            ucRqBodyDic.TryGetValue(x.Key, out ucRqValue);
//        //            d.TryGetValue(x.Value, out ucMqValue);
//        //            if (ucRqValue != ucMqValue)
//        //                c_flag = false;
//        //        }
//        //        if (c_flag)
//        //            finalMqDicLst.Add(d);
//        //    }
//        //    return finalMqDicLst;
//        //}
//    }




//    public class MsmqtalkDefine
//    {
//        public MsmqtalkDefine()
//        {
//        }
//        //public System.Guid BTID;
//        //public string MSMQ_Label;
//        //public string MSMQ_Body;
//        //public byte MSMQ_Priority;
//        //public string MSMQ_Type;
//        //public int MSMQ_Size;
//        //public string MSMQ_Path;
//        //public string MachineName;
//        //public string URL;
//        //public short Status;
//        //public short RetryCount;
//        //public short LastStatus;
//        //public string LastDescription;
//        //public System.DateTime CreateDate;
//        //public string CreateUser;
//        //public System.DateTime UpdateDate;
//        //public string UpdateUser;
//        public string BTID;
//        public string MSMQ_Label;
//        public string MSMQ_Body;
//        public string MSMQ_Priority;
//        public string MSMQ_Type;
//        public string MSMQ_Size;
//        public string MSMQ_Path;
//        public string MachineName;
//        public string URL;
//        public string Status;
//        public string RetryCount;
//        public string LastStatus;
//        public string LastDescription;
//        public DateTime CreateDate;
//        public string CreateUser;
//        public DateTime UpdateDate;
//        public string UpdateUser;
//    }
//}