﻿using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using Bankpro.EAI.Utility;
using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Linq;

namespace ESunBank.Gateway.BPM.Util
{
    internal class TxPWChk : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.Gateway.BPM.TxPWChk");
        private const string spN_GW = "GW";
        private const string custId_GW = "GW";

        public string rq_t24_data = string.Empty;

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            return ChkTxPW(context, txID, txDef, requestXml);
        }

        public AppXmlExecResult ChkTxPW(EaiContext context, string txID, HostTxDef txDef, XmlDocument requestXml)
        {

            AppXmlExecResult resultXML = null;

            XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
            rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
            m_log.Info("ChkTxPW txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

            string channel = string.Empty;
            Dictionary<string, string> headDic; Dictionary<string, string> bodyDic;
            UcControler uCcontroler = new UcControler();
            ParseUcToDic(uCcontroler, rq_t24_data, out headDic, out bodyDic);

            //渠道07:網銀，渠道12:手機網銀。渠道07不處理
            headDic.TryGetValue("Channel", out channel);
            m_log.Info("RunImpl channel = [{0}]", channel);

            string ucPWBaseCol = string.Empty; string ucPWCol = string.Empty; string ucExcludeCol = string.Empty;
            string ucPWBase = string.Empty; string ucPW = string.Empty; string ucExclude = string.Empty;
            if (!channel.Equals("07"))
            {
                //檢核密碼
                TxSettings txSettings = txDef.TITA.Settings;
                ucPWBaseCol = txSettings.GetString("UCPWBase", "");
                ucPWCol = txSettings.GetString("UCPW", "");

                m_log.Info("ChkTxPW ucPWBaseCol = [{0}] ucPWCol = [{1}]", ucPWBaseCol, ucPWCol);

                if (!string.IsNullOrEmpty(ucPWBaseCol) && !string.IsNullOrEmpty(ucPWCol))
                {
                    bodyDic.TryGetValue(ucPWBaseCol, out ucPWBase);
                    bodyDic.TryGetValue(ucPWCol, out ucPW);

                    if (!string.IsNullOrEmpty(ucPWBase) && !string.IsNullOrEmpty(ucPW))
                    {

                        //當密碼為6F4D4DF2A2608559（AAAAAA），代表頁面上交易密碼欄位調掉了。不檢核
                        if (ucPW.Equals("6F4D4DF2A2608559")) return resultXML;

                        //當為2010500，檢查是否EXCLUDE。EXCLUDE不檢核
                        if(txID.Equals("2010500")){
                            ucExcludeCol = txSettings.GetString("UCExclude", "");
                            if (!string.IsNullOrEmpty(ucExcludeCol)){
                                string[] ucExcludeColArr = ucExcludeCol.Split(',');
                                bodyDic.TryGetValue("4053", out ucExclude);
                                m_log.Info("ChkTxPW ucExcludeCol = [{0}] ucExclude = [{1}]", ucExcludeCol, ucExclude);
                                if(ucExcludeColArr.Contains(ucExclude)) return resultXML;
                            }
                        }
                        
                        string bodyCardEnq = GetT24_pwENQ_Content(ucPWBase, ucPW);
                        AppXmlExecResult pwEnq_result = SendMsgToEAIProcess(context, bodyCardEnq, "ESCN.IB.PW.CHK.ENQ", true);
                        XmlHelper xmlHelperPWEnq = XmlHelper.GetInstance(pwEnq_result.ResponseXml);
                        string result = xmlHelperPWEnq.GetXPath(pwEnq_result.ResponseXml, "//RESULT").Trim();

                        if (!result.Equals("Y"))
                        {
                            string failCode = "CO1MA999";
                            string rs_Code = "E-TXPWDERR"; //交易密碼不相符
                            string failDescription = ErrorCodeMapping("BPM", rs_Code);

                            Dictionary<string, string> ucTypeDic = Get_ucType_Expend(bodyDic);
                            string afterRSERR = CheckUC_FailResponseProcess(uCcontroler, ucTypeDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                            m_log.Debug("AppXmlExecResult ChkTxPW.afterRSERR={0}", afterRSERR);
                            XmlDocument rs_UCERR = base.TransformCommMsg("0", "Info", "交易完成", afterRSERR);
                            resultXML = base.BuildExecResult(context, rs_UCERR);
                        }
                    }
                }
            }

            return resultXML;
        }

        private void ParseUcToDic(UcControler uCcontroler, string rsString, out Dictionary<string, string> ucHeadDic, out Dictionary<string, string> ucBodyDic)
        {
            if (string.IsNullOrEmpty(rsString))
            {
                ucHeadDic = new Dictionary<string, string>();
                ucBodyDic = new Dictionary<string, string>();
                return;
            }

            UcBody ucBody = new UcBody();
            ucHeadDic = uCcontroler.UC2T24_Head(rsString);
            ucBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);
        }

        private string GetT24_pwENQ_Content(string custAcc, string pwCode)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.IB.PW.CHK.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.IB.PW.CHK.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "IB001.0015");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<CUSTACC op='EQ'>{0}</CUSTACC>", custAcc);
            sb.AppendFormat("<PWCODE op='EQ'>{0}</PWCODE>", pwCode);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private Dictionary<string, string> Get_ucType_Expend(Dictionary<string, string> ucBodyDic)
        {
            Dictionary<string, string> ucTypeDic = new Dictionary<string, string>();

            foreach (KeyValuePair<string, string> kv in ucBodyDic)
            {
                switch (kv.Key)
                {
                    case "2001":
                    case "2002":
                    case "2003":
                    case "2004":
                    case "2005":
                    case "2006":
                    case "2039":
                        ucTypeDic.Add(kv.Key, kv.Value);
                        break;
                }
            }

            return ucTypeDic;
        }

        private string ErrorCodeMapping(string sourceName, string sourceStatus)
        {
            Bankpro.EAI.Component.StatusData status = Bankpro.EAI.Component.ProjectCache.GetInstance().GetStatusData(sourceName, sourceStatus);

            if (status != null)
                return status.m_statusDesc;
            else
                return sourceStatus;

        }

        private string CheckUC_FailResponseProcess(UcControler m_UcControler, Dictionary<string, string> expendDic, string failCode, string failDescription)
        {
            return m_UcControler.GetFailUcRS(expendDic, failCode, failDescription);
        }

        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey, bool SendToEAI)
        {
            string msgContent = string.Empty;
            if (SendToEAI)
            { msgContent = base.SendToEAIProcess(body, eAI_MsgKey, spN_GW, custId_GW); }
            else
            { msgContent = base.SendToEAIProcess(body, eAI_MsgKey); }

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(msgContent);
            XmlDocument subRqXml = null;
            if (SendToEAI)
            { subRqXml = CopyToNewDocument(rq, spN_GW, custId_GW, eAI_MsgKey, Guid.NewGuid().ToString()); }
            else
            { subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString()); }
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, subRqXml.InnerXml);
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml, SendToEAI);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }
    }
}
