﻿using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Net;
using System.IO;

using System.Data;

using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using Bankpro.EAI.Utility;
using ESunBank.Gateway.BPM.Util;


namespace ESunBank.Gateway.BPM
{
    public class BATCH : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("ESUNBank.Gateway.BPM.BATCH");
        private const string spN_GW = "GW";
        private const string custId_GW = "GW";
        UCCommonUtil ucComUtil = new UCCommonUtil();
        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            switch (txID)
            {
                case "2010845"://個人 批量轉帳手續費查詢
                case "2020604"://企業 批量轉帳手續費查詢
                    return ChkBatchFee(context, correlationID, txID, txDef, requestXml);

                case "ES_2010768"://個人 行內批量轉帳   存DB 發MQ
                case "ES_2010771"://個人 跨行批量轉帳   存DB 發MQ
                case "ES_2020581"://企業 行內批量轉帳   存DB 發MQ
                case "ES_2020584"://企業 跨行批量轉帳   存DB 發MQ
                    return DoBatchIncomingProcess(context, correlationID, txID, txDef, requestXml);

                case "2010768"://個人 行內批量轉帳   由MQ過來
                case "2010771"://個人 跨行批量轉帳   由MQ過來
                case "2020581"://企業 行內批量轉帳   由MQ過來
                case "2020584"://企業 跨行批量轉帳   由MQ過來
                    return DoBatchMqProcess(context, correlationID, txID, txDef, requestXml);

                case "2010769"://個人 行內/跨行批量轉帳查詢
                case "2020582"://企業 行內/跨行批量轉帳查詢
                    return Do2020582_2010769Process(context, correlationID, txID, txDef, requestXml);
                case "2010770"://個人 行內/跨行批量轉帳明細查詢
                case "2020583"://企業 行內/跨行批量轉帳明細查詢
                    return Do2020583_2010770Process(context, correlationID, txID, txDef, requestXml);
            }
            EaiResponse eaiRs = null;
            XmlDocument responseXml = null;
            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }

        #region 批量轉帳手續費查詢
        AppXmlExecResult ChkBatchFee(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);
                string rq_commType = txID == "2010845" ? "PIBCNYREMIT" : (txID == "2020604" ? "CIBCNYREMIT" : string.Empty);//個"PIBCNYREMIT" 企"CIBCNYREMIT"
                string rq_TxnType = string.Empty, rq_totAmt = string.Empty, rq_Curr = string.Empty;
                string rq_totCount = string.Empty, rq_FileName = string.Empty;
                #region 1.分析報文
                Dictionary<string, string> rqHeadDic = new Dictionary<string, string>();
                Dictionary<string, string> rqBodyDic = new Dictionary<string, string>();
                ParseUcToDic(rq_t24_data, out rqHeadDic, out rqBodyDic);
                rqBodyDic.TryGetValue("4949", out rq_TxnType);//1.跨行 2.行內
                rqBodyDic.TryGetValue("4100", out rq_totAmt);//總金額
                rqBodyDic.TryGetValue("4118", out rq_Curr);//幣別
                rqBodyDic.TryGetValue("4112", out rq_totCount);//總筆數
                rqBodyDic.TryGetValue("zzzx", out rq_FileName);//檔案名
                #endregion 1.分析報文
                #region 2.取平均金額
                int rq_totCount_int; decimal rq_totAmt_dec, rq_avgAmt_dec; string rq_avgAmt = string.Empty;
                if (int.TryParse(rq_totCount, out rq_totCount_int) && decimal.TryParse(rq_totAmt, out rq_totAmt_dec))
                {
                    rq_avgAmt_dec = Math.Floor((rq_totAmt_dec / rq_totCount_int) + 0.5m);//取平均金額：總金額/總筆數 四捨五入至整數
                    rq_avgAmt = rq_avgAmt_dec.ToString();
                }
                else
                {
                    Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
                    rs_fail_otherBodyDic.Add("2028", "CO1MM005");
                    rs_fail_otherBodyDic.Add("2038", "解析报文失败");
                    rs_fail_otherBodyDic.Add("4165", "0.00");
                    string rs_fail_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);
                    XmlDocument rs_fail = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_string);
                    return base.BuildExecResult(context, rs_fail);
                }
                #endregion 2.取平均金額
                #region 3.撈手續費 再乘以總比數
                string t24Data_FeeChkEnq_Content = GetT24_FeeChkEnq_Content(rq_TxnType, rq_avgAmt, rq_Curr, rq_commType);

                AppXmlExecResult srResult = SendMsgToEAIProcess(context, t24Data_FeeChkEnq_Content, "IB.CHG.CHK.ENQ", true);
                string avg_Fee = XmlHelper.GetInstance(srResult.ResponseXml).GetXPath(srResult.ResponseXml, "//CHG_AMT").Trim();
                decimal avg_Fee_dec, tot_Fee_dec; string tot_Fee = string.Empty;
                if (decimal.TryParse(avg_Fee, out avg_Fee_dec))
                {
                    tot_Fee_dec = avg_Fee_dec * rq_totCount_int;
                    tot_Fee = tot_Fee_dec.ToString();
                }
                #endregion 3.撈手續費 再乘以總比數
                #region 5.回覆報文
                Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
                rs_succ_otherBodyDic.Add("2028", "CO1M0000");
                rs_succ_otherBodyDic.Add("4165", tot_Fee);
                string rs_succ_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_string);
                XmlDocument rs_succ = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_string);
                return base.BuildExecResult(context, rs_succ);
                #endregion 4.回覆報文
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("ChkBatchFee Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        private string GetT24_FeeChkEnq_Content(string txnType, string txnAmt, string curr, string commType)
        {

            StringBuilder sbXmlFeeEnq = new StringBuilder();
            sbXmlFeeEnq.Append("<T24_DATA>");
            sbXmlFeeEnq.Append("<T24_EAI>");
            sbXmlFeeEnq.Append("<T24_EAI_HDR>");
            sbXmlFeeEnq.Append("<MSG_SYS_ID/>");
            sbXmlFeeEnq.Append("<HDR_MD5_DES/>");
            sbXmlFeeEnq.Append("</T24_EAI_HDR>");
            sbXmlFeeEnq.Append("<T24_EAI_MSG>");
            sbXmlFeeEnq.Append("<REQ_MSG_GRP>");
            sbXmlFeeEnq.Append("<REQ_MSG_OPT>");
            sbXmlFeeEnq.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sbXmlFeeEnq.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sbXmlFeeEnq.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sbXmlFeeEnq.Append("</REQ_MSG_OPT>");
            sbXmlFeeEnq.Append("<REQ_MSG_DATA>");
            sbXmlFeeEnq.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "IB.CHG.CHK.ENQ");
            sbXmlFeeEnq.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0035");
            sbXmlFeeEnq.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sbXmlFeeEnq.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sbXmlFeeEnq.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sbXmlFeeEnq.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sbXmlFeeEnq.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sbXmlFeeEnq.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sbXmlFeeEnq.AppendFormat("<TXN_TYPE op='EQ'>{0}</TXN_TYPE>", txnType);
            sbXmlFeeEnq.AppendFormat("<TXN_AMOUNT op='EQ'>{0}</TXN_AMOUNT>", txnAmt);
            sbXmlFeeEnq.AppendFormat("<CURR op='EQ'>{0}</CURR>", curr);
            sbXmlFeeEnq.AppendFormat("<COMM_TYPE op='EQ'>{0}</COMM_TYPE>", commType);
            sbXmlFeeEnq.Append("</REQ_MSG_DATA>");
            sbXmlFeeEnq.Append("</REQ_MSG_GRP>");
            sbXmlFeeEnq.Append("<REQ_PROC_INFO>");
            sbXmlFeeEnq.Append("<UNQ_REF_ID/>");
            sbXmlFeeEnq.Append("<REQ_PROC_SYS/>");
            sbXmlFeeEnq.Append("</REQ_PROC_INFO>");
            sbXmlFeeEnq.Append("</T24_EAI_MSG>");
            sbXmlFeeEnq.Append("</T24_EAI>");
            sbXmlFeeEnq.Append("</T24_DATA>");
            string sXmlFeeEnq = sbXmlFeeEnq.ToString();
            return sXmlFeeEnq;
        }
        #endregion 批量轉帳手續費查詢

        #region 批量轉帳   存DB 發MQ
        AppXmlExecResult DoBatchIncomingProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            bool separate = true;//抓CONFIG
            try
            {
                /*
                  1.分析報文 若失敗，回覆失敗報文
                    a.組批次號
                  2.資料解析後 寫入新TABLE 若失敗，回覆失敗報文
                  3.做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(不一定做 判斷separate)
                  4.各筆資料組織新報文<XMLOFS> 借過渡帳->貸各筆收款人 送往MSMQTALK(做在MSMQTALK?)
                    a.取檔 分析
                    b.LABEL='BATCH'
                    c.組XML時，記錄BTID於MSMQ_Body中
                  5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
                */
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

                string batchNo = string.Empty;
                string payAcnt = string.Empty, payName = string.Empty, curr = string.Empty, txnDate = string.Empty,
                       txnCount = string.Empty, totAmt = string.Empty, fileName = string.Empty;
                string transition = string.Empty;
                int iTxnCount = 0;
                DateTime t_txnDate;

                #region 1.分析報文
                Dictionary<string, string> rqHeadDic = new Dictionary<string, string>();
                Dictionary<string, string> rqBodyDic = new Dictionary<string, string>();
                ParseUcToDic(rq_t24_data, out rqHeadDic, out rqBodyDic);
                //1.a.組批次號
                batchNo = GetBatchNo(rqHeadDic, rqBodyDic);//批次號
                rqBodyDic.TryGetValue("4157", out payAcnt);//付款人帳號
                rqBodyDic.TryGetValue("4900", out payName);//付款人名稱
                rqBodyDic.TryGetValue("4118", out curr);//幣種
                rqBodyDic.TryGetValue("2006", out txnDate);//交易日期
                if (txID == "ES_2020581" || txID == "ES_2020584")
                { rqBodyDic.TryGetValue("4113", out txnCount); }//總筆數
                else//ES_2010768 ES_2010771
                { rqBodyDic.TryGetValue("4112", out txnCount); }//總筆數
                rqBodyDic.TryGetValue("4100", out totAmt);//總金額
                rqBodyDic.TryGetValue("zzzx", out fileName);//檔案名稱
                iTxnCount = Convert.ToInt32(txnCount);
                t_txnDate = DateTime.ParseExact(txnDate, "yyyyMMdd", null);
                transition = separate ? string.Empty : "transitionQQQQQ";//過渡帳戶
                #endregion 1.分析報文
                #region 2.資料解析後 寫入新TABLE
                Guid batID = Guid.NewGuid();
                int status = 2;//交易狀態為"未處理"
                int tbBATDetail_Result = DBLog.InsertBatchData(batID, batchNo, payAcnt, payName,
                                                               txID.Replace("ES_", ""), transition, curr, t_txnDate,
                                                               fileName, status, iTxnCount, totAmt, requestXml.InnerXml);
                if (tbBATDetail_Result == 0)//若無法寫入DB
                {
                    #region SendErrorMail
                    new SendMail().Send(string.Format("{0} InsertBatchData Error", txID), "", string.Format("{0} InsertBatchData Error, PLS Check RQ:[{1}]", txID, context.RequestXml.OuterXml));
                    #endregion SendErrorMail
                    m_log.Error("InsertBatchData Fail !!! BatchNO=[{0}] PayAcnt=[{1}]", batchNo, payAcnt);
                    #region 失敗 回覆失敗報文
                    Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
                    rs_fail_otherBodyDic.Add("2028", "CO1MD005");
                    rs_fail_otherBodyDic.Add("2038", "INSERT失败");
                    rs_fail_otherBodyDic.Add("4345", "2");
                    rs_fail_otherBodyDic.Add("4111", batchNo);
                    string rs_fail_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);
                    XmlDocument rs_fail = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_string);
                    return base.BuildExecResult(context, rs_fail);
                    #endregion 失敗 回覆失敗報文
                }
                #endregion 2.資料解析後 寫入新TABLE
                #region 3.若不拆分 則做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
                //string mainFt_XMLData = GetT24_FT_Content(co_Code, "I", "", curr, payAcnt, "internalAcc", "", totAmt, "", "", "", "ITF001.0025");
                //AppXmlExecResult mainFt_XMLResult = SendMsgToEAIProcess(context, mainFt_XMLData, "IB.INCOPR.TFR");//-----------------------
                //bool isSuccMainFtResult = XmlHelper.GetInstance(mainFt_XMLResult.ResponseXml).GetXPath(mainFt_XMLResult.ResponseXml, "//RSP_PROC_RET") == "SUCC";
                //if (!isSuccMainFtResult)//回覆失敗報文
                //{
                //    //更新交易狀態為"失敗"
                //    int tbUpdateBatchStatus_Result = DBLog.UpdateBatchData(batID, 2);
                //    if (tbUpdateBatchStatus_Result == 0)
                //    {
                //        //SendMail
                //    }
                //    //失敗 回覆失敗報文
                //}
                #endregion 3.若不拆分 則做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
                #region 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2020584 送往MSMQTALK(LABEL='BATCH')
                //在MSMQTALK中自動執行
                #endregion 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2020584 送往MSMQTALK(LABEL='BATCH')
                #region 5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
                Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
                rs_succ_otherBodyDic.Add("2028", "CO1M0000");
                rs_succ_otherBodyDic.Add("4345", "3");
                rs_succ_otherBodyDic.Add("4111", batchNo);
                string rs_succ_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_string);
                XmlDocument rs_succ = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_string);
                return base.BuildExecResult(context, rs_succ);
                #endregion 5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("DoBatchIncomingProcess Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        #endregion 批量轉帳   存DB 發MQ

        #region 批量轉帳   由MQ過來
        AppXmlExecResult DoBatchMqProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

                string msmq_BTID = XmlHelper.GetInstance(requestXml).GetXPath(requestXml, "//MSMQ_BTID").Trim();
                string newRqUID = Guid.NewGuid().ToString();
                if (txID == "2020581")
                {
                    rq_XmlHelper.SetXPath(requestXml, "//SIGN_ON_ID", ProjectConfig.GetInstance().OfsUser);
                    rq_XmlHelper.SetXPath(requestXml, "//SIGN_ON_PSWD", ProjectConfig.GetInstance().OfsPwd);
                    rq_XmlHelper.SetXPath(requestXml, "//CHANNEL_ID", ProjectConfig.GetInstance().ITFChannelID);
                    rq_XmlHelper.SetXPath(requestXml, "//EXT_BUSS_DATE", DateTime.Today.ToString("yyyyMMdd"));
                    rq_XmlHelper.SetXPath(requestXml, "//EXT_REFERENCE", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
                    rq_XmlHelper.SetXPath(requestXml, "//EXT_TXN_TIME", DateTime.Now.ToString("yyyyMMddHHmmss"));
                }
                #region 1.TXID改成轉帳
                string newTxID = ConvertToFtTxID(txID);
                XmlDocument xNewDoc = CopyToNewDocument(requestXml, spN_GW, custId_GW, newTxID, newRqUID);
                #endregion 1.TXID改轉帳
                #region 2.往EAI送
                AppXmlExecResult mq_Result = Send1Recv1(m_log, context, xNewDoc, true);
                #endregion 2.往EAI送
                #region 3.接取回傳結果，擷取需要資訊(明細查詢使用)
                XmlHelper xhlpr = XmlHelper.GetInstance(mq_Result.ResponseXml);
                string rsString = xhlpr.GetXPath(mq_Result.ResponseXml, "//T24_DATA").Trim();
                string rsp_proc_ret = string.Empty, commission_amt = string.Empty, itf_return_code = string.Empty,
                       rsp_txn_id = string.Empty, itf_return_msg = string.Empty;
                string workBlance = string.Empty, achAmt = string.Empty, succFail = string.Empty, errMsg = string.Empty;
                if (txID == "2020581")//企業本行
                {
                    rsp_proc_ret = xhlpr.GetXPath(mq_Result.ResponseXml, "//RSP_PROC_RET");//成功失敗
                    commission_amt = xhlpr.GetXPath(mq_Result.ResponseXml, "//COMMISSION_AMT");//手續費
                    itf_return_code = xhlpr.GetXPath(mq_Result.ResponseXml, "//ITF_RETURN_CODE");//回覆代號 E-005000之類
                    rsp_txn_id = xhlpr.GetXPath(mq_Result.ResponseXml, "//RSP_TXN_ID");//FT RECID
                    itf_return_msg = xhlpr.GetXPath(mq_Result.ResponseXml, "//ITF_RETURN_MSG ");//ITF_RETURN_MSG
                }
                else//2010768個人本行 2010771個人跨行 2020584企業跨行
                {
                    Dictionary<string, string> rsUcHead_dic, rsUcBody_dic;
                    ParseUcToDic(rsString, out rsUcHead_dic, out rsUcBody_dic);
                    rsUcBody_dic.TryGetValue("4315", out workBlance);//餘額
                    rsUcBody_dic.TryGetValue("4165", out achAmt);//手續費
                    rsUcBody_dic.TryGetValue("4345", out succFail);//成功失敗
                    rsUcBody_dic.TryGetValue("2038", out errMsg);
                }
                #endregion 3.接取回傳結果，擷取需要資訊(明細查詢使用)
                #region 4.若不拆分 則若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL(判斷separate)
                //若不拆分 判斷成功失敗 若失敗則 借過渡帳 貸付款人 往EAI送
                #endregion 4.若不拆分 則若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL(判斷separate)
                #region 5.回寫MSMQTALK
                StringBuilder xmlSB = new StringBuilder();
                if (txID == "2020581")//企業本行
                {
                    string errMappingString = (rsp_proc_ret != "SUCC" && !string.IsNullOrEmpty(itf_return_code)) ? ErrorCodeMapping("T24", itf_return_code) : "系统错误";
                    xmlSB.AppendFormat("<AdditionalInfo>");
                    xmlSB.AppendFormat("<TXN_ID>{0}</TXN_ID>", rsp_txn_id);
                    xmlSB.AppendFormat("<Fee>{0}</Fee>", commission_amt);
                    xmlSB.AppendFormat("<SuccFail>{0}</SuccFail>", rsp_proc_ret == "SUCC" ? "SUCC" : "FAIL");
                    xmlSB.AppendFormat("<ErrMsg>{0}</ErrMsg>", rsp_proc_ret == "SUCC" ? string.Empty : errMappingString);
                    xmlSB.AppendFormat("<Return_Msg>{0}</Return_Msg>", itf_return_msg);
                    xmlSB.AppendFormat("</AdditionalInfo>");
                }
                else//2010768個人本行 2010771個人跨行 2020584企業跨行
                {
                    xmlSB.AppendFormat("<AdditionalInfo>");
                    xmlSB.AppendFormat("<PayBal>{0}</PayBal>", workBlance);
                    xmlSB.AppendFormat("<Fee>{0}</Fee>", achAmt);
                    xmlSB.AppendFormat("<SuccFail>{0}</SuccFail>", succFail == "1" ? "SUCC" : "FAIL");
                    xmlSB.AppendFormat("<ErrMsg>{0}</ErrMsg>", errMsg);
                    xmlSB.AppendFormat("</AdditionalInfo>");
                }
                string xmlstring = xmlSB.ToString();
                int updateAdditInfo_Result = DBLog.UpdateMsmqAddinfoByBTID(xmlstring, msmq_BTID);
                if (updateAdditInfo_Result == 0)
                {
                    m_log.Error("UpdateMsmqAddinfoByBTID Fail !!! BTID=[{0}]", msmq_BTID);
                    new SendMail().Send(string.Format("UpdateMsmqAddinfoByBTID Fail !!! BTID=[{0}] txIX=[{1}]", msmq_BTID, txID), ""
                        , string.Format("UpdateMsmqAddinfo Error, PLS Check BTID:[{0}] AdditionalInfo:[{1}] RQ:[{2}]"
                                                         , msmq_BTID, xmlstring, context.RequestXml.OuterXml));
                }
                #endregion 5.回寫MSMQTALK
                #region 6.回覆報文(DEFAULT 並未真的回傳給城商)
                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);
                #endregion 6.回覆報文(DEFAULT 並未真的回傳給城商)
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("DoBatchMqProcess Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        string ConvertToFtTxID(string txID)
        {
            switch (txID)
            {
                case "2010768":
                    return "ES_2010766";
                case "2010771":
                    return "ES_2010767";
                case "2020581":
                    return "IB.INCOPR.TFR";
                case "2020584":
                    return "ES_2020580";
                default:
                    return txID;
            }
        }
        #endregion 批量轉帳   由MQ過來


        private string GetBankNameByAcct(string acct, EaiContext context, Dictionary<string, string> compCodeNamePairByAcct)
        {
            string companyCode = string.Empty;//CN001XXXX
            string bankCode = string.Empty;
            string bankName = string.Empty;
            if (acct.Length > 15) //CARD
            {
                string newT24RqString = GetT24_CardCustDataEnq_Content(acct);
                AppXmlExecResult cardEnqResult = SendMsgToEAIProcess(context, newT24RqString, "ESCN.CARD.CUSDATA.ENQ", true);
                XmlHelper xHelper = XmlHelper.GetInstance(cardEnqResult.ResponseXml);
                companyCode = xHelper.GetXPath(cardEnqResult.ResponseXml, "//CUS_CO_CODE").Trim();
            }
            else//T24 ACCT 
            { companyCode = string.Format("CN001{0}", acct.Substring(0, 4)); }
            if (!compCodeNamePairByAcct.ContainsKey(companyCode))//Key:9碼行號CN00XXXXX Value:行名
            {
                bankName = GetBankName(companyCode, context);//9碼行號查行名
                compCodeNamePairByAcct.Add(companyCode, bankName);
                m_log.Info("GetBankNameByAcct - Add compCodeNamePair - Key:[{0}] Value:[{1}] Total:[{2}]Pairs", companyCode, bankName, compCodeNamePairByAcct.Count);
            }
            else
            { compCodeNamePairByAcct.TryGetValue(companyCode, out bankName); }
            return bankName;
        }
        private string GetT24_CardCustDataEnq_Content(string cardNo)
        {
            StringBuilder sbXmlCardCompanyCodeEnq = new StringBuilder();
            sbXmlCardCompanyCodeEnq.Append("<T24_DATA>");
            sbXmlCardCompanyCodeEnq.Append("<T24_EAI>");
            sbXmlCardCompanyCodeEnq.Append("<T24_EAI_HDR>");
            sbXmlCardCompanyCodeEnq.Append("<MSG_SYS_ID/>");
            sbXmlCardCompanyCodeEnq.Append("<HDR_MD5_DES/>");
            sbXmlCardCompanyCodeEnq.Append("</T24_EAI_HDR>");
            sbXmlCardCompanyCodeEnq.Append("<T24_EAI_MSG>");
            sbXmlCardCompanyCodeEnq.Append("<REQ_MSG_GRP>");
            sbXmlCardCompanyCodeEnq.Append("<REQ_MSG_OPT>");
            sbXmlCardCompanyCodeEnq.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sbXmlCardCompanyCodeEnq.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sbXmlCardCompanyCodeEnq.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sbXmlCardCompanyCodeEnq.Append("</REQ_MSG_OPT>");
            sbXmlCardCompanyCodeEnq.Append("<REQ_MSG_DATA>");
            sbXmlCardCompanyCodeEnq.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.CARD.CUSDATA.ENQ");
            sbXmlCardCompanyCodeEnq.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "CUP001.0001");
            sbXmlCardCompanyCodeEnq.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sbXmlCardCompanyCodeEnq.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sbXmlCardCompanyCodeEnq.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sbXmlCardCompanyCodeEnq.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sbXmlCardCompanyCodeEnq.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sbXmlCardCompanyCodeEnq.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sbXmlCardCompanyCodeEnq.AppendFormat("<CARD_NO op='EQ'>{0}</CARD_NO>", cardNo);
            sbXmlCardCompanyCodeEnq.Append("</REQ_MSG_DATA>");
            sbXmlCardCompanyCodeEnq.Append("</REQ_MSG_GRP>");
            sbXmlCardCompanyCodeEnq.Append("<REQ_PROC_INFO>");
            sbXmlCardCompanyCodeEnq.Append("<UNQ_REF_ID/>");
            sbXmlCardCompanyCodeEnq.Append("<REQ_PROC_SYS/>");
            sbXmlCardCompanyCodeEnq.Append("</REQ_PROC_INFO>");
            sbXmlCardCompanyCodeEnq.Append("</T24_EAI_MSG>");
            sbXmlCardCompanyCodeEnq.Append("</T24_EAI>");
            sbXmlCardCompanyCodeEnq.Append("</T24_DATA>");
            return sbXmlCardCompanyCodeEnq.ToString();
        }
        private string GetBankName(string companyCode, EaiContext context)
        {
            string newT24RqString = GetT24_SeeBkNameByCoCode_Content(companyCode);
            AppXmlExecResult bankCodeResult = SendMsgToEAIProcess(context, newT24RqString, "ESCN.BP.COMP.INQ", true);
            XmlHelper xHelper = XmlHelper.GetInstance(bankCodeResult.ResponseXml);
            var nodeLst = xHelper.SelectNodes(bankCodeResult.ResponseXml, "//COMPANY_NAME");
            string bankName = nodeLst.Count > 0 ? nodeLst.Item(nodeLst.Count - 1).InnerText : string.Empty;
            if (nodeLst.Count == 0 && string.IsNullOrEmpty(bankName))
            { m_log.Error("GetBankName Error !!! CompanyCode:[{0}]", companyCode); }
            else
            { m_log.Info("GetBankName Succ ! CompanyCode:[{0}] BankName:[{1}]", companyCode, bankName); }
            return bankName;
        }
        private string GetT24_SeeBkNameByCoCode_Content(string companyCode)
        {
            StringBuilder sbXmlBankNameEnq = new StringBuilder();
            sbXmlBankNameEnq.Append("<T24_DATA>");
            sbXmlBankNameEnq.Append("<T24_EAI>");
            sbXmlBankNameEnq.Append("<T24_EAI_HDR>");
            sbXmlBankNameEnq.Append("<MSG_SYS_ID/>");
            sbXmlBankNameEnq.Append("<HDR_MD5_DES/>");
            sbXmlBankNameEnq.Append("</T24_EAI_HDR>");
            sbXmlBankNameEnq.Append("<T24_EAI_MSG>");
            sbXmlBankNameEnq.Append("<REQ_MSG_GRP>");
            sbXmlBankNameEnq.Append("<REQ_MSG_OPT>");
            sbXmlBankNameEnq.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sbXmlBankNameEnq.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sbXmlBankNameEnq.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sbXmlBankNameEnq.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", "S");
            sbXmlBankNameEnq.Append("</REQ_MSG_OPT>");
            sbXmlBankNameEnq.Append("<REQ_MSG_DATA>");
            sbXmlBankNameEnq.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "COMPANY");
            sbXmlBankNameEnq.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "ITF.CO.COMP.INQ");
            sbXmlBankNameEnq.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", companyCode);
            sbXmlBankNameEnq.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF000.0002");
            sbXmlBankNameEnq.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sbXmlBankNameEnq.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sbXmlBankNameEnq.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sbXmlBankNameEnq.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sbXmlBankNameEnq.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sbXmlBankNameEnq.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sbXmlBankNameEnq.Append("</REQ_MSG_DATA>");
            sbXmlBankNameEnq.Append("</REQ_MSG_GRP>");
            sbXmlBankNameEnq.Append("<REQ_PROC_INFO>");
            sbXmlBankNameEnq.Append("<UNQ_REF_ID/>");
            sbXmlBankNameEnq.Append("<REQ_PROC_SYS/>");
            sbXmlBankNameEnq.Append("</REQ_PROC_INFO>");
            sbXmlBankNameEnq.Append("</T24_EAI_MSG>");
            sbXmlBankNameEnq.Append("</T24_EAI>");
            sbXmlBankNameEnq.Append("</T24_DATA>");
            string sXmlFeeEnq = sbXmlBankNameEnq.ToString();
            return sXmlFeeEnq;
        }
        private string GetT24_SeeBankName_Content(string finCodde)
        {
            StringBuilder sbXmlBankNameEnq = new StringBuilder();
            sbXmlBankNameEnq.Append("<T24_DATA>");
            sbXmlBankNameEnq.Append("<T24_EAI>");
            sbXmlBankNameEnq.Append("<T24_EAI_HDR>");
            sbXmlBankNameEnq.Append("<MSG_SYS_ID/>");
            sbXmlBankNameEnq.Append("<HDR_MD5_DES/>");
            sbXmlBankNameEnq.Append("</T24_EAI_HDR>");
            sbXmlBankNameEnq.Append("<T24_EAI_MSG>");
            sbXmlBankNameEnq.Append("<REQ_MSG_GRP>");
            sbXmlBankNameEnq.Append("<REQ_MSG_OPT>");
            sbXmlBankNameEnq.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sbXmlBankNameEnq.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sbXmlBankNameEnq.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sbXmlBankNameEnq.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", "S");
            sbXmlBankNameEnq.Append("</REQ_MSG_OPT>");
            sbXmlBankNameEnq.Append("<REQ_MSG_DATA>");
            sbXmlBankNameEnq.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "ESCN.FIN.BANK.CODE");
            sbXmlBankNameEnq.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "");
            sbXmlBankNameEnq.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", finCodde);
            sbXmlBankNameEnq.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "IB001.0013");
            sbXmlBankNameEnq.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sbXmlBankNameEnq.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sbXmlBankNameEnq.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sbXmlBankNameEnq.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sbXmlBankNameEnq.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sbXmlBankNameEnq.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sbXmlBankNameEnq.Append("</REQ_MSG_DATA>");
            sbXmlBankNameEnq.Append("</REQ_MSG_GRP>");
            sbXmlBankNameEnq.Append("<REQ_PROC_INFO>");
            sbXmlBankNameEnq.Append("<UNQ_REF_ID/>");
            sbXmlBankNameEnq.Append("<REQ_PROC_SYS/>");
            sbXmlBankNameEnq.Append("</REQ_PROC_INFO>");
            sbXmlBankNameEnq.Append("</T24_EAI_MSG>");
            sbXmlBankNameEnq.Append("</T24_EAI>");
            sbXmlBankNameEnq.Append("</T24_DATA>");
            string sXmlFeeEnq = sbXmlBankNameEnq.ToString();
            return sXmlFeeEnq;
        }


        #region util ---ParseUcToDic() ErrorCodeMapping() GetBatchNo() DatasetToDiclist() GetRsStringFromRqDic()---
        void ParseUcToDic(string rsString, out Dictionary<string, string> ucHeadDic, out Dictionary<string, string> ucBodyDic)
        {
            if (string.IsNullOrEmpty(rsString))
            {
                ucHeadDic = new Dictionary<string, string>();
                ucBodyDic = new Dictionary<string, string>();
                return;
            }
            UcControler uCcontroler = new UcControler();
            UcBody ucBody = new UcBody();
            ucHeadDic = uCcontroler.UC2T24_Head(rsString);
            ucBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);
            m_log.Debug("ParseUcToDic rsString = [{0}]", rsString);
            foreach (KeyValuePair<string, string> kv in ucHeadDic)
            { m_log.Debug("ucHead = [{0}][{1}]", kv.Key, kv.Value); }
            foreach (KeyValuePair<string, string> kv in ucBodyDic)
            { m_log.Debug("ucBody = [{0}][{1}]", kv.Key, kv.Value); }
        }
        string GetBatchNo(Dictionary<string, string> rqUcHeadDic, Dictionary<string, string> rqUcBodyDic)
        {
            #region 組出批次號 由具有唯一性的"委託日期+發起行行號+業務類型+交易序號"組成
            string commissionDate, fCompany, binsType, trxNo, batchNo;
            rqUcBodyDic.TryGetValue("2006", out commissionDate);
            rqUcBodyDic.TryGetValue("2002", out fCompany);
            rqUcHeadDic.TryGetValue("BinsType", out binsType);
            rqUcBodyDic.TryGetValue("2039", out trxNo);
            batchNo = commissionDate + fCompany + binsType + trxNo;
            #endregion 組出批次號 由具有唯一性的"委託日期+發起行行號+業務類型+交易序號"組成
            return batchNo;
        }
        public List<Dictionary<string, string>> DatasetToDiclist(DataSet dataset)
        {
            List<Dictionary<string, string>> lstdata = new List<Dictionary<string, string>>();
            if (dataset != null && dataset.Tables.Count > 0)
            {
                foreach (DataRow drow in dataset.Tables[0].Rows)
                {
                    Dictionary<string, string> tempData = new Dictionary<string, string>();

                    for (int i = 0; i <= drow.ItemArray.Length - 1; i++)
                    {
                        tempData.Add(dataset.Tables[0].Columns[i].ColumnName, drow.ItemArray[i].ToString());
                    }
                    lstdata.Add(tempData);
                }
            }
            return lstdata;
        }
        string ErrorCodeMapping(string sourceName, string sourceStatus)
        {
            Bankpro.EAI.Component.StatusData status = Bankpro.EAI.Component.ProjectCache.GetInstance().GetStatusData(sourceName, sourceStatus);

            if (status != null)
                return status.m_statusDesc;
            else
                return sourceStatus;
        }
        //string GetRsStringFromRqDic(Dictionary<string, string> rqHeadDic, Dictionary<string, string> rqBodyDic, Dictionary<string, string> otherBodyDic)
        //{
        //    UcControler rs_uccontroler = new UcControler();
        //    UcHead rs_uchead = new UcHead();
        //    UcBody rs_ucbody = new UcBody();
        //    Dictionary<string, string> newBodyDic = new Dictionary<string, string>();
        //    foreach (KeyValuePair<string, string> kv in rqBodyDic)
        //    {
        //        switch (kv.Key)
        //        {
        //            case "2001":
        //            case "2002":
        //            case "2003":
        //            case "2004":
        //            case "2005":
        //            case "2006":
        //            case "2039":
        //                newBodyDic.Add(kv.Key, kv.Value);
        //                break;
        //        }
        //    }
        //    foreach (KeyValuePair<string, string> kv in otherBodyDic)
        //    {
        //        newBodyDic.Add(kv.Key, kv.Value);
        //    }
        //    string rs_head = rs_uchead.GetRSHeadString(rqHeadDic, "");
        //    string rs_body = rs_ucbody.GetUcStringFromDic(newBodyDic);
        //    return rs_head + rs_body;
        //}
        AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey, bool SendToEAI)
        {
            string msgContent = string.Empty;
            if (SendToEAI)
            { msgContent = base.SendToEAIProcess(body, eAI_MsgKey, spN_GW, custId_GW); }
            else
            { msgContent = base.SendToEAIProcess(body, eAI_MsgKey); }

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(msgContent);
            XmlDocument subRqXml = null;
            if (SendToEAI)
            { subRqXml = CopyToNewDocument(rq, spN_GW, custId_GW, eAI_MsgKey, Guid.NewGuid().ToString()); }
            else
            { subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString()); }
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, subRqXml.InnerXml);
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml, SendToEAI);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }

        #endregion util ---ParseUcToDic() ErrorCodeMapping() GetBatchNo() DatasetToDiclist() GetRsStringFromRqDic()---




        #region 跨行批量轉帳查詢
        private AppXmlExecResult Do2020582_2010769Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA");
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(rq_t24_data);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string rq_IsCross = string.Empty, rq_PayAcnt = string.Empty,
                       rq_StartDate = string.Empty, rq_EndDate = string.Empty;
                rqBodyDic.TryGetValue("4026", out rq_IsCross);//1為行內 2為跨行
                rqBodyDic.TryGetValue("4300", out rq_PayAcnt);
                rqBodyDic.TryGetValue("4119", out rq_StartDate);
                rqBodyDic.TryGetValue("4120", out rq_EndDate);
                string tg_MsgKey = string.Empty;
                if (txID == "2020582")
                    tg_MsgKey = rq_IsCross == "1" ? "2020581" : "2020584";
                else if (txID == "2010769")
                    tg_MsgKey = rq_IsCross == "1" ? "2010768" : "2010771";
                #endregion 1.分析報文
                #region 2.撈取批量資訊
                DataSet dsBatch = DBLog.SelectBatchByPayacntAndDate(rq_PayAcnt, rq_StartDate, rq_EndDate, tg_MsgKey);
                List<Dictionary<string, string>> dicListBatch = DatasetToDiclist(dsBatch);
                dicListBatch = dicListBatch.OrderByDescending(p => p.ContainsKey("BatchNo") ? p["BatchNo"] : string.Empty).ToList();
                #endregion 2.撈取批量資訊
                #region 3.撈取批量明細資訊並且產生FileContent
                List<string> fileContentList = new List<string>();
                foreach (Dictionary<string, string> dicBatch in dicListBatch)
                {
                    string bat_BATID = string.Empty, bat_BatchNo = string.Empty;
                    string bat_PayAcnt = string.Empty, bat_PayName = string.Empty,
                           bat_TxnCount = string.Empty, bat_TotAmt = string.Empty,
                           bat_Status = string.Empty, bat_TxnDate = string.Empty;
                    DateTime bat_TxnDate_d;
                    dicBatch.TryGetValue("BATID", out bat_BATID); dicBatch.TryGetValue("BatchNo", out bat_BatchNo);
                    dicBatch.TryGetValue("PayAcnt", out bat_PayAcnt); dicBatch.TryGetValue("PayName", out bat_PayName);
                    dicBatch.TryGetValue("TxnCount", out bat_TxnCount); dicBatch.TryGetValue("TotAmt", out bat_TotAmt);
                    dicBatch.TryGetValue("Status", out bat_Status); dicBatch.TryGetValue("TxnDate", out bat_TxnDate);
                    if (DateTime.TryParse(bat_TxnDate, out bat_TxnDate_d))
                    { bat_TxnDate = bat_TxnDate_d.ToString("yyyyMMdd"); }
                    DataSet dsMsmq = DBLog.SelectMqtkByImportID(bat_BATID, "BATCH");
                    List<Dictionary<string, string>> dicListMsmq = DatasetToDiclist(dsMsmq);
                    dicListMsmq = dicListMsmq.OrderBy(p => p.ContainsKey("CreateDate") ? p["CreateDate"] : string.Empty).ToList();
                    int succ_Count = 0, fail_Count = 0; decimal succ_TotAmt = 0, fail_TotAmt = 0;
                    foreach (Dictionary<string, string> dicMsmq in dicListMsmq)
                    {
                        string mq_msmq_Body = string.Empty, mq_AdditInfo = string.Empty, mq_Status = string.Empty;
                        string msmqai_SuccFail = string.Empty;
                        string msmqbd_Amt = string.Empty;
                        dicMsmq.TryGetValue("MSMQ_Body", out mq_msmq_Body);
                        dicMsmq.TryGetValue("AdditionalInfo", out mq_AdditInfo);
                        dicMsmq.TryGetValue("Status", out mq_Status);
                        XmlDocument msmqbd_Xdoc = new XmlDocument(); msmqbd_Xdoc.LoadXml(mq_msmq_Body);
                        if (tg_MsgKey == "2020581")
                        {
                            msmqbd_Amt = XmlHelper.GetInstance(msmqbd_Xdoc).GetXPath(msmqbd_Xdoc, "//DEBIT_AMOUNT");
                        }
                        else//2020584 2010768 2010771
                        {
                            string msmqbd_T24DATA = XmlHelper.GetInstance(msmqbd_Xdoc).GetXPath(msmqbd_Xdoc, "//T24_DATA");
                            Dictionary<string, string> msmqbd_T24DATA_hDic, msmqbd_T24DATA_bDic;
                            ParseUcToDic(msmqbd_T24DATA, out msmqbd_T24DATA_hDic, out msmqbd_T24DATA_bDic);
                            msmqbd_T24DATA_bDic.TryGetValue("4100", out msmqbd_Amt);
                        }
                        XmlDocument msmqai_Xdoc = new XmlDocument();
                        if (!string.IsNullOrEmpty(mq_AdditInfo))
                        {
                            msmqai_Xdoc.LoadXml(mq_AdditInfo);
                            msmqai_SuccFail = XmlHelper.GetInstance(msmqai_Xdoc).GetXPath(msmqai_Xdoc, "//SuccFail");
                            string txnStatus = Get_Txn_Status(mq_Status, msmqai_SuccFail);
                            if (txnStatus == "0")
                            {
                                succ_Count += 1;
                                succ_TotAmt += Convert.ToDecimal(msmqbd_Amt);
                            }
                            else if (txnStatus == "1")
                            {
                                fail_Count += 1;
                                fail_TotAmt += Convert.ToDecimal(msmqbd_Amt);
                            }
                        }
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.Append(bat_BatchNo).Append("|");//批次號
                    sb.Append(bat_PayAcnt).Append("|");//付款帳號
                    sb.Append(bat_PayName).Append("|");//付款名稱
                    sb.Append(bat_TxnCount).Append("|");//總筆數
                    sb.Append(bat_TotAmt).Append("|");//總金額
                    sb.Append(succ_Count.ToString()).Append("|");//成功筆數
                    sb.Append(succ_TotAmt.ToString()).Append("|");//成功金額
                    sb.Append(fail_Count.ToString()).Append("|");//失敗筆數
                    sb.Append(fail_TotAmt.ToString()).Append("|");//失敗金額
                    sb.Append(bat_Status).Append("|");//狀態
                    sb.Append(bat_TxnDate).Append("|");//交易日期
                    fileContentList.Add(sb.ToString());
                }
                #endregion 3.撈取批量明細資訊並且產生FileContent
                #region 4.回覆結果
                uCcontroler.CreateEnqFileToUC(fileContentList, true);
                Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
                rs_succ_otherBodyDic.Add("2028", "CO1M0000");
                rs_succ_otherBodyDic.Add("4112", fileContentList.Count.ToString());//總筆數
                rs_succ_otherBodyDic.Add("zzzx", uCcontroler.enqFileName);//文件名
                string rs_succ_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_String);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_String);
                return base.BuildExecResult(context, rs);
                #endregion 4.回覆結果
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do2020582_2010769Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        #endregion 跨行批量轉帳查詢

        #region 跨行批量轉帳明細查詢
        private AppXmlExecResult Do2020583_2010770Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA");
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

                #region 1.分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(rq_t24_data);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string rq_IsCross = string.Empty, rq_BatchNo = string.Empty;
                rqBodyDic.TryGetValue("4026", out rq_IsCross);//1為行內 2為跨行
                rqBodyDic.TryGetValue("4111", out rq_BatchNo);
                string tg_MsgKey = string.Empty;
                if (txID == "2020583")
                    tg_MsgKey = rq_IsCross == "1" ? "2020581" : "2020584";
                else if (txID == "2010770")
                    tg_MsgKey = rq_IsCross == "1" ? "2010768" : "2010771";
                #endregion 1.分析報文
                #region 2.撈取批量資訊
                DataSet dsBatch = DBLog.SelectBatchByBatchno(rq_BatchNo, tg_MsgKey);
                List<Dictionary<string, string>> dicListBatch = DatasetToDiclist(dsBatch);
                #endregion 2.撈取批量資訊
                #region 3.撈取批量明細資訊並且產生FileContent
                List<string> fileContentList = new List<string>();
                Dictionary<string, string> dicBatch = dicListBatch[0];
                string bat_BATID = string.Empty; //bat_BatchNo = string.Empty;
                string bat_PayAcnt = string.Empty, bat_PayName = string.Empty,
                       //bat_TxnCount = string.Empty, //bat_TotAmt = string.Empty,
                       //bat_Status = string.Empty, //bat_TxnDate = string.Empty,
                       bat_Curr = string.Empty;
                dicBatch.TryGetValue("BATID", out bat_BATID); //dicBatch.TryGetValue("BatchNo", out bat_BatchNo);
                dicBatch.TryGetValue("PayAcnt", out bat_PayAcnt); dicBatch.TryGetValue("PayName", out bat_PayName);
                //dicBatch.TryGetValue("TxnCount", out bat_TxnCount); //dicBatch.TryGetValue("TotAmt", out bat_TotAmt);
                //dicBatch.TryGetValue("Status", out bat_Status); //dicBatch.TryGetValue("TxnDate", out bat_TxnDate);
                dicBatch.TryGetValue("Curr", out bat_Curr);
                DataSet dsMsmq = DBLog.SelectMqtkByImportID(bat_BATID, "BATCH");
                List<Dictionary<string, string>> dicListMsmq = DatasetToDiclist(dsMsmq);
                dicListMsmq = dicListMsmq.OrderBy(p => p.ContainsKey("CreateDate") ? p["CreateDate"] : string.Empty).ToList();
                Dictionary<string, string> compCodeNamePairByAcct = new Dictionary<string, string>();
                foreach (Dictionary<string, string> dicMsmq in dicListMsmq)
                {
                    string mq_msmq_Body = string.Empty, mq_additInfo = string.Empty,
                           mq_updateDate = string.Empty, mq_status = string.Empty; ;
                    string mq_updateDate_Date = string.Empty, mq_updateDate_Time = string.Empty;
                    DateTime mq_updateDate_d;
                    dicMsmq.TryGetValue("MSMQ_Body", out mq_msmq_Body); dicMsmq.TryGetValue("AdditionalInfo", out mq_additInfo);
                    dicMsmq.TryGetValue("UpdateDate", out mq_updateDate); dicMsmq.TryGetValue("Status", out mq_status);
                    if (DateTime.TryParse(mq_updateDate, out mq_updateDate_d))
                    {
                        mq_updateDate_Date = mq_updateDate_d.ToString("yyyyMMdd");
                        mq_updateDate_Time = mq_updateDate_d.ToString("HHmmss");
                    }
                    string msmqbd_PyeBankName = string.Empty, msmqbd_PyeAcnt = string.Empty, msmqbd_PyeName = string.Empty,
                           msmqbd_Amt = string.Empty, msmqbd_Usage = string.Empty;
                    XmlDocument msmqbd_Xdoc = new XmlDocument(); msmqbd_Xdoc.LoadXml(mq_msmq_Body);
                    if (tg_MsgKey == "2020581")//企業 本行
                    {
                        msmqbd_PyeAcnt = XmlHelper.GetInstance(msmqbd_Xdoc).GetXPath(msmqbd_Xdoc, "//CREDIT_ACCT.NO");
                        msmqbd_PyeName = XmlHelper.GetInstance(msmqbd_Xdoc).GetXPath(msmqbd_Xdoc, "//C_PAYEE_NAME");
                        msmqbd_Amt = XmlHelper.GetInstance(msmqbd_Xdoc).GetXPath(msmqbd_Xdoc, "//DEBIT_AMOUNT");
                        msmqbd_Usage = XmlHelper.GetInstance(msmqbd_Xdoc).GetXPath(msmqbd_Xdoc, "//DEBIT_THEIR_REF");
                        msmqbd_PyeBankName = GetBankNameByAcct(msmqbd_PyeAcnt, context, compCodeNamePairByAcct);
                    }
                    else
                    {
                        string msmqbd_T24DATA = XmlHelper.GetInstance(msmqbd_Xdoc).GetXPath(msmqbd_Xdoc, "//T24_DATA");
                        Dictionary<string, string> msmqbd_T24DATA_hDic, msmqbd_T24DATA_bDic;
                        ParseUcToDic(msmqbd_T24DATA, out msmqbd_T24DATA_hDic, out msmqbd_T24DATA_bDic);
                        if (tg_MsgKey == "2020584")//企業 跨行
                        {
                            msmqbd_T24DATA_bDic.TryGetValue("PBKN", out msmqbd_PyeBankName);
                            msmqbd_T24DATA_bDic.TryGetValue("4161", out msmqbd_PyeAcnt);
                            msmqbd_T24DATA_bDic.TryGetValue("4732", out msmqbd_PyeName);
                            msmqbd_T24DATA_bDic.TryGetValue("4100", out msmqbd_Amt);
                            msmqbd_T24DATA_bDic.TryGetValue("4349", out msmqbd_Usage);
                        }
                        else if (tg_MsgKey == "2010768")//個人 本行
                        {
                            msmqbd_T24DATA_bDic.TryGetValue("4161", out msmqbd_PyeAcnt);
                            msmqbd_T24DATA_bDic.TryGetValue("4900", out msmqbd_PyeName);
                            msmqbd_T24DATA_bDic.TryGetValue("4100", out msmqbd_Amt);
                            msmqbd_T24DATA_bDic.TryGetValue("4732", out msmqbd_Usage);
                            msmqbd_PyeBankName = GetBankNameByAcct(msmqbd_PyeAcnt, context, compCodeNamePairByAcct);
                        }
                        else //2010771 //個人 跨行
                        {
                            msmqbd_T24DATA_bDic.TryGetValue("4658", out msmqbd_PyeBankName);
                            msmqbd_T24DATA_bDic.TryGetValue("4161", out msmqbd_PyeAcnt);
                            msmqbd_T24DATA_bDic.TryGetValue("4733", out msmqbd_PyeName);
                            msmqbd_T24DATA_bDic.TryGetValue("4100", out msmqbd_Amt);
                            msmqbd_T24DATA_bDic.TryGetValue("4897", out msmqbd_Usage);
                        }
                    }
                    string msmqai_SuccFail = string.Empty, msmqai_ErrMsg = string.Empty, msmqai_Fee = string.Empty;
                    XmlDocument msmqai_Xdoc = new XmlDocument();
                    if (!string.IsNullOrEmpty(mq_additInfo))
                    {
                        msmqai_Xdoc.LoadXml(mq_additInfo);
                        msmqai_SuccFail = XmlHelper.GetInstance(msmqai_Xdoc).GetXPath(msmqai_Xdoc, "//SuccFail");
                        msmqai_ErrMsg = XmlHelper.GetInstance(msmqai_Xdoc).GetXPath(msmqai_Xdoc, "//ErrMsg");
                        msmqai_Fee = XmlHelper.GetInstance(msmqai_Xdoc).GetXPath(msmqai_Xdoc, "//Fee");
                    }
                    StringBuilder sb = new StringBuilder();
                    string txnStatus = Get_Txn_Status(mq_status, msmqai_SuccFail);
                    if (txnStatus == "0" && string.IsNullOrEmpty(msmqai_Fee))
                    { msmqai_Fee = "0.00"; }
                    if (txID == "2020583")//查企業批量明細
                    {
                        sb.Append(bat_PayAcnt).Append("|");//付款帳號
                        sb.Append(bat_PayName).Append("|");//付款名稱
                        sb.Append(msmqbd_PyeBankName).Append("|");//收款行名
                        sb.Append(msmqbd_PyeAcnt).Append("|");//收款帳號
                        sb.Append(msmqbd_PyeName).Append("|");//收款名稱
                        sb.Append(msmqbd_Amt).Append("|");//付款金額
                        sb.Append(bat_Curr).Append("|");//幣種
                        sb.Append(txnStatus).Append("|");//交易狀態
                        sb.Append(mq_updateDate_Date).Append("|");//交易日期
                        sb.Append(mq_updateDate_Time).Append("|");//交易時間
                        sb.Append(msmqai_ErrMsg).Append("|");//錯誤訊息
                        sb.Append(msmqbd_Usage).Append("|");//付款用途
                        sb.Append(msmqai_Fee).Append("|");//匯款手續費
                    }
                    else if (txID == "2010770")//查個人批量明細
                    {
                        sb.Append(bat_Curr).Append("|");//幣種
                        sb.Append(mq_updateDate_Date).Append("|");//交易日期
                        sb.Append(mq_updateDate_Time).Append("|");//交易時間
                        sb.Append(bat_PayAcnt).Append("|");//付款帳號
                        sb.Append(bat_PayName).Append("|");//付款名稱
                        sb.Append(msmqbd_PyeBankName).Append("|");//收款行名
                        sb.Append(msmqbd_PyeAcnt).Append("|");//收款帳號
                        sb.Append(msmqbd_PyeName).Append("|");//收款名稱
                        sb.Append(msmqbd_Amt).Append("|");//付款金額
                        sb.Append(msmqai_Fee).Append("|");//匯款手續費
                        sb.Append(msmqbd_Usage).Append("|");//付款用途
                        sb.Append(txnStatus).Append("|");//交易狀態
                        sb.Append(msmqai_ErrMsg).Append("|");//錯誤訊息
                    }
                    fileContentList.Add(sb.ToString());
                }
                #endregion 3.撈取批量明細資訊並且產生FileContent
                #region 4.回覆結果
                uCcontroler.CreateEnqFileToUC(fileContentList, true);
                Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
                rs_succ_otherBodyDic.Add("2028", "CO1M0000");
                rs_succ_otherBodyDic.Add("4113", fileContentList.Count.ToString());//總筆數
                rs_succ_otherBodyDic.Add("zzzx", uCcontroler.enqFileName);//文件名
                string rs_succ_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_String);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_String);
                return base.BuildExecResult(context, rs);
                #endregion 4.回覆結果
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do2020583_2010770Process Error TxID=[{0}]", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        #endregion 跨行批量轉帳明細查詢

        string Get_Txn_Status(string mq_status, string msmqai_SuccFail)
        {
            switch (mq_status)
            {
                case "1"://Processing
                case "2"://Sending
                case "3"://Resend
                    return "2";//銀行處理中
                //case "7"://Stop(交易暫停發送)
                case "8"://Pending
                case "9"://Fail
                    return "1";//失敗
                case "0":
                    if (msmqai_SuccFail == "SUCC")
                        return "0";//成功
                    else
                        return "1";//失敗
                default:
                    return "1";
            }
        }


        #region 暫止使用
        #region 個人 行內批量轉帳
        //private AppXmlExecResult DoES_2010768Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        //{
        //    bool separate = true;//抓CONFIG
        //    try
        //    {
        //        /*
        //          TXID=ES_2010768
        //          1.分析報文 若失敗，回覆失敗報文
        //            a.組批次號
        //          2.資料解析後 寫入新TABLE 若失敗，回覆失敗報文
        //          3.做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //          4.各筆資料組織新報文<XMLOFS> 借過渡帳->貸各筆收款人 送往MSMQTALK(做在MSMQTALK?)
        //            a.取檔 分析
        //            b.TXID=2020581 
        //            c.LABEL='BATCH'
        //            d.組XML時，記錄BTID於MSMQ_Body中
        //          5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //        */
        //        XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
        //        string rq_t24_data = rq_XmlHelper.SelectSingleNode(requestXml, "//T24_DATA").InnerXml;
        //        m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

        //        string batchNo = string.Empty;
        //        string payAcnt = string.Empty, payName = string.Empty, curr = string.Empty, txnDate = string.Empty, txnCount = string.Empty, totAmt = string.Empty, fileName = string.Empty;
        //        string transition = string.Empty;
        //        int iTxnCount = 0;
        //        DateTime t_txnDate;

        //        #region 1.分析報文
        //        Dictionary<string, string> rqHeadDic = new Dictionary<string, string>();
        //        Dictionary<string, string> rqBodyDic = new Dictionary<string, string>();
        //        GetRsRq_H_B_Dic(rq_t24_data, out rqHeadDic, out rqBodyDic);
        //        //1.a.組批次號
        //        batchNo = GetBatchNo(rqHeadDic, rqBodyDic);//批次號
        //        rqBodyDic.TryGetValue("4157", out payAcnt);//付款人帳號
        //        rqBodyDic.TryGetValue("4900", out payName);//付款人名稱
        //        rqBodyDic.TryGetValue("4118", out curr);//幣種
        //        rqBodyDic.TryGetValue("2006", out txnDate);//交易日期
        //        rqBodyDic.TryGetValue("4112", out txnCount);//總筆數
        //        rqBodyDic.TryGetValue("4100", out totAmt);//總金額
        //        rqBodyDic.TryGetValue("zzzx", out fileName);//檔案名稱
        //        iTxnCount = Convert.ToInt32(txnCount);
        //        t_txnDate = DateTime.ParseExact(txnDate, "yyyyMMdd", null);
        //        transition = separate ? string.Empty : "transitionQQQQQ";//過渡帳戶
        //        #endregion 1.分析報文
        //        #region 2.資料解析後 寫入新TABLE
        //        Guid batID = Guid.NewGuid();
        //        int status = 2;//交易狀態為"未處理"
        //        int tbBATDetail_Result = DBLog.InsertBatchData(batID, batchNo, payAcnt, payName,
        //                                                       "2010768", transition, curr, t_txnDate, fileName, status, iTxnCount, totAmt, requestXml.InnerXml);
        //        if (tbBATDetail_Result == 0)//若無法寫入DB
        //        {
        //            #region SendErrorMail
        //            new SendMail().Send("ES_2010768 InsertBatchData Error", "", string.Format("ES_2010768 InsertBatchData Error, PLS Check RQ:[{0}]", context.RequestXml.OuterXml));
        //            #endregion SendErrorMail
        //            m_log.Error("InsertBatchData Fail !!! BatchNO=[{0}] PayAcnt=[{1}]", batchNo, payAcnt);
        //            #region 失敗 回覆失敗報文
        //            Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
        //            rs_fail_otherBodyDic.Add("2028", "CO1MD005");
        //            rs_fail_otherBodyDic.Add("2038", "INSERT失败");
        //            rs_fail_otherBodyDic.Add("4345", "2");
        //            rs_fail_otherBodyDic.Add("4111", batchNo);
        //            string rs_fail_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);
        //            XmlDocument rs_fail = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_string);
        //            return base.BuildExecResult(context, rs_fail);
        //            #endregion 失敗 回覆失敗報文
        //        }
        //        #endregion 2.資料解析後 寫入新TABLE
        //        #region 3.若不拆分 則做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //        //string mainFt_XMLData = GetT24_FT_Content(co_Code, "I", "", curr, payAcnt, "internalAcc", "", totAmt, "", "", "", "ITF001.0025");
        //        //AppXmlExecResult mainFt_XMLResult = SendMsgToEAIProcess(context, mainFt_XMLData, "IB.INCOPR.TFR");//-----------------------
        //        //bool isSuccMainFtResult = XmlHelper.GetInstance(mainFt_XMLResult.ResponseXml).GetXPath(mainFt_XMLResult.ResponseXml, "//RSP_PROC_RET") == "SUCC";
        //        //if (!isSuccMainFtResult)//回覆失敗報文
        //        //{
        //        //    //更新交易狀態為"失敗"
        //        //    int tbUpdateBatchStatus_Result = DBLog.UpdateBatchData(batID, 2);
        //        //    if (tbUpdateBatchStatus_Result == 0)
        //        //    {
        //        //        //SendMail
        //        //    }
        //        //    //失敗 回覆失敗報文
        //        //}
        //        #endregion 3.若不拆分 則做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //        #region 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2010768 送往MSMQTALK(LABEL='BATCH')
        //        //在MSMQTALK中自動執行
        //        #endregion 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2010768 送往MSMQTALK(LABEL='BATCH')
        //        #region 5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //        Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
        //        rs_succ_otherBodyDic.Add("2028", "CO1M0000");
        //        rs_succ_otherBodyDic.Add("4345", "3");
        //        rs_succ_otherBodyDic.Add("4111", batchNo);
        //        string rs_succ_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

        //        m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_string);
        //        XmlDocument rs_succ = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_string);
        //        return base.BuildExecResult(context, rs_succ);
        //        #endregion 5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //    }
        //    catch (Exception ex)
        //    {
        //        m_log.ErrorException("DoES_2010768Process Error", ex);
        //        return null;
        //    }
        //}
        //private AppXmlExecResult Do2010768Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        //{
        //    try
        //    {
        //        XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
        //        string rq_t24_data = rq_XmlHelper.SelectSingleNode(requestXml, "//T24_DATA").InnerXml;
        //        m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

        //        string msmq_BTID = XmlHelper.GetInstance(requestXml).GetXPath(requestXml, "//MSMQ_BTID");
        //        string newRqUID = Guid.NewGuid().ToString();
        //        #region 1.TXID改成個人行內轉帳
        //        XmlDocument xNewDoc = CopyToNewDocument(requestXml, "ES_2010766", newRqUID);
        //        #endregion 1.TXID改成個人行內轉帳
        //        #region 2.往EAI送
        //        AppXmlExecResult mq_Result = Send1Recv1(m_log, context, xNewDoc);
        //        #endregion 2.往EAI送
        //        #region 3.接取回傳結果，擷取需要資訊(明細查詢使用)
        //        string rsString = XmlHelper.GetInstance(mq_Result.ResponseXml).SelectSingleNode(mq_Result.ResponseXml, "//T24_DATA").InnerXml;
        //        Dictionary<string, string> rsUcHead_dic, rsUcBody_dic;
        //        GetRsRq_H_B_Dic(rsString, out rsUcHead_dic, out rsUcBody_dic);

        //        string workBlance = string.Empty, achAmt = string.Empty, succFail = string.Empty, errMsg = string.Empty;
        //        rsUcBody_dic.TryGetValue("4315", out workBlance);//餘額
        //        rsUcBody_dic.TryGetValue("4165", out achAmt);//手續費
        //        rsUcBody_dic.TryGetValue("4345", out succFail);//成功失敗
        //        rsUcBody_dic.TryGetValue("2038", out errMsg);
        //        #endregion 3.接取回傳結果，擷取需要資訊(明細查詢使用)
        //        #region 4.若不拆分 則若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL(判斷separate)
        //        //若不拆分 判斷成功失敗 若失敗則 借過渡帳 貸付款人 往EAI送
        //        #endregion 4.若不拆分 則若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL(判斷separate)
        //        #region 5.回寫MSMQTALK
        //        StringBuilder xmlSB = new StringBuilder();
        //        xmlSB.AppendFormat("<AdditionalInfo>");
        //        xmlSB.AppendFormat("<PayBal>{0}</PayBal>", workBlance);
        //        xmlSB.AppendFormat("<Fee>{0}</Fee>", achAmt);
        //        xmlSB.AppendFormat("<SuccFail>{0}</SuccFail>", succFail == "1" ? "SUCC" : "FAIL");
        //        xmlSB.AppendFormat("<ErrMsg>{0}</ErrMsg>", errMsg);
        //        xmlSB.AppendFormat("</AdditionalInfo>");
        //        string xmlstring = xmlSB.ToString();

        //        int updateAdditInfo_Result = DBLog.UpdateMsmqAddinfoByBTID(xmlstring, msmq_BTID);
        //        if (updateAdditInfo_Result == 0)
        //        { m_log.Error("UpdateMsmqAddinfoByRqUID Fail !!! BTID=[{0}] MSMQ_BODY=[{1}]", msmq_BTID, requestXml.InnerXml); }
        //        #endregion 5.回寫MSMQTALK
        //        #region 6.回覆報文(DEFAULT 並未真的回傳給城商)
        //        m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
        //        XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
        //        return base.BuildExecResult(context, rs);
        //        #endregion 6.回覆報文(DEFAULT 並未真的回傳給城商)
        //    }
        //    catch (Exception ex)
        //    {
        //        m_log.ErrorException("Do2010768Process Error", ex);
        //        return null;
        //    }
        //}
        #endregion 個人 行內批量轉帳

        #region 個人 跨行批量轉帳
        //private AppXmlExecResult DoES_2010771Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        //{
        //    bool separate = true;//抓CONFIG
        //    try
        //    {
        //        /*
        //          TXID=ES_2010771
        //          1.分析報文 若失敗，回覆失敗報文
        //            a.組批次號
        //          2.資料解析後 寫入新TABLE 若失敗，回覆失敗報文
        //          3.做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //          4.各筆資料組織新報文<XMLOFS> 借過渡帳->貸各筆收款人 送往MSMQTALK(做在MSMQTALK?)
        //            a.取檔 分析
        //            b.TXID=2020581 
        //            c.LABEL='BATCH'
        //            d.組XML時，記錄BTID於MSMQ_Body中
        //          5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //        */
        //        XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
        //        string rq_t24_data = rq_XmlHelper.SelectSingleNode(requestXml, "//T24_DATA").InnerXml;
        //        m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

        //        string batchNo = string.Empty;
        //        string payAcnt = string.Empty, payName = string.Empty, curr = string.Empty, txnDate = string.Empty, txnCount = string.Empty, totAmt = string.Empty, fileName = string.Empty;
        //        string transition = string.Empty;
        //        int iTxnCount = 0;
        //        DateTime t_txnDate;

        //        #region 1.分析報文
        //        Dictionary<string, string> rqHeadDic = new Dictionary<string, string>();
        //        Dictionary<string, string> rqBodyDic = new Dictionary<string, string>();
        //        GetRsRq_H_B_Dic(rq_t24_data, out rqHeadDic, out rqBodyDic);
        //        //1.a.組批次號
        //        batchNo = GetBatchNo(rqHeadDic, rqBodyDic);//批次號
        //        rqBodyDic.TryGetValue("4157", out payAcnt);//付款人帳號
        //        rqBodyDic.TryGetValue("4900", out payName);//付款人名稱
        //        rqBodyDic.TryGetValue("4118", out curr);//幣種
        //        rqBodyDic.TryGetValue("2006", out txnDate);//交易日期
        //        rqBodyDic.TryGetValue("4112", out txnCount);//總筆數
        //        rqBodyDic.TryGetValue("4100", out totAmt);//總金額
        //        rqBodyDic.TryGetValue("zzzx", out fileName);//檔案名稱
        //        iTxnCount = Convert.ToInt32(txnCount);
        //        t_txnDate = DateTime.ParseExact(txnDate, "yyyyMMdd", null);
        //        transition = separate ? string.Empty : "transitionQQQQQ";//過渡帳戶
        //        #endregion 1.分析報文
        //        #region 2.資料解析後 寫入新TABLE
        //        Guid batID = Guid.NewGuid();
        //        int status = 2;//交易狀態為"未處理"
        //        int tbBATDetail_Result = DBLog.InsertBatchData(batID, batchNo, payAcnt, payName,
        //                                                       "2010771", transition, curr, t_txnDate, fileName, status, iTxnCount, totAmt, requestXml.InnerXml);
        //        if (tbBATDetail_Result == 0)//若無法寫入DB
        //        {
        //            #region SendErrorMail
        //            new SendMail().Send("ES_2010771 InsertBatchData Error", "", string.Format("ES_2010771 InsertBatchData Error, PLS Check RQ:[{0}]", context.RequestXml.OuterXml));
        //            #endregion SendErrorMail
        //            m_log.Error("InsertBatchData Fail !!! BatchNO=[{0}] PayAcnt=[{1}]", batchNo, payAcnt);
        //            #region 失敗 回覆失敗報文
        //            Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
        //            rs_fail_otherBodyDic.Add("2028", "CO1MD005");
        //            rs_fail_otherBodyDic.Add("2038", "INSERT失败");
        //            rs_fail_otherBodyDic.Add("4345", "2");
        //            rs_fail_otherBodyDic.Add("4111", batchNo);
        //            string rs_fail_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);
        //            XmlDocument rs_fail = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_string);
        //            return base.BuildExecResult(context, rs_fail);
        //            #endregion 失敗 回覆失敗報文
        //        }
        //        #endregion 2.資料解析後 寫入新TABLE
        //        #region 3.若不拆分 則做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //        //string mainFt_XMLData = GetT24_FT_Content(co_Code, "I", "", curr, payAcnt, "internalAcc", "", totAmt, "", "", "", "ITF001.0025");
        //        //AppXmlExecResult mainFt_XMLResult = SendMsgToEAIProcess(context, mainFt_XMLData, "IB.INCOPR.TFR");//-----------------------
        //        //bool isSuccMainFtResult = XmlHelper.GetInstance(mainFt_XMLResult.ResponseXml).GetXPath(mainFt_XMLResult.ResponseXml, "//RSP_PROC_RET") == "SUCC";
        //        //if (!isSuccMainFtResult)//回覆失敗報文
        //        //{
        //        //    //更新交易狀態為"失敗"
        //        //    int tbUpdateBatchStatus_Result = DBLog.UpdateBatchData(batID, 2);
        //        //    if (tbUpdateBatchStatus_Result == 0)
        //        //    {
        //        //        //SendMail
        //        //    }
        //        //    //失敗 回覆失敗報文
        //        //}
        //        #endregion 3.若不拆分 則做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //        #region 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2010771 送往MSMQTALK(LABEL='BATCH')
        //        //在MSMQTALK中自動執行
        //        #endregion 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2010771 送往MSMQTALK(LABEL='BATCH')
        //        #region 5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //        Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
        //        rs_succ_otherBodyDic.Add("2028", "CO1M0000");
        //        rs_succ_otherBodyDic.Add("4345", "3");
        //        rs_succ_otherBodyDic.Add("4111", batchNo);
        //        string rs_succ_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

        //        m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_string);
        //        XmlDocument rs_succ = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_string);
        //        return base.BuildExecResult(context, rs_succ);
        //        #endregion 5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //    }
        //    catch (Exception ex)
        //    {
        //        m_log.ErrorException("DoES_2010771Process Error", ex);
        //        return null;
        //    }
        //}
        //private AppXmlExecResult Do2010771Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        //{
        //    try
        //    {
        //        XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
        //        string rq_t24_data = rq_XmlHelper.SelectSingleNode(requestXml, "//T24_DATA").InnerXml;
        //        m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

        //        string msmq_BTID = XmlHelper.GetInstance(requestXml).GetXPath(requestXml, "//MSMQ_BTID");
        //        string newRqUID = Guid.NewGuid().ToString();
        //        #region 1.TXID改成個人行內轉帳
        //        XmlDocument xNewDoc = CopyToNewDocument(requestXml, "ES_2010767", newRqUID);
        //        #endregion 1.TXID改成個人行內轉帳
        //        #region 2.往EAI送
        //        AppXmlExecResult mq_Result = Send1Recv1(m_log, context, xNewDoc);
        //        #endregion 2.往EAI送
        //        #region 3.接取回傳結果，擷取需要資訊(明細查詢使用)
        //        string rsString = XmlHelper.GetInstance(mq_Result.ResponseXml).SelectSingleNode(mq_Result.ResponseXml, "//T24_DATA").InnerXml;
        //        Dictionary<string, string> rsUcHead_dic, rsUcBody_dic;
        //        GetRsRq_H_B_Dic(rsString, out rsUcHead_dic, out rsUcBody_dic);

        //        string workBlance = string.Empty, achAmt = string.Empty, succFail = string.Empty, errMsg = string.Empty;
        //        rsUcBody_dic.TryGetValue("4315", out workBlance);//餘額
        //        rsUcBody_dic.TryGetValue("4165", out achAmt);//手續費
        //        rsUcBody_dic.TryGetValue("4345", out succFail);//成功失敗
        //        rsUcBody_dic.TryGetValue("2038", out errMsg);
        //        #endregion 3.接取回傳結果，擷取需要資訊(明細查詢使用)
        //        #region 4.若不拆分 則若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL(判斷separate)
        //        //若不拆分 判斷成功失敗 若失敗則 借過渡帳 貸付款人 往EAI送
        //        #endregion 4.若不拆分 則若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL(判斷separate)
        //        #region 5.回寫MSMQTALK
        //        StringBuilder xmlSB = new StringBuilder();
        //        xmlSB.AppendFormat("<AdditionalInfo>");
        //        xmlSB.AppendFormat("<PayBal>{0}</PayBal>", workBlance);
        //        xmlSB.AppendFormat("<Fee>{0}</Fee>", achAmt);
        //        xmlSB.AppendFormat("<SuccFail>{0}</SuccFail>", succFail == "1" ? "SUCC" : "FAIL");
        //        xmlSB.AppendFormat("<ErrMsg>{0}</ErrMsg>", errMsg);
        //        xmlSB.AppendFormat("</AdditionalInfo>");
        //        string xmlstring = xmlSB.ToString();

        //        int updateAdditInfo_Result = DBLog.UpdateMsmqAddinfoByBTID(xmlstring, msmq_BTID);
        //        if (updateAdditInfo_Result == 0)
        //        { m_log.Error("UpdateMsmqAddinfoByRqUID Fail !!! BTID=[{0}] MSMQ_BODY=[{1}]", msmq_BTID, requestXml.InnerXml); }
        //        #endregion 5.回寫MSMQTALK
        //        #region 6.回覆報文(DEFAULT 並未真的回傳給城商)
        //        m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
        //        XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
        //        return base.BuildExecResult(context, rs);
        //        #endregion 6.回覆報文(DEFAULT 並未真的回傳給城商)
        //    }
        //    catch (Exception ex)
        //    {
        //        m_log.ErrorException("Do2010771Process Error", ex);
        //        return null;
        //    }
        //}
        #endregion 個人 跨行批量轉帳

        #region 企業 行內批量轉帳
        //private AppXmlExecResult DoES_2020581Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        //{
        //    bool separate = true;//抓CONFIG
        //    try
        //    {
        //        /*
        //          TXID=ES_2020581 
        //          1.分析報文 若失敗，回覆失敗報文
        //            a.組批次號
        //          2.資料解析後 寫入新TABLE 若失敗，回覆失敗報文
        //          3.做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //          4.各筆資料組織新報文<XMLOFS> 借過渡帳->貸各筆收款人 送往MSMQTALK(做在MSMQTALK?)
        //            a.取檔 分析
        //            b.TXID=2020581 
        //            c.LABEL='BATCH'
        //            d.組XML時，記錄BTID於MSMQ_Body中
        //          5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //        */
        //        XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
        //        string rq_t24_data = rq_XmlHelper.SelectSingleNode(requestXml, "//T24_DATA").InnerXml;
        //        m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

        //        string batchNo = string.Empty;
        //        string payAcnt = string.Empty, payName = string.Empty, curr = string.Empty, txnDate = string.Empty, txnCount = string.Empty, totAmt = string.Empty, fileName = string.Empty;
        //        string transition = string.Empty;
        //        int iTxnCount = 0;
        //        DateTime t_txnDate;

        //        #region 1.分析報文
        //        Dictionary<string, string> rqHeadDic = new Dictionary<string, string>();
        //        Dictionary<string, string> rqBodyDic = new Dictionary<string, string>();
        //        GetRsRq_H_B_Dic(rq_t24_data, out rqHeadDic, out rqBodyDic);
        //        //1.a.組批次號
        //        batchNo = GetBatchNo(rqHeadDic, rqBodyDic);//批次號
        //        rqBodyDic.TryGetValue("4157", out payAcnt);//付款人帳號
        //        rqBodyDic.TryGetValue("4900", out payName);//付款人名稱
        //        rqBodyDic.TryGetValue("4118", out curr);//幣種
        //        rqBodyDic.TryGetValue("2006", out txnDate);//交易日期
        //        rqBodyDic.TryGetValue("4113", out txnCount);//總筆數
        //        rqBodyDic.TryGetValue("4100", out totAmt);//總金額
        //        rqBodyDic.TryGetValue("zzzx", out fileName);//檔案名稱
        //        iTxnCount = Convert.ToInt32(txnCount);
        //        t_txnDate = DateTime.ParseExact(txnDate, "yyyyMMdd", null);
        //        transition = separate ? string.Empty : "transitionQQQQQ";//過渡帳戶
        //        #endregion 1.分析報文
        //        #region 2.資料解析後 寫入新TABLE
        //        Guid batID = Guid.NewGuid();
        //        int status = 2;//交易狀態為"未處理"
        //        int tbBATDetail_Result = DBLog.InsertBatchData(batID, batchNo, payAcnt, payName,
        //                                                       "2020581", transition, curr, t_txnDate, fileName, status, iTxnCount, totAmt, requestXml.InnerXml);
        //        if (tbBATDetail_Result == 0)//若無法寫入DB
        //        {
        //            #region SendErrorMail
        //            new SendMail().Send("ES_2020581 InsertBatchData Error", "", string.Format("ES_2020581 InsertBatchData Error, PLS Check RQ:[{0}]", context.RequestXml.OuterXml));
        //            #endregion SendErrorMail
        //            m_log.Error("InsertBatchData Fail !!! BatchNO=[{0}] PayAcnt=[{1}]", batchNo, payAcnt);
        //            #region 失敗 回覆失敗報文
        //            Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
        //            rs_fail_otherBodyDic.Add("2028", "CO1MD005");
        //            rs_fail_otherBodyDic.Add("2038", "INSERT失败");
        //            rs_fail_otherBodyDic.Add("4345", "2");
        //            rs_fail_otherBodyDic.Add("4111", batchNo);
        //            string rs_fail_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);
        //            XmlDocument rs_fail = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_string);
        //            return base.BuildExecResult(context, rs_fail);
        //            #endregion 失敗 回覆失敗報文
        //        }
        //        #endregion 2.資料解析後 寫入新TABLE
        //        #region 3.若不拆分 則做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //        //string mainFt_XMLData = GetT24_FT_Content(co_Code, "I", "", curr, payAcnt, "internalAcc", "", totAmt, "", "", "", "ITF001.0025");
        //        //AppXmlExecResult mainFt_XMLResult = SendMsgToEAIProcess(context, mainFt_XMLData, "IB.INCOPR.TFR");//-----------------------
        //        //bool isSuccMainFtResult = XmlHelper.GetInstance(mainFt_XMLResult.ResponseXml).GetXPath(mainFt_XMLResult.ResponseXml, "//RSP_PROC_RET") == "SUCC";
        //        //if (!isSuccMainFtResult)//回覆失敗報文
        //        //{
        //        //    //更新交易狀態為"失敗"
        //        //    int tbUpdateBatchStatus_Result = DBLog.UpdateBatchData(batID, 2);
        //        //    if (tbUpdateBatchStatus_Result == 0)
        //        //    {
        //        //        //SendMail
        //        //    }
        //        //    //失敗 回覆失敗報文
        //        //}
        //        #endregion 3.若不拆分 則做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //        #region 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2020581 送往MSMQTALK(LABEL='BATCH')
        //        //在MSMQTALK中自動執行
        //        #endregion 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2020581 送往MSMQTALK(LABEL='BATCH')
        //        #region 5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //        Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
        //        rs_succ_otherBodyDic.Add("2028", "CO1M0000");
        //        rs_succ_otherBodyDic.Add("4345", "3");
        //        rs_succ_otherBodyDic.Add("4111", batchNo);
        //        string rs_succ_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

        //        m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_string);
        //        XmlDocument rs_succ = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_string);
        //        return base.BuildExecResult(context, rs_succ);
        //        #endregion 5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //    }
        //    catch (Exception ex)
        //    {
        //        m_log.ErrorException("DoES_2020581Process Error", ex);
        //        return null;
        //    }
        //}
        //private AppXmlExecResult Do2020581Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        //{
        //    try
        //    {
        //        XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
        //        string rq_t24_data = rq_XmlHelper.SelectSingleNode(requestXml, "//T24_DATA").InnerXml;
        //        m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

        //        string msmq_BTID = XmlHelper.GetInstance(requestXml).GetXPath(requestXml, "//MSMQ_BTID");
        //        string newRqUID = Guid.NewGuid().ToString();
        //        rq_XmlHelper.SetXPath(requestXml, "//SIGN_ON_ID", ProjectConfig.GetInstance().OfsUser);
        //        rq_XmlHelper.SetXPath(requestXml, "//SIGN_ON_PSWD", ProjectConfig.GetInstance().OfsPwd);
        //        rq_XmlHelper.SetXPath(requestXml, "//CHANNEL_ID", ProjectConfig.GetInstance().ITFChannelID);
        //        rq_XmlHelper.SetXPath(requestXml, "//EXT_BUSS_DATE", DateTime.Today.ToString("yyyyMMdd"));
        //        rq_XmlHelper.SetXPath(requestXml, "//EXT_REFERENCE", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
        //        rq_XmlHelper.SetXPath(requestXml, "//EXT_TXN_TIME", DateTime.Now.ToString("yyyyMMddHHmmss"));

        //        #region 1.TXID改成企業行內轉帳
        //        XmlDocument xNewDoc = CopyToNewDocument(requestXml, "IB.INCOPR.TFR", newRqUID);
        //        #endregion 1.TXID改成企業行內轉帳
        //        #region 2.往EAI送
        //        AppXmlExecResult mq_Result = Send1Recv1(m_log, context, xNewDoc);
        //        #endregion 2.往EAI送
        //        #region 3.接取回傳結果，擷取需要資訊(明細查詢使用)
        //        string rsString = XmlHelper.GetInstance(mq_Result.ResponseXml).SelectSingleNode(mq_Result.ResponseXml, "//T24_DATA").InnerXml;
        //        XmlHelper xhlpr = XmlHelper.GetInstance(mq_Result.ResponseXml);
        //        string rsp_proc_ret = xhlpr.GetXPath(mq_Result.ResponseXml, "//RSP_PROC_RET");//成功失敗
        //        string commission_amt = xhlpr.GetXPath(mq_Result.ResponseXml, "//COMMISSION_AMT");//手續費
        //        string itf_return_code = xhlpr.GetXPath(mq_Result.ResponseXml, "//ITF_RETURN_CODE");//回覆代號 E-005000之類
        //        string rsp_txn_id = xhlpr.GetXPath(mq_Result.ResponseXml, "//RSP_TXN_ID");//FT RECID
        //        string itf_return_msg = xhlpr.GetXPath(mq_Result.ResponseXml, "//ITF_RETURN_MSG ");//ITF_RETURN_MSG
        //        #endregion 3.接取回傳結果，擷取需要資訊(明細查詢使用)
        //        #region 4.若不拆分 則若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL(判斷separate)
        //        //if (rsp_proc_ret != "SUCC")
        //        //{
        //        //    DataSet mqDataSet_Fail = DBLog.SelectBatchMqtkByCorrID(rq_RqUID);
        //        //    List<Dictionary<string, string>> dicList_Fail = DatasetToDiclist(mqDataSet_Fail);
        //        //}
        //        #endregion 4.若不拆分 則若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL(判斷separate)
        //        #region 5.回寫MSMQTALK
        //        string errMappingString = (rsp_proc_ret != "SUCC" && !string.IsNullOrEmpty(itf_return_code)) ? ErrorCodeMapping("T24", itf_return_code) : "系统错误";
        //        StringBuilder xmlSB = new StringBuilder();
        //        xmlSB.AppendFormat("<AdditionalInfo>");
        //        xmlSB.AppendFormat("<TXN_ID>{0}</TXN_ID>", rsp_txn_id);
        //        xmlSB.AppendFormat("<Fee>{0}</Fee>", commission_amt);
        //        xmlSB.AppendFormat("<SuccFail>{0}</SuccFail>", rsp_proc_ret == "SUCC" ? "SUCC" : "FAIL");
        //        xmlSB.AppendFormat("<ErrMsg>{0}</ErrMsg>", rsp_proc_ret == "SUCC" ? string.Empty : errMappingString);
        //        xmlSB.AppendFormat("<Return_Msg>{0}</Return_Msg>", itf_return_msg);
        //        xmlSB.AppendFormat("</AdditionalInfo>");
        //        string xmlstring = xmlSB.ToString();

        //        int updateAdditInfo_Result = DBLog.UpdateMsmqAddinfoByBTID(xmlstring, msmq_BTID);
        //        if (updateAdditInfo_Result == 0)
        //        { m_log.Error("UpdateMsmqAddinfoByRqUID Fail !!! BTID=[{0}] MSMQ_BODY=[{1}]", msmq_BTID, requestXml.InnerXml); }
        //        #endregion 5.回寫MSMQTALK
        //        #region 6.回覆報文(DEFAULT 並未真的回傳給城商)
        //        m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
        //        XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
        //        return base.BuildExecResult(context, rs);
        //        #endregion 6.回覆報文(DEFAULT 並未真的回傳給城商)
        //    }
        //    catch (Exception ex)
        //    {
        //        m_log.ErrorException("Do2020581Process Error", ex);
        //        return null;
        //    }
        //}
        #endregion 企業 行內批量轉帳

        #region 企業 跨行批量轉帳
        //private AppXmlExecResult DoES_2020584Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        //{
        //    bool separate = true;//抓CONFIG
        //    try
        //    {
        //        /*
        //          TXID=ES_2020584
        //          1.分析報文 若失敗，回覆失敗報文
        //            a.組批次號
        //          2.資料解析後 寫入新TABLE 若失敗，回覆失敗報文
        //          3.做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //          4.各筆資料組織新報文<XMLOFS> 借過渡帳->貸各筆收款人 送往MSMQTALK(做在MSMQTALK?)
        //            a.取檔 分析
        //            b.TXID=2020581 
        //            c.LABEL='BATCH'
        //            d.組XML時，記錄BTID於MSMQ_Body中
        //          5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //        */
        //        XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
        //        string rq_t24_data = rq_XmlHelper.SelectSingleNode(requestXml, "//T24_DATA").InnerXml;
        //        m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

        //        string batchNo = string.Empty;
        //        string payAcnt = string.Empty, payName = string.Empty, curr = string.Empty, txnDate = string.Empty, txnCount = string.Empty, totAmt = string.Empty, fileName = string.Empty;
        //        string transition = string.Empty;
        //        int iTxnCount = 0;
        //        DateTime t_txnDate;

        //        #region 1.分析報文
        //        Dictionary<string, string> rqHeadDic = new Dictionary<string, string>();
        //        Dictionary<string, string> rqBodyDic = new Dictionary<string, string>();
        //        GetRsRq_H_B_Dic(rq_t24_data, out rqHeadDic, out rqBodyDic);
        //        //1.a.組批次號
        //        batchNo = GetBatchNo(rqHeadDic, rqBodyDic);//批次號
        //        rqBodyDic.TryGetValue("4157", out payAcnt);//付款人帳號
        //        rqBodyDic.TryGetValue("4900", out payName);//付款人名稱
        //        rqBodyDic.TryGetValue("4118", out curr);//幣種
        //        rqBodyDic.TryGetValue("2006", out txnDate);//交易日期
        //        rqBodyDic.TryGetValue("4112", out txnCount);//總筆數
        //        rqBodyDic.TryGetValue("4100", out totAmt);//總金額
        //        rqBodyDic.TryGetValue("zzzx", out fileName);//檔案名稱
        //        iTxnCount = Convert.ToInt32(txnCount);
        //        t_txnDate = DateTime.ParseExact(txnDate, "yyyyMMdd", null);
        //        transition = separate ? string.Empty : "transitionQQQQQ";//過渡帳戶
        //        #endregion 1.分析報文
        //        #region 2.資料解析後 寫入新TABLE
        //        Guid batID = Guid.NewGuid();
        //        int status = 2;//交易狀態為"未處理"
        //        int tbBATDetail_Result = DBLog.InsertBatchData(batID, batchNo, payAcnt, payName,
        //                                                       "2020584", transition, curr, t_txnDate, fileName, status, iTxnCount, totAmt, requestXml.InnerXml);
        //        if (tbBATDetail_Result == 0)//若無法寫入DB
        //        {
        //            #region SendErrorMail
        //            new SendMail().Send("ES_2020584 InsertBatchData Error", "", string.Format("ES_2020584 InsertBatchData Error, PLS Check RQ:[{0}]", context.RequestXml.OuterXml));
        //            #endregion SendErrorMail
        //            m_log.Error("InsertBatchData Fail !!! BatchNO=[{0}] PayAcnt=[{1}]", batchNo, payAcnt);
        //            #region 失敗 回覆失敗報文
        //            Dictionary<string, string> rs_fail_otherBodyDic = new Dictionary<string, string>();
        //            rs_fail_otherBodyDic.Add("2028", "CO1MD005");
        //            rs_fail_otherBodyDic.Add("2038", "INSERT失败");
        //            rs_fail_otherBodyDic.Add("4345", "2");
        //            rs_fail_otherBodyDic.Add("4111", batchNo);
        //            string rs_fail_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_fail_otherBodyDic);
        //            XmlDocument rs_fail = base.TransformCommMsg("0", "Info", "交易完成", rs_fail_string);
        //            return base.BuildExecResult(context, rs_fail);
        //            #endregion 失敗 回覆失敗報文
        //        }
        //        #endregion 2.資料解析後 寫入新TABLE
        //        #region 3.若不拆分 則做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //        //string mainFt_XMLData = GetT24_FT_Content(co_Code, "I", "", curr, payAcnt, "internalAcc", "", totAmt, "", "", "", "ITF001.0025");
        //        //AppXmlExecResult mainFt_XMLResult = SendMsgToEAIProcess(context, mainFt_XMLData, "IB.INCOPR.TFR");//-----------------------
        //        //bool isSuccMainFtResult = XmlHelper.GetInstance(mainFt_XMLResult.ResponseXml).GetXPath(mainFt_XMLResult.ResponseXml, "//RSP_PROC_RET") == "SUCC";
        //        //if (!isSuccMainFtResult)//回覆失敗報文
        //        //{
        //        //    //更新交易狀態為"失敗"
        //        //    int tbUpdateBatchStatus_Result = DBLog.UpdateBatchData(batID, 2);
        //        //    if (tbUpdateBatchStatus_Result == 0)
        //        //    {
        //        //        //SendMail
        //        //    }
        //        //    //失敗 回覆失敗報文
        //        //}
        //        #endregion 3.若不拆分 則做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文(判斷separate)
        //        #region 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2020584 送往MSMQTALK(LABEL='BATCH')
        //        //在MSMQTALK中自動執行
        //        #endregion 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2020584 送往MSMQTALK(LABEL='BATCH')
        //        #region 5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //        Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
        //        rs_succ_otherBodyDic.Add("2028", "CO1M0000");
        //        rs_succ_otherBodyDic.Add("4345", "3");
        //        rs_succ_otherBodyDic.Add("4111", batchNo);
        //        string rs_succ_string = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

        //        m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_string);
        //        XmlDocument rs_succ = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_string);
        //        return base.BuildExecResult(context, rs_succ);
        //        #endregion 5.回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //    }
        //    catch (Exception ex)
        //    {
        //        m_log.ErrorException("DoES_2020584Process Error", ex);
        //        return null;
        //    }
        //}
        //private AppXmlExecResult Do2020584Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        //{
        //    try
        //    {
        //        XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
        //        string rq_t24_data = rq_XmlHelper.SelectSingleNode(requestXml, "//T24_DATA").InnerXml;
        //        m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

        //        string msmq_BTID = XmlHelper.GetInstance(requestXml).GetXPath(requestXml, "//MSMQ_BTID");
        //        string newRqUID = Guid.NewGuid().ToString();
        //        #region 1.TXID改成個人行內轉帳
        //        XmlDocument xNewDoc = CopyToNewDocument(requestXml, "ES_2020580", newRqUID);
        //        #endregion 1.TXID改成個人行內轉帳
        //        #region 2.往EAI送
        //        AppXmlExecResult mq_Result = Send1Recv1(m_log, context, xNewDoc);
        //        #endregion 2.往EAI送
        //        #region 3.接取回傳結果，擷取需要資訊(明細查詢使用)
        //        string rsString = XmlHelper.GetInstance(mq_Result.ResponseXml).SelectSingleNode(mq_Result.ResponseXml, "//T24_DATA").InnerXml;
        //        Dictionary<string, string> rsUcHead_dic, rsUcBody_dic;
        //        GetRsRq_H_B_Dic(rsString, out rsUcHead_dic, out rsUcBody_dic);

        //        string workBlance = string.Empty, achAmt = string.Empty, succFail = string.Empty, errMsg = string.Empty;
        //        rsUcBody_dic.TryGetValue("4315", out workBlance);//餘額
        //        rsUcBody_dic.TryGetValue("4165", out achAmt);//手續費
        //        rsUcBody_dic.TryGetValue("4345", out succFail);//成功失敗
        //        rsUcBody_dic.TryGetValue("2038", out errMsg);
        //        #endregion 3.接取回傳結果，擷取需要資訊(明細查詢使用)
        //        #region 4.若不拆分 則若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL(判斷separate)
        //        //若不拆分 判斷成功失敗 若失敗則 借過渡帳 貸付款人 往EAI送
        //        #endregion 4.若不拆分 則若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL(判斷separate)
        //        #region 5.回寫MSMQTALK
        //        StringBuilder xmlSB = new StringBuilder();
        //        xmlSB.AppendFormat("<AdditionalInfo>");
        //        xmlSB.AppendFormat("<PayBal>{0}</PayBal>", workBlance);
        //        xmlSB.AppendFormat("<Fee>{0}</Fee>", achAmt);
        //        xmlSB.AppendFormat("<SuccFail>{0}</SuccFail>", succFail == "1" ? "SUCC" : "FAIL");
        //        xmlSB.AppendFormat("<ErrMsg>{0}</ErrMsg>", errMsg);
        //        xmlSB.AppendFormat("</AdditionalInfo>");
        //        string xmlstring = xmlSB.ToString();

        //        int updateAdditInfo_Result = DBLog.UpdateMsmqAddinfoByBTID(xmlstring, msmq_BTID);
        //        if (updateAdditInfo_Result == 0)
        //        { m_log.Error("UpdateMsmqAddinfoByRqUID Fail !!! BTID=[{0}] MSMQ_BODY=[{1}]", msmq_BTID, requestXml.InnerXml); }
        //        #endregion 5.回寫MSMQTALK
        //        #region 6.回覆報文(DEFAULT 並未真的回傳給城商)
        //        m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
        //        XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
        //        return base.BuildExecResult(context, rs);
        //        #endregion 6.回覆報文(DEFAULT 並未真的回傳給城商)
        //    }
        //    catch (Exception ex)
        //    {
        //        m_log.ErrorException("Do2020584Process Error", ex);
        //        return null;
        //    }
        //}
        #endregion 企業 跨行批量轉帳

        //private AppXmlExecResult DoES_2020581Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        //{
        //    try
        //    {
        //        /*
        //          TXID=ES_2020581 
        //          1.分析報文 若失敗，回覆失敗報文
        //            a.組批次號
        //            b.取檔 分析
        //          2.資料解析後 寫入新TABLE 若失敗，回覆失敗報文
        //          3.做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文
        //          4.各筆資料組織新報文<XMLOFS> 借過渡帳->貸各筆收款人 送往MSMQTALK(做在MSMQTALK?)
        //            a.TXID=2020581 
        //            b.LABEL='BATCH'
        //            c.組XML時，記錄CorrID，存在AdditionalInfo     X  
        //          5.全部送入MSMQTALK成功後 回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //        */
        //        XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
        //        string rq_t24_data = rq_XmlHelper.SelectSingleNode(requestXml, "//T24_DATA").InnerXml;
        //        m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

        //        string batchNo = string.Empty;
        //        string payAcnt = string.Empty, payName = string.Empty, curr = string.Empty, txnCount = string.Empty, totAmt = string.Empty, fileName = string.Empty;
        //        string co_Code = string.Empty;
        //        if (txID == "ES_2020581")
        //        {
        //            #region 1.分析報文
        //            Dictionary<string, string> rqHeadDic = new Dictionary<string, string>();
        //            Dictionary<string, string> rqBodyDic = new Dictionary<string, string>();

        //            List<string> dataStringList = new List<string>();
        //            List<Dictionary<string, string>> dataDicList = new List<Dictionary<string, string>>();
        //            GetRsRq_H_B_Dic(rq_t24_data, out rqHeadDic, out rqBodyDic);
        //            //1.a.組批次號
        //            batchNo = GetBatchNo(rqHeadDic, rqBodyDic);//批次號
        //            rqBodyDic.TryGetValue("4157", out payAcnt);//付款人帳號
        //            rqBodyDic.TryGetValue("4900", out payName);//付款人名稱
        //            rqBodyDic.TryGetValue("4118", out curr);//幣種
        //            rqBodyDic.TryGetValue("4113", out txnCount);//總筆數
        //            rqBodyDic.TryGetValue("4100", out totAmt);//總金額
        //            rqBodyDic.TryGetValue("zzzx", out fileName);//檔案名稱
        //            co_Code = string.Format("CN001{}0", payAcnt.Substring(0, 4));//分行別
        //            //1.b.取檔 分析
        //            dataStringList = ReadBatchFile(fileName);//每一組string為一個交易
        //            dataDicList = GetDataDicList(dataStringList, txID);//每一組Dictionary為一個交易
        //            #endregion 1.分析報文
        //            #region 2.資料解析後 寫入新TABLE
        //            Guid batID = Guid.NewGuid();
        //            //交易狀態為"銀行已受理"
        //            int tbBATDetail_Result = DBLog.InsertBatchData(batID, batchNo, payAcnt, payName, "2020581", false, fileName, requestXml.InnerXml, 3);
        //            if (tbBATDetail_Result == 0)
        //            {
        //                //SendMail
        //                //失敗 回覆失敗報文
        //            }
        //            #endregion 2.資料解析後 寫入新TABLE
        //            #region 3.做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文
        //            string mainFt_XMLData = GetT24_FT_Content(co_Code, "I", "", curr, payAcnt, "internalAcc", "", totAmt, "", "", "", "ITF001.0025");
        //            AppXmlExecResult mainFt_XMLResult = SendMsgToEAIProcess(context, mainFt_XMLData, "IB.INCOPR.TFR");//-----------------------
        //            bool isSuccMainFtResult = XmlHelper.GetInstance(mainFt_XMLResult.ResponseXml).GetXPath(mainFt_XMLResult.ResponseXml, "//RSP_PROC_RET") == "SUCC";
        //            if (!isSuccMainFtResult)//回覆失敗報文
        //            {
        //                //更新交易狀態為"失敗"
        //                int tbUpdateBatchStatus_Result = DBLog.UpdateBatchData(batID, 2);
        //                if (tbUpdateBatchStatus_Result == 0)
        //                {
        //                    //SendMail
        //                }
        //                //失敗 回覆失敗報文
        //            }
        //            #endregion 3.做FT交易 借付款人->貸過渡帳 若失敗，回覆失敗報文
        //            #region 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2020581 送往MSMQTALK(LABEL='BATCH')
        //            foreach (Dictionary<string, string> dic in dataDicList)
        //            {
        //                string pyeAcnt = string.Empty, pyeName = string.Empty, tranAmt = string.Empty, dtr = string.Empty, remarks = string.Empty;
        //                string subFT_XMLData = GetT24_FT_Content(co_Code, "I", "", curr, "internalAcc", pyeAcnt, pyeName, tranAmt, dtr, remarks, "", "ITF001.0025");
        //                XmlDocument xdoc = new XmlDocument();
        //                xdoc.LoadXml(subFT_XMLData);
        //                XmlDocument newXdoc = CopyToNewDocument(xdoc, "2010581", Guid.NewGuid().ToString());
        //                //string subFt_MsmqBody = base.SendToEAIProcess(subFT_XMLData, "IB.INCOPR.TFR");//-----------------------CopytoNew
        //                int result = InsertBatchToMsmqtalk(newXdoc.InnerXml, txID, batID, 1);
        //                if (result == 0)
        //                {
        //                    //SendMail
        //                }
        //            }
        //            #endregion 4.各筆資料組織新報文<XMLOFS> 借過渡帳 貸各筆收款人 TXID=2020581 送往MSMQTALK(LABEL='BATCH')
        //            #region 5.全部送入MSMQTALK成功後 回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //            #endregion 5.全部送入MSMQTALK成功後 回覆報文-交易狀態(銀行已受理)批次號(batchID)
        //        }

        //        if (txID == "2020581")//MSMQ來的
        //        {
        //            //1.TXID改成企業行內轉帳
        //            string rq_RqUID = rq_XmlHelper.GetXPath(requestXml, "//RqUID").Trim();
        //            XmlDocument xNewDoc = CopyToNewDocument(requestXml, "IB.INCOPR.TFR", rq_RqUID);

        //            //2.往EAI送
        //            AppXmlExecResult mq_Result = Send1Recv1(m_log, context, xNewDoc);

        //            //3.接取回傳結果，擷取需要資訊(明細查詢使用)回寫MSMQTALK
        //            XmlHelper xhlpr = XmlHelper.GetInstance(mq_Result.ResponseXml);
        //            string rsp_proc_ret = xhlpr.GetXPath(mq_Result.ResponseXml, "//RSP_PROC_RET");
        //            string commission_amt = xhlpr.GetXPath(mq_Result.ResponseXml, "//COMMISSION_AMT");
        //            string itf_return_code = xhlpr.GetXPath(mq_Result.ResponseXml, "//ITF_RETURN_CODE");
        //            // Additional

        //            //4.若交易失敗，馬上組新報文<XMLOFS> 借過渡帳 貸付款人 往EAI送-->若也失敗 SENDMAIL
        //            if (rsp_proc_ret != "SUCC")
        //            {
        //                DataSet mqDataSet_Fail = DBLog.SelectBatchMqtkByCorrID(rq_RqUID);
        //                List<Dictionary<string, string>> dicList_Fail = DatasetToDiclist(mqDataSet_Fail);
        //            }
        //            //5.回覆報文(DEFAULT 並未真的回傳給城商)
        //        }

        //        return null;
        //    }
        //    catch (Exception ex)
        //    {
        //        m_log.ErrorException("DoES_2020581Process Error", ex);
        //        return null;
        //    }

        //}
        #endregion 暫止使用















    }
}
