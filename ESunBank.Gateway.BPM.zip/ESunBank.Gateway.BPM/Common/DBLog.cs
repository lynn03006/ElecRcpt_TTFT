﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Service;
using System.Data;
using System.Data.SqlClient;

namespace ESunBank.Gateway.BPM
{
    class DBLog
    {
        internal DBLog() { }
        private const string m_DatabaseName = "Middleware_TxLog";
        private static readonly Logger m_log = LogManager.GetLogger("ESunBank.Gateway.BPM.DBLog");

        #region NDA
        static public DataSet SelectValidNdaByDate(string startDate, string endDate)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();// "SELECT * FROM BroadcastMSMQTalk WHERE 1 = 1 {0}";
                sbCmd.AppendFormat("SELECT [BTID], [MSMQ_Body], [Status], [CreateDate] FROM BroadcastMSMQTalk ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [STATUS] = @STATUS ");
                sbCmd.AppendFormat("AND [CreateDate]>=@beginDate AND [CreateDate]<DATEADD(d,1,@endDate) ");
                //sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@STATUS", "999");
                parameters.Add("@beginDate", startDate);
                parameters.Add("@endDate", endDate);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectValidNdaByDate Exception : ", ex);
            }
            return dataset;
        }

        static public DataSet SelectValidNdaByBTID(string BTID)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();// "SELECT * FROM BroadcastMSMQTalk WHERE 1 = 1 {0}";
                sbCmd.AppendFormat("SELECT [MSMQ_Body] FROM BroadcastMSMQTalk ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [STATUS] = @STATUS ");
                sbCmd.AppendFormat("AND [BTID] = @BTID");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@STATUS", "999");
                parameters.Add("@BTID", BTID);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectValidNdaByDate Exception : ", ex);
            }
            return dataset;
        }

        static public DataSet SelectValidNda()
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();// "SELECT * FROM BroadcastMSMQTalk WHERE 1 = 1 {0}";
                sbCmd.AppendFormat("SELECT [BTID], [MSMQ_Body], [CreateDate] FROM BroadcastMSMQTalk ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [STATUS] = @STATUS ");
                //sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@STATUS", "999");

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectValidNDA Exception : ", ex);
            }
            return dataset;
        }
        static public int CancelNda(string btID, int statusFrom, int statusTo)
        {
            int execRows = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();// "SELECT * FROM BroadcastMSMQTalk WHERE 1 = 1 {0}";
                sbCmd.AppendFormat("UPDATE BroadcastMSMQTalk SET [Status] = @STATUS2, [UpdateDate] = GETDATE() ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [BTID] = @BTID AND [Status] = @STATUS1");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@STATUS2", statusTo);
                parameters.Add("@BTID", btID);
                parameters.Add("@STATUS1", statusFrom);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                execRows = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("CancelNda Exception : ", ex);
            }
            return execRows;
        }
        #endregion NDA

        #region RSV
        /// <summary>
        /// 撤銷預約交易
        /// </summary>
        /// <param name="status">撤銷後的Status</param>
        /// <param name="signId">簽約序號</param>
        /// <param name="payAcnt">付款人帳號</param>
        /// <returns></returns>
        static public int CancelRsv(int status, string signId, string payAcnt)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("UPDATE RSVDetail SET {0} ", "[Status] = @Status, [StatusChgDate]=GETDATE(), [UpdateDate] = GETDATE() ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [SignID] = @SignID AND [PayAcnt] = @PayAcnt AND [Status] != @Status1 AND [Status] != @Status2");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@Status", status);
                parameters.Add("@SignID", signId);
                parameters.Add("@PayAcnt", payAcnt);
                parameters.Add("@Status1", 3);
                parameters.Add("@Status2", 4);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                resutl = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("CancelRsv Exception : ", ex);
            }
            return resutl;
        }
        /// <summary>
        /// 交易發送中(Status為2時)，更新MSMQTalk [AdditionalInfo]欄位
        /// </summary>
        /// <param name="additionalInfo">新資料 xml格式</param>
        /// <param name="importId">資料來源TALBE的ID</param>
        /// <returns></returns>
        static public int UpdateMsmqAddinfo(string additionalInfo, string importId, string msmq_BTID)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat(";WITH XMLNAMESPACES ('urn:schema-bankpro-com:multichannel' as ns) ");
                sbCmd.AppendFormat("UPDATE BroadcastMSMQTalk SET [AdditionalInfo]=@AdditionalInfo ");
                sbCmd.AppendFormat("WHERE 1 = 1");
                sbCmd.AppendFormat(" AND [ImportID]=@ImportID");
                sbCmd.AppendFormat(" AND [BTID]=@BTID");
                //sbCmd.AppendFormat(" AND CONVERT(xml,MSMQ_Body).exist('/ns:BankproML/ns:CommMsg/ns:RSV_UID[text()[1]= sql:variable(\"@RSV_UID\")]') = 1");
                sbCmd.AppendFormat(" AND [Status]=2");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@AdditionalInfo", additionalInfo);
                parameters.Add("@ImportID", importId);
                parameters.Add("@BTID", msmq_BTID);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                resutl = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("UpdateMsmqAddinfo Exception : ", ex);
            }
            return resutl;
        }
        /// <summary>
        /// 查詢預約交易簽約資訊
        /// </summary>
        /// <param name="signId">簽約序號</param>
        /// <param name="payAcnt">付款人帳號</param>
        /// <returns></returns>
        static public DataSet SelectRsvBySignidAndPayacnt(string signId, string payAcnt)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT [RSVID], [Frequency], [ExecTiming], [BeginDate], [EndDate], [UC] FROM  RSVDetail ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [SignID] = @SignID AND [PayAcnt] = @PayAcnt ");
                //sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@SignID", signId);
                parameters.Add("@PayAcnt", payAcnt);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectRsvBySignidAndPayacnt Exception : ", ex);
            }
            return dataset;
        }

        /// <summary>
        /// 查詢預約交易簽約資訊
        /// </summary>
        /// <param name="payAcnt">付款人帳號</param>
        /// <param name="beginDate">簽約日期起始日</param>
        /// <param name="endDate">簽約日期結束日</param>
        /// <param name="status">狀態</param>
        /// <returns></returns>
        static public DataSet SelectRsvByPayacntAndCmsdtInterval(string payAcnt, string beginDate, string endDate, string status)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT [SignID], [PayAcnt], [Status], [StatusChgDate], [UC], [Msgkey] FROM  RSVDetail ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [PayAcnt] = @PayAcnt  AND [CommissionDate]>=@beginDate AND [commissiondate]<=@endDate ");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@PayAcnt", payAcnt);
                parameters.Add("@beginDate", beginDate);
                parameters.Add("@endDate", endDate);
                if (!string.IsNullOrEmpty(status))
                {
                    sbCmd.Append("AND [Status] = @status ");
                    parameters.Add("@status", status);
                }
                //sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                //sbCmd.AppendFormat("ORDER BY [SignID] DESC");
                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectRsvByPayacntAndCmsdtInterval Exception : ", ex);
            }
            return dataset;
        }
        /// <summary>
        /// 查詢預約交易簽約資訊
        /// </summary>
        /// <param name="signId">簽約序號</param>
        /// <returns></returns>
        static public DataSet SelectRsvBySignid(string signId)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT [RSVID] FROM  RSVDetail ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [SignID] = @SignID ");
                //sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@SignID", signId);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectRsvBySignid Exception : ", ex);
            }
            return dataset;
        }
        /// <summary>
        /// 查詢MSMQTalk
        /// </summary>
        /// <param name="importId">資料來源TALBE的ID</param>
        /// <param name="beginDate">建立日期起始日</param>
        /// <param name="endDate">建立日期結束日</param>
        /// <returns></returns>
        static public DataSet SelectMqtkByImpidAndCredtInterval(string importId, string beginDate, string endDate)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT [Status], [CreateDate], [AdditionalInfo] FROM  BroadcastMSMQTalk ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [ImportID]=@ImportID AND [CreateDate]>=@beginDate AND [CreateDate]<DATEADD(d,1,@endDate) ");
                //sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@ImportID", importId);
                parameters.Add("@beginDate", beginDate);
                parameters.Add("@endDate", endDate);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectMqtkByImpidAndCredtInterval Exception : ", ex);
            }
            return dataset;
        }

        public int InsertRsvData(string signID, string account, DateTime timeCommission,
                             string frequency, string exec_timing, DateTime timeStart,
                             DateTime timeEnd, object msgBody, string msgKey, DateTime? timeNext)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO [RSVDetail]");
                sbCmd.Append("([RSVID],[SignID],[PayAcnt],[CommissionDate],[Status],[Frequency],[ExecTiming]");
                sbCmd.Append(",[BeginDate],[EndDate],[UC],[Msgkey],[NextExecDate],[CreateDate],[UpdateDate])");
                sbCmd.Append("VALUES");
                sbCmd.Append("(@RSVID, @SignID, @PayAcnt, @CommissionDate, @Status, @Frequency, @ExecTiming");
                sbCmd.Append(",@BeginDate,@EndDate, @UC, @Msgkey, @NextExecDate, GETDATE(), @UpdateDate)");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@RSVID", Guid.NewGuid());
                parameters.Add("@SignID", signID);
                parameters.Add("@PayAcnt", account);
                parameters.Add("@CommissionDate", timeCommission);
                parameters.Add("@Status", "1");
                parameters.Add("@Frequency", frequency);
                if (!string.IsNullOrEmpty(exec_timing))
                    parameters.Add("@ExecTiming", exec_timing);
                else
                    parameters.Add("@ExecTiming", DBNull.Value);
                parameters.Add("@BeginDate", timeStart);
                parameters.Add("@EndDate", timeEnd);
                parameters.Add("@UC", msgBody);
                parameters.Add("@Msgkey", msgKey);
                parameters.Add("@NextExecDate", timeNext);
                //parameters.Add("@CreateDate", DateTime.Now);
                parameters.Add("@UpdateDate", DBNull.Value);

                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                { resutl = db.ExecuteNonQuery(sbCmd.ToString(), parameters); }
                if (resutl == 0)
                { m_log.Error("DB Table InsertRsvData Fail"); }

            }
            catch (Exception ex)
            {
                m_log.ErrorException("DB Table InsertRsvData Fail :", ex);
            }
            return resutl;
        }
        #endregion RSV

        /// <summary>
        /// 查詢銀企對帳簽約帳戶Table
        /// </summary>
        /// <param name="acctNo"></param>
        /// <param name="custNo"></param>
        static public DataSet SelectIBAccRecSign(string acctNo, string custNo)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("SELECT * FROM IBAccRecSign");
                sbCmd.Append("WHERE [AcctNo] = @AcctNo AND [CustNo] = @CustNo");
                string sqlCmd = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@AcctNo", acctNo);
                parameters.Add("@CustNo", custNo);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCmd, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectIBAccRecSign Exception : ", ex);
            }
            return dataset;
        }


        #region BATCH
        static public int InsertBatchData(Guid batID, string batchNo, string payAcnt, string payName,
                                          string msgKey, string transition, string curr, DateTime t_txnDate, string fileName, int status, int txnCount, string totAmt, string uc)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO [BATCHDetail]");
                sbCmd.Append("([BATID],[BatchNo],[PayAcnt],[PayName],[Msgkey],[Transition],[Curr],[TxnDate],");
                sbCmd.Append("[CreateDate],[UpdateDate],[FileName],[Status],[TxnCount],[TotAmt],[UC]) ");
                sbCmd.Append("VALUES");
                sbCmd.Append("(@BATID, @BatchNo, @PayAcnt, @PayName, @Msgkey, @Transition, @Curr, @TxnDate,");
                sbCmd.Append("GETDATE(),@UpdateDate,@FileName, @Status, @TxnCount, @TotAmt, @UC)");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@BATID", batID);
                parameters.Add("@BatchNo", batchNo);
                parameters.Add("@PayAcnt", payAcnt);
                parameters.Add("@PayName", payName);
                parameters.Add("@Msgkey", msgKey);
                parameters.Add("@Transition", transition);
                parameters.Add("@Curr", curr);
                parameters.Add("@TxnDate", t_txnDate);
                //parameters.Add("@CreateDate", DateTime.Now);
                parameters.Add("@UpdateDate", DBNull.Value);
                parameters.Add("@FileName", fileName);
                parameters.Add("@Status", status);
                parameters.Add("@TxnCount", txnCount);
                parameters.Add("@TotAmt", totAmt);
                parameters.Add("@UC", uc);


                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                { resutl = db.ExecuteNonQuery(sbCmd.ToString(), parameters); }
                if (resutl == 0)
                { m_log.Error("DB Table InsertBatchData Fail"); }

            }
            catch (Exception ex)
            {
                m_log.ErrorException("DB Table InsertBatchData Fail :", ex);
            }
            return resutl;
        }

        static public DataSet SelectBatchByPayacntAndDate(string payAcnt, string startDate, string endDate, string msgKey)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT [BATID], [BatchNo], [PayAcnt], [PayName], [TxnDate], [Status], [TxnCount], [TotAmt] FROM  BatchDetail ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [PayAcnt] = @PayAcnt ");
                sbCmd.AppendFormat("AND [TxnDate] BETWEEN @StartDate AND @EndDate ");
                sbCmd.AppendFormat("AND [MsgKey] = @MsgKey ");
                //sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                //sbCmd.AppendFormat("ORDER BY [BatchNo] DESC");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@PayAcnt", payAcnt);
                parameters.Add("@StartDate", startDate);
                parameters.Add("@EndDate", endDate);
                parameters.Add("@MsgKey", msgKey);

                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectBatchByPayacntAndDate Exception : ", ex);
            }
            return dataset;
        }
        static public DataSet SelectBatchByBatchno(string batchNo, string msgKey)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT [BATID], [PayAcnt], [PayName], [Curr] FROM  BatchDetail ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [BatchNo] = @BatchNo ");
                sbCmd.AppendFormat("AND [MsgKey] = @MsgKey ");
                //sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@BatchNo", batchNo);
                parameters.Add("@MsgKey", msgKey);

                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectBatchByPayacntAndDate Exception : ", ex);
            }
            return dataset;
        }


        static public int UpdateMsmqAddinfoByBTID(string additionalInfo, string msmq_BTID)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat(";WITH XMLNAMESPACES ('urn:schema-bankpro-com:multichannel' as ns) ");
                sbCmd.AppendFormat("UPDATE BroadcastMSMQTalk SET [AdditionalInfo]=@AdditionalInfo ");
                sbCmd.AppendFormat("WHERE 1 = 1");
                sbCmd.AppendFormat(" AND [BTID]=@BTID");
                //sbCmd.AppendFormat(" AND CONVERT(xml,MSMQ_Body).exist('/ns:BankproML/ns:CommMsg/ns:BATCH_UID[text()[1]= sql:variable(\"@BATCH_UID\")]') = 1");
                sbCmd.AppendFormat(" AND [Status]=2");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@AdditionalInfo", additionalInfo);
                parameters.Add("@BTID", msmq_BTID);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                resutl = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("UpdateMsmqAddinfoByRqUID Exception : ", ex);
            }
            return resutl;
        }

        static public DataSet SelectMqtkByImportID(string importId, string label = null)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                sbCmd.AppendFormat("SELECT [MSMQ_Body], [Status], [CreateDate], [UpdateDate], [AdditionalInfo] FROM  BroadcastMSMQTalk ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [ImportID]=@ImportID ");
                if (!string.IsNullOrEmpty(label))
                {
                    sbCmd.AppendFormat("AND [MSMQ_Label]=@MSMQ_Label ");
                    parameters.Add("@MSMQ_Label", label);
                }
                //sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();


                parameters.Add("@ImportID", importId);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectMqtkByImpidAndCredtInterval Exception : ", ex);
            }
            return dataset;
        }
        #endregion BATCH

        #region UCAcctRecon
        static public DataSet SelAccRec(string custNo, string acctNo)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  IBAccRecSign ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [CustNo] = @CustNo ");
                sbCmd.AppendFormat("AND [AcctNo] = @AcctNo ");
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@CustNo", custNo);
                parameters.Add("@AcctNo", acctNo);

                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelAccRecByCustNo Exception : ", ex);
            }
            return dataset;
        }

        static public int InsAccRec(string custNo, string custName, string custComp, string custCompNm, string acctNo, string acctTitle,
                                                    string acctType, string acctComp, string acctCompNm, string contractNo, string iPAddress)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO  [IBAccRecSign]");
                sbCmd.Append("([CustNo],[CustName],[CustComp],[CustCompNm],[AcctNo],[AcctTitle],[AcctType],[AcctComp],[AcctCompNm],");
                sbCmd.Append("[ContractNo],[Status],[StatusChgDate],[IPAddress],[CreateDate]) ");
                sbCmd.Append("VALUES");
                sbCmd.Append("(@CustNo, @CustName, @CustComp, @CustCompNm, @AcctNo, @AcctTitle, @AcctType,");
                sbCmd.Append("@AcctComp, @AcctCompNm, @ContractNo, 0, GETDATE(), @IPAddress, GETDATE())");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@CustNo", custNo);
                parameters.Add("@CustName", custName);
                parameters.Add("@CustComp", custComp);
                parameters.Add("@CustCompNm", custCompNm);
                parameters.Add("@AcctNo", acctNo);
                parameters.Add("@AcctTitle", acctTitle);
                parameters.Add("@AcctType", acctType);
                parameters.Add("@AcctComp", acctComp);
                parameters.Add("@AcctCompNm", acctCompNm);
                parameters.Add("@ContractNo", contractNo);
                parameters.Add("@IPAddress", iPAddress);

                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                { resutl = db.ExecuteNonQuery(sbCmd.ToString(), parameters); }
                if (resutl == 0)
                { m_log.Error("DB Table InsertIBAccRecSignData Fail"); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("InsAccRec Exception : ", ex);
            }
            return resutl;
        }

        static public int UpdAccRecStatus(string acctNo, string status, string iPAddress, string contractNo)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();

                if (status == "1" || status == "")
                {
                    sbCmd.AppendFormat("UPDATE IBAccRecSign SET [Status]= '0', ");
                    sbCmd.AppendFormat("[ContractNo]=@ContractNo, ");
                }
                else if (status == "0")
                {
                    sbCmd.AppendFormat("UPDATE IBAccRecSign SET [Status]= '1', ");
                }
                sbCmd.AppendFormat("[StatusChgDate]=GETDATE(), ");
                sbCmd.AppendFormat("[IPAddress]=@IPAddress ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [AcctNo]=@AcctNo");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@AcctNo", acctNo);
                parameters.Add("@IPAddress", iPAddress);
                parameters.Add("@ContractNo", contractNo);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                resutl = db.ExecuteNonQuery(sqlCMD, parameters);
                if (resutl == 0)
                { m_log.Error("DB Table UpdAccRecStatus Fail"); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("UpdAccRecStatus Exception : ", ex);
            }
            return resutl;
        }

        static public DataSet SelIBBalRecChk(string txID, string custNo, string acctNo, string status, string result,
                                                                   string year, string volumn)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();

                #region 2020530  2020641
                if (txID == "2020530" || txID == "2020641")
                {
                    sbCmd.AppendFormat("SELECT * FROM  IBBalRecChk ");
                    sbCmd.AppendFormat("LEFT JOIN IBAccRecSign ON IBBalRecChk.AcctNo = IBAccRecSign.AcctNo ");
                    sbCmd.AppendFormat("WHERE 1 = 1 ");
                    sbCmd.AppendFormat("AND IBBalRecChk.CustNo = @CustNo ");
                    if (acctNo != null)
                    {
                        sbCmd.AppendFormat("AND charindex(IBBalRecChk.AcctNo,@AcctNo)>0 ");
                    }
                    sbCmd.AppendFormat("AND IBBalRecChk.Year = @Year ");
                    if (status == "0")
                    {
                        sbCmd.AppendFormat("AND IBBalRecChk.Status = '0' ");
                    }
                    else if (status == "1")
                    {
                        sbCmd.AppendFormat("AND IBBalRecChk.Status = '1' ");
                    }

                    if (result != null)
                    {
                        sbCmd.AppendFormat("AND IBBalRecChk.Result = @Result ");
                    }
                    sbCmd.AppendFormat("ORDER BY IBBalRecChk.CreateDate DESC");
                }
                #endregion 2020530  2020641
                #region 2020607
                if (txID == "2020607")
                {
                    sbCmd.AppendFormat("SELECT * FROM  IBBalRecChk ");
                    sbCmd.AppendFormat("WHERE 1 = 1 ");
                    sbCmd.AppendFormat("AND [CustNo] = @CustNo ");
                    sbCmd.AppendFormat("AND [AcctNo] = @AcctNo ");
                    sbCmd.AppendFormat("AND [Year] = @Year ");
                    sbCmd.AppendFormat("AND [Volumn] = @Volumn ");
                    sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                }
                #endregion 2020607
                #region 2020642
                if (txID == "2020642")
                {
                    sbCmd.AppendFormat("SELECT * FROM  IBBalRecChk ");
                    sbCmd.AppendFormat("LEFT JOIN IBAccRecSign ON IBBalRecChk.AcctNo = IBAccRecSign.AcctNo ");
                    sbCmd.AppendFormat("LEFT JOIN IBBalRecAdj ON IBBalRecChk.BalRecPKey = IBBalRecAdj.BalRecPKey ");
                    sbCmd.AppendFormat("WHERE 1 = 1 ");
                    sbCmd.AppendFormat("AND IBBalRecChk.CustNo = @CustNo ");
                    sbCmd.AppendFormat("AND IBBalRecChk.AcctNo = @AcctNo ");
                    sbCmd.AppendFormat("AND IBBalRecChk.Year = @Year ");
                    sbCmd.AppendFormat("AND IBBalRecChk.Volumn = @Volumn ");
                    sbCmd.AppendFormat("ORDER BY IBBalRecAdj.AdjId");
                }
                #endregion 2020642

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@CustNo", custNo);
                if (acctNo != null)
                {
                    parameters.Add("@AcctNo", acctNo);
                }
                if (result != null)
                {
                    parameters.Add("@Result", result);
                }
                parameters.Add("@Year", year);
                if (txID == "2020607" || txID == "2020642")
                {
                    parameters.Add("@Volumn", volumn);
                }

                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelIBBalRecChk Exception : ", ex);
            }
            return dataset;
        }

        static public int UpdIBBalRecChk(string acctNo, string companyBal, string iPAddress, string recsult, string remark, string hasAdj,
                                                             string uc, string year, string volumn)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("UPDATE IBBalRecChk SET [ChkDate]=GETDATE(), ");
                if (companyBal != null) { sbCmd.AppendFormat("[CompanyBal]=@CompanyBal, "); }
                if (iPAddress != null) { sbCmd.AppendFormat("[IPAddress]=@IPAddress, "); }
                if (recsult != null) { sbCmd.AppendFormat("[Result]=@Result, "); }
                sbCmd.AppendFormat("[Status]='1', ");
                if (remark != null) { sbCmd.AppendFormat("[Remark]=@Remark, "); }
                if (hasAdj != null) { sbCmd.AppendFormat("[HasAdj]=@HasAdj, "); }
                sbCmd.AppendFormat("[UC]=@UC ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                if (acctNo != null) { sbCmd.AppendFormat("AND [AcctNo]=@AcctNo "); }
                if (year != null) { sbCmd.AppendFormat("AND [Year]=@Year "); }
                if (volumn != null) { sbCmd.AppendFormat("AND [Volumn]=@Volumn"); }

                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                if (companyBal != null) { parameters.Add("@CompanyBal", companyBal); }
                if (iPAddress != null) { parameters.Add("@IPAddress", iPAddress); }
                if (recsult != null) { parameters.Add("@Result", recsult); }
                if (remark != null) { parameters.Add("@Remark", remark); }
                if (hasAdj != null) { parameters.Add("@HasAdj", hasAdj); }
                parameters.Add("@UC", uc);
                if (acctNo != null) { parameters.Add("@AcctNo", acctNo); }
                if (year != null) { parameters.Add("@Year", year); }
                if (volumn != null) { parameters.Add("@Volumn", volumn); }

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                resutl = db.ExecuteNonQuery(sqlCMD, parameters);
                if (resutl == 0)
                { m_log.Error("DB Table UpdIBBalRecChk Fail"); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("UpdIBBalRecChk Exception : ", ex);
            }
            return resutl;
        }

        static public int InsIBBalRecAdj(string balRecPKey, string comRecDbtDate, string comRecDbtAmt, string comRecCdtDate,
                                                           string comRecCdtAmt, string bnkRecDbtDate, string bnkRecDbtAmt, string bnkRecCdtDate,
                                                           string bnkRecCdtAmt)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO  [IBBalRecAdj]");
                sbCmd.Append("([BalRecPKey],[ComRecDbtDate],[ComRecDbtAmt],[ComRecCdtDate],[ComRecCdtAmt],[BnkRecDbtDate],");
                sbCmd.Append("[BnkRecDbtAmt],[BnkRecCdtDate],[BnkRecCdtAmt],[CreateDate]) ");
                sbCmd.Append("VALUES");
                sbCmd.Append("(@BalRecPKey, @ComRecDbtDate, @ComRecDbtAmt, @ComRecCdtDate, @ComRecCdtAmt, @BnkRecDbtDate,");
                sbCmd.Append("@BnkRecDbtAmt, @BnkRecCdtDate, @BnkRecCdtAmt, GETDATE())");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@BalRecPKey", balRecPKey);
                parameters.Add("@ComRecDbtDate", comRecDbtDate);
                parameters.Add("@ComRecDbtAmt", comRecDbtAmt);
                parameters.Add("@ComRecCdtDate", comRecCdtDate);
                parameters.Add("@ComRecCdtAmt", comRecCdtAmt);
                parameters.Add("@BnkRecDbtDate", bnkRecDbtDate);
                parameters.Add("@BnkRecDbtAmt", bnkRecDbtAmt);
                parameters.Add("@BnkRecCdtDate", bnkRecCdtDate);
                parameters.Add("@BnkRecCdtAmt", bnkRecCdtAmt);

                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                { resutl = db.ExecuteNonQuery(sbCmd.ToString(), parameters); }
                if (resutl == 0)
                { m_log.Error("DB Table InsertIBBalRecAdjData Fail"); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("InsIBBalRecAdj Exception : ", ex);
            }
            return resutl;
        }

        static public DataSet SelIBTxnRec(string txID, string custNo, string acctNo, string startDate, string endDate, string recId)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  IBTxnRec ");
                if (txID == "2020637")
                {
                    sbCmd.AppendFormat("LEFT JOIN IBAccRecSign ON IBTxnRec.AcctNo = IBAccRecSign.AcctNo ");
                    sbCmd.AppendFormat("WHERE 1 = 1 ");
                    sbCmd.AppendFormat("AND IBTxnRec.CustNo = @CustNo ");
                    sbCmd.AppendFormat("AND charindex(IBTxnRec.AcctNo,@AcctNo)>0 ");
                    sbCmd.AppendFormat("AND (IBTxnRec.TxnDate >= @StartDate) ");
                    sbCmd.AppendFormat("AND (IBTxnRec.TxnDate <= @EndDate) ");
                    sbCmd.AppendFormat("ORDER BY IBTxnRec.AcctNo, IBTxnRec.RecId");
                }
                if (txID == "2020638")
                {
                    sbCmd.AppendFormat("WHERE 1 = 1 ");
                    sbCmd.AppendFormat("AND [RecId] = @RecId ");
                    sbCmd.AppendFormat("AND [AcctNo] = @AcctNo ");
                    sbCmd.AppendFormat("ORDER BY CreateDate DESC");
                }
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@CustNo", custNo);
                parameters.Add("@AcctNo", acctNo);
                parameters.Add("@StartDate", startDate);
                parameters.Add("@EndDate", endDate);
                if (txID == "2020638")
                {
                    parameters.Add("@RecId", recId);
                }

                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelIBTxnRec Exception : ", ex);
            }
            return dataset;
        }

        static public DataSet SelIBTxnRecLotNo(string txID, string custNo, string acctNo, string status, string startDate, string endDate)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  IBTxnRecLotNo ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [CustNo] = @CustNo ");
                if (acctNo != null)
                {
                    sbCmd.AppendFormat("AND [AcctNo] LIKE @AcctNo ");
                }
                if (txID == "2020639")
                {
                    if (status == "1")
                    {
                        sbCmd.AppendFormat("AND [NotMatchCnt]  = 0  ");
                    }
                    if (status == "2")
                    {
                        sbCmd.AppendFormat("AND [NotMatchCnt]  > 0  ");
                    }
                }
                sbCmd.AppendFormat("AND ((@StartDate <= [StartDate] AND [StartDate] <= @EndDate) ");
                sbCmd.AppendFormat("OR (@StartDate <= [EndDate] AND [EndDate] <= @EndDate)) ");
                sbCmd.AppendFormat("ORDER BY [LotNo] ASC");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@CustNo", custNo);
                if (acctNo != null)
                {
                    acctNo = "%" + acctNo + "%";
                    parameters.Add("@AcctNo", acctNo);
                }
                parameters.Add("@StartDate", startDate);
                parameters.Add("@EndDate", endDate);

                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelIBTxnRecLotNo Exception : ", ex);
            }
            return dataset;
        }

        static public DataSet SelIBTxnRecChk(string txID, string custNo, string reAcctNo, string startDate, string endDate, string lotNo)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  IBTxnRecChk ");
                sbCmd.AppendFormat("LEFT JOIN IBAccRecSign ON IBTxnRecChk.AcctNo = IBAccRecSign.AcctNo ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND IBTxnRecChk.CustNo = @CustNo ");
                if (txID == "2020640")
                {
                    sbCmd.AppendFormat("AND IBTxnRecChk.LotNo = @LotNo ");
                }
                if (txID == "2020637")
                {
                    sbCmd.AppendFormat("AND IBTxnRecChk.AcctNo = @AcctNo ");
                    sbCmd.AppendFormat("AND (IBTxnRecChk.TxnDate >= @StartDate) ");
                    sbCmd.AppendFormat("AND (IBTxnRecChk.TxnDate <= @EndDate) ");
                }
                sbCmd.AppendFormat("ORDER BY IBTxnRecChk.RecId, IBTxnRecChk.AcctNo");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@CustNo", custNo);
                if (txID == "2020640")
                {
                    parameters.Add("@LotNo", lotNo);
                }
                if (txID == "2020637")
                {
                    parameters.Add("@AcctNo", reAcctNo);
                    parameters.Add("@StartDate", startDate);
                    parameters.Add("@EndDate", endDate);
                }

                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelIBTxnRecChk Exception : ", ex);
            }
            return dataset;
        }

        static public int DelIBTxnRec(string recId, string acctNo)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();

                sbCmd.AppendFormat("DELETE FROM IBTxnRec ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [RecId]=@RecId ");
                sbCmd.AppendFormat("AND [AcctNo]=@AcctNo");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@RecId", recId);
                parameters.Add("@AcctNo", acctNo);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                resutl = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("DelIBTxnRec Exception : ", ex);
            }
            return resutl;
        }

        static public int InsIBTxnRecLotNo(string custNo, string acctNo, string startDate, string endDate,
                                                           int matchCnt, int notMatchCnt, string ip, string uc)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO  [IBTxnRecLotNo]");
                sbCmd.Append("([CustNo],[AcctNo],[StartDate],[EndDate],[MatchCnt],[NotMatchCnt],");
                sbCmd.Append("[IP],[UC],[LotDate]) ");
                sbCmd.Append("VALUES");
                sbCmd.Append("(@CustNo, @AcctNo, @StartDate, @EndDate, @MatchCnt, @NotMatchCnt,");
                sbCmd.Append("@IP, @UC, GETDATE())");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@CustNo", custNo);
                parameters.Add("@AcctNo", acctNo);
                parameters.Add("@StartDate", startDate);
                parameters.Add("@EndDate", endDate);
                parameters.Add("@MatchCnt", matchCnt);
                parameters.Add("@NotMatchCnt", notMatchCnt);
                parameters.Add("@IP", ip);
                parameters.Add("@UC", uc);

                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                { resutl = db.ExecuteNonQuery(sbCmd.ToString(), parameters); }
                if (resutl == 0)
                { m_log.Error("DB Table InsertIBTxnRecLotNoData Fail"); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("InsIBTxnRecLotNo Exception : ", ex);
            }
            return resutl;
        }

        static public int InsIBTxnRecChk(string recId, string custNo, string acctNo, string txnDate, string cashFlag, string dbtAmt,
                                                            string cdtAmt, string balance, string remark, string txnId, string createDate, string lotNo, string result)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO  [IBTxnRecChk]");
                sbCmd.Append("([RecId],[CustNo],[AcctNo],[TxnDate],[CashFlag],[DbtAmt],[CdtAmt],[Balance],");
                sbCmd.Append("[Remark],[TxnId],[CreateDate],[LotNo],[Result],[LotDate]) ");
                sbCmd.Append("VALUES");
                sbCmd.Append("(@RecId, @CustNo, @AcctNo, @TxnDate, @CashFlag, @DbtAmt, @CdtAmt, @Balance,");
                sbCmd.Append("@Remark, @TxnId, @CreateDate, @LotNo, @Result, GETDATE())");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@RecId", recId);
                parameters.Add("@CustNo", custNo);
                parameters.Add("@AcctNo", acctNo);
                parameters.Add("@TxnDate", txnDate);
                parameters.Add("@CashFlag", cashFlag);
                parameters.Add("@DbtAmt", dbtAmt);
                parameters.Add("@CdtAmt", cdtAmt);
                parameters.Add("@Balance", balance);
                parameters.Add("@Remark", remark);
                parameters.Add("@TxnId", txnId);
                parameters.Add("@CreateDate", createDate);
                parameters.Add("@LotNo", lotNo);
                parameters.Add("@Result", result);

                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                { resutl = db.ExecuteNonQuery(sbCmd.ToString(), parameters); }
                if (resutl == 0)
                { m_log.Error("DB Table InsertIBTxnRecChkData Fail"); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("InsIBTxnRecChk Exception : ", ex);
            }
            return resutl;
        }
        #endregion UCAcctRecon

        #region IBNextDay
        /// <summary>
        /// 扣帳成功後寫入
        /// </summary>
        /// <param name="txnId"></param>
        /// <param name="payerAcctNo"></param>
        /// <param name="debCustomer"></param>
        /// <param name="payeeAcctNo"></param>
        /// <param name="intAcctNo"></param>
        /// <param name="cardIntAcctNo"></param>
        /// <param name="txnDate"></param>
        /// <param name="debValDate"></param>
        /// <param name="debAmt"></param>
        /// <param name="creCur"></param>
        /// <param name="debCur"></param>
        /// <param name="transGate"></param>
        /// <param name="remark"></param>
        /// <param name="remarks"></param>
        /// <param name="payerName"></param>
        /// <param name="payeeName"></param>
        /// <param name="debitRef"></param>
        /// <param name="payMethod"></param>
        /// <param name="flag"></param>
        /// <param name="recTxn"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        static public int InsertIBNextIntTrans(string txnId, string payerAcctNo, string debCustomer, string payeeAcctNo, string intAcctNo, string cardIntAcctNo, string txnDate, string debValDate, decimal debAmt,
            string creCur, string debCur, string transGate, string remark, string remarks, string payerName, string payeeName, string debitRef, int payMethod, int flag, string recTxn, int status, Guid btId)
        {
            int resultCnt = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO [IBNextIntTrans]");
                sbCmd.Append("([RecId],[DebAcctNo],[DebCusNo],[CreAcctNo],[IntAcctNo],[CardIntAcct],[TxnDate],[ValueDate],[Amt],[CreCur]");
                sbCmd.Append(",[DebCur],[TransGate],[Remark],[Remarks],[PayerName],[PayeeName],[Ref],[PayMethod],[Flag],[RecTxn],[Status],[MSMQ_BTID])");
                sbCmd.Append("VALUES");
                sbCmd.Append("(@RecId,@DebAcctNo,@DebCusNo,@CreAcctNo,@IntAcctNo,@CardIntAcct,@TxnDate,@ValueDate,@Amt,@CreCur");
                sbCmd.Append(",@DebCur,@TransGate,@Remark,@Remarks,@PayerName,@PayeeName,@Ref,@PayMethod,@Flag,@RecTxn,@Status,@MSMQ_BTID)");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@RecId", txnId);
                parameters.Add("@DebAcctNo", payerAcctNo);
                parameters.Add("@DebCusNo", debCustomer);
                parameters.Add("@CreAcctNo", payeeAcctNo);
                parameters.Add("@IntAcctNo", intAcctNo);
                parameters.Add("@CardIntAcct", cardIntAcctNo);
                parameters.Add("@TxnDate", txnDate);
                parameters.Add("@ValueDate", debValDate);
                parameters.Add("@Amt", debAmt);
                parameters.Add("@CreCur", creCur);
                parameters.Add("@DebCur", debCur);
                parameters.Add("@TransGate", transGate);
                parameters.Add("@Remark", remark);
                parameters.Add("@Remarks", remarks);
                parameters.Add("@PayerName", payerName);
                parameters.Add("@PayeeName", payeeName);
                parameters.Add("@Ref", debitRef);
                parameters.Add("@PayMethod", payMethod);
                parameters.Add("@Flag", flag);
                parameters.Add("@RecTxn", recTxn);
                parameters.Add("@Status", status);
                parameters.Add("@MSMQ_BTID", btId);

                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                { resultCnt = db.ExecuteNonQuery(sbCmd.ToString(), parameters); }
                if (resultCnt == 0)
                { m_log.Error("DB Table Insert IBNextIntTrans Fail"); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("DB Table Insert IBNextIntTrans Fail : ", ex);
            }
            return resultCnt;
        }

        /// <summary>
        /// Insert主動通知訊息
        /// </summary>
        /// <param name="Label">訊息標題</param>
        /// <param name="Body">訊息內容</param>
        /// <param name="Priority">訊息優先順序</param>
        /// <param name="Type">訊息型態</param>
        /// <param name="Size">訊息長度</param>
        /// <param name="Path">MSMQueue路徑</param>
        /// <param name="MachineName">機器名稱</param>
        /// <param name="URL">傳送的URL</param>
        /// <param name="User">使用者</param>
        /// <returns></returns>
        static public int InsBroadcastMSMQTalk(Guid BTID, string Label, string Body, int Priority, string Type, int Size, string Path, string MachineName, string URL, string User, int Status)
        {
            int result = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO [BroadcastMSMQTalk]([BTID],[MSMQ_Label],[MSMQ_Body],[MSMQ_Priority],[MSMQ_Type]");
                sbCmd.Append(",[MSMQ_Size],[MSMQ_Path],[MachineName],[URL],[Status],[CreateDate] ,[CreateUser])");
                sbCmd.Append("VALUES (@BTID, @MSMQ_Label, @MSMQ_Body, @MSMQ_Priority, @MSMQ_Type");
                sbCmd.Append(",@MSMQ_Size, @MSMQ_Path, @MachineName, @URL, @Status, @CreateDate ,@CreateUser)");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@BTID", BTID);
                parameters.Add("@MSMQ_Label", Label);
                parameters.Add("@MSMQ_Body", Body);
                parameters.Add("@MSMQ_Priority", Priority);
                parameters.Add("@MSMQ_Type", Type);
                parameters.Add("@MSMQ_Size", Size);
                parameters.Add("@MSMQ_Path", Path);
                parameters.Add("@MachineName", MachineName);
                parameters.Add("@URL", URL);
                parameters.Add("@Status", Status);
                parameters.Add("@CreateDate", DateTime.Now);
                parameters.Add("@CreateUser", User);

                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                {
                    result = db.ExecuteNonQuery(sbCmd.ToString(), parameters);
                }

                if (result == 0)
                {
                    m_log.Error("DB Table Insert InsBroadcastMSMQTalk Fail");
                }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("DB Table Insert InsBroadcastMSMQTalk Fail : ", ex);
            }
            return result;
        }

        /// <summary>
        /// 入帳成功時更新RecTxn為入帳流水號,Status為1(不可撤銷)
        /// 
        /// </summary>
        /// <param name="RecId"></param>
        /// <param name="RecTxn"></param>
        /// <param name="Status"></param>
        /// <returns></returns>
        static public int UpdateAfterNextIntTrans(string RecId, string RecTxn, int Status)
        {
            int execRows = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("UPDATE [IBNextIntTrans] SET [RecTxn] = @RecTxn , [Status] = @Status ");
                sbCmd.AppendFormat("WHERE [RecId] = @RecId ");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@RecTxn", RecTxn);
                parameters.Add("@Status", Status);
                parameters.Add("@RecId", RecId);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                execRows = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("UpdateAfterNextIntTrans Exception : ", ex);
            }
            return execRows;
        }

        /// <summary>
        /// 轉帳撤銷時先更新IBNextIntTrans之Status(若Status為0則改為1)
        /// </summary>
        /// <param name="RecId"></param>
        /// <param name="Status"></param>
        /// <returns></returns>
        static public int UpdateNextIntTransStatus(int Status, string RecId)
        {
            int execRows = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("UPDATE [IBNextIntTrans] SET [Status] = @Status ");
                sbCmd.AppendFormat("WHERE [RecId] = @RecId ");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@Status", Status);
                parameters.Add("@RecId", RecId);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                execRows = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("UpdateNextIntTransStatus Exception : ", ex);
            }
            return execRows;
        }


        static public DataSet SelectIBNextIntTransQuery(string DebAcctNo, string StartDate, string EndDate)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM IBNextIntTrans ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [DebAcctNo] = @DebAcctNo ");
                sbCmd.AppendFormat("AND  CONVERT(datetime,TxnDate) Between CONVERT(datetime, @StartDate) AND CONVERT(datetime,@EndDate)");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@DebAcctNo", DebAcctNo);
                parameters.Add("@StartDate", StartDate);
                parameters.Add("@EndDate", EndDate);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                {
                    string dbStr = string.Format("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count);
                }
            }
            catch (Exception ex)
            {
                string dbStr = string.Format("SelectIBNextIntTransQuery Exception : {0}", ex);
            }
            return dataset;
        }

        /// <summary>
        /// 以轉帳撤銷請求的C_ORG_FT_REF_NO(會帶FT流水號)查詢IBNextIntTrans表上的欄位
        /// </summary>
        /// <param name="C_ORG_FT_REF_NO"></param>
        /// <returns></returns>
        static public DataSet SelectIBNextIntTransAll(string C_ORG_FT_REF_NO)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM [IBNextIntTrans] ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [RecId] = @C_ORG_FT_REF_NO ");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@C_ORG_FT_REF_NO", C_ORG_FT_REF_NO);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                {
                    string dbStr = string.Format("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count);
                }
            }
            catch (Exception ex)
            {
                string dbStr = string.Format("SelectIBNextIntTransAll Exception : {0}", ex);
            }
            return dataset;
        }

        /// <summary>
        /// 撤銷時除了更新IBNextIntTrans之Status，也需更動BroadcastMSMQTalk的Status
        /// </summary>
        /// <param name="Status"></param>
        /// <param name="BTID"></param>
        /// <returns></returns>
        static public int UpdateNextDayMSMQStatus(int Status, string BTID)
        {
            int execRows = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("UPDATE [BroadcastMSMQTalk] SET [Status] = @Status ");
                sbCmd.AppendFormat("WHERE [BTID] = @BTID ");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@Status", Status);
                parameters.Add("@BTID", BTID);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                execRows = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("UpdateNextIntTransStatus Exception : ", ex);
            }
            return execRows;
        }
        #endregion
    }
}
