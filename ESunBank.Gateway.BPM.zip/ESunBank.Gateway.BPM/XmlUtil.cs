using System;
using System.Xml;

namespace ESunBank.Gateway.BPM
{
    internal class XmlUtil {


        public static string GetXPath(XmlDocument doc, string xpath)
        {
            XmlNode node = doc.SelectSingleNode(xpath);
            if (node == null)
            {
                return "";
            }
            else
            {
                return node.InnerText.Trim();
            }
        }
        public static string GetXPath(XmlDocument doc, string xpath, XmlNamespaceManager xmlnsMgr)
        {
            XmlNode node = doc.SelectSingleNode(xpath, xmlnsMgr);
            if (node == null)
            {
                return "";
            }
            else
            {
                return node.InnerText.Trim();
            }
        }


        public static void SetXPath(XmlDocument doc, string xpath, string value) {
            XmlNode node = doc.SelectSingleNode(xpath);
            if (node != null) {
                node.InnerText = value;
                return;
            }
            string parentXPath = xpath.Substring(0, xpath.LastIndexOf("/"));
            XmlNode parentNode = doc.SelectSingleNode(parentXPath);
            if (parentNode == null) {
                throw new ApplicationException(string.Format("parent node [{0}] is not found.", parentXPath));
            }
            string elementName = xpath.Substring(xpath.LastIndexOf("/") + 1);
            XmlNode newNode = doc.CreateElement(elementName);
            newNode.InnerText = value;
            parentNode.AppendChild(newNode);
        }

        public static XmlWriterSettings GetStandardXmlWritterSettings() {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            return settings;
        }

    }
}
