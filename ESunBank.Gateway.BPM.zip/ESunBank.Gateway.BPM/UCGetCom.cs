﻿using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using Bankpro.EAI.Utility;
using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace ESunBank.Gateway.BPM
{
    public class UCGetCom : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.Gateway.BPM.UCGetCom");
        private const string spN_GW = "GW";
        private const string custId_GW = "GW";

        public string rq_t24_data = string.Empty;

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            return getCom(context, txID, txDef, requestXml);
        }

        public AppXmlExecResult getCom(EaiContext context, string txID, HostTxDef txDef, XmlDocument requestXml)
        {

            XmlHelper rq_XmlHelper = XmlHelper.GetInstance(requestXml);
            rq_t24_data = rq_XmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
            m_log.Info("UCGetCom txID = [{0}] UC_Request = [{1}]", txID, rq_t24_data);

            try
            {
                string channel = string.Empty;
                Dictionary<string, string> headDic; Dictionary<string, string> bodyDic;
                UcControler uCcontroler = new UcControler();
                ParseUcToDic(uCcontroler, rq_t24_data, out headDic, out bodyDic);

                //取得客戶號或帳號欄位和欄位值
                string ucChkBaseCol = string.Empty; string ucChkBase = string.Empty;
                string ucComCol = string.Empty; string ucCom = string.Empty;
                TxSettings txSettings = txDef.TITA.Settings;
                ucChkBaseCol = txSettings.GetString("ucChkBaseCol", "");
                ucComCol = txSettings.GetString("ucComCol", "");

                m_log.Info("UCGetCom ucChkBaseCol, ucComCol = [{0}],[{1}]", ucChkBaseCol, ucComCol);

                if (!string.IsNullOrEmpty(ucChkBaseCol))
                {
                    bodyDic.TryGetValue(ucChkBaseCol, out ucChkBase);

                    if (!string.IsNullOrEmpty(ucChkBase))
                    {
                        string rq_t24_enq = GetT24_AcntInfoEnq_Content(ucChkBase);
                        AppXmlExecResult t24Enq_result = SendMsgToEAIProcess(context, rq_t24_enq, "ACC.CUST.INFO.ENQ", spN_GW, custId_GW, true);

                        XmlHelper xmlHelperT24Enq = XmlHelper.GetInstance(t24Enq_result.ResponseXml);
                        ucCom = xmlHelperT24Enq.GetXPath(t24Enq_result.ResponseXml, "//" + ucComCol).Trim();

                        //將分行號append到原城商電文
                        rq_t24_data = string.IsNullOrEmpty(ucCom) ? rq_t24_data : rq_t24_data + "000019" + ucCom;
                    }
                }

                string newucString = string.Format("<T24_DATA>{0}</T24_DATA>", rq_t24_data);
                return SendMsgToEAIProcess(context, newucString, txID, spN_GW, custId_GW, true);
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("UCGetCom Error TxID=[{0}]", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        private void ParseUcToDic(UcControler uCcontroler, string rsString, out Dictionary<string, string> ucHeadDic, out Dictionary<string, string> ucBodyDic)
        {
            if (string.IsNullOrEmpty(rsString))
            {
                ucHeadDic = new Dictionary<string, string>();
                ucBodyDic = new Dictionary<string, string>();
                return;
            }

            UcBody ucBody = new UcBody();
            ucHeadDic = uCcontroler.UC2T24_Head(rsString);
            ucBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);
        }

        private string GetT24_AcntInfoEnq_Content(string acctNo)
        {
            StringBuilder sb = new StringBuilder();
            #region ACC.CUST.INFO.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ACC.CUST.INFO.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0043");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<FIELD.1 op='EQ'>{0}</FIELD.1>", acctNo);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }
    }
}
