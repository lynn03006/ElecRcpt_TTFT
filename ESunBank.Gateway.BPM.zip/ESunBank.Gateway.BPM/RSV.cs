﻿using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

using System.Data;

using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using System.Xml.Linq;
using Bankpro.EAI.Utility;

namespace ESunBank.Gateway.BPM
{
    public class RSV : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("ESUNBank.Gateway.BPM.RSV");
        private const string spN_GW = "GW";
        private const string custId_GW = "GW";
        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            switch (txID)
            {
                case "2010745"://定時發送之交易
                case "2020574":
                case "ES_2010745"://定時轉帳簽約請求 簽約時 產生簽約當下需回傳的Response
                case "ES_2020574":
                    return Do_2010745_2020574_Process(context, correlationID, txID, txDef, requestXml);
                case "2010746"://定時轉帳簽約信息查詢請求
                case "2020575":
                case "2010746BE":
                case "2020575BE":
                    return Do_2010746_2020575_Process(context, correlationID, txID, txDef, requestXml);
                case "2010747"://定時轉帳明細查詢請求
                case "2020576":
                case "2010747BE":
                case "2020576BE":
                    return Do_2010747_2020576_Process(context, correlationID, txID, txDef, requestXml);
                case "2010748"://定時轉帳撤銷請求
                case "2020577":
                case "2010748BE":
                case "2020577BE":
                    return Do_2010748_2020577_Process(context, correlationID, txID, txDef, requestXml);
            }
            EaiResponse eaiRs = null;
            XmlDocument responseXml = null;
            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }

        #region (定時轉帳)定時轉帳簽約請求 2010745 (定時轉帳)定時轉帳簽約請求 2020574
        AppXmlExecResult Do_2010745_2020574_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucString = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, ucString);
                m_log.Info("Do_2010745_2020574_Process txID=[{0}]", txID);
                string rsString = string.Empty;
                Dictionary<string, string> rqUcHeadDic, rqUcBodyDic;
                ParseUcToDic(ucString, out rqUcHeadDic, out rqUcBodyDic);//提取Request Dictionary

                #region 組出簽約序號 由具有唯一性的"委託日期+發起行行號+業務類型+交易序號"組成
                string commissionDate, fCompany, binsType, trxNo, signID;
                rqUcBodyDic.TryGetValue("2006", out commissionDate);
                rqUcBodyDic.TryGetValue("2002", out fCompany);
                rqUcHeadDic.TryGetValue("BinsType", out binsType);
                rqUcBodyDic.TryGetValue("2039", out trxNo);
                signID = commissionDate + fCompany + binsType + trxNo;
                #endregion 組出簽約序號 由具有唯一性的"委託日期+發起行行號+業務類型+交易序號"組成

                //int selResult = 0;
                //selResult = DBLog.SelectRsvBySignid(signID).Tables[0].Rows.Count;
                if (txID == "ES_2010745" || txID == "ES_2020574")//判斷是否前面有帶ES_ 若有帶 表示簽約  
                {
                    #region 簽約 寫進DB 並回覆成功報文(包含簽約序號)或失敗報文
                    XmlDocument toDbRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", string.Empty), "");
                    int insResult = 0;
                    insResult = InsertRSVData(toDbRqXml, ucString, rqUcHeadDic, rqUcBodyDic, signID);

                    UcControler rs_sign_ucControler = new UcControler();
                    rs_sign_ucControler.UC2T24(ucString);
                    Dictionary<string, string> totalDic = new Dictionary<string, string>();
                    totalDic.Add("4111", signID);
                    if (insResult == 0)//insert進DB失敗，回復失敗報文
                    {
                        rsString = rs_sign_ucControler.GetFailUcRS(totalDic, "CO1MD999", "签约失败");
                    }
                    else//insert進DB成功，回復包含簽約序號的成功報文
                    {
                        rsString = rs_sign_ucControler.GetToUCRS(totalDic);
                    }
                    #endregion 簽約 寫進DB 並回覆成功報文(包含簽約序號)或失敗報文
                }
                else//判斷是否前面有帶ES_ 若沒帶 表示定時發送之交易
                {
                    #region 往T24發送交易，並取回Response
                    rsString = SendToT24_2010745_2020574(context, txID, ucString, requestXml);
                    #region 至RSV TABLE取出RSVID
                    DataSet rsvDataset = DBLog.SelectRsvBySignid(signID);
                    string rsvId;
                    List<Dictionary<string, string>> rsvDicLst = DatasetToDiclist(rsvDataset);
                    if (rsvDicLst.Count == 0)
                    {
                        new SendMail().Send("Can't Get Any Record From Table[RSVDetail] By SignID",
                                            "",
                                            string.Format("Can't Get Any Record From Table[RSVDetail] By SignID SignID:[{0}] RQ:[{1}]"
                                                          , signID, context.RequestXml.OuterXml)
                                            );
                    }
                    rsvDicLst[0].TryGetValue("RSVID", out rsvId);
                    #endregion 至RSV TABLE取出RSVID
                    #region MSMQTalk AdditionalInfo的 組xml
                    Dictionary<string, string> rsUcHeadDic, rsUcBodyDic;
                    ParseUcToDic(rsString, out rsUcHeadDic, out rsUcBodyDic);

                    string msgkey = string.Empty;
                    rsUcBodyDic.TryGetValue("2001", out msgkey);

                    string workBlance = string.Empty, achAmt = string.Empty, succFail = string.Empty, errMsg = string.Empty;
                    if (txID == "2010745")
                    {
                        rsUcBodyDic.TryGetValue("4315", out workBlance);
                        rsUcBodyDic.TryGetValue("4165", out achAmt);
                        rsUcBodyDic.TryGetValue("4345", out succFail);
                        rsUcBodyDic.TryGetValue("2038", out errMsg);
                    }
                    else if (txID == "2020574")
                    {
                        //rsUcBodyDic.TryGetValue("4326", out workBlance);
                        if (msgkey == "2020579")
                        { rsUcBodyDic.TryGetValue("4326", out workBlance); }
                        else
                        { rsUcBodyDic.TryGetValue("4315", out workBlance); }
                        rsUcBodyDic.TryGetValue("4165", out achAmt);
                        rsUcBodyDic.TryGetValue("4345", out succFail);
                        rsUcBodyDic.TryGetValue("2038", out errMsg);
                    }
                    StringBuilder xmlSB = new StringBuilder();
                    xmlSB.AppendFormat("<AdditionalInfo>");
                    xmlSB.AppendFormat("<PayBal>{0}</PayBal>", workBlance);
                    xmlSB.AppendFormat("<Fee>{0}</Fee>", achAmt);
                    xmlSB.AppendFormat("<SuccFail>{0}</SuccFail>", succFail == "1" ? "SUCC" : "FAIL");
                    xmlSB.AppendFormat("<ErrMsg>{0}</ErrMsg>", errMsg);
                    xmlSB.AppendFormat("</AdditionalInfo>");
                    string xmlString = xmlSB.ToString();
                    string ClientDtString = XmlHelper.GetInstance(requestXml).GetXPath(requestXml, "//ClientDt").Trim();
                    string msmq_BTID = XmlHelper.GetInstance(requestXml).GetXPath(requestXml, "//MSMQ_BTID").Trim();
                    int result = DBLog.UpdateMsmqAddinfo(xmlString, rsvId, msmq_BTID);
                    if (result == 0)//更新交易結果不成功
                    {
                        new SendMail().Send("UpdateMsmqAddinfo Error",
                                            "",
                                            string.Format("UpdateMsmqAddinfo Error, PLS Check BTID:[{0}] ImportID:[{1}] ClientDt:[{2}] AdditionalInfo:[{3}] RQ:[{4}]"
                                                         , msmq_BTID, rsvId, ClientDtString, xmlString, context.RequestXml.OuterXml)
                                            );
                    }
                    #endregion MSMQTalk AdditionalInfo的 組xml
                    #endregion 往T24發送交易，並取回Response
                }
                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2010745_2020574_Process Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        public int InsertRSVData(XmlDocument requestXml, string ucString, Dictionary<string, string> ucHeadDic, Dictionary<string, string> ucBodyDic, string signID)
        {
            m_log.Info("InsertRSVData : [{0}]!!", ucString);
            DateTime? timeNext;

            string account, frequency, exec_timing, stimeCommission, stimeStart, stimeEnd, msgKey; DateTime timeCommission, timeStart, timeEnd;
            //string signID1, signID2, signID3, signID4, signID;
            ucBodyDic.TryGetValue("2006", out stimeCommission); timeCommission = DateTime.ParseExact(stimeCommission, "yyyyMMdd", null);

            ucBodyDic.TryGetValue("4157", out account);
            ucBodyDic.TryGetValue("4652", out frequency);
            ucBodyDic.TryGetValue("4364", out exec_timing);
            ucBodyDic.TryGetValue("2001", out msgKey);

            ucBodyDic.TryGetValue("4119", out stimeStart); timeStart = DateTime.ParseExact(stimeStart, "yyyyMMdd", null);
            ucBodyDic.TryGetValue("4120", out stimeEnd); timeEnd = DateTime.ParseExact(stimeEnd, "yyyyMMdd", null);

            //signID1 = stimeCommission;
            //ucBodyDic.TryGetValue("2002", out signID2);
            //ucHeadDic.TryGetValue("BinsType", out signID3);
            //ucBodyDic.TryGetValue("2039", out signID4);
            //signID = signID1 + signID2 + signID3 + signID4;
            #region 取得接下來要執行的日期
            List<DateTime> execTimeLst = GetExecuteDateList(timeStart, timeEnd, frequency, exec_timing, false);
            timeNext = null;
            foreach (DateTime dt in execTimeLst)//下個執行日一定等於今日或大於今日
            {
                if (dt >= new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day))
                {
                    timeNext = dt;
                    break;
                }
            }
            #endregion 取得接下來要執行的日期
            DBLog dblog = new DBLog();
            int resutl = 0;
            resutl = dblog.InsertRsvData(signID, account, timeCommission, frequency, exec_timing, timeStart, timeEnd, requestXml.InnerXml, msgKey, timeNext);
            return resutl;
        }

        string SendToT24_2010745_2020574(EaiContext context, string txID, string ucString, XmlDocument requestXml)
        {
            m_log.Info("SendToT24_2010745_2020574 txID=[{0}]", txID);
            string newTxID = string.Empty;
            if (txID == "2010745")//個人
            { ucString = Change_2010745_ToFtUcString(ucString, out newTxID); }
            if (txID == "2020574")//企業
            { ucString = Change_2020574_ToFtUcString(ucString, out newTxID); }

            m_log.Info("SendToT24_2010745_2020574 OldtxID=[{0}]->NewTxID=[{1}]", txID, newTxID);

            string newucString = string.Format("<T24_DATA>{0}</T24_DATA>", ucString);
            AppXmlExecResult srResult = SendMsgToEAIProcess(context, newucString, newTxID, true);

            XmlHelper xHelper = XmlHelper.GetInstance(srResult.ResponseXml);
            string rsString = xHelper.GetXPath(srResult.ResponseXml, "//T24_DATA");
            m_log.Info("SendToT24_2010745_2020574 rqString=[{0}] rsString=[{1}]", ucString, rsString);
            return rsString;
        }
        private string Change_2010745_ToFtUcString(string ucString, out string newTxID)
        {
            m_log.Info("ChangeToFtUcString");

            Dictionary<string, string> ucHeadDic, ucBodyDic;
            ParseUcToDic(ucString, out ucHeadDic, out ucBodyDic);

            string field4949;
            ucBodyDic.TryGetValue("4949", out field4949);

            Dictionary<string, string> newBodyDic = new Dictionary<string, string>();
            if (field4949 == "1")
            {
                newTxID = "ES_2010767";
                foreach (KeyValuePair<string, string> field in ucBodyDic)
                {
                    switch (field.Key)
                    {
                        case "2001":
                            newBodyDic.Add(field.Key, "2010767");
                            break;
                        case "4311":
                            newBodyDic.Add("4897", field.Value);//2010745[付款用途]->ES_2010767[付款用途]
                            break;
                        case "4732":
                            newBodyDic.Add("4734", field.Value);//2010745[交易附言]->ES_2010767[交易附言]
                            break;
                        case "4949":
                        case "4306"://2010745[附款帳戶類型]->ES_2010767不帶
                        case "4652"://2010745[轉帳頻率]->ES_2010767不帶
                        case "4364"://2010745[轉帳執行日]->ES_2010767不帶
                        case "4119"://2010745[協議生效日期]->ES_2010767不帶
                        case "4120"://2010745[協議失效日期]->ES_2010767不帶
                        case "4004"://2010745[電子郵箱]->ES_2010767不帶
                            break;
                        default:
                            newBodyDic.Add(field.Key, field.Value);
                            break;
                    }
                }
            }
            else
            {
                newTxID = "ES_2010766";
                foreach (KeyValuePair<string, string> field in ucBodyDic)
                {
                    switch (field.Key)
                    {
                        case "2001":
                            newBodyDic.Add(field.Key, "2010766");
                            break;
                        case "4733":
                            newBodyDic.Add("4900", field.Value);//2010745[收款人名稱]->ES_2010766[收款人名稱]
                            break;
                        case "4311":
                            newBodyDic.Add("4732", field.Value);//2010745[付款用途]->ES_2010766[付款用途]
                            break;
                        case "4732":
                            newBodyDic.Add("4658", field.Value);//2010745[交易附言]->ES_2010766[交易附言]
                            break;
                        case "4026":
                            if (!newBodyDic.ContainsKey("4835"))
                            { newBodyDic.Add("4835", string.Empty); }
                            newBodyDic["4835"] = string.Format("Priority={0};", field.Value) + newBodyDic["4835"];//2010745[轉帳方式]->ES_2010766[備用字段]
                            break;
                        case "4835":
                            if (!newBodyDic.ContainsKey("4835"))
                            { newBodyDic.Add("4835", string.Empty); }
                            newBodyDic["4835"] = newBodyDic["4835"] + field.Value;//2010745[備用字段]->ES_2010766[備用字段]
                            break;
                        case "4949":
                        case "4900"://2010745[付款人名稱]->ES_2010766不帶
                        case "4112"://2010745[收款人行號]->ES_2010766不帶
                        case "2021"://2010745[收款人聯行號]->ES_2010766不帶
                        case "4658"://2010745[收款人行名]->ES_2010766不帶，並且把2010745-4658域空出來給[交易附言]
                        case "4652"://2010745[轉帳頻率]->ES_2010766不帶
                        case "4364"://2010745[轉帳執行日]->ES_2010766不帶
                        case "4119"://2010745[協議生效日期]->ES_2010766不帶
                        case "4120"://2010745[協議失效日期]->ES_2010766不帶
                        case "4004"://2010745[電子郵箱]->ES_2010766不帶
                            break;
                        default:
                            newBodyDic.Add(field.Key, field.Value);
                            break;
                    }
                }
            }
            UcControler ucControler = new UcControler();
            string newUcString = ucControler.MakeNewUcString(ucHeadDic, newBodyDic);

            m_log.Info("ChangeToFtUcString OldUcString=[{0}] NewUcString=[{1}]", ucString, newUcString);
            return newUcString;
        }
        private string Change_2020574_ToFtUcString(string ucString, out string newTxID)
        {
            m_log.Info("ChangeToFtUcString");

            Dictionary<string, string> ucHeadDic, ucBodyDic;
            ParseUcToDic(ucString, out ucHeadDic, out ucBodyDic);

            string field4949;
            ucBodyDic.TryGetValue("4949", out field4949);//0.本行 1.他行

            Dictionary<string, string> newBodyDic = new Dictionary<string, string>();
            if (field4949 == "1")
            {
                newTxID = "ES_2020580";
                foreach (KeyValuePair<string, string> field in ucBodyDic)
                {
                    switch (field.Key)
                    {
                        case "2001":
                            newBodyDic.Add(field.Key, "2020580");
                            break;
                        case "4733":
                            newBodyDic.Add("4658", field.Value);//2020574[交易附言]->ES_2020580[交易附言]
                            break;
                        case "4396":
                            newBodyDic.Add("4006", field.Value);//2020574[收款人手機號碼]->ES_2020580[收款人手機號碼]
                            break;
                        case "4949":
                        case "4306"://2020574[付款帳戶類型]->ES_2020580不帶
                        case "4658"://2020574[收款人行名]->ES_2020580不帶，並且把ES_2020580-4658域空出來給[交易附言]
                        case "4652"://2020574[轉帳頻率]->ES_2020580不帶
                        case "4364"://2020574[轉帳執行日]->ES_2020580不帶
                        case "4119"://2020574[協議生效日期]->ES_2020580不帶
                        case "4120"://2020574[協議結束日期]->ES_2020580不帶
                        case "4114"://2020574[EMAIL地址]->ES_2020580不帶
                        case "4005"://2020574[付款人手機號碼地址]->ES_2020580不帶
                            break;
                        default:
                            newBodyDic.Add(field.Key, field.Value);
                            break;
                    }
                }
            }
            else
            {
                newTxID = "2020579";
                foreach (KeyValuePair<string, string> field in ucBodyDic)
                {
                    switch (field.Key)
                    {
                        case "2001":
                            newBodyDic.Add(field.Key, "2020579");
                            break;
                        case "4157":
                            newBodyDic.Add("4323", field.Value);//2020574[付款人帳號]->2020579[付款帳號]
                            break;
                        case "4161":
                            newBodyDic.Add("4324", field.Value);//2020574[收款人帳號]->2020579[收款帳號]
                            break;
                        case "4732":
                            newBodyDic.Add("4897", field.Value);//2020574[收款人名稱]->2020579[收款帳戶名稱]
                            break;
                        case "4733":
                            newBodyDic.Add("4658", field.Value);//2020574[附言]->2020579[交易附言]
                            break;
                        case "4396":
                            newBodyDic.Add("4006", field.Value);//2020574[收款人手機號碼]->2020579[收款人手機號碼]
                            break;
                        case "4026":
                            if (!newBodyDic.ContainsKey("4835"))
                            { newBodyDic.Add("4835", string.Empty); }
                            newBodyDic["4835"] = string.Format("Priority={0};", field.Value) + newBodyDic["4835"];//2020574[轉帳方式]->2020579[通用備用字段]
                            break;
                        case "4835":
                            if (!newBodyDic.ContainsKey("4835"))
                            { newBodyDic.Add("4835", string.Empty); }
                            newBodyDic["4835"] = newBodyDic["4835"] + field.Value;//2020574[備用字段]->2020579[通用備用字段]
                            break;
                        case "4949":
                        case "4900"://2020574[收款人名稱]->2020579不帶
                        case "4186"://2020574[收款人開戶行]->2020579不帶
                        case "4658"://2020574[收款人行名]->2020579不帶
                        case "2021"://2020574[收款人聯行號]->2020579不帶
                        case "4652"://2020574[轉帳頻率]->2020579不帶
                        case "4364"://2020574[轉帳執行日]->2020579不帶
                        case "4119"://2020574[協議生效日期]->2020579不帶
                        case "4120"://2020574[協議結束日期]->2020579不帶
                        case "4114"://2020574[EMAIL地址]->2020579不帶
                        case "4005"://2020574[付款人手機號碼]->2020579不帶
                            break;
                        default:
                            newBodyDic.Add(field.Key, field.Value);
                            break;
                    }
                }
            }
            UcControler ucControler = new UcControler();
            string newUcString = ucControler.MakeNewUcString(ucHeadDic, newBodyDic);

            m_log.Info("ChangeToFtUcString OldUcString=[{0}] NewUcString=[{1}]", ucString, newUcString);
            return newUcString;
        }

        #endregion (定時轉帳)定時轉帳簽約請求 2010745 (定時轉帳)定時轉帳簽約請求 2020574


        //2010746 2020575查詢條件 UC報文帶入"付款帳戶 狀態 起始日與結束日（2017.04.24討論先暫定為簽約日期區間）"
        #region (定時轉帳)定時轉帳簽約信息查詢請求 2010746 (定時轉帳)定時轉帳簽約信息查詢請求 2020575
        AppXmlExecResult Do_2010746_2020575_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string queryString = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                bool isRqXml = (txID == "2010746BE" || txID == "2020575BE");
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, queryString);
                m_log.Info("Do_2010746_2020575_Process txID=[{0}]", txID);
                string payAcnt = string.Empty,
                       payName = string.Empty,
                       beginDate = string.Empty,
                       endDate, status = string.Empty;
                UcControler rq_ucControler = new UcControler();
                //Dictionary<string, string> rqQueryHeadDic = null;
                Dictionary<string, string> rqQueryBodyDic = null;
                if (!isRqXml)//非XML，UC格式，網銀
                {
                    rq_ucControler.UC2T24(queryString);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4157", out payAcnt);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4900", out payName);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4119", out beginDate);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4120", out endDate);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4580", out status);
                }
                else//XML格式，櫃面...等
                {
                    rqQueryBodyDic = XDocument.Parse(requestXml.InnerXml).Descendants()
                                                                         .Where(p => p.Name.LocalName == "T24_DATA")
                                                                         .Descendants()
                                                                         .ToDictionary(p => p.Name.LocalName, p => p.Value);
                    rqQueryBodyDic.TryGetValue("PayAcct", out payAcnt);
                    rqQueryBodyDic.TryGetValue("PayAcctNm", out payName);
                    rqQueryBodyDic.TryGetValue("StartDate", out beginDate);
                    rqQueryBodyDic.TryGetValue("EndDate", out endDate);
                    rqQueryBodyDic.TryGetValue("Status", out status);
                }

                DataSet rsvDataset = DBLog.SelectRsvByPayacntAndCmsdtInterval(payAcnt, beginDate, endDate, status); //目前付款人名稱未列入查詢條件
                List<Dictionary<string, string>> dataRowList = DatasetToDiclist(rsvDataset);
                dataRowList = dataRowList.OrderByDescending(p => p.ContainsKey("SignID") ? p["SignID"] : string.Empty).ToList();
                string rsString = string.Empty;
                if (!isRqXml)
                {
                    List<string> fileContentLst = new List<string>();
                    fileContentLst = GetFileContentList_2010746_2020575(context, dataRowList, txID);
                    Dictionary<string, string> totalDic = new Dictionary<string, string>();
                    rq_ucControler.CreateEnqFileToUC(fileContentLst, true); //FileContentList落檔 上傳FTP
                    totalDic.Add("4305", fileContentLst.Count.ToString());
                    totalDic.Add("zzzx", rq_ucControler.enqFileName);//文件名
                    rsString = rq_ucControler.GetToUCRS(totalDic);
                }
                else
                {
                    XmlDocument xdoc = GetXmlQueryRS(context, dataRowList, txID);
                    rsString = xdoc.InnerXml;
                }
                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2010746_2020575_Process Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        private XmlDocument GetXmlQueryRS(EaiContext context, List<Dictionary<string, string>> dataRowList, string txID)
        {
            #region 格式
            //<Rsp_Msg>
            //    <RspCode>SUCC</RspCode>
            //    <RspMsg>交易成功</RspMsg>
            //    <RspCnt>1</Rsp_Cnt>
            //    <Rsps row=”1”>
            //        <SignID>2018030299999999999920000038940920</SignID>
            //        <TxnType>0</TxnType>
            //        <PayCur>CNY</PayCur>
            //        <PayAcct>000251000013048</PayAcct>
            //        <PayAcctNm>王小明</PayAcctNm>
            //        <PayeeAcct>000251000012028</PayeeAcct>
            //        <PayeeAcctNm>王大華</PayeeAcctNm>
            //        <PayeeAcctBkNo>529584000006</PayeeAcctBkNo>
            //        <PayeeAcctBkNm>玉山银行(中国)</PayeeAcctBkNm>
            //        <SignAmt>13.00</SignAmt>
            //        <SignDate>20180302</SignDate>
            //        <SignFreq>02</SignFreq>
            //        <TxnMtd>1</TxnMtd>
            //        <TxnUsage>往來款</TxnUsage>
            //        <TxnRemark></TxnRemark>
            //        <SignTxnDate>3</SignTxnDate>
            //        <ActiveDate>20180305</ActiveDate>
            //        <DeActiveDate>20180405</DeActiveDate>
            //        <Status>2</Status>
            //        <CancelDate></CancelDate>
            //        <CancelAvail>1</CancelAvail>	  	
            //    <Rsps>
            //</Rsp_Msg>
            #endregion 格式
            int dataCnt = dataRowList.Count;
            XmlDocument xdoc = new XmlDocument();
            XmlElement xelT24Data_Rsp_Msg = xdoc.CreateElement("Rsp_Msg");
            XmlElement xelRsp_Msg_RspCode = xdoc.CreateElement("RspCode");
            xelRsp_Msg_RspCode.InnerText = "SUCC";
            XmlElement xelRsp_Msg_RspMsg = xdoc.CreateElement("RspMsg");
            xelRsp_Msg_RspMsg.InnerText = "交易成功";
            XmlElement xelRsp_Msg_RspCnt = xdoc.CreateElement("RspCnt");
            xelRsp_Msg_RspCnt.InnerText = dataCnt.ToString();

            xdoc.AppendChild(xelT24Data_Rsp_Msg);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_RspCode);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_RspMsg);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_RspCnt);

            if (dataRowList.Count > 0)
            {
                for (int i = 0; i <= dataCnt - 1; i++)
                {
                    XmlElement xelRsp_Msg_Rsps = xdoc.CreateElement("Rsps");
                    xelRsp_Msg_Rsps.SetAttribute("row", (i + 1).ToString());
                    Dictionary<string, string> dataRowDic = dataRowList[i];
                    string SignID, TxnType, PayCur, PayAcct, PayAcctNm, PayeeAcct,
                        PayeeAcctNm, PayeeAcctBkNo, PayeeAcctBkNm, SignAmt, SignDate,
                        SignFreq, TxnMtd, TxnUsage, TxnRemark, SignTxnDate, ActiveDate,
                        DeActiveDate, Status, CancelDate, CancelAvail, ucString;
                    Dictionary<string, string> ucBodyDic = new Dictionary<string, string>();
                    dataRowDic.TryGetValue("UC", out ucString);
                    ucBodyDic = GetUcbodyDicFromUcXml(ucString);

                    XmlElement xelSignID = xdoc.CreateElement("SignID");
                    XmlElement xelTxnType = xdoc.CreateElement("TxnType");
                    XmlElement xelPayCur = xdoc.CreateElement("PayCur");
                    XmlElement xelPayAcct = xdoc.CreateElement("PayAcct");
                    XmlElement xelPayAcctNm = xdoc.CreateElement("PayAcctNm");
                    XmlElement xelPayeeAcct = xdoc.CreateElement("PayeeAcct");
                    XmlElement xelPayeeAcctNm = xdoc.CreateElement("PayeeAcctNm");
                    XmlElement xelPayeeAcctBkNo = xdoc.CreateElement("PayeeAcctBkNo");
                    XmlElement xelPayeeAcctBkNm = xdoc.CreateElement("PayeeAcctBkNm");
                    XmlElement xelSignAmt = xdoc.CreateElement("SignAmt");
                    XmlElement xelSignDate = xdoc.CreateElement("SignDate");
                    XmlElement xelSignFreq = xdoc.CreateElement("SignFreq");
                    XmlElement xelTxnMtd = xdoc.CreateElement("TxnMtd");
                    XmlElement xelTxnUsage = xdoc.CreateElement("TxnUsage");
                    XmlElement xelTxnRemark = xdoc.CreateElement("TxnRemark");
                    XmlElement xelSignTxnDate = xdoc.CreateElement("SignTxnDate");
                    XmlElement xelActiveDate = xdoc.CreateElement("ActiveDate");
                    XmlElement xelDeActiveDate = xdoc.CreateElement("DeActiveDate");
                    XmlElement xelStatus = xdoc.CreateElement("Status");

                    dataRowDic.TryGetValue("SignID", out SignID); xelSignID.InnerText = SignID;
                    ucBodyDic.TryGetValue("4949", out TxnType); xelTxnType.InnerText = TxnType;
                    ucBodyDic.TryGetValue("4118", out PayCur); xelPayCur.InnerText = PayCur;
                    dataRowDic.TryGetValue("PayAcnt", out PayAcct); xelPayAcct.InnerText = PayAcct;
                    ucBodyDic.TryGetValue("4900", out PayAcctNm); xelPayAcctNm.InnerText = PayAcctNm;
                    ucBodyDic.TryGetValue("4161", out PayeeAcct); xelPayeeAcct.InnerText = PayeeAcct;
                    ucBodyDic.TryGetValue(txID == "2020575BE" ? "4732" : "4733", out PayeeAcctNm); xelPayeeAcctNm.InnerText = PayeeAcctNm;
                    ucBodyDic.TryGetValue(txID == "2020575BE" ? "4186" : "4112", out PayeeAcctBkNo); xelPayeeAcctBkNo.InnerText = PayeeAcctBkNo;

                    ucBodyDic.TryGetValue("4658", out PayeeAcctBkNm);
                    if (string.IsNullOrEmpty(PayeeAcctBkNm) && TxnType == "0")
                    { PayeeAcctBkNm = GetBkNmByAcc(context, PayeeAcct); }
                    xelPayeeAcctBkNm.InnerText = PayeeAcctBkNm;

                    ucBodyDic.TryGetValue("4100", out SignAmt); xelSignAmt.InnerText = SignAmt;
                    ucBodyDic.TryGetValue("2006", out SignDate); xelSignDate.InnerText = SignDate;
                    ucBodyDic.TryGetValue("4652", out SignFreq); xelSignFreq.InnerText = SignFreq;
                    ucBodyDic.TryGetValue("4026", out TxnMtd); xelTxnMtd.InnerText = TxnMtd;
                    ucBodyDic.TryGetValue(txID == "2020575BE" ? "4349" : "4311", out TxnUsage); xelTxnUsage.InnerText = TxnUsage;
                    ucBodyDic.TryGetValue(txID == "2020575BE" ? "4733" : "4732", out TxnRemark); xelTxnRemark.InnerText = TxnRemark;
                    ucBodyDic.TryGetValue("4364", out SignTxnDate); xelSignTxnDate.InnerText = SignTxnDate;
                    ucBodyDic.TryGetValue("4119", out ActiveDate); xelActiveDate.InnerText = ActiveDate;
                    ucBodyDic.TryGetValue("4120", out DeActiveDate); xelDeActiveDate.InnerText = DeActiveDate;
                    dataRowDic.TryGetValue("Status", out Status); xelStatus.InnerText = Status;

                    xelRsp_Msg_Rsps.AppendChild(xelSignID);
                    xelRsp_Msg_Rsps.AppendChild(xelTxnType);
                    xelRsp_Msg_Rsps.AppendChild(xelPayCur);
                    xelRsp_Msg_Rsps.AppendChild(xelPayAcct);
                    xelRsp_Msg_Rsps.AppendChild(xelPayAcctNm);
                    xelRsp_Msg_Rsps.AppendChild(xelPayeeAcct);
                    xelRsp_Msg_Rsps.AppendChild(xelPayeeAcctNm);
                    xelRsp_Msg_Rsps.AppendChild(xelPayeeAcctBkNo);
                    xelRsp_Msg_Rsps.AppendChild(xelPayeeAcctBkNm);
                    xelRsp_Msg_Rsps.AppendChild(xelSignAmt);
                    xelRsp_Msg_Rsps.AppendChild(xelSignDate);
                    xelRsp_Msg_Rsps.AppendChild(xelSignFreq);
                    xelRsp_Msg_Rsps.AppendChild(xelTxnMtd);
                    xelRsp_Msg_Rsps.AppendChild(xelTxnUsage);
                    xelRsp_Msg_Rsps.AppendChild(xelTxnRemark);
                    xelRsp_Msg_Rsps.AppendChild(xelSignTxnDate);
                    xelRsp_Msg_Rsps.AppendChild(xelActiveDate);
                    xelRsp_Msg_Rsps.AppendChild(xelDeActiveDate);
                    xelRsp_Msg_Rsps.AppendChild(xelStatus);

                    if (Status == "4")
                    {
                        XmlElement xelCancelDate = xdoc.CreateElement("CancelDate"); xelRsp_Msg_Rsps.AppendChild(xelCancelDate);
                        dataRowDic.TryGetValue("StatusChgDate", out CancelDate);
                        CancelDate = Convert.ToDateTime(CancelDate).ToString("yyyyMMdd");
                        xelCancelDate.InnerText = CancelDate;
                    }
                    XmlElement xelCancelAvail = xdoc.CreateElement("CancelAvail"); xelRsp_Msg_Rsps.AppendChild(xelCancelAvail);
                    if (Status == "1" || Status == "2")
                    { CancelAvail = "1"; }
                    else
                    { CancelAvail = "0"; }
                    xelCancelAvail.InnerText = CancelAvail;

                    xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_Rsps);
                }
            }
            return xdoc;
        }
        public List<string> GetFileContentList_2010746_2020575(EaiContext context, List<Dictionary<string, string>> dataRowList, string txID)
        {
            List<string> fileContentLst = new List<string>();
            StringBuilder fileContentSB;
            foreach (Dictionary<string, string> D in dataRowList)
            {
                fileContentSB = new StringBuilder();
                string tempString = string.Empty;
                string msgkey = string.Empty;
                Dictionary<string, string> ucBodyDic = new Dictionary<string, string>();

                D.TryGetValue("Msgkey", out msgkey);

                D.TryGetValue("UC", out tempString);
                ucBodyDic = GetUcbodyDicFromUcXml(tempString);

                string payeeAcct = string.Empty;
                ucBodyDic.TryGetValue("4161", out payeeAcct);

                D.TryGetValue("SignID", out tempString);
                fileContentSB.Append(tempString).Append("|");//簽約編號

                string txnType = string.Empty;
                ucBodyDic.TryGetValue("4949", out txnType);
                fileContentSB.Append(txnType).Append("|");//交易類型 0-本行 1-他行

                ucBodyDic.TryGetValue("4306", out tempString);
                fileContentSB.Append(tempString).Append("|");//付款帳戶類型

                ucBodyDic.TryGetValue("4118", out tempString);
                fileContentSB.Append(tempString).Append("|");//幣種

                D.TryGetValue("PayAcnt", out tempString);
                fileContentSB.Append(tempString).Append("|");//付款帳戶

                ucBodyDic.TryGetValue("4900", out tempString);
                fileContentSB.Append(tempString).Append("|");//付款人名稱

                if (txID.Contains("2010746"))//個人
                { ucBodyDic.TryGetValue("4112", out tempString); }
                else//企業
                { ucBodyDic.TryGetValue("4186", out tempString); }
                fileContentSB.Append(tempString).Append("|");//收款人行號

                string payeeBkNm = string.Empty;
                ucBodyDic.TryGetValue("4658", out payeeBkNm);
                if (string.IsNullOrEmpty(payeeBkNm) && txnType == "0")//若為本行
                { payeeBkNm = GetBkNmByAcc(context, payeeAcct); }
                fileContentSB.Append(payeeBkNm).Append("|");//收款人行名

                if (txID.Contains("2020575"))//企業
                {
                    ucBodyDic.TryGetValue("2021", out tempString);
                    fileContentSB.Append(tempString).Append("|");//收款人聯行號
                }

                fileContentSB.Append(payeeAcct).Append("|");//收款人帳號

                if (txID.Contains("2010746"))//個人
                { ucBodyDic.TryGetValue("4733", out tempString); }
                else//企業
                { ucBodyDic.TryGetValue("4732", out tempString); }
                fileContentSB.Append(tempString).Append("|");//收款人名稱

                ucBodyDic.TryGetValue("4100", out tempString);
                fileContentSB.Append(tempString).Append("|");//簽約金額

                ucBodyDic.TryGetValue("2006", out tempString);
                fileContentSB.Append(tempString).Append("|");//簽約日期

                ucBodyDic.TryGetValue("4652", out tempString);
                fileContentSB.Append(tempString).Append("|");//轉帳頻率

                ucBodyDic.TryGetValue("4364", out tempString);
                fileContentSB.Append(tempString).Append("|");//定時執行日

                ucBodyDic.TryGetValue("4119", out tempString);
                fileContentSB.Append(tempString).Append("|");//協議生效日

                ucBodyDic.TryGetValue("4120", out tempString);
                fileContentSB.Append(tempString).Append("|");//協議失效日

                D.TryGetValue("Status", out tempString);
                fileContentSB.Append(tempString).Append("|");//狀態

                if (tempString == "4")//4為已撤銷
                {
                    D.TryGetValue("StatusChgDate", out tempString);
                    tempString = Convert.ToDateTime(tempString).ToString("yyyyMMdd");
                    fileContentSB.Append(tempString).Append("|");
                }
                else
                { fileContentSB.Append("").Append("|"); }//撤銷日期

                fileContentSB.Append("").Append("|");//撤銷時間???

                D.TryGetValue("Status", out tempString);
                if (tempString == "1" || tempString == "2")
                { fileContentSB.Append("1").Append("|"); }
                else
                { fileContentSB.Append("0").Append("|"); }//是否可撤銷

                fileContentSB.Append("").Append("|");//備註

                fileContentLst.Add(fileContentSB.ToString());
            }
            return fileContentLst;
        }
        #endregion (定時轉帳)定時轉帳簽約信息查詢請求 2010746 (定時轉帳)定時轉帳簽約信息查詢請求 2020575

        //2010747 2020576查詢條件 UC報文帶入"簽約編號 狀態 起始日與結束日（2017.04.24討論先暫定為要查詢的交易明細區間）"
        #region (定時轉帳)定時轉帳明細查詢請求 2010747 (定時轉帳)定時轉帳明細查詢請求 2020576
        AppXmlExecResult Do_2010747_2020576_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string queryString = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                bool isRqXml = (txID == "2010747BE" || txID == "2020576BE");
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, queryString);
                m_log.Info("Do_2010747_2020576_Process txID=[{0}]", txID);
                string rq_signId = string.Empty,
                       rq_custName = string.Empty,
                       rq_payAcnt = string.Empty,
                       rq_payName = string.Empty,
                       rq_beginDate = string.Empty,
                       rq_endDate = string.Empty,
                       rq_status = string.Empty;
                //List<string> accList = new List<string>();
                UcControler rq_ucControler = new UcControler();
                Dictionary<string, string> rqQueryBodyDic = null;
                if (!isRqXml)
                {
                    rq_ucControler.UC2T24(queryString);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4111", out rq_signId);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4001", out rq_custName);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4157", out rq_payAcnt);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4900", out rq_payName);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4119", out rq_beginDate);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4120", out rq_endDate);
                    rq_ucControler.m_ucBodyDiy.TryGetValue("4580", out rq_status);
                }
                else
                {
                    rqQueryBodyDic = XDocument.Parse(requestXml.InnerXml).Descendants()
                                                         .Where(p => p.Name.LocalName == "T24_DATA")
                                                         .Descendants()
                                                         .ToDictionary(p => p.Name.LocalName, p => p.Value);
                    rqQueryBodyDic.TryGetValue("SignID", out rq_signId);
                    rqQueryBodyDic.TryGetValue("PayAcct", out rq_payAcnt);
                    rqQueryBodyDic.TryGetValue("StartDate", out rq_beginDate);
                    rqQueryBodyDic.TryGetValue("EndDate", out rq_endDate);
                }


                DataSet rsvDataset = new DataSet(),
                        msmqDataset = new DataSet();

                #region 取出RSVDetail中符合條件的資料 最多只會有一筆

                rsvDataset = DBLog.SelectRsvBySignidAndPayacnt(rq_signId, rq_payAcnt);
                List<Dictionary<string, string>> rsvDataRowList = DatasetToDiclist(rsvDataset);
                string tb_RSVID = string.Empty,
                    //tb_SignID = string.Empty,
                    //tb_CommissionDate = string.Empty,
                       tb_UC = string.Empty,
                       tb_BeginDate = string.Empty,
                       tb_EndDate = string.Empty,
                       tb_Frequency = string.Empty,
                       tb_ExexTiming = string.Empty;
                if (rsvDataRowList.Count > 0)
                {
                    rsvDataRowList[0].TryGetValue("RSVID", out tb_RSVID);
                    //rsvDataRowList[0].TryGetValue("SignID", out tb_SignID);
                    //rsvDataRowList[0].TryGetValue("CommissionDate", out tb_CommissionDate);
                    rsvDataRowList[0].TryGetValue("UC", out tb_UC);

                    rsvDataRowList[0].TryGetValue("BeginDate", out tb_BeginDate);
                    rsvDataRowList[0].TryGetValue("EndDate", out tb_EndDate);
                    rsvDataRowList[0].TryGetValue("Frequency", out tb_Frequency);
                    rsvDataRowList[0].TryGetValue("ExexTiming", out tb_ExexTiming);
                }
                Dictionary<string, string> rsvUcBodyDic = GetUcbodyDicFromUcXml(tb_UC);
                #endregion 取出RSVDetail中符合條件的資料 最多只會有一筆

                #region 利用上述搜尋出來的資料[RSVID]欄位，至MSMQTalk table比對[ImportID]欄位，撈出符合的資料
                if (!string.IsNullOrEmpty(tb_RSVID))
                    msmqDataset = DBLog.SelectMqtkByImpidAndCredtInterval(tb_RSVID, rq_beginDate, rq_endDate);
                List<Dictionary<string, string>> msmqDataRowList = DatasetToDiclist(msmqDataset);
                msmqDataRowList = msmqDataRowList.OrderBy(p => p.ContainsKey("CreateDate") ? p["CreateDate"] : string.Empty).ToList();
                #endregion 利用上述搜尋出來的資料[RSVID]欄位，至MSMQTalk table比對[ImportID]欄位，撈出符合的資料

                //List<DateTime> ExecutedDateList = GetExecuteDateList(Convert.ToDateTime(tb_BeginDate), Convert.ToDateTime(tb_EndDate), tb_Frequency, tb_ExexTiming, false);

                List<string> fileContentLst = GetFileContentList_2010747_2020576(msmqDataRowList, rsvDataRowList, rq_beginDate, rq_endDate);

                Dictionary<string, string> totalDic = new Dictionary<string, string>();
                #region 組擴展數據
                string tempString = string.Empty;

                if (!isRqXml)
                    rq_ucControler.CreateEnqFileToUC(fileContentLst, true);

                totalDic.Add("4305", fileContentLst.Count.ToString());//總筆數

                totalDic.Add("zzzx", rq_ucControler.enqFileName);//文件名

                string payeeAcct = string.Empty;
                rsvUcBodyDic.TryGetValue("4161", out payeeAcct);

                string txnType = string.Empty;
                rsvUcBodyDic.TryGetValue("4949", out txnType);
                totalDic.Add("4949", txnType);//交易類型 0-本行 1-他行

                rsvUcBodyDic.TryGetValue("4118", out tempString);
                totalDic.Add("4118", tempString);//幣種

                totalDic.Add("4157", rq_payAcnt);//付款帳戶

                rsvUcBodyDic.TryGetValue("4900", out tempString);
                totalDic.Add("4900", tempString);//付款人名稱

                string payeeBkNm = string.Empty;
                rsvUcBodyDic.TryGetValue("4658", out payeeBkNm);
                if (string.IsNullOrEmpty(payeeBkNm) && txnType == "0")//若為行內
                { payeeBkNm = GetBkNmByAcc(context, payeeAcct); }
                totalDic.Add("4658", payeeBkNm);//收款人行名

                totalDic.Add("4161", payeeAcct);//收款人帳號

                tempString = string.Empty;
                if (txID.Contains("2010747"))
                    rsvUcBodyDic.TryGetValue("4733", out tempString);
                else if (txID.Contains("2020576"))
                    rsvUcBodyDic.TryGetValue("4732", out tempString);
                totalDic.Add("4732", tempString);//收款人名稱

                totalDic.Add("4958", fileContentLst.Count.ToString());//執行總次數

                string amt = string.Empty;
                rsvUcBodyDic.TryGetValue("4100", out amt);//轉帳金額
                totalDic.Add("4316", (Convert.ToDecimal(amt) * fileContentLst.Count).ToString());//轉帳總金額

                int succTime = fileContentLst.Where(p => p.Split('|')[4] == "0").Count();
                totalDic.Add("4047", succTime.ToString());//成功執行次數

                totalDic.Add("4100", (Convert.ToDecimal(amt) * succTime).ToString());//成功轉帳金額

                int failTime = fileContentLst.Where(p => p.Split('|')[4] == "1").Count();
                totalDic.Add("4961", failTime.ToString());//失敗執行次數

                totalDic.Add("4165", (Convert.ToDecimal(amt) * failTime).ToString());//失敗轉帳金額
                #endregion 組擴展數據

                string rsString = string.Empty;
                if (!isRqXml)
                { rsString = rq_ucControler.GetToUCRS(totalDic); }
                else
                {
                    XmlDocument xdoc = GetXmlDetailQueryRS(fileContentLst, totalDic, txID);
                    rsString = xdoc.InnerXml;
                }
                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2010747_2020576_Process Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        public List<string> GetFileContentList_2010747_2020576(List<Dictionary<string, string>> msmqDataRowList, List<Dictionary<string, string>> rsvDataRowList, string beginDate, string endDate)
        {
            List<string> fileContentLst = new List<string>();
            if (rsvDataRowList.Count > 0)
            {
                Dictionary<string, string> rsvDataDic = rsvDataRowList[0];//RSV TABLE的資料撈出來後轉成Dictionary
                string sDetailStartDate, sDetailStopDate, frequency, exectime, uc, amount;
                rsvDataDic.TryGetValue("BeginDate", out sDetailStartDate); DateTime timeDetailStartDate = Convert.ToDateTime(sDetailStartDate);//生效日
                rsvDataDic.TryGetValue("EndDate", out sDetailStopDate); DateTime timeDetailStopDate = Convert.ToDateTime(sDetailStopDate);//生效日
                rsvDataDic.TryGetValue("Frequency", out frequency);//頻率
                rsvDataDic.TryGetValue("ExecTiming", out exectime);//執行日 1~7每周 1~28每月
                rsvDataDic.TryGetValue("UC", out uc);//UC報文
                //↓從"生效日"至"今日"要執行轉帳的日期列表
                List<DateTime> executedDateList = GetExecuteDateList(timeDetailStartDate, (timeDetailStopDate.Date.AddDays(-1) > DateTime.Now.Date ? DateTime.Now : timeDetailStopDate.Date.AddDays(-1)), frequency, exectime, true);
                //↓查詢條件的區間的日期列表
                List<DateTime> queryDateList = GetExecuteDateList(DateTime.ParseExact(beginDate, "yyyyMMdd", null), DateTime.ParseExact(endDate, "yyyyMMdd", null), frequency, exectime, true);
                Dictionary<string, string> rsvUcBodyDic = GetUcbodyDicFromUcXml(uc);//RSV TABLE的UC報文UCBODY轉成Dictionary
                rsvUcBodyDic.TryGetValue("4100", out amount);//簽約金額

                StringBuilder fileContentSB = null;
                List<DateTime> finalDateList = executedDateList.Intersect(queryDateList).ToList();
                foreach (DateTime dt in finalDateList)
                {
                    bool hasTxn = false;
                    foreach (Dictionary<string, string> msmqDic in msmqDataRowList)
                    {
                        string smsmqCreateDate, smsmqStatus, smsmqAdditionalInfo;
                        msmqDic.TryGetValue("CreateDate", out smsmqCreateDate);
                        msmqDic.TryGetValue("Status", out smsmqStatus);
                        msmqDic.TryGetValue("AdditionalInfo", out smsmqAdditionalInfo);
                        DateTime msmqCreateDate = Convert.ToDateTime(smsmqCreateDate);
                        XmlDocument xdoc = new XmlDocument();
                        if (DateTime.Compare(dt.Date, msmqCreateDate.Date) == 0)
                        {
                            //若日期列表finalDateList的日期存在於撈出的msmqDataRowList的CreateDate中，表示該天msmqtalk有發交易，可用status判斷交易狀態為成功或失敗，並編寫fileContentSB
                            fileContentSB = new StringBuilder();
                            string payBal = string.Empty;
                            string fee = string.Empty;
                            string succFail = string.Empty;
                            string ErrMsg = string.Empty;
                            if (!string.IsNullOrEmpty(smsmqAdditionalInfo))
                            {
                                xdoc.LoadXml(smsmqAdditionalInfo);
                                payBal = xdoc.SelectSingleNode("//PayBal").InnerText;
                                fee = xdoc.SelectSingleNode("//Fee").InnerText;
                                succFail = xdoc.SelectSingleNode("//SuccFail").InnerText;
                                ErrMsg = xdoc.SelectSingleNode("//ErrMsg").InnerText;
                            }
                            fileContentSB.Append(msmqCreateDate.ToString("yyyyMMddHHmmss")).Append("|");//定時執行時間
                            fileContentSB.Append(amount).Append("|");//轉帳金額
                            fileContentSB.Append(fee).Append("|");//匯款手續費
                            fileContentSB.Append(payBal).Append("|");//帳戶餘額
                            if (succFail.ToUpper() == "SUCC")
                            { fileContentSB.Append("0").Append("|"); }//交易狀態 成功
                            else
                            {
                                switch (smsmqStatus)
                                {
                                    case "1"://Processing
                                    case "2"://Sending
                                    case "3"://Resend
                                        fileContentSB.Append("4").Append("|");//交易狀態 銀行處理中
                                        break;
                                    case "8"://Pending
                                    case "9"://Fail
                                        fileContentSB.Append("1").Append("|");//交易狀態 失敗
                                        break;
                                    default:
                                        fileContentSB.Append("1").Append("|");//交易狀態 失敗
                                        break;
                                }
                            }
                            fileContentSB.Append(ErrMsg).Append("|");//備註 目前放錯誤訊息
                            //break;//有設break表示每天只能有一筆，所以撈到一筆後就break離開
                            fileContentLst.Add(fileContentSB.ToString());
                            hasTxn = true;
                        }
                    }
                    //若發交易，交易狀態為未執行，編寫fileContentSB
                    if (!hasTxn)
                    {
                        fileContentSB = new StringBuilder();
                        fileContentSB.Append(dt.ToString("yyyyMMdd")).Append("|");//定時執行時間
                        fileContentSB.Append(amount).Append("|");//轉帳金額
                        fileContentSB.Append("").Append("|");//匯款手續費
                        fileContentSB.Append("").Append("|");//帳戶餘額
                        fileContentSB.Append("2").Append("|");//交易狀態 未執行
                        fileContentSB.Append("").Append("|");//備註

                        fileContentLst.Add(fileContentSB.ToString());
                    }
                }
            }
            return fileContentLst;
        }
        private XmlDocument GetXmlDetailQueryRS(List<string> fileContentLst, Dictionary<string, string> totalDic, string txID)
        {
            #region 格式
            //<Rsp_Msg>
            //    <RspCode>SUCC</RspCode>
            //    <RspMsg>交易成功</RspMsg>
            //    <RspCnt>3</Rsp_Cnt>
            //    <TtlTxnAmt>3000.00<TtlTxnAmt>
            //    <TtlTxnCnt>3</TtlTxnCnt>
            //    <TtlSuccAmt>2000.00</TtlSuccAmt>
            //    <TtlSuccCnt>2</TtlSuccCnt>
            //    <TtlFailAmt>1000.00</TtlFailAmt>
            //    <TtlFailCnt>1</TtlFailCnt>
            //    <Rsps row=”1”>
            //        <TxnExcDate>20180101</TxnExcDate>
            //        <TxnAmt>1000.00</TxnAmt>
            //        <TxnChg>0.00</TxnChg>
            //        <PayAcctBal>5000.00</PayAcctBal>
            //        <TxnResult>0</TxnResult>
            //        <TxnRmk></TxnRmk>  	
            //    <Rsps>
            //    <Rsps row=”2”>
            //        <TxnExcDate>20180201</TxnExcDate>
            //        <TxnAmt>1000.00</TxnAmt>
            //        <TxnChg>0.00</TxnChg>
            //        <PayAcctBal>5000.00</PayAcctBal>
            //        <TxnResult>1</TxnResult>
            //        <TxnRmk>errmag</TxnRmk>  	
            //    <Rsps>
            //    <Rsps row=”3”>
            //        <TxnExcDate>20180301</TxnExcDate>
            //        <TxnAmt>1000.00</TxnAmt>
            //        <TxnChg>0.00</TxnChg>
            //        <PayAcctBal>4000.00</PayAcctBal>
            //        <TxnResult>0</TxnResult>
            //        <TxnRmk></TxnRmk>  	
            //    <Rsps>
            //</Rsp_Msg>
            #endregion 格式
            int dataCnt = fileContentLst.Count;
            XmlDocument xdoc = new XmlDocument();
            XmlElement xelT24Data_Rsp_Msg = xdoc.CreateElement("Rsp_Msg");
            XmlElement xelRsp_Msg_RspCode = xdoc.CreateElement("RspCode");
            xelRsp_Msg_RspCode.InnerText = "SUCC";
            XmlElement xelRsp_Msg_RspMsg = xdoc.CreateElement("RspMsg");
            xelRsp_Msg_RspMsg.InnerText = "交易成功";
            XmlElement xelRsp_Msg_RspCnt = xdoc.CreateElement("RspCnt");
            xelRsp_Msg_RspCnt.InnerText = dataCnt.ToString();

            xdoc.AppendChild(xelT24Data_Rsp_Msg);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_RspCode);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_RspMsg);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_RspCnt); //筆數

            XmlElement xelRsp_Msg_TtlTxnAmt = xdoc.CreateElement("TtlTxnAmt"); //總交易金額	
            XmlElement xelRsp_Msg_TtlTxnCnt = xdoc.CreateElement("TtlTxnCnt"); //總執行次數
            XmlElement xelRsp_Msg_TtlSuccAmt = xdoc.CreateElement("TtlSuccAmt"); //成功交易金額
            XmlElement xelRsp_Msg_TtlSuccCnt = xdoc.CreateElement("TtlSuccCnt"); //成功執行次數
            XmlElement xelRsp_Msg_TtlFailAmt = xdoc.CreateElement("TtlFailAmt"); //失敗交易金額
            XmlElement xelRsp_Msg_TtlFailCnt = xdoc.CreateElement("TtlFailCnt"); //失敗執行次數
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_TtlTxnAmt);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_TtlTxnCnt);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_TtlSuccAmt);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_TtlSuccCnt);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_TtlFailAmt);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_TtlFailCnt);
            if (dataCnt > 0)
            {
                string field4316, field4958, field4100, field4047, field4165, field4961;
                totalDic.TryGetValue("4316", out field4316); xelRsp_Msg_TtlTxnAmt.InnerText = field4316;
                totalDic.TryGetValue("4958", out field4958); xelRsp_Msg_TtlTxnCnt.InnerText = field4958;
                totalDic.TryGetValue("4100", out field4100); xelRsp_Msg_TtlSuccAmt.InnerText = field4100;
                totalDic.TryGetValue("4047", out field4047); xelRsp_Msg_TtlSuccCnt.InnerText = field4047;
                totalDic.TryGetValue("4165", out field4165); xelRsp_Msg_TtlFailAmt.InnerText = field4165;
                totalDic.TryGetValue("4961", out field4961); xelRsp_Msg_TtlFailCnt.InnerText = field4961;
                for (int i = 0; i <= dataCnt - 1; i++)
                {
                    string[] sDetailArr = fileContentLst[i].Split('|');
                    XmlElement xelRsps = xdoc.CreateElement("Rsps");
                    xelRsps.SetAttribute("row", (i + 1).ToString());
                    XmlElement xelRsps_TxnExcDate = xdoc.CreateElement("TxnExcDate"); //定期執行時間
                    xelRsps_TxnExcDate.InnerText = sDetailArr[0];
                    XmlElement xelRsps_TxnAmt = xdoc.CreateElement("TxnAmt"); //交易金額	
                    xelRsps_TxnAmt.InnerText = sDetailArr[1];
                    XmlElement xelRsps_TxnChg = xdoc.CreateElement("TxnChg"); //手續費
                    xelRsps_TxnChg.InnerText = sDetailArr[2];
                    XmlElement xelRsps_PayAcctBal = xdoc.CreateElement("PayAcctBal"); //餘額	
                    xelRsps_PayAcctBal.InnerText = sDetailArr[3];
                    XmlElement xelRsps_TxnResult = xdoc.CreateElement("TxnResult"); //交易狀態
                    xelRsps_TxnResult.InnerText = sDetailArr[4];
                    XmlElement xelRsps_TxnRmk = xdoc.CreateElement("TxnRmk"); //備註	
                    xelRsps_TxnRmk.InnerText = sDetailArr[5];

                    xelRsps.AppendChild(xelRsps_TxnExcDate);
                    xelRsps.AppendChild(xelRsps_TxnAmt);
                    xelRsps.AppendChild(xelRsps_TxnChg);
                    xelRsps.AppendChild(xelRsps_PayAcctBal);
                    xelRsps.AppendChild(xelRsps_TxnResult);
                    xelRsps.AppendChild(xelRsps_TxnRmk);
                    xelT24Data_Rsp_Msg.AppendChild(xelRsps);
                }
            }
            else
            {
                xelRsp_Msg_TtlTxnAmt.InnerText = "0.00";
                xelRsp_Msg_TtlTxnCnt.InnerText = "0";
                xelRsp_Msg_TtlSuccAmt.InnerText = "0.00";
                xelRsp_Msg_TtlSuccCnt.InnerText = "0";
                xelRsp_Msg_TtlFailAmt.InnerText = "0.00";
                xelRsp_Msg_TtlFailCnt.InnerText = "0";
            }
            return xdoc;
        }
        #endregion (定時轉帳)定時轉帳明細查詢請求 2010747 (定時轉帳)定時轉帳明細查詢請求 2020576

        #region (定時轉帳)定時轉帳撤銷請求 2010748 (定時轉帳)定時轉帳規則撤銷請求 2020577
        /// <summary>
        /// 撤銷預約
        /// </summary>
        /// <param name="context"></param>
        /// <param name="correlationID"></param>
        /// <param name="txID"></param>
        /// <param name="txDef"></param>
        /// <param name="requestXml"></param>
        /// <param name="ucString"></param>
        /// <returns></returns>
        AppXmlExecResult Do_2010748_2020577_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string querycString = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                bool isRqXml = (txID == "2010748BE" || txID == "2020577BE");
                m_log.Info("RunImpl txID = [{0}] UC_Request = [{1}]", txID, querycString);
                m_log.Info("Do_2010748_2020577_Process txID=[{0}]", txID);
                string signId = string.Empty;
                string account = string.Empty;
                UcControler ucControler = new UcControler();
                Dictionary<string, string> rqQueryBodyDic = null;
                if (!isRqXml)
                {
                    ucControler.UC2T24(querycString);
                    ucControler.m_ucBodyDiy.TryGetValue("4111", out signId);
                    ucControler.m_ucBodyDiy.TryGetValue("4157", out account);
                }
                else
                {
                    rqQueryBodyDic = XDocument.Parse(requestXml.InnerXml).Descendants()
                                                                         .Where(p => p.Name.LocalName == "T24_DATA")
                                                                         .Descendants()
                                                                         .ToDictionary(p => p.Name.LocalName, p => p.Value);
                    rqQueryBodyDic.TryGetValue("SignID", out signId);
                    rqQueryBodyDic.TryGetValue("PayAcct", out account);
                }


                int result = DBLog.CancelRsv(4, signId, account);
                Dictionary<string, string> totalDic = new Dictionary<string, string>();

                string rsString = string.Empty;
                if (!isRqXml)
                {
                    if (result == 0) //若UPDATE不成功 表示特定錯誤：無法撤銷，回錯誤序號O102，寫死
                    { rsString = ucControler.GetFailUcRS(totalDic, "CO1MO102", "无法撤销"); }
                    else
                    { rsString = ucControler.GetToUCRS(totalDic); }
                }
                else
                {
                    XmlDocument xdoc = GetXmlCancelRS(result, signId);
                    rsString = xdoc.InnerXml;
                }

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);

            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2010748_2020577_Process Error ! TXID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }
        private XmlDocument GetXmlCancelRS(int result, string signID)
        {
            #region 格式
            //<Rsp_Msg>
            //    <RspCode>SUCC</RspCode>
            //    <RspMsg>交易成功</RspMsg>
            //    <SignID>2018030299999999999920000038940920</SignID>
            //</Rsp_Msg>
            #endregion 格式
            XmlDocument xdoc = new XmlDocument();
            XmlElement xelT24Data_Rsp_Msg = xdoc.CreateElement("Rsp_Msg");
            XmlElement xelRsp_Msg_RspCode = xdoc.CreateElement("RspCode");
            xelRsp_Msg_RspCode.InnerText = result != 0 ? "SUCC" : "FAIL";
            XmlElement xelRsp_Msg_RspMsg = xdoc.CreateElement("RspMsg");
            xelRsp_Msg_RspMsg.InnerText = result != 0 ? "交易成功" : "无法撤销";
            XmlElement xelRsp_Msg_SignID = xdoc.CreateElement("SignID");
            xelRsp_Msg_SignID.InnerText = signID;

            xdoc.AppendChild(xelT24Data_Rsp_Msg);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_RspCode);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_RspMsg);
            xelT24Data_Rsp_Msg.AppendChild(xelRsp_Msg_SignID);
            return xdoc;
        }

        #endregion (定時轉帳)定時轉帳撤銷請求 2010748 (定時轉帳)定時轉帳規則撤銷請求 2020577

        string GetBkNmByAcc(EaiContext context, string acct)
        {
            try
            {
                string bankName = string.Empty;
                string newT24RqString = GetT24_AcntInfoEnq_Content(acct);
                AppXmlExecResult rsResult = SendMsgToEAIProcess(context, newT24RqString, "ESCN.BP.ACCT.ENQ", true);
                XmlHelper xHelper = XmlHelper.GetInstance(rsResult.ResponseXml);
                bankName = xHelper.GetXPath(rsResult.ResponseXml, "//CO_NAME").Trim();
                return bankName;
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("GetBkNmByAcc Error ! ACCT=[{0}] ", acct) + ex.ToString(), ex);
                return null;
            }
        }
        string GetT24_AcntInfoEnq_Content(string acnt)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.BP.ACCT.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "UPC001.0005");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<ACCOUNT_NUMBER op='EQ'>{0}</ACCOUNT_NUMBER>", acnt);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            return sb.ToString();
        }

        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey, bool SendToEAI)
        {
            string msgContent = string.Empty;
            if (SendToEAI)
            { msgContent = base.SendToEAIProcess(body, eAI_MsgKey, spN_GW, custId_GW); }
            else
            { msgContent = base.SendToEAIProcess(body, eAI_MsgKey); }

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(msgContent);
            XmlDocument subRqXml = null;
            if (SendToEAI)
            { subRqXml = CopyToNewDocument(rq, spN_GW, custId_GW, eAI_MsgKey, Guid.NewGuid().ToString()); }
            else
            { subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString()); }
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, subRqXml.InnerXml);
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml, SendToEAI);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }


        /// <summary>
        /// 給定起始日、中止日、頻率、執行日，計算出該執行的日期列表
        /// </summary>
        /// <param name="timeStart">起始日</param>
        /// <param name="timeEnd">中止日</param>
        /// <param name="frequency">頻率 00.每天 01.每周 02.每月</param>
        /// <param name="exec_timing">執行日 某每周1~7 每月1~28</param>
        /// <param name="includeEndDate">日期列表是否包含中止日當天</param>
        /// <returns>該執行的日期列表</returns>
        public static List<DateTime> GetExecuteDateList(DateTime timeStart, DateTime timeEnd, string frequency, string exec_timing, bool includeEndDate)
        {
            List<DateTime> execTimeList = new List<DateTime>();

            switch (frequency[1])
            {
                case '0':
                    for (DateTime t = timeStart; t <= timeEnd; t = t.AddDays(1))
                    {
                        DateTime newTime = t;
                        if (newTime >= timeStart && newTime <= (includeEndDate ? timeEnd : timeEnd.AddDays(-1)))
                            execTimeList.Add(t);
                    }
                    break;
                case '1':
                    for (DateTime t = timeStart; t <= timeEnd.AddDays(7); t = t.AddDays(7))
                    {
                        int day = Convert.ToInt32(exec_timing);
                        DateTime newTime = t.AddDays(day - ((int)t.DayOfWeek == 0 ? 7 : (int)t.DayOfWeek));
                        if (newTime >= timeStart && newTime <= (includeEndDate ? timeEnd : timeEnd.AddDays(-1)))
                            execTimeList.Add(newTime);
                    }
                    break;
                case '2':
                    for (DateTime t = timeStart; t <= timeEnd.AddMonths(1); t = t.AddMonths(1))
                    {
                        int date = Convert.ToInt32(exec_timing);
                        DateTime newTime = new DateTime(t.Year, t.Month, date);
                        if (newTime >= timeStart && newTime <= (includeEndDate ? timeEnd : timeEnd.AddDays(-1)))
                        { execTimeList.Add(newTime); }
                    }
                    break;
            }
            return execTimeList;
        }

        private void ParseUcToDic(string ucString, out Dictionary<string, string> ucHeadDic, out Dictionary<string, string> ucBodyDic)
        {
            if (string.IsNullOrEmpty(ucString))
            {
                ucHeadDic = new Dictionary<string, string>();
                ucBodyDic = new Dictionary<string, string>();
                return;
            }
            UcControler uCcontroler = new UcControler();
            UcBody ucBody = new UcBody();
            ucHeadDic = uCcontroler.UC2T24_Head(ucString);
            ucBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);
            m_log.Debug("ParseUcToDic rsString = [{0}]", ucString);
            foreach (KeyValuePair<string, string> kv in ucHeadDic)
            { m_log.Debug("ucHead = [{0}][{1}]", kv.Key, kv.Value); }
            foreach (KeyValuePair<string, string> kv in ucBodyDic)
            { m_log.Debug("ucBody = [{0}][{1}]", kv.Key, kv.Value); }
        }

        /// <summary>
        /// 傳入完整UCXML，返回UCbodyDic
        /// </summary>
        /// <param name="xmlString">完整UCXML</param>
        /// <returns></returns>
        public Dictionary<string, string> GetUcbodyDicFromUcXml(string xmlString)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            try
            {
                if (!string.IsNullOrEmpty(xmlString))
                {
                    XmlDocument xmld = new XmlDocument();
                    xmld.LoadXml(xmlString);
                    XmlHelper xmlh = XmlHelper.GetInstance(xmld);
                    string ucString = xmlh.GetXPath(xmld, "//T24_DATA");

                    UcControler ucControler = new UcControler();
                    UcBody ucBody = new UcBody();
                    ucControler.UC2T24_Head(ucString);
                    dic = ucBody.ParserString(ucControler.m_ucbody);
                }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("GetUcbodyDicFromUcXml Error : ", ex);
            }
            return dic;
        }
        public List<Dictionary<string, string>> DatasetToDiclist(DataSet dataset)
        {
            List<Dictionary<string, string>> lstdata = new List<Dictionary<string, string>>();
            if (dataset != null && dataset.Tables.Count > 0)
            {
                foreach (DataRow drow in dataset.Tables[0].Rows)
                {
                    Dictionary<string, string> tempData = new Dictionary<string, string>();

                    for (int i = 0; i <= drow.ItemArray.Length - 1; i++)
                    {
                        tempData.Add(dataset.Tables[0].Columns[i].ColumnName, drow.ItemArray[i].ToString());
                    }
                    lstdata.Add(tempData);
                }
            }
            return lstdata;
        }

    }
}
