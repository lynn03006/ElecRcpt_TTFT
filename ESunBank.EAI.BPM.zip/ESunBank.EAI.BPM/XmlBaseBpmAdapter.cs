using System;
using System.Text;
using System.Xml;
using System.Xml.Linq;

using Microsoft.Service;
using Microsoft.EAIServer;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;

using Bankpro.EAI.Component;

namespace Bankpro.EAI.BPM
{
    public abstract class XmlBaseBpmAdapter : BaseBpmAdapter
    {

        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.XmlBaseBpmAdapter");

        protected XmlBaseBpmAdapter()
        {

        }

        public override bool IsXmlVersionImplemented { get { return true; } }

        public override bool IsBinaryVersionImplemented { get { return false; } }


        public override AppXmlExecResult Run(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            context.Set("WriteApRsStatus", false);//Ap��Status�v�Ѥl����নEAI�з�RS, �i�DBankproML.cs���n�A�g�@��
            return RunImpl(context, correlationID, txID, txDef, requestXml);
        }

        protected abstract AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml);

        public EaiClient CreateEaiClient()
        {
            return new EaiClient(TimeoutMilliseconds);
        }
        public EsunEAI CreateEsunEAI()
        {
            return new EsunEAI(TimeoutMilliseconds);
        }
        /// <summary>
        /// ��Request XML�A�ƻs���@�ӷs��XML�A�è��N�䤤����N�X�BChannelID�Bstano������(�]�AFMPConnectionString��TxHead�����)
        /// </summary>
        /// <param name="sourceXml"></param>
        /// <param name="newSpName"></param>
        /// <param name="newLoginId"></param>
        /// <param name="newMsgId"></param>
        /// <param name="newRqUID"></param>
        /// <returns>�@�ӥ��s��RequestXML</returns>
        protected static XmlDocument CopyToNewDocument(XmlDocument sourceXml, string newSpName, string newLoginId, string newMsgId, string newRqUID)
        {
            XmlDocument xml = CloneDocument(sourceXml);
            XmlHelper xmlHelper = XmlHelper.GetInstance(sourceXml);
            xmlHelper.SetMultipleXPath(xml, "//SPName", newSpName);
            xmlHelper.SetMultipleXPath(xml, "//MsgId", newMsgId);
            xmlHelper.SetMultipleXPath(xml, "//RqUID", newRqUID);
            xmlHelper.SetMultipleXPath(xml, "//CustLoginId", newLoginId);
            return xml;
        }


        /// <summary>
        /// ��Request XML�A�ƻs���@�ӷs��XML�A�è��N�䤤����N�X�BChannelID�Bstano������(�]�AFMPConnectionString��TxHead�����)
        /// </summary>
        /// <param name="sourceXml"></param>
        /// <param name="newMsgId"></param>
        /// <param name="newRqUID"></param>
        /// <returns>�@�ӥ��s��RequestXML</returns>
        public static XmlDocument CopyToNewDocument(XmlDocument sourceXml, string newMsgId, string newRqUID)
        {
            return CopyToNewDocument(sourceXml, "EAI", "EAI", newMsgId, newRqUID);
        }


        public static void FixKeyFieldsInResponseXml(EaiContext context, XmlDocument requestXml, XmlDocument responseXml)
        {
            if (responseXml == null) { throw new ArgumentNullException("responseXml"); }
            XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
            xmlHelper.SetMultipleXPath(responseXml, "//MsgId", xmlHelper.GetXPath(requestXml, "//MsgId"));
            xmlHelper.SetMultipleXPath(responseXml, "//RqUID", context.CorrelationID);
            xmlHelper.SetMultipleXPath(responseXml, "//SPName", xmlHelper.GetXPath(requestXml, "//SPName"));
            xmlHelper.SetMultipleXPath(responseXml, "//CustLoginId", xmlHelper.GetXPath(requestXml, "//CustLoginId"));
        }

        public XmlDocument TransformCommMsg(string strStatusCode, string strSeverity, string strStatusDesc, string responseXml)
        {

            StringBuilder sbXml = new StringBuilder();
            sbXml.Append("<BankproML xmlns=\"urn:schema-bankpro-com:multichannel\">");
            sbXml.Append("<CommMsg>");
            sbXml.Append("<Status>");
            sbXml.AppendFormat("<StatusCode>{0}</StatusCode>", strStatusCode);
            sbXml.AppendFormat("<Severity>{0}</Severity>", strSeverity);
            //�N������N�A�~��ǰe����XML�ܫe�x
            sbXml.AppendFormat("<StatusDesc>{0}</StatusDesc>", strStatusDesc.Replace("\r\n", ""));
            sbXml.Append("</Status>");

            sbXml.AppendFormat("<T24_DATA>{0}</T24_DATA>", responseXml);
            sbXml.Append("</CommMsg>");
            sbXml.Append("</BankproML>");

            XmlDocument xmlRs = new XmlDocument();
            xmlRs.LoadXml(sbXml.ToString());
            return xmlRs;

        }

        public AppXmlExecResult Send1Recv1(Logger log, EaiContext context, XmlDocument subRqXml)
        {
            if (log.IsDebugEnabled)
            {
                log.Debug("Sending sub-tx xml for correlationId={0}, xml=\r\n{1}", context.CorrelationID, subRqXml.OuterXml);
            }

            EaiClient client = CreateEaiClient();
            TransportResult result = client.Send1Recv1(subRqXml);
            if (result.IsTransportOK)
            {
                if (log.IsDebugEnabled)
                {
                    log.Debug("Received sub-tx xml for correlationId={0}, xml=\r\n{1}", context.CorrelationID, result.GetXml().OuterXml);
                }
                context.Set("WriteApRsStatus", false);//Ap��Status�v�Ѥl����নEAI�з�RS, �i�DLandBankML.cs���n�A�g�@��

                XmlDocument respXml = result.GetXml();
                XmlHelper xmlHelper = XmlHelper.GetInstance(respXml);
                string strStatusCode = xmlHelper.GetXPath(respXml, "/*/*/*/*/StatusCode");

                if (strStatusCode != "0")
                {
                    //BPMSendMailInfo.GetInstance().SendBPMErrorMail(subRqXml, respXml, context.TxID, strStatusCode);
                }

                return BuildExecResult(context, respXml);
            }
            else
            {
                if (log.IsDebugEnabled)
                {
                    log.Debug("Received sub-tx xml for correlationId={0}, error={1}, data={2}", context.CorrelationID, result.ErrText, result.Data);
                }
                //BPMSendMailInfo.GetInstance().SendBPMErrorMail(subRqXml, result.ErrText, context.TxID, "9999");
                return BuildExecResult(context, "TPXX", result.ErrText);
            }
        }

        public AppXmlExecResult Send1Recv1(Logger log, EaiContext context, XmlDocument subRqXml, bool sendToEAI)
        {
            if (log.IsDebugEnabled)
            {
                log.Debug("Sending sub-tx xml for correlationId={0}, xml=\r\n{1}", context.CorrelationID, subRqXml.OuterXml);
            }

            TransportResult result = sendToEAI ? CreateEsunEAI().Send1Recv1(subRqXml) : CreateEaiClient().Send1Recv1(subRqXml);

            if (result.IsTransportOK)
            {
                if (log.IsDebugEnabled)
                {
                    log.Debug("Received sub-tx xml for correlationId={0}, xml=\r\n{1}", context.CorrelationID, result.GetXml().OuterXml);
                }
                context.Set("WriteApRsStatus", false);//Ap��Status�v�Ѥl����নEAI�з�RS, �i�DLandBankML.cs���n�A�g�@��

                XmlDocument respXml = result.GetXml();
                XmlHelper xmlHelper = XmlHelper.GetInstance(respXml);
                string strStatusCode = xmlHelper.GetXPath(respXml, "/*/*/*/*/StatusCode");

                if (strStatusCode != "0")
                {
                    //BPMSendMailInfo.GetInstance().SendBPMErrorMail(subRqXml, respXml, context.TxID, strStatusCode);
                }

                return BuildExecResult(context, respXml);
            }
            else
            {
                if (log.IsDebugEnabled)
                {
                    log.Debug("Received sub-tx xml for correlationId={0}, error={1}, data={2}", context.CorrelationID, result.ErrText, result.Data);
                }
                //BPMSendMailInfo.GetInstance().SendBPMErrorMail(subRqXml, result.ErrText, context.TxID, "9999");
                return BuildExecResult(context, "TPXX", result.ErrText);
            }
        }

        public AppXmlExecResult BuildExecResult(EaiContext context, XmlTxParallelProcData data)
        {
            XmlDocument rqXml = context.RequestXml;
            XmlDocument respXml = data.ResponseXml;
            FixKeyFieldsInResponseXml(context, rqXml, respXml);
            return AppXmlExecResult.GetInstanceForEaiErr(context.CorrelationID, context.TxID, rqXml, respXml, data.GetString("ErrCode"), data.GetString("ErrText"));
        }

        public AppXmlExecResult BuildExecResult(EaiContext context, XmlDocument responseXml)
        {
            XmlDocument rqXml = context.RequestXml;
            XmlDocument respXml = responseXml;
            FixKeyFieldsInResponseXml(context, rqXml, respXml);
            return AppXmlExecResult.GetInstanceForEaiErr(context.CorrelationID, context.TxID, rqXml, respXml, "0", "");
        }

        public AppXmlExecResult BuildExecResult(EaiContext context, string errCode, string errText)
        {
            XmlDocument rqXml = context.RequestXml;
            //XmlDocument respXml = responseXml;
            //FixKeyFieldsInResponseXml(context, rqXml, respXml);
            return AppXmlExecResult.GetInstanceForEaiErr(context.CorrelationID, context.TxID, rqXml, null, errCode, errText);
        }

        public static XmlDocument CloneDocument(XmlDocument source)
        {
            XmlDocument target = new XmlDocument();
            target.LoadXml(source.OuterXml);
            return target;
        }

        public string SendToEAIProcess(string msg, string msgID, string spName = "EAI", string custLoginId = "EAI")
        {
            StringBuilder doc = new StringBuilder();
            doc.Append("<BankproML xmlns=\"urn:schema-bankpro-com:multichannel\">");
            doc.Append("<SignonRq>");
            doc.Append("<SignonPswd>");
            doc.Append("<CustId>");
            doc.AppendFormat("<SPName>{0}</SPName>", spName);
            doc.AppendFormat("<CustLoginId>{0}</CustLoginId>", custLoginId);
            doc.Append("</CustId>");
            doc.Append("<CustPswd>");
            doc.Append("<CryptType>DES1</CryptType>");
            doc.Append("<Pswd>NONE</Pswd>");
            doc.Append("</CustPswd>");
            doc.Append("</SignonPswd>");
            doc.AppendFormat("<ClientDt>{0}</ClientDt>", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
            doc.Append("</SignonRq>");
            doc.Append("<CommMsg>");
            doc.AppendFormat("<SPName>{0}</SPName>", spName);
            doc.AppendFormat("<MsgId>{0}</MsgId>", msgID);
            doc.Append("<RqUID></RqUID>");
            doc.Append(msg);
            doc.Append("</CommMsg>");
            doc.Append("</BankproML>");
            return doc.ToString();
        }

        #region �l�����(EAI)

        /// <summary>
        /// BPM�y�{
        /// </summary>
        /// <param name="context">�����Context</param>
        /// <param name="NewTxId">�s����W��</param>
        /// <param name="requestMsg">�s���RQ</param>
        /// <returns></returns>
        public AppXmlExecResult Send1Recv1ByAA(EaiContext context, string txId, XmlDocument requestMsg)
        {

            EaiContext context2 = GetNewContextAndFixXml(context, txId, requestMsg);

            AppXmlExecResult result = Send1Recv1ByAAImpl(
                   context2,
                   context2.CorrelationID,
                   txId,
                   HostTxDefManager.GetInstance().GetTxDef(txId),
                   requestMsg
                   );

            context.EaiRs = result.EaiRs;
            return result;
        }

        private AppXmlExecResult Send1Recv1ByAAImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            LogToDbStep1(context, requestXml);
            m_log.Info("CorrelationID = [{0}] ;TxID = [{1}] ;SubRequest = \r\n{2}", correlationID, txID, XDocument.Parse(requestXml.OuterXml));

            AppXmlExecResult execResult = AppAdapterManager.GetInstance().Get(txDef.AppAdapter).Run(context, context.CorrelationID, txID, txDef, requestXml);

            XmlDocument responseXml = execResult.ResponseXml;
            LogToDbStep6(context, txDef, execResult, responseXml);

            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, context.EaiRs);

        }

        private EaiContext GetNewContextAndFixXml(EaiContext context, string txId, XmlDocument requestMsg)
        {
            string clientIp = "127.0.0.1";

            EaiContext context2 = EaiContext.CreateContext(Guid.NewGuid().ToString(), clientIp, context.UserName, context.UserLanguage);
            context2.MasterCorrelationID = context.CorrelationID;
            context2.TxID = txId;
            context2.ChannelID = context.ChannelID;
            context2.RequestXml = requestMsg;
            context2.TxSeqNo = context.TxSeqNo;
            context2.LoginID = context.LoginID;

            //��GetTxPrimaryInfo�MInitEaiContext���ӭnSet���F��
            context2.Set("MsgId", context.GetString("MsgId"));
            context2.Set("CryptType", context.GetString("CryptType"));
            context2.Set("Pswd", context.GetString("Pswd"));
            context2.Set("isEC", context.GetBoolean("isEC", false));

            //FIX RQUID IN XML
            XmlHelper reqXmlHelper = XmlHelper.GetInstance(requestMsg);
            reqXmlHelper.SetMultipleXPath(requestMsg, "//RqUID", context2.CorrelationID);
            return context2;
        }

        private static void LogToDbStep1(EaiContext context, XmlDocument requestXml)
        {
            try
            {
                Component.DB.DbLog.InsertMsgLog(context, context.CorrelationID, "1", requestXml, true);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("Error inserting message log for sub tx:" + ex.Message, ex);
            }
        }

        private static void LogToDbStep6(EaiContext context, HostTxDef txDef, AppXmlExecResult execResult, XmlDocument responseXml)
        {
            //20080829 Log to DB
            try
            {
                XmlTransformer xmlTrm = XmlTransformerManager.GetInstance().Get(txDef);

                string strResponseXml = responseXml.OuterXml;
                strResponseXml = strResponseXml.Replace("utf-16", "utf-8");

                Component.DB.DbLog.InsertMsgLog(context, context.CorrelationID, "6", strResponseXml, false);

                DateTime insertTime = Convert.ToDateTime(context.Get("InsertMsgCtrlTime"));
                Component.DB.DbLog.UpdateMsgCtrl(context, context.CorrelationID, execResult.ErrCode, execResult.ErrText, "N", "Y", insertTime);

            }
            catch (Exception ex)
            {
                m_log.ErrorException("Error inserting message log for sub tx:" + ex.Message, ex);
            }
        }

        #endregion
    }
}
