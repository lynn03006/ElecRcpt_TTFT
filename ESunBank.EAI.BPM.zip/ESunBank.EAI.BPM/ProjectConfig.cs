using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Service;
using Microsoft.Service.Config;

//EAI98CHG: no need to change

namespace Bankpro.EAI.BPM
{
    internal class ProjectConfig : AppConfigManager
    {
        private static ProjectConfig m_myIinstance;
        private static object m_lock = new object[0];
        private string m_appId;

        private ProjectConfig(AppConfigProviderProxy provider, string appId)
            : base(provider, appId)
        {
            m_appId = appId;
        }


        public new static ProjectConfig GetInstance()
        {
            if (m_myIinstance == null)
            {
                lock (m_lock)
                {
                    if (m_myIinstance != null)
                    {
                        return m_myIinstance;
                    }
                    //m_myIinstance = new ProjectConfig(AppConfigManager.DefaultProvider, AppConfigManager.GetAppIdFromConfig());
                    m_myIinstance = new ProjectConfig(AppConfigManager.DefaultProvider, "EAI");
                }
            }
            return m_myIinstance;

        }


        /// <summary>
        /// application id
        /// </summary>
        public string AppID { get { return m_appId; } }

        /// <summary>
        /// �ҭn�ǰe�����|
        /// </summary>
        public String Send_URL
        {
            get { return Application.GetAsString("Send_URL", @"http://localhost/Front/HttpPost.ashx", "�ҭn�ǰe�����|"); }
        }

        /// <summary>
        /// �ҭn�ǰe��EAI���|
        /// </summary>
        public String Send_EaiURL
        {
            get { return Application.GetAsString("Send_EaiURL", @"http://10.26.11.101/Front/HttpPost.ashx", "�ҭn�ǰe��EAI���|"); }
        }

        /// <summary>
        /// �I�sEAI Time out �ɶ�
        /// </summary>
        public Int32 PostTimerOut
        {
            get { return Application.GetAsInt("PostTimerOut", 30, "Post��EAI��TimeOut�ɶ�(��)"); }
        }

        public string OfsUser
        {
            get { return Application.GetAsString("OfsUser", "INPUTT", "OFS�b���C"); }
            set { Application.Set("OfsUser", value); }
        }
        public string OfsPwd
        {
            get { return Application.GetAsString("OfsPwd", Convert.ToBase64String(Encoding.UTF8.GetBytes("123456")), "OFS�K�X�C"); }
            set { Application.Set("OfsPwd", value); }
        }
        public string ITFChannelID
        {
            get { return Application.GetAsString("ITFChannelID", "UC", "ITF CHANNEL ID�C"); }
            set { Application.Set("ITFChannelID", value); }
        }

        public string UploadFtpIP
        {
            get { return Application.GetAsString("UploadFtpIP", "ftp://10.26.11.89", "�W��FTP��IP�C"); }
            set { Application.Set("UploadFtpIP", value); }
        }
        public string UploadFtpFolder
        {
            get { return Application.GetAsString("UploadFtpFolder", @"/00001/", "�W��FTP����Ƨ��C"); }
            set { Application.Set("UploadFtpFolder", value); }
        }
        public string UploadFtpUser
        {
            get { return Application.GetAsString("UploadFtpUser", "NFE", "�n�JFTP���ϥΪ̡C"); }
            set { Application.Set("UploadFtpUser", value); }
        }
        public string UploadFtpPassword
        {
            get { return Application.GetAsString("UploadFtpPassword", Convert.ToBase64String(Encoding.UTF8.GetBytes("!QAZ2wsx")), "�n�JFTP���K�X�C"); }
            set { Application.Set("UploadFtpPassword", value); }
        }
        public string DropFilesPath
        {
            get { return Application.GetAsString("DropFilesPath", @"C:\Middleware\File\", "�ɮ׸��ɪ����|�C"); }
            set { Application.Set("DropFilesPath", value); }
        }

        public string UPC_UploadFtpIP
        {
            get { return Application.GetAsString("UPC", "UPC_UploadFtpIP", "ftp://10.26.11.66", "�W��FTP��IP�C"); }
            set { Application.Set("UPC", "UPC_UploadFtpIP", value); }
        }
        public string UPC_UploadFtpFolder
        {
            get { return Application.GetAsString("UPC", "UPC_UploadFtpFolder", @"/00001/", "�W��FTP����Ƨ��C"); }
            set { Application.Set("UPC", "UPC_UploadFtpFolder", value); }
        }
        public string UPC_UploadFtpUser
        {
            get { return Application.GetAsString("UPC", "UPC_UploadFtpUser", "User1", "�n�JFTP���ϥΪ̡C"); }
            set { Application.Set("UPC", "UPC_UploadFtpUser", value); }
        }
        public string UPC_UploadFtpPassword
        {
            get { return Application.GetAsString("UPC", "UPC_UploadFtpPassword", Convert.ToBase64String(Encoding.UTF8.GetBytes("!QAZ2wsx")), "�n�JFTP���K�X�C"); }
            set { Application.Set("UPC", "UPC_UploadFtpPassword", value); }
        }
        //public string ToGateWayQPath
        //{
        //    get { return Application.GetAsString("ToGateWayQPath", "FormatName:Direct=TCP:10.26.11.77\\private$\\eai.MSMQTalk.GW.recv", "��GateWayFront�C"); }
        //    set { Application.Set("ToGateWayQPath", value); }
        //}
    }
}
