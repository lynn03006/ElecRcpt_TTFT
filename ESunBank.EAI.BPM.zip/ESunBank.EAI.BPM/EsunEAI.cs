﻿using System;
using System.IO;
using System.Xml;
using System.Text;
using System.Net;
using System.Collections.Generic;

namespace Bankpro.EAI.BPM
{
    public class EsunEAI : IDisposable
    {
        private string m_url = ProjectConfig.GetInstance().Send_EaiURL;
        private int m_timeoutMilliseconds = ProjectConfig.GetInstance().PostTimerOut * 1000;


        public EsunEAI(int timeoutMilliseconds)
        {
            m_timeoutMilliseconds = timeoutMilliseconds;
        }

        ~EsunEAI()
        {
            Dispose();
        }

        public void Dispose()
        {
            //
        }

        /// <summary>
        /// 一去一回，保証不傳回exception, 從TransportResult.IsTransportOK判斷是否有正常收送？
        /// </summary>
        /// <param name="requestXml"></param>
        /// <returns></returns>
        public TransportResult Send1Recv1(XmlDocument requestXml)
        {
            return HttpPost(m_url, requestXml.DocumentElement.OuterXml, m_timeoutMilliseconds);
        }

        private XmlDocument GetErrResponseXml(XmlDocument requestXml, string errCode, string errText)
        {
            //return EAIMessage.GetErrResponseXml(errCode, errText, requestXml);
            //return error directly.
            return null;
        }


        /// <summary>
        /// 必須保証能傳回XML, 連線失敗也要傳回錯誤描述的XML
        /// </summary>
        /// <param name="requestXml"></param>
        /// <returns></returns>
        private XmlDocument HttpPost(XmlDocument requestXml)
        {
            TransportResult result = HttpPost(m_url, requestXml.DocumentElement.OuterXml, m_timeoutMilliseconds);
            if (result.IsTransportOK)
            {
                return result.GetXml();
            }
            else
            {
                return GetErrResponseXml(requestXml, "TPXX", result.ErrText);
            }
        }



        /// <summary>
        /// send request and get response
        /// </summary>
        /// <param name="url"></param>
        /// <param name="requestText"></param>
        /// <param name="timeoutMilliseconds"></param>
        /// <returns>responseText</returns>
        private TransportResult HttpPost(string url, string requestText, int timeoutMilliseconds)
        {
            WebRequest webRequest = WebRequest.Create(url);
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.Method = "POST";
            webRequest.Timeout = timeoutMilliseconds;

            try
            {
                using (StreamWriter sw = new StreamWriter(webRequest.GetRequestStream()))
                {
                    sw.Write(requestText);
                }
            }
            catch (WebException ex)
            {
                return TransportResult.GetInstance(TransportStatus.ConnectTimeout, "", string.Format("HttpPost: Request error:{0}", ex.Message));
            }

            try
            {
                WebResponse webResponse = webRequest.GetResponse();
                if (webResponse == null)
                {
                    return TransportResult.GetInstance(TransportStatus.ResponseTimeout, "", string.Format("HttpPost: Unable to get WebResponse"));
                }
                using (StreamReader sr = new StreamReader(webResponse.GetResponseStream(), Encoding.UTF8))
                {
                    string responseText = sr.ReadToEnd().Trim();
                    TransportResult ret = TransportResult.GetInstance(TransportStatus.Transported, responseText);
                    ret.GetXml();
                    return ret;
                }
            }
            catch (WebException ex)
            {
                return TransportResult.GetInstance(TransportStatus.ResponseTimeout, "", string.Format("HttpPost: Unable to get WebResponse:{0} URL = {1}", ex.Message, url));
            }
        }
    }
}
