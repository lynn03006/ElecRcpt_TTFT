﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

using Microsoft.Service;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;
using Microsoft.EAIServer;

using Bankpro.EAI.BPM;
using Bankpro.EAI.Utility;
using Bankpro.EAI.Component;

namespace Bankpro.EAI.BPM
{
    public class UPC2CUP : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.UPC2CUP");
        //private UcControler m_UcControler;
        private String m_SendURL = ProjectConfig.GetInstance().Send_URL;
        private Int32 m_PostTimeOut = ProjectConfig.GetInstance().PostTimerOut * 1000;

        //private XferVariables xv = XferVariables.GetInstance();

        public UPC2CUP()
        {
        }




        /// <summary>
        /// timeout standard status code = 6005
        /// </summary>
        /// <param name="context"></param>
        /// <param name="correlationID"></param>
        /// <param name="txID"></param>
        /// <param name="txDef"></param>
        /// <param name="requestXml"></param>
        /// <returns></returns>
        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            switch (txID)
            {
                case "ES_ESCN.BP.TRANS.REMIT":  //UPC REMIT TRANSACTION 
                    return DoUPCProcess(context, correlationID, txID, txDef, requestXml);
                default :
                    return DoDefault(context, correlationID, txID, txDef, requestXml);
                    
            }
        }

        private AppXmlExecResult DoDefault(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            EaiResponse eaiRs = null;
            XmlDocument responseXml = null;
            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }

        private AppXmlExecResult DoUPCProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            
            XmlHelper xmlHelperUPCRS = XmlHelper.GetInstance(requestXml);
            string flag = xmlHelperUPCRS.GetXPath(requestXml, "//C_IN_OUT_TYPE");
            string debitACC = xmlHelperUPCRS.GetXPath(requestXml, "//DEBIT_ACCT_NO");
            string creditACC = xmlHelperUPCRS.GetXPath(requestXml, "//CREDIT_ACCT_NO");
            string tranAMT = xmlHelperUPCRS.GetXPath(requestXml, "//DEBIT_AMOUNT");
            string cURR = xmlHelperUPCRS.GetXPath(requestXml, "//DEBIT_CURRENCY");
            string transGATE = xmlHelperUPCRS.GetXPath(requestXml, "//L_TRANS_GATE");
            string extREF = xmlHelperUPCRS.GetXPath(requestXml, "//EXT_REFERENCE");
            string co_CODE = xmlHelperUPCRS.GetXPath(requestXml, "//SIGN_ON_BRH");
            string cardREF = xmlHelperUPCRS.GetXPath(requestXml, "//CARD_REF");
            string PIN_flag = xmlHelperUPCRS.GetXPath(requestXml, "//PIN_FLAG");
            string PIN_data = xmlHelperUPCRS.GetXPath(requestXml, "//PIN_DATA");
            string func = xmlHelperUPCRS.GetXPath(requestXml, "//PROC_FUNC");
            //string CommType = xmlHelperUPCRS.GetXPath(requestXml, "//COMMISSION_TYPE");
            string CommType1 = xmlHelperUPCRS.GetXPath(requestXml, "//COMMISSION_TYPE[@mp='1']");
            string CommType2 = xmlHelperUPCRS.GetXPath(requestXml, "//COMMISSION_TYPE[@mp='2']");
            string CommCode = xmlHelperUPCRS.GetXPath(requestXml, "//COMMISSION_CODE");

            string payerAcct = xmlHelperUPCRS.GetXPath(requestXml, "//C_PAYER_ACCT_NO");
            string payeeAcct = xmlHelperUPCRS.GetXPath(requestXml, "//C_PAYEE_ACCT_NO");

            //判斷DEBIT/CREDIT和PAYER/PAYEE是否相符，以抓取真正的他行帳號
            if (debitACC.Equals(payerAcct))
                creditACC = string.IsNullOrEmpty(payeeAcct) ? creditACC : payeeAcct;
            else if (debitACC.Equals(payeeAcct))
                creditACC = string.IsNullOrEmpty(payerAcct) ? creditACC : payerAcct;
            else if (creditACC.Equals(payerAcct))
                debitACC = string.IsNullOrEmpty(payeeAcct) ? debitACC : payeeAcct;
            else if (creditACC.Equals(payeeAcct))
                debitACC = string.IsNullOrEmpty(payerAcct) ? debitACC : payerAcct;

            m_log.Info("Result (flag)={0}&&(debit)={1}&&(credit)={2}&&(amt)={3}&&(curr)={4}&&(gate)={5}&&(cardREF)={6}&&(pin)={7}&&(type1)={8}&&(type2)={9}", flag, debitACC, creditACC, tranAMT, cURR, transGATE, cardREF, PIN_flag, CommType1, CommType2);
            UcControler m_UcControler = new UcControler();

            xmlHelperUPCRS.SetMultipleXPath(requestXml, "//CARD_REF", "");
            xmlHelperUPCRS.SetMultipleXPath(requestXml, "//PIN_FLAG", "");
            xmlHelperUPCRS.SetMultipleXPath(requestXml, "//PIN_DATA", "");
            xmlHelperUPCRS.SetMultipleXPath(requestXml, "//COMMISSION_CODE", "WAIVE");
            xmlHelperUPCRS.SetMultipleXPath(requestXml, "//COMMISSION_TYPE[@mp='1']", "");
            xmlHelperUPCRS.SetMultipleXPath(requestXml, "//COMMISSION_TYPE[@mp='2']", "");

            if (func.Equals("R"))  //REVERSE
                return DoECProcess(context, m_UcControler, debitACC, creditACC, tranAMT, cURR, txID, extREF, func, co_CODE, flag, txDef, cardREF, transGATE,PIN_flag, requestXml);

            else if (flag.Equals("OUT")) //OUTGOING REMIT
                return DoCardtoT24Process(context, m_UcControler, debitACC, creditACC, tranAMT, cURR, transGATE, co_CODE, txID, txDef, extREF, PIN_data, CommType1, CommCode, requestXml, CommType2);

            else if(flag.Equals("IN")) // INCOMING REMIT
                return DoT24toCardProcess(context, m_UcControler, debitACC, creditACC, tranAMT, cURR, co_CODE, txID, txDef, extREF, requestXml);
            
            else
                return DoDefault(context, correlationID, txID, txDef, requestXml);
          
        }

        private string GetCoCode(String t24Account)
        {
            string subCode = t24Account.Substring(0, 4);
            return String.Format("CN001{0}", subCode);
        }

        private string GetCURR_NUM(string currNo)
        {
            switch (currNo)
            {
                case "156":
                    return "CNY";
                case "840":
                    return "USD";
                case "CNY":
                    return "156";
                case "USD":
                    return "840";
                default:
                    return "CNY";
            }
        }

        private AppXmlExecResult DoCardtoT24Process(EaiContext context, UcControler m_UcControler, string debitACC, string creditACC, string tranAMT, string cURR, string transGATE, string co_CODE, string txID, HostTxDef txDef, string extREF, string PIN_data, string CommType1, string CommCode, XmlDocument requestXml, string CommType2)
        {
            string failDescription = string.Empty;

            if (transGATE != "BRANCH") //Check Debit Limit
            {
                string gate = (transGATE == "PHONE") ? "02" : "01";
                string limitEnq = GetT24_LimitENQ_Content(debitACC, gate);
                AppXmlExecResult limitEnq_result = SendMsgToEAIProcess(context, limitEnq, "ESCN.BP.DEB.LIM.ENQ");
                XmlHelper xmlHelperLimitEnq = XmlHelper.GetInstance(limitEnq_result.ResponseXml);
                string rs_LimRes = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//RSP_PROC_RET");

                if (rs_LimRes == "SUCC")
                {
                    string checkAmount = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//TOTAL").Trim();
                    string checkCount = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//COUNT").Trim();
                    Decimal ckAMT = 0;
                    Decimal ckCNT = 0;
                    if (!string.IsNullOrEmpty(checkAmount))
                    {
                        ckAMT = Convert.ToDecimal(checkAmount) - Convert.ToDecimal(tranAMT);
                    }
                    if (!string.IsNullOrEmpty(checkCount))
                    {
                        ckCNT = Convert.ToDecimal(checkCount) - 1;
                    }

                    if (ckAMT < 0 || ckCNT < 0)
                    {
                        string failCode = "CO1MA999";
                        failDescription = "账户超过限额";

                        string afterRS = GetT24_ErrorRS("", failCode, extREF, failDescription); //RETURN ERROR MESSAGE
                        m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
                        XmlDocument rs_UPC = base.TransformCommMsg(limitEnq_result.EaiRs.EaiErrCode, limitEnq_result.EaiRs.EaiErrText, limitEnq_result.EaiRs.EaiErrDetail, afterRS);
                        return base.BuildExecResult(context, rs_UPC);
                    }
                }
            }
                  
            //Get Branch Setting 

            string mer_type = string.Empty;
            string add_res_data = string.Empty;
            string pos_entry = string.Empty;
            string msg_rea_co = string.Empty;
            string commFee = "0.00";

            if (transGATE.Equals("BRANCH"))
            {
                if (CommType1 == "")
                {
                    CommType1 = "PCNYREMIT";
                }
                mer_type = "6010";
                msg_rea_co = "        06     ";
                if (PIN_data == "")
                {
                    pos_entry = "012";
                    add_res_data = "0Y079021";
                }
                else
                {
                    pos_entry = "011";
                    add_res_data = "0Y16   1";
                }
            }
            else
            {
                if (CommType1 == "")
                {
                    CommType1 = "PIBCNYREMIT";
                }
                mer_type = "6013";
                add_res_data = "0Y08   1";
                pos_entry = "012";
                msg_rea_co = "        07     ";
            }

            if (CommCode != "WAIVE")
            {
                string bodyCardEnq1 = GetT24_CommENQ_Content(tranAMT, cURR, CommType1);
                AppXmlExecResult commEnq_result1 = SendMsgToEAIProcess(context, bodyCardEnq1, "IB.CHG.CHK.ENQ");
                XmlHelper xmlHelperCommEnq1 = XmlHelper.GetInstance(commEnq_result1.ResponseXml);
                commFee = xmlHelperCommEnq1.GetXPath(commEnq_result1.ResponseXml, "//CHG_AMT").Trim();

                if (CommType2 != "")
                {
                    string bodyCardEnq2 = GetT24_CommENQ_Content(tranAMT, cURR, CommType2);
                    AppXmlExecResult commEnq_result2 = SendMsgToEAIProcess(context, bodyCardEnq2, "IB.CHG.CHK.ENQ");
                    XmlHelper xmlHelperCommEnq2 = XmlHelper.GetInstance(commEnq_result2.ResponseXml);
                    string commFee2 = xmlHelperCommEnq2.GetXPath(commEnq_result2.ResponseXml, "//CHG_AMT").Trim();
                    commFee = (Convert.ToDecimal(commFee) + Convert.ToDecimal(commFee2)).ToString();
                }
            }
         
            //Send CUP.Card.Debit
            string tranFee = string.Format("D{0}{1}", Math.Truncate(Convert.ToDecimal(commFee)).ToString().PadLeft(6, '0'), commFee.Substring(commFee.Length - 2));
            string bodyCUP = string.Empty;
            AppXmlExecResult cup_result;

            if (PIN_data == "")  //無密
            {
                bodyCUP = GetCard_Debit(debitACC, creditACC, tranAMT, tranFee, mer_type, pos_entry, "03450000", add_res_data, GetCURR_NUM(cURR), co_CODE, msg_rea_co);
                cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Debit");
            }
            else   //有密
            {
                bodyCUP = GetCard_Debit_With_Pin(debitACC, creditACC, tranAMT, tranFee, mer_type, pos_entry, "03450000", add_res_data, GetCURR_NUM(cURR), co_CODE, PIN_data, msg_rea_co);
                cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Debit.With.PIN");
            }

            XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
            string rs_CUPCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");
            string msgType = "0200";
            string dateTime_Now = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//TRAN_TIME");
            string traceNo = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//SYS_TRACE_NUM");
            string acqCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ACQ_INST_ID_CO");
            string forCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FOR_INT_ID_CO");

            string oriData = string.Format("{0}{1}{2}{3}{4}", msgType, traceNo, dateTime_Now, acqCode.PadLeft(11, '0'), forCode.PadLeft(11, '0'));
 
            XmlDocument subRqXml; 


            if (rs_CUPCode == "00")
            {
                //Send to T24
                subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                AppXmlExecResult t24_result = Send1Recv1(m_log, context, subRqXml);

                XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
                string rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
                string rs_Msg = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_MSG");
                string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

                if (rs_Code == "E-000000" && proc_ret == "SUCC")
                {                    
                    string t24data = xmlHelperT24RS.SelectSingleNode(t24_result.ResponseXml, "//T24_DATA").InnerXml;
                    int var = t24data.IndexOf("</CO_CODE>");
                    t24data = t24data.Insert(var + 10, "<CARD_REF>" + oriData + "</CARD_REF>");
                    int var1 = t24data.IndexOf("</C_PAYEE_NAME>");
                    t24data = t24data.Insert(var1 + 15, "<COMMISSION_AMT>" + "CNY" + commFee + "</COMMISSION_AMT>"); 

                    XmlDocument rs_t24_result = base.TransformCommMsg(t24_result.EaiRs.EaiErrCode, t24_result.EaiRs.EaiErrText, t24_result.EaiRs.EaiErrDetail, t24data);
                    return base.BuildExecResult(context, rs_t24_result);
                }
                else if (rs_Code == string.Empty)                
                    new SendMail().Send("Do Outward Rimit Transfer(no ErrorCoe) Error", "", string.Format("Do Outward Rimit Transfer(no ErrorCoe) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));

                //Card Reverse
                string bodyCUP_EC = Get_Card_EC(debitACC, debitACC, creditACC, tranAMT, mer_type, pos_entry, "03450000", add_res_data, GetCURR_NUM(cURR), oriData, co_CODE, msg_rea_co);
                AppXmlExecResult cup_EC_result = SendMsgToEAIProcess(context, bodyCUP_EC, "CUP.Card.Debit.EC");

                XmlHelper xmlHelperCUPRS_EC = XmlHelper.GetInstance(cup_EC_result.ResponseXml);
                rs_CUPCode = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//RES_CO");

                if (rs_CUPCode != "00")
                    //SEND MAIL
                    new SendMail().Send("Do Outward Rimit Transfer(CARD EC) Error", "", string.Format("Do Outward Rimit Transfer(CARD EC) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));

                string afterRS = GetT24_ErrorRS("", rs_Code, extREF, rs_Msg); //RETURN ERROR MESSAGE
                m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
                XmlDocument rs_t24_error = base.TransformCommMsg(cup_result.EaiRs.EaiErrCode, cup_result.EaiRs.EaiErrText, cup_result.EaiRs.EaiErrDetail, afterRS);
                return base.BuildExecResult(context, rs_t24_error);
            }
            else
            {
                failDescription = ErrorCodeMapping("CUP", rs_CUPCode);
                string afterRS = GetT24_ErrorRS("", rs_CUPCode, extREF, failDescription); //RETURN ERROR MESSAGE
                m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
                XmlDocument rs_UPC = base.TransformCommMsg(cup_result.EaiRs.EaiErrCode, cup_result.EaiRs.EaiErrText, cup_result.EaiRs.EaiErrDetail, afterRS);
                return base.BuildExecResult(context, rs_UPC);
            }
        }

        private AppXmlExecResult DoT24toCardProcess(EaiContext context, UcControler m_UcControler, string debitACC, string creditACC, string tranAMT, string cURR, string co_CODE, string txID, HostTxDef txDef, string extREF, XmlDocument requestXml)
        {
            XmlDocument subRqXml;
            string failDescription = string.Empty;

            //先傳送FT至T24
            subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
            AppXmlExecResult t24_result = Send1Recv1(m_log, context, subRqXml);

            //取得T24 Response判斷成功失敗
            XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
            string rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
            string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

            if (rs_Code == "E-000000" && proc_ret == "SUCC")
            {
                //T24扣款成功，送銀聯
                string bodyCUP = GetCard_Credit(creditACC, debitACC, tranAMT, "6014", "03450000", GetCURR_NUM(cURR), co_CODE);
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Credit");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                string rs_CUPCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");
                string msgType = "0200";
                string dateTime_Now = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//TRAN_TIME");
                string traceNo = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//SYS_TRACE_NUM");
                string acqCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ACQ_INST_ID_CO");
                string forCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FOR_INT_ID_CO");

                string oriData = string.Format("{0}{1}{2}{3}{4}", msgType, traceNo, dateTime_Now, acqCode.PadLeft(11, '0'), forCode.PadLeft(11, '0'));

                if (rs_CUPCode != "00")
                {
                    //銀聯入款如果失敗，T24做R
                    string ftRspId = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_TXN_ID");
                    string bodyRFT = GetT24_RFT_Content(co_CODE, "R", ftRspId, "UPC001.0010");
                    AppXmlExecResult t24_R_Result = SendMsgToEAIProcess(context, bodyRFT, "ESCN.BP.TRANS.REMIT");

                    XmlHelper xmlHelperT24RS_R = XmlHelper.GetInstance(t24_R_Result.ResponseXml);
                    rs_Code = xmlHelperT24RS_R.GetXPath(t24_R_Result.ResponseXml, "//ITF_RETURN_CODE");
                    string proc_ret_R = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

                    if (!rs_Code.Equals("E-000000") || proc_ret_R != "SUCC")
                        //send mail
                        new SendMail().Send("Do Inward Remit Transfer(T24 EC) Error", "6", string.Format("Do Inward Remit Transfer(T24 EC) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));

                    failDescription = ErrorCodeMapping("CUP", rs_CUPCode);
                    string afterRS = GetT24_ErrorRS("", rs_CUPCode, extREF, failDescription); //RETURN ERROR MESSAGE
                    m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
                    XmlDocument rs_UPC = base.TransformCommMsg(cup_result.EaiRs.EaiErrCode, cup_result.EaiRs.EaiErrText, cup_result.EaiRs.EaiErrDetail, afterRS);
                    return base.BuildExecResult(context, rs_UPC);
                }

                string t24data = xmlHelperT24RS.SelectSingleNode(t24_result.ResponseXml, "//T24_DATA").InnerXml;
                int var = t24data.IndexOf("</CO_CODE>");
                t24data = t24data.Insert(var + 10, "<CARD_REF>" + oriData + "</CARD_REF>");
                XmlDocument rs_t24_result = base.TransformCommMsg(t24_result.EaiRs.EaiErrCode, t24_result.EaiRs.EaiErrText, t24_result.EaiRs.EaiErrDetail, t24data);
                return base.BuildExecResult(context, rs_t24_result);
            }
            else
                return t24_result;           
        }

        private AppXmlExecResult DoECProcess(EaiContext context, UcControler m_UcControler, string debitACC, string creditACC, string tranAMT, string cURR, string txID, string extREF, string func, string co_CODE, string flag, HostTxDef txDef, string cardREF, string transGATE, string PIN_flag, XmlDocument requestXml)
        {
            XmlDocument subRqXml;
            string failDescription = string.Empty;

            if (flag.Equals("OUT"))   //匯入做EC
            {
                string bodyCUP_EC = Get_Card_EC(debitACC, creditACC, debitACC, tranAMT, "6014", "012", "03450000", "", GetCURR_NUM(cURR), cardREF, co_CODE, "");
                AppXmlExecResult cup_EC_result = SendMsgToEAIProcess(context, bodyCUP_EC, "CUP.Card.Credit.EC");

                XmlHelper xmlHelperCUPRS_EC = XmlHelper.GetInstance(cup_EC_result.ResponseXml);
                string rs_CUPCode = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//RES_CO");

                if (rs_CUPCode != "00")
                {
                    //SEND MAIL
                    new SendMail().Send("Do CARD.Transfer(EC) Error", "", string.Format("Do CARD.Transfer(EC) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));

                    failDescription = ErrorCodeMapping("CUP", rs_CUPCode);
                    string afterRS = GetT24_ErrorRS("", rs_CUPCode, cardREF, failDescription); //RETURN ERROR MESSAGE
                    m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
                    XmlDocument rs_UPC = base.TransformCommMsg(cup_EC_result.EaiRs.EaiErrCode, cup_EC_result.EaiRs.EaiErrText, cup_EC_result.EaiRs.EaiErrDetail, afterRS);
                    return base.BuildExecResult(context, rs_UPC);
                }
                else
                {
                    subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                    AppXmlExecResult t24_result = Send1Recv1(m_log, context, subRqXml);
                    XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
                    string rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
                    string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

                    if (rs_Code == "E-000000" && proc_ret == "SUCC")
                        return t24_result;
                    else
                    {
                        //SEND MAIL
                        new SendMail().Send("Do T24.Transfer(EC) Error", "", string.Format("Do T24.Transfer(EC) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));

                        failDescription = ErrorCodeMapping("CUP", "TC-999999");
                        string afterRS = GetT24_ErrorRS("", "TC-999999", extREF, failDescription); //RETURN ERROR MESSAGE
                        m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
                        XmlDocument rs_T24 = base.TransformCommMsg(cup_EC_result.EaiRs.EaiErrCode, cup_EC_result.EaiRs.EaiErrText, cup_EC_result.EaiRs.EaiErrDetail, afterRS);
                        return base.BuildExecResult(context, rs_T24);

                    }
                }
            }
            else  //匯出做EC
            {
                subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                AppXmlExecResult t24_result = Send1Recv1(m_log, context, subRqXml);

                XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
                string rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
                string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

                if (rs_Code == "E-000000" && proc_ret == "SUCC")
                {
                    string rs_CUPCode = string.Empty;

                    //Get Branch Setting 
                    string commCODE = string.Empty;
                    string mer_type = string.Empty;
                    string add_res_data = string.Empty;
                    string pos_entry = string.Empty;
                    string msg_rea_co = string.Empty;

                    if (transGATE.Equals("BRANCH"))
                    {
                        mer_type = "6010";
                        msg_rea_co = "        06     ";
                        if (PIN_flag == "N")
                        {
                            pos_entry = "012";
                            add_res_data = "0Y079021";
                        }
                        else
                        {
                            pos_entry = "011";
                            add_res_data = "0Y16   1";
                        }
                    }
                    else
                    {
                        mer_type = "6013";
                        add_res_data = "0Y08   1";
                        pos_entry = "012";
                        msg_rea_co = "        07     ";
                    }

                    AppXmlExecResult cup_EC_result;
                    string bodyCUP_EC = Get_Card_EC(creditACC, debitACC, creditACC, tranAMT, mer_type, pos_entry, "03450000", add_res_data, GetCURR_NUM(cURR), cardREF, co_CODE, msg_rea_co);
                    cup_EC_result = SendMsgToEAIProcess(context, bodyCUP_EC, "CUP.Card.Debit.EC");
                    XmlHelper xmlHelperCUPRS_EC = XmlHelper.GetInstance(cup_EC_result.ResponseXml);
                    rs_CUPCode = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//RES_CO");                

                    if (rs_CUPCode != "00")
                    {
                        //SEND MAIL
                        new SendMail().Send("Do CARD.Transfer(EC) Error", "", string.Format("Do CARD.Transfer(EC) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));

                        failDescription = ErrorCodeMapping("CUP", "TC-999999");
                        string afterRS = GetT24_ErrorRS("", "TC-999999", extREF, failDescription); //RETURN ERROR MESSAGE
                        m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
                        XmlDocument rs_UPC = base.TransformCommMsg(cup_EC_result.EaiRs.EaiErrCode, cup_EC_result.EaiRs.EaiErrText, cup_EC_result.EaiRs.EaiErrDetail, afterRS);
                        return base.BuildExecResult(context, rs_UPC);
                    }
                }
                else
                    new SendMail().Send("Do T24.Transfer(EC) Error", "", string.Format("Do T24.Transfer(EC) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));

                return t24_result;
            }
        }

        private string GetT24_RFT_Content(string co_CODE, string proc_FUNC, string txnID, string itfID)
        {
            StringBuilder sb = new StringBuilder();
            #region FT XML MSG
            sb.Append("<T24_DATA>"); 
            sb.Append("<T24_EAI>"); 
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_CODE);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "FUNDS.TRANSFER");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "ESCN.BP.TRANS.REMIT");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>"); 
            #endregion
            return sb.ToString();
        }

        private string GetT24_ErrorRS(string txnID, string itfID, string extREF, string failDescription)
        {
            StringBuilder sb = new StringBuilder();
            #region FT ERROR XML MSG
            //sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<RSP_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<RSP_PROC_SYS/>");
            sb.Append("<PROC_RESULT/>");
            sb.Append("<DATE_TIME_REQ/>");
            sb.Append("<DATE_TIME_RSP/>");
            sb.Append("</RSP_PROC_INFO>");
            sb.Append("<RSP_MSG_GRP>");
            sb.Append("<RSP_MSG_DATA no='1'>");
            sb.Append("<RSP_TXN_CODE/>");
            sb.Append("<RSP_TXN_CODE_S/>");
            sb.AppendFormat("<RSP_TXN_ID>{0}</RSP_TXN_ID>", txnID);
            sb.AppendFormat("<RSP_PROC_RET>{0}</RSP_PROC_RET>", "FAIL");
            sb.AppendFormat("<ITF_RETURN_CODE mp='1' sp='1'>{0}</ITF_RETURN_CODE>", itfID);
            sb.AppendFormat("<ITF_RETURN_MSG mp='1' sp='1'>{0}</ITF_RETURN_MSG>", failDescription);
            //sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", extREF);
            sb.Append("</RSP_MSG_DATA>");
            sb.Append("</RSP_MSG_GRP>");  
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            //sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_CardENQ_Content(string debitACC)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.CARD.CUSDATA.ENQ XML MSG
            sb.Append("<T24_DATA>"); 
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.CARD.CUSDATA.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "CUP001.0001");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<CARD_NO op='EQ'>{0}</CARD_NO>", debitACC);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>"); 
            #endregion
            return sb.ToString();
        }

        private string GetT24_CommENQ_Content(string tranAMT, string cURR, string CommType)
        {
            StringBuilder sb = new StringBuilder();
            #region IB.CHG.CHK.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "IB.CHG.CHK.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0035");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<TXN_TYPE op='EQ'>{0}</TXN_TYPE>", "AC");
            sb.AppendFormat("<TXN_AMOUNT op='EQ'>{0}</TXN_AMOUNT>", tranAMT);
            sb.AppendFormat("<COMM_TYPE op='EQ'>{0}</COMM_TYPE>", CommType);
            sb.AppendFormat("<CURR op='EQ'>{0}</CURR>", cURR);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_LimitENQ_Content(string debitACC, string gate)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.BP.DEB.LIM.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.BP.DEB.LIM.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "IB001.0010");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<ACCOUNT_NUMBER op='EQ'>{0}</ACCOUNT_NUMBER>", debitACC);
            sb.AppendFormat("<VALUE_DATE op='EQ'>{0}</VALUE_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<TRANS_GATE op='EQ'>{0}</TRANS_GATE>", gate);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_DebLim_Content(string co_Code, string proc_FUNC, string debitACC, string tranAMT, string cURR, string creditACC)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.BP.DEBIT.LIMIT XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "ESCN.BP.DEBIT.LIMIT");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", debitACC + "." + DateTime.Today.ToString("yyyyMMdd") + "." + DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<CURRENCY sp='1' mp='1'>{0}</CURRENCY>", cURR);
            sb.AppendFormat("<DEBIT_ACCT sp='1' mp='1'>{0}</DEBIT_ACCT>", debitACC);
            sb.AppendFormat("<AMOUNT sp='1' mp='1'>{0}</AMOUNT>", tranAMT);
            sb.AppendFormat("<CREDIT_ACCT sp='1' mp='1'>{0}</CREDIT_ACCT>", creditACC);
            sb.AppendFormat("<VALUE_DATE sp='1' mp='1'>{0}</VALUE_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<CARD_NO sp='1' mp='1'>{0}</CARD_NO>", debitACC);
            sb.AppendFormat("<REFERENCE sp='1' mp='1'>{0}</REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<TRANS_GATE sp='1' mp='1'>{0}</TRANS_GATE>", "01");
            //sb.AppendFormat("<CUSTOMER_NO sp='1' mp='1'>{0}</CUSTOMER_NO>", checkCustNo);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", "IB001.0011");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_ECDebLim_Content(string co_Code, string proc_FUNC, string debitACC, string tranAMT, string cURR, string creditACC)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.BP.DEBIT.LIMIT XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "ESCN.BP.DEBIT.LIMIT");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", debitACC + "." + DateTime.Today.ToString("yyyyMMdd") + "." + DateTime.Now.ToString("yyyyMMddHHmmss") + "R");
            sb.AppendFormat("<CURRENCY sp='1' mp='1'>{0}</CURRENCY>", cURR);
            sb.AppendFormat("<DEBIT_ACCT sp='1' mp='1'>{0}</DEBIT_ACCT>", debitACC);
            sb.AppendFormat("<AMOUNT sp='1' mp='1'>{0}</AMOUNT>", tranAMT);
            sb.AppendFormat("<CREDIT_ACCT sp='1' mp='1'>{0}</CREDIT_ACCT>", creditACC);
            sb.AppendFormat("<VALUE_DATE sp='1' mp='1'>{0}</VALUE_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<CARD_NO sp='1' mp='1'>{0}</CARD_NO>", debitACC);
            sb.AppendFormat("<REFERENCE sp='1' mp='1'>{0}</REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            //sb.AppendFormat("<CUSTOMER_NO sp='1' mp='1'>{0}</CUSTOMER_NO>", checkCustNo);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", "IB001.0011");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        public string GetCard_Debit(string pAN, string creditACC, string tranAMT, string tranFee, string merType, string pos_entry, string bankCUPCode, string addResData, string cURR, string co_Code, string msg_Rea)
        {
            StringBuilder sb = new StringBuilder();
            #region Card_Debit
            string dateTime_Now = DateTime.Now.ToString("MMddHHmmss");

            sb.AppendFormat("<PAN>{0}</PAN>", pAN);
            sb.AppendFormat("<AMT_OF_TRAN>{0}</AMT_OF_TRAN>", tranAMT);
            sb.AppendFormat("<TRAN_TIME>{0}</TRAN_TIME>", dateTime_Now);
            sb.AppendFormat("<L_TRAN_TIME>{0}</L_TRAN_TIME>", dateTime_Now.Substring(4));
            sb.AppendFormat("<L_TRAN_DATE>{0}</L_TRAN_DATE>", dateTime_Now.Substring(0, 4));
            sb.AppendFormat("<MER_TYPE>{0}</MER_TYPE>", merType);
            sb.AppendFormat("<POS_ENTRY_MO>{0}</POS_ENTRY_MO>", pos_entry);
            sb.AppendFormat("<POS_CONDITION_CO>{0}</POS_CONDITION_CO>", "00");
            sb.AppendFormat("<POS_PIN_CAPTURE_CO>{0}</POS_PIN_CAPTURE_CO>", "06");
            sb.AppendFormat("<TRAN_FEE_AMT>{0}</TRAN_FEE_AMT>", tranFee);
            sb.AppendFormat("<ACQ_INST_ID_CO>{0}</ACQ_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<FOR_INT_ID_CO>{0}</FOR_INT_ID_CO>", bankCUPCode);
            sb.AppendFormat("<C_ACC_TERMINAL_ID>{0}</C_ACC_TERMINAL_ID>", co_Code.Substring(1, 8));
            sb.AppendFormat("<C_ACC_ID_CO>{0}</C_ACC_ID_CO>", "100000000000000");
            sb.AppendFormat("<ADD_RES_DATA>{0}</ADD_RES_DATA>", addResData);
            sb.AppendFormat("<C_ACC_NAME_LO>{0}</C_ACC_NAME_LO>", "UPPC");
            sb.AppendFormat("<ADD_DATA>{0}</ADD_DATA>", "");
            sb.AppendFormat("<TRAN_CURR_CODE>{0}</TRAN_CURR_CODE>", cURR);
            sb.AppendFormat("<MSG_REA_CO>{0}</MSG_REA_CO>", msg_Rea);
            sb.AppendFormat("<REC_INST_ID_CO>{0}</REC_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<ACC_IDE_1>{0}</ACC_IDE_1>", pAN);
            sb.AppendFormat("<ACC_IDE_2>{0}</ACC_IDE_2>", creditACC);
            #endregion
            return sb.ToString();
        }

        public string GetCard_Debit_With_Pin(string pAN, string creditACC, string tranAMT, string tranFee, string merType, string pos_entry, string bankCUPCode, string addResData, string cURR, string co_Code, string PIN_data, string msg_Rea)
        {
            StringBuilder sb = new StringBuilder();
            #region Card_Debit_With_Pin
            string dateTime_Now = DateTime.Now.ToString("MMddHHmmss");

            sb.AppendFormat("<PAN>{0}</PAN>", pAN);
            sb.AppendFormat("<AMT_OF_TRAN>{0}</AMT_OF_TRAN>", tranAMT);
            sb.AppendFormat("<TRAN_TIME>{0}</TRAN_TIME>", dateTime_Now);
            sb.AppendFormat("<L_TRAN_TIME>{0}</L_TRAN_TIME>", dateTime_Now.Substring(4));
            sb.AppendFormat("<L_TRAN_DATE>{0}</L_TRAN_DATE>", dateTime_Now.Substring(0, 4));
            sb.AppendFormat("<MER_TYPE>{0}</MER_TYPE>", merType);
            sb.AppendFormat("<POS_ENTRY_MO>{0}</POS_ENTRY_MO>", pos_entry);
            sb.AppendFormat("<POS_CONDITION_CO>{0}</POS_CONDITION_CO>", "00");
            sb.AppendFormat("<POS_PIN_CAPTURE_CO>{0}</POS_PIN_CAPTURE_CO>", "06");
            sb.AppendFormat("<TRAN_FEE_AMT>{0}</TRAN_FEE_AMT>", tranFee);
            sb.AppendFormat("<ACQ_INST_ID_CO>{0}</ACQ_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<FOR_INT_ID_CO>{0}</FOR_INT_ID_CO>", bankCUPCode);
            sb.AppendFormat("<C_ACC_TERMINAL_ID>{0}</C_ACC_TERMINAL_ID>", co_Code.Substring(1, 8));
            sb.AppendFormat("<C_ACC_ID_CO>{0}</C_ACC_ID_CO>", "100000000000000");
            sb.AppendFormat("<ADD_RES_DATA>{0}</ADD_RES_DATA>", addResData);
            sb.AppendFormat("<C_ACC_NAME_LO>{0}</C_ACC_NAME_LO>", "UPPC");
            sb.AppendFormat("<ADD_DATA>{0}</ADD_DATA>", "");
            sb.AppendFormat("<PIN_DATA>{0}</PIN_DATA>", PIN_data);
            sb.AppendFormat("<TRAN_CURR_CODE>{0}</TRAN_CURR_CODE>", cURR);
            sb.AppendFormat("<MSG_REA_CO>{0}</MSG_REA_CO>", msg_Rea); 
            sb.AppendFormat("<REC_INST_ID_CO>{0}</REC_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<ACC_IDE_1>{0}</ACC_IDE_1>", pAN);
            sb.AppendFormat("<ACC_IDE_2>{0}</ACC_IDE_2>", creditACC);
            #endregion
            return sb.ToString();
        }

        public string GetCard_Credit(string pAN, string debitACC, string tranAMT, string merType, string bankCUPCode, string cURR, string co_Code)
        {
            StringBuilder sb = new StringBuilder();
            #region Card_Credit
            string dateTime_Now = DateTime.Now.ToString("MMddHHmmss");

            sb.AppendFormat("<PAN>{0}</PAN>", pAN);
            sb.AppendFormat("<AMT_OF_TRAN>{0}</AMT_OF_TRAN>", tranAMT);
            sb.AppendFormat("<TRAN_TIME>{0}</TRAN_TIME>", dateTime_Now);
            sb.AppendFormat("<L_TRAN_TIME>{0}</L_TRAN_TIME>", dateTime_Now.Substring(4));
            sb.AppendFormat("<L_TRAN_DATE>{0}</L_TRAN_DATE>", dateTime_Now.Substring(0, 4));
            sb.AppendFormat("<MER_TYPE>{0}</MER_TYPE>", merType);
            sb.AppendFormat("<POS_ENTRY_MO>{0}</POS_ENTRY_MO>", "012");
            sb.AppendFormat("<POS_CONDITION_CO>{0}</POS_CONDITION_CO>", "00");
            sb.AppendFormat("<ACQ_INST_ID_CO>{0}</ACQ_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<FOR_INT_ID_CO>{0}</FOR_INT_ID_CO>", bankCUPCode);
            sb.AppendFormat("<C_ACC_TERMINAL_ID>{0}</C_ACC_TERMINAL_ID>", co_Code.Substring(1, 8));
            sb.AppendFormat("<C_ACC_ID_CO>{0}</C_ACC_ID_CO>", "100000000000000");
            sb.AppendFormat("<ADD_RES_DATA>{0}</ADD_RES_DATA>", "0       1");
            sb.AppendFormat("<C_ACC_NAME_LO>{0}</C_ACC_NAME_LO>", "汇入汇款");
            sb.AppendFormat("<ADD_DATA>{0}</ADD_DATA>", "ABCDEFGAAA");
            sb.AppendFormat("<TRAN_CURR_CODE>{0}</TRAN_CURR_CODE>", cURR);
            sb.AppendFormat("<REC_INST_ID_CO>{0}</REC_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<ACC_IDE_1>{0}</ACC_IDE_1>", debitACC);
            sb.AppendFormat("<ACC_IDE_2>{0}</ACC_IDE_2>", pAN);
            #endregion
            return sb.ToString();
        }

        public string Get_Card_EC(string pAN, string debitACC, string creditACC, string tranAMT, string merType, string pos_entry, string bankCUPCode, string addResData, string cURR,
                                           string oriData, string co_Code, string msg_Rea)
        {
            StringBuilder sb = new StringBuilder();
            #region Card_EC
            string dateTime_Now = DateTime.Now.ToString("MMddHHmmss");

            sb.AppendFormat("<PAN>{0}</PAN>", pAN);
            sb.AppendFormat("<AMT_OF_TRAN>{0}</AMT_OF_TRAN>", tranAMT);
            sb.AppendFormat("<TRAN_TIME>{0}</TRAN_TIME>", dateTime_Now);
            sb.AppendFormat("<SYS_TRACE_NUM>{0}</SYS_TRACE_NUM>", "");
            sb.AppendFormat("<L_TRAN_TIME>{0}</L_TRAN_TIME>", dateTime_Now.Substring(4));
            sb.AppendFormat("<L_TRAN_DATE>{0}</L_TRAN_DATE>", dateTime_Now.Substring(0, 4));
            sb.AppendFormat("<MER_TYPE>{0}</MER_TYPE>", merType);
            sb.AppendFormat("<POS_ENTRY_MO>{0}</POS_ENTRY_MO>", pos_entry);
            sb.AppendFormat("<POS_CONDITION_CO>{0}</POS_CONDITION_CO>", "00");
            sb.AppendFormat("<POS_PIN_CAPTURE_CO>{0}</POS_PIN_CAPTURE_CO>", "06");
            sb.AppendFormat("<ACQ_INST_ID_CO>{0}</ACQ_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<FOR_INT_ID_CO>{0}</FOR_INT_ID_CO>", bankCUPCode);
            sb.AppendFormat("<RET_REF_NUM>{0}</RET_REF_NUM>", "");
            sb.AppendFormat("<C_ACC_TERMINAL_ID>{0}</C_ACC_TERMINAL_ID>", co_Code.Substring(1, 8));
            sb.AppendFormat("<C_ACC_ID_CO>{0}</C_ACC_ID_CO>", "100000000000000");
            sb.AppendFormat("<C_ACC_NAME_LO>{0}</C_ACC_NAME_LO>", "UPPC");
            sb.AppendFormat("<ADD_RES_DATA>{0}</ADD_RES_DATA>", addResData);
            sb.AppendFormat("<TRAN_CURR_CODE>{0}</TRAN_CURR_CODE>", cURR);
            sb.AppendFormat("<MSG_REA_CO>{0}</MSG_REA_CO>", msg_Rea); 
            sb.AppendFormat("<ORI_DATA_ELE>{0}</ORI_DATA_ELE>", oriData);
            sb.AppendFormat("<REC_INST_ID_CO>{0}</REC_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<ACC_IDE_1>{0}</ACC_IDE_1>", debitACC);
            sb.AppendFormat("<ACC_IDE_2>{0}</ACC_IDE_2>", creditACC);
            #endregion
            return sb.ToString();
        }


        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey)
        {
            string msgContent = base.SendToEAIProcess(body, eAI_MsgKey);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, msgContent);

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(msgContent);
            XmlDocument subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString());
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }

        private string ErrorCodeMapping(string sourceName, string sourceStatus)
        {
            Bankpro.EAI.Component.StatusData status = Bankpro.EAI.Component.ProjectCache.GetInstance().GetStatusData(sourceName, sourceStatus);

            if (status != null)
                return status.m_statusDesc;
            else
                return sourceStatus;

        }
        
    }
}
