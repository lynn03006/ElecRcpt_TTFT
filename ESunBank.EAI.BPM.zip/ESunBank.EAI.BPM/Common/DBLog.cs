﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Service;
using System.Data;

namespace Bankpro.EAI.BPM
{
    class DBLog
    {
        internal DBLog() { }
        private const string m_DatabaseName = "Middleware_TxLog";
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.DBLog");

        #region NDA
        static public DataSet SelectValidNdaByDate(string startDate, string endDate)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();// "SELECT * FROM BroadcastMSMQTalk WHERE 1 = 1 {0}";
                sbCmd.AppendFormat("SELECT * FROM BroadcastMSMQTalk ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [STATUS] = @STATUS ");
                sbCmd.AppendFormat("AND [CreateDate]>=@beginDate AND [CreateDate]<DATEADD(d,1,@endDate) ");
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@STATUS", "999");
                parameters.Add("@beginDate", startDate);
                parameters.Add("@endDate", endDate);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectValidNdaByDate Exception : ", ex);
            }
            return dataset;
        }
        static public DataSet SelectValidNda()
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();// "SELECT * FROM BroadcastMSMQTalk WHERE 1 = 1 {0}";
                sbCmd.AppendFormat("SELECT * FROM BroadcastMSMQTalk ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [STATUS] = @STATUS ");
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@STATUS", "999");

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectValidNDA Exception : ", ex);
            }
            return dataset;
        }
        static public int CancelNda(string btID, int statusFrom, int statusTo)
        {
            int execRows = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();// "SELECT * FROM BroadcastMSMQTalk WHERE 1 = 1 {0}";
                sbCmd.AppendFormat("UPDATE BroadcastMSMQTalk SET [Status] = @STATUS2, [UpdateDate] = GETDATE() ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [BTID] = @BTID AND [Status] = @STATUS1");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@STATUS2", statusTo);
                parameters.Add("@BTID", btID);
                parameters.Add("@STATUS1", statusFrom);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                execRows = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("CancelNda Exception : ", ex);
            }
            return execRows;
        }
        #endregion NDA

        #region RSV
        /// <summary>
        /// 撤銷預約交易
        /// </summary>
        /// <param name="status">撤銷後的Status</param>
        /// <param name="signId">簽約序號</param>
        /// <param name="payAcnt">付款人帳號</param>
        /// <returns></returns>
        static public int CancelRsv(int status, string signId, string payAcnt)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("UPDATE RSVDetail SET {0} ", "[Status] = @Status, [StatusChgDate]=GETDATE(), [UpdateDate] = GETDATE() ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [SignID] = @SignID AND [PayAcnt] = @PayAcnt AND [Status] != @Status1 AND [Status] != @Status2");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@Status", status);
                parameters.Add("@SignID", signId);
                parameters.Add("@PayAcnt", payAcnt);
                parameters.Add("@Status1", 3);
                parameters.Add("@Status2", 4);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                resutl = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("CancelRsv Exception : ", ex);
            }
            return resutl;
        }
        /// <summary>
        /// 交易發送中(Status為2時)，更新MSMQTalk [AdditionalInfo]欄位
        /// </summary>
        /// <param name="additionalInfo">新資料 xml格式</param>
        /// <param name="importId">資料來源TALBE的ID</param>
        /// <returns></returns>
        static public int UpdateMsmqAddinfo(string additionalInfo, string importId, string msmq_BTID)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat(";WITH XMLNAMESPACES ('urn:schema-bankpro-com:multichannel' as ns) ");
                sbCmd.AppendFormat("UPDATE BroadcastMSMQTalk SET [AdditionalInfo]=@AdditionalInfo ");
                sbCmd.AppendFormat("WHERE 1 = 1");
                sbCmd.AppendFormat(" AND [ImportID]=@ImportID");
                sbCmd.AppendFormat(" AND [BTID]=@BTID");
                //sbCmd.AppendFormat(" AND CONVERT(xml,MSMQ_Body).exist('/ns:BankproML/ns:CommMsg/ns:RSV_UID[text()[1]= sql:variable(\"@RSV_UID\")]') = 1");
                sbCmd.AppendFormat(" AND [Status]=2");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@AdditionalInfo", additionalInfo);
                parameters.Add("@ImportID", importId);
                parameters.Add("@BTID", msmq_BTID);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                resutl = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("UpdateMsmqAddinfo Exception : ", ex);
            }
            return resutl;
        }
        /// <summary>
        /// 查詢預約交易簽約資訊
        /// </summary>
        /// <param name="signId">簽約序號</param>
        /// <param name="payAcnt">付款人帳號</param>
        /// <returns></returns>
        static public DataSet SelectRsvBySignidAndPayacnt(string signId, string payAcnt)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  RSVDetail ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [SignID] = @SignID AND [PayAcnt] = @PayAcnt ");
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@SignID", signId);
                parameters.Add("@PayAcnt", payAcnt);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectRsvBySignidAndPayacnt Exception : ", ex);
            }
            return dataset;
        }
        /// <summary>
        /// 查詢預約交易簽約資訊
        /// </summary>
        /// <param name="payAcnt">付款人帳號</param>
        /// <param name="beginDate">簽約日期起始日</param>
        /// <param name="endDate">簽約日期結束日</param>
        /// <param name="status">狀態</param>
        /// <returns></returns>
        static public DataSet SelectRsvByPayacntAndCmsdtInterval(string payAcnt, string beginDate, string endDate, string status)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  RSVDetail ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [PayAcnt] = @PayAcnt  AND [CommissionDate]>=@beginDate AND [commissiondate]<=@endDate ");
                
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@PayAcnt", payAcnt);
                parameters.Add("@beginDate", beginDate);
                parameters.Add("@endDate", endDate);
                if (!string.IsNullOrEmpty(status))
                {
                    sbCmd.Append("AND [Status] = @status ");
                    parameters.Add("@status", status);
                }
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectRsvByPayacntAndCmsdtInterval Exception : ", ex);
            }
            return dataset;
        }
        /// <summary>
        /// 查詢預約交易簽約資訊
        /// </summary>
        /// <param name="signId">簽約序號</param>
        /// <returns></returns>
        static public DataSet SelectRsvBySignid(string signId)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  RSVDetail ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [SignID] = @SignID ");
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@SignID", signId);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectRsvBySignid Exception : ", ex);
            }
            return dataset;
        }
        /// <summary>
        /// 查詢MSMQTalk
        /// </summary>
        /// <param name="importId">資料來源TALBE的ID</param>
        /// <param name="beginDate">建立日期起始日</param>
        /// <param name="endDate">建立日期結束日</param>
        /// <returns></returns>
        static public DataSet SelectMqtkByImpidAndCredtInterval(string importId, string beginDate, string endDate)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  BroadcastMSMQTalk ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [ImportID]=@ImportID AND [CreateDate]>=@beginDate AND [CreateDate]<DATEADD(d,1,@endDate) ");
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@ImportID", importId);
                parameters.Add("@beginDate", beginDate);
                parameters.Add("@endDate", endDate);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectMqtkByImpidAndCredtInterval Exception : ", ex);
            }
            return dataset;
        }

        public int InsertRsvData(string signID, string account, DateTime timeCommission,
                             string frequency, string exec_timing, DateTime timeStart,
                             DateTime timeEnd, object msgBody, string msgKey, DateTime? timeNext)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO [RSVDetail]");
                sbCmd.Append("([RSVID],[SignID],[PayAcnt],[CommissionDate],[Status],[Frequency],[ExecTiming]");
                sbCmd.Append(",[BeginDate],[EndDate],[UC],[Msgkey],[NextExecDate],[CreateDate],[UpdateDate])");
                sbCmd.Append("VALUES");
                sbCmd.Append("(@RSVID, @SignID, @PayAcnt, @CommissionDate, @Status, @Frequency, @ExecTiming");
                sbCmd.Append(",@BeginDate,@EndDate, @UC, @Msgkey, @NextExecDate, GETDATE(), @UpdateDate)");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@RSVID", Guid.NewGuid());
                parameters.Add("@SignID", signID);
                parameters.Add("@PayAcnt", account);
                parameters.Add("@CommissionDate", timeCommission);
                parameters.Add("@Status", "1");
                parameters.Add("@Frequency", frequency);
                if (!string.IsNullOrEmpty(exec_timing))
                    parameters.Add("@ExecTiming", exec_timing);
                else
                    parameters.Add("@ExecTiming", DBNull.Value);
                parameters.Add("@BeginDate", timeStart);
                parameters.Add("@EndDate", timeEnd);
                parameters.Add("@UC", msgBody);
                parameters.Add("@Msgkey", msgKey);
                parameters.Add("@NextExecDate", timeNext);
                //parameters.Add("@CreateDate", DateTime.Now);
                parameters.Add("@UpdateDate", DBNull.Value);

                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                { resutl = db.ExecuteNonQuery(sbCmd.ToString(), parameters); }
                if (resutl == 0)
                { m_log.Error("DB Table InsertRsvData Fail"); }

            }
            catch (Exception ex)
            {
                m_log.ErrorException("DB Table InsertRsvData Fail :", ex);
            }
            return resutl;
        }
        #endregion RSV

        #region BATCH
        static public int InsertBatchData(Guid batID, string batchNo, string payAcnt, string payName,
                                          string msgKey, string transition, string curr, DateTime t_txnDate, string fileName, int status, int txnCount, string totAmt, string uc)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO [BATCHDetail]");
                sbCmd.Append("([BATID],[BatchNo],[PayAcnt],[PayName],[Msgkey],[Transition],[Curr],[TxnDate],");
                sbCmd.Append("[CreateDate],[UpdateDate],[FileName],[Status],[TxnCount],[TotAmt],[UC]) ");
                sbCmd.Append("VALUES");
                sbCmd.Append("(@BATID, @BatchNo, @PayAcnt, @PayName, @Msgkey, @Transition, @Curr, @TxnDate,");
                sbCmd.Append("GETDATE(),@UpdateDate,@FileName, @Status, @TxnCount, @TotAmt, @UC)");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@BATID", batID);
                parameters.Add("@BatchNo", batchNo);
                parameters.Add("@PayAcnt", payAcnt);
                parameters.Add("@PayName", payName);
                parameters.Add("@Msgkey", msgKey);
                parameters.Add("@Transition", transition);
                parameters.Add("@Curr", curr);
                parameters.Add("@TxnDate", t_txnDate);
                //parameters.Add("@CreateDate", DateTime.Now);
                parameters.Add("@UpdateDate", DBNull.Value);
                parameters.Add("@FileName", fileName);
                parameters.Add("@Status", status);
                parameters.Add("@TxnCount", txnCount);
                parameters.Add("@TotAmt", totAmt);
                parameters.Add("@UC", uc);


                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                { resutl = db.ExecuteNonQuery(sbCmd.ToString(), parameters); }
                if (resutl == 0)
                { m_log.Error("DB Table InsertBatchData Fail"); }

            }
            catch (Exception ex)
            {
                m_log.ErrorException("DB Table InsertBatchData Fail :", ex);
            }
            return resutl;
        }

        static public DataSet SelectBatchByPayacntAndDate(string payAcnt, string startDate, string endDate, string msgKey)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  BatchDetail ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [PayAcnt] = @PayAcnt ");
                sbCmd.AppendFormat("AND [TxnDate] BETWEEN @StartDate AND @EndDate ");
                sbCmd.AppendFormat("AND [MsgKey] = @MsgKey ");
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@PayAcnt", payAcnt);
                parameters.Add("@StartDate", startDate);
                parameters.Add("@EndDate", endDate);
                parameters.Add("@MsgKey", msgKey);

                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectBatchByPayacntAndDate Exception : ", ex);
            }
            return dataset;
        }
        static public DataSet SelectBatchByBatchno(string batchNo, string msgKey)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  BatchDetail ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [BatchNo] = @BatchNo ");
                sbCmd.AppendFormat("AND [MsgKey] = @MsgKey ");
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@BatchNo", batchNo);
                parameters.Add("@MsgKey", msgKey);

                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectBatchByPayacntAndDate Exception : ", ex);
            }
            return dataset;
        }


        static public int UpdateMsmqAddinfoByBTID(string additionalInfo, string msmq_BTID)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat(";WITH XMLNAMESPACES ('urn:schema-bankpro-com:multichannel' as ns) ");
                sbCmd.AppendFormat("UPDATE BroadcastMSMQTalk SET [AdditionalInfo]=@AdditionalInfo ");
                sbCmd.AppendFormat("WHERE 1 = 1");
                sbCmd.AppendFormat(" AND [BTID]=@BTID");
                //sbCmd.AppendFormat(" AND CONVERT(xml,MSMQ_Body).exist('/ns:BankproML/ns:CommMsg/ns:BATCH_UID[text()[1]= sql:variable(\"@BATCH_UID\")]') = 1");
                sbCmd.AppendFormat(" AND [Status]=2");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@AdditionalInfo", additionalInfo);
                parameters.Add("@BTID", msmq_BTID);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                resutl = db.ExecuteNonQuery(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("UpdateMsmqAddinfoByRqUID Exception : ", ex);
            }
            return resutl;
        }

        static public DataSet SelectMqtkByImportID(string importId, string label = null)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                sbCmd.AppendFormat("SELECT * FROM  BroadcastMSMQTalk ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [ImportID]=@ImportID ");
                if (!string.IsNullOrEmpty(label))
                {
                    sbCmd.AppendFormat("AND [MSMQ_Label]=@MSMQ_Label ");
                    parameters.Add("@MSMQ_Label", label);
                }
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");
                string sqlCMD = sbCmd.ToString();


                parameters.Add("@ImportID", importId);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectMqtkByImpidAndCredtInterval Exception : ", ex);
            }
            return dataset;
        }
        #endregion BATCH

        #region UCAcctRecon
        static public DataSet SelAccRec(string custNo, string acctNo)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.AppendFormat("SELECT * FROM  IBAccRecSign ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [CustNo] = @CustNo ");
                sbCmd.AppendFormat("AND [AcctNo] = @AcctNo ");
                sbCmd.AppendFormat("ORDER BY [CreateDate] DESC");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@CustNo", custNo);
                parameters.Add("@AcctNo", acctNo);

                string sqlCMD = sbCmd.ToString();
                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
                if (dataset != null && dataset.Tables.Count > 0)
                { m_log.Info("DB [{0}] Rows Found!", dataset.Tables[0].Rows.Count); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SelectUCAcctReconByCustNo Exception : ", ex);
            }
            return dataset;
        }

        static public int InsAccRec(string custNo, string custName, string custComp, string custCompNm, string acctNo, string acctTitle,
                                                    string acctType, string acctComp, string acctCompNm, string contractNo, string iPAddress)
        {
            int resutl = 0;
            try
            {
                StringBuilder sbCmd = new StringBuilder();
                sbCmd.Append("INSERT INTO  [IBAccRecSign]");
                sbCmd.Append("([CustNo],[CustName],[CustComp],[CustCompNm],[AcctNo],[AcctTitle],[AcctType],[AcctComp],[AcctCompNm],");
                sbCmd.Append("[ContractNo],[Status],[StatusChgDate],[IPAddress],[CreateDate]) ");
                sbCmd.Append("VALUES");
                sbCmd.Append("(@CustNo, @CustName, @CustComp, @CustCompNm, @AcctNo, @AcctTitle, @AcctType,");
                sbCmd.Append("@AcctComp, @AcctCompNm, @ContractNo, 0, GETDATE(), @IPAddress, GETDATE())");
                sbCmd.Append("ORDER BY [CreateDate] DESC");

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@CustNo", custNo);
                parameters.Add("@CustName", custName);
                parameters.Add("@CustComp", custComp);
                parameters.Add("@CustCompNm", custCompNm);
                parameters.Add("@AcctNo", acctNo);
                parameters.Add("@AcctTitle", acctTitle);
                parameters.Add("@AcctType", acctType);
                parameters.Add("@AcctComp", acctComp);
                parameters.Add("@AcctCompNm", acctCompNm);
                parameters.Add("@ContractNo", contractNo);
                //parameters.Add("@Status", status);
                //parameters.Add("@StatusChgDate", statusChgDate);
                parameters.Add("@IPAddress", iPAddress);
                //parameters.Add("@CreateDate", DateTime.Now);

                using (Database db = DatabaseManager.CreateDatabase(m_DatabaseName))
                { resutl = db.ExecuteNonQuery(sbCmd.ToString(), parameters); }
                if (resutl == 0)
                { m_log.Error("DB Table InsertIBAccRecSignData Fail"); }
            }
            catch (Exception ex)
            {
                m_log.ErrorException("InsAccRec Exception : ", ex);
            }
            return resutl;
        }

        static public DataSet UpdAccRecStatus(string acctNo, string status, string iPAddress)
        {
            DataSet dataset = null;
            try
            {
                StringBuilder sbCmd = new StringBuilder();

                if (status == "1" || status == "")
                {
                    sbCmd.AppendFormat("UPDATE IBAccRecSign SET [Status]=0, ");
                }
                else if (status == "0")
                {
                    sbCmd.AppendFormat("UPDATE IBAccRecSign SET [Status]=1, ");
                }
                sbCmd.AppendFormat("[StatusChgDate]=GETDATE(), ");
                sbCmd.AppendFormat("[IPAddress]=@IPAddress ");
                sbCmd.AppendFormat("WHERE 1 = 1 ");
                sbCmd.AppendFormat("AND [AcctNo]=@AcctNo ");
                sbCmd.AppendFormat("AND [Status]=@Status");
                string sqlCMD = sbCmd.ToString();

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@AcctNo", acctNo);
                parameters.Add("@Status", status);
                parameters.Add("@IPAddress", iPAddress);

                Database db = DatabaseManager.CreateDatabase(m_DatabaseName);
                dataset = db.ExecuteDataSet(sqlCMD, parameters);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("UpdAccRecStatus Exception : ", ex);
            }
            return dataset;
        }
        #endregion UCAcctRecon
    }
}
