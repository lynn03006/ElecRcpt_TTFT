﻿using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bankpro.EAI.BPM.Common
{
    class UCCommonUtil
    {
        public string GetRsStringFromRqDic(Dictionary<string, string> rqHeadDic, Dictionary<string, string> rqBodyDic, Dictionary<string, string> otherBodyDic)
        {
            UcHead rs_uchead = new UcHead();
            UcBody rs_ucbody = new UcBody();
            Dictionary<string, string> newBodyDic = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> kv in rqBodyDic)
            {
                switch (kv.Key)
                {
                    case "2001":
                    case "2002":
                    case "2003":
                    case "2004":
                    case "2005":
                    case "2006":
                    case "2039":
                        newBodyDic.Add(kv.Key, kv.Value);
                        break;
                }
            }
            foreach (KeyValuePair<string, string> kv in otherBodyDic)
            {
                newBodyDic.Add(kv.Key, kv.Value);
            }
            string rs_head = rs_uchead.GetRSHeadString(rqHeadDic, "");
            string rs_body = rs_ucbody.GetUcStringFromDic(newBodyDic);
            return rs_head + rs_body;
        }

        public static void ParseUcToDic(UcControler uCcontroler, string ucString, out Dictionary<string, string> ucHeadDic, out Dictionary<string, string> ucBodyDic)
        {
            if (string.IsNullOrEmpty(ucString))
            {
                ucHeadDic = new Dictionary<string, string>();
                ucBodyDic = new Dictionary<string, string>();
                return;
            }

            UcBody ucBody = new UcBody();
            ucHeadDic = uCcontroler.UC2T24_Head(ucString);
            ucBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);
        }
    }
}
