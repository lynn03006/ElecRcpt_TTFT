﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace Bankpro.EAI.BPM
{
    class RDBUtil
    {
        private static readonly string ns = "urn:schema-bankpro-com:multichannel";
        internal static List<Record> GetRdbRsList<T>(string xmlString) where T : IXMLRECORD
        {
            List<Record> returnLst = new List<Record>();

            XmlDocument xdoc = new XmlDocument();
            xdoc.LoadXml(xmlString);
            XmlNamespaceManager nsMgr = new XmlNamespaceManager(xdoc.NameTable);
            nsMgr.AddNamespace("ns", ns);
            var statusCode = xdoc.SelectSingleNode("/ns:BankproML/ns:CommMsg/ns:Status/ns:StatusCode", nsMgr);
            var statusDesc = xdoc.SelectSingleNode("/ns:BankproML/ns:CommMsg/ns:Status/ns:StatusDesc", nsMgr);
            var jsonDataNLst = xdoc.SelectSingleNode("/ns:BankproML/ns:CommMsg/ns:JsonData", nsMgr);
            if (statusCode == null)
            { throw new ApplicationException("RDB Response Error!"); }
            else if (statusCode.InnerText != "0")
            { throw new ApplicationException(string.Format("{0}-{1}", statusCode.InnerText, statusDesc.InnerText)); }

            if (jsonDataNLst != null)
            {
                returnLst = new List<Record>();
                var recordList = xdoc.GetElementsByTagName("Array");
                foreach (XmlElement record in recordList)
                {
                    var recid_XE = record.GetElementsByTagName("RECID");
                    var rowInXMLRECORD_XE = record.GetElementsByTagName("row");
                    if (recid_XE != null && recid_XE.Count > 0)
                    {
                        string xmlJS = rowInXMLRECORD_XE != null && rowInXMLRECORD_XE.Count > 0 ?
                                       JsonConvert.SerializeXmlNode(rowInXMLRECORD_XE[0], Newtonsoft.Json.Formatting.None, true) :
                                       null;
                        T xmlrecord = JsonConvert.DeserializeObject<T>(xmlJS);
                        returnLst.Add(new Record() { RECID = recid_XE[0].InnerText, XMLRECORD = xmlrecord });
                    }
                }
            }
            return returnLst;
        }
        internal static List<Record> GetRdbRsHisList<T>(string xmlString) where T : IXMLRECORD
        {
            var recordLst = GetRdbRsList<T>(xmlString);
            var newRecordLst = recordLst.GroupBy(p => p.RECID.Split(';')[0])
                                        .SelectMany(a => a.Where(b => b.RECID.Split(';')[1] == a.Max(c => Convert.ToInt32(c.RECID.Split(';')[1])).ToString()))
                                        .ToList();
            return newRecordLst;
        }
        internal static string GetFieldString(object obj, bool returnFirst)
        {
            string rtnStr = null;
            if (obj == null) { return null; }
            if (obj is string) { return obj.ToString(); }

            JArray obJArr = new JArray();
            if (obj is JArray)
            { obJArr = (obj as JArray); }

            int cnt = obJArr.Count;
            if (cnt == 0) { return null; }

            if (returnFirst)
            {
                if (obJArr[0] is JValue)
                { rtnStr = obJArr[0].ToString(); }
                else if (obJArr[0] is JObject && (obJArr[0] as JObject)["#text"] != null)
                { rtnStr = (obJArr[0] as JObject)["#text"].ToString(); }
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i <= cnt - 1; i++)
                {
                    if (obJArr[i] is JValue)
                    { sb.Append(obJArr[i].ToString()); }
                    else if (obJArr[i] is JObject && (obJArr[i] as JObject)["#text"] != null)
                    { sb.Append((obJArr[i] as JObject)["#text"].ToString()); }
                }
                rtnStr = sb.ToString();
            }
            return rtnStr;
        }

        internal static string GetRdbMsgContent(string msgId, string rdbController, T24QueryInfo t24Qi)
        {
            var jsonT24QiString = JsonConvert.SerializeObject(t24Qi);
            var xmlT24QiString = JsonConvert.DeserializeXmlNode(jsonT24QiString, "JsonData", true);

            var eaiT24QiString = GetRDBEaiXmlStr(msgId, rdbController, "POST", xmlT24QiString.InnerXml);
            return eaiT24QiString;
        }

        internal static string GetRDBEaiXmlStr(string msgId, string controller, string httpMethod, string msg)
        {
            XmlDocument xmldoc = new XmlDocument();
            var eleBankproML = xmldoc.CreateElement("BankproML");
            eleBankproML.SetAttribute("xmlns", "urn:schema-bankpro-com:multichannel");
            {
                var eleSignonRq = xmldoc.CreateElement("SignonRq");
                {
                    var eleSignonPswd = xmldoc.CreateElement("SignonPswd");
                    {
                        var eleCustId = xmldoc.CreateElement("CustId");
                        {
                            var eleSPName = xmldoc.CreateElement("SPName");
                            eleSPName.InnerText = "EAI";
                            eleCustId.AppendChild(eleSPName);
                            var eleCustLoginId = xmldoc.CreateElement("CustLoginId");
                            eleCustLoginId.InnerText = "EAI";
                            eleCustId.AppendChild(eleCustLoginId);
                        }
                        eleSignonPswd.AppendChild(eleCustId);
                    }
                    eleSignonRq.AppendChild(eleSignonPswd);
                    var eleCustPswd = xmldoc.CreateElement("CustPswd");
                    {
                        var eleCryptType = xmldoc.CreateElement("CryptType");
                        eleCryptType.InnerText = "DES1";
                        eleCustPswd.AppendChild(eleCryptType);
                        var elePswd = xmldoc.CreateElement("CryptType");
                        elePswd.InnerText = "NONE";
                        eleCustPswd.AppendChild(elePswd);
                    }
                    eleSignonRq.AppendChild(eleCustPswd);
                    var eleClientDt = xmldoc.CreateElement("ClientDt");
                    eleClientDt.InnerText = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    eleSignonRq.AppendChild(eleClientDt);
                }
                eleBankproML.AppendChild(eleSignonRq);
                var eleCommMsg = xmldoc.CreateElement("CommMsg");
                {
                    var eleSPName = xmldoc.CreateElement("SPName");
                    eleSPName.InnerText = "EAI";
                    eleCommMsg.AppendChild(eleSPName);
                    var eleMsgId = xmldoc.CreateElement("MsgId");
                    eleMsgId.InnerText = msgId;
                    eleCommMsg.AppendChild(eleMsgId);
                    var eleRqUID = xmldoc.CreateElement("RqUID");
                    eleCommMsg.AppendChild(eleRqUID);
                    var eleControllerName = xmldoc.CreateElement("ControllerName");
                    eleControllerName.InnerText = controller;
                    eleCommMsg.AppendChild(eleControllerName);
                    var eleHttpMethod = xmldoc.CreateElement("HttpMethod");
                    eleHttpMethod.InnerText = httpMethod;
                    eleCommMsg.AppendChild(eleHttpMethod);

                    eleCommMsg.InnerXml += msg;
                }
                eleBankproML.AppendChild(eleCommMsg);
            }
            xmldoc.AppendChild(eleBankproML);
            return xmldoc.InnerXml;
        }
    }
}
