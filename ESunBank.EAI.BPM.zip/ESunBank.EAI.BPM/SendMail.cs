using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Service;
using Bankpro.EAI.SendMail;

namespace Bankpro.EAI.BPM
{
    internal class SendMail
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.SendMail");

        /// <summary>
        /// �H�o���~�l��
        /// </summary>

        internal SendMail()
        {
        }

        /// <summary>
        /// �H�e�����覡����A�H�קK�]�H�omail�Ӽv�T�ثe������y�{
        /// </summary>
        /// <param name="strSubject"></param>
        /// <param name="strPriority"></param>
        /// <param name="strBody"></param>
        internal void Send(string strSubject, string strPriority, string strBody)
        {
            try
            {
                SendMaildelegate sendmaildelegate = new SendMaildelegate(sendmail);
                sendmaildelegate.BeginInvoke(strSubject, strPriority, strBody, null, null);
            }
            catch (Exception ex)
            {
                m_log.ErrorException("SendMail Exception:", ex);
                throw new ApplicationException(string.Format("SendMail Exception:{0}<br>{1}",ex.Message,ex.StackTrace));
            }
        }

        public delegate void SendMaildelegate(string strSubject, string strPriority, string strBody);
        private void sendmail(string strSubject, string strPriority, string strBody)
        {
            m_log.Debug("Start Send Error Mail>>>>");
            //m_log.Debug("Subject=[{0}], Priority=[{1}], Body=[{2}]", strSubject, strPriority, strBody);

            Mail mail = new Mail();
            mail.Send(strSubject, strBody, strPriority);
            m_log.Debug("<<<<<<Send Error Mail END");
        }
    }
}
