using System;
using System.Xml;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;

using Microsoft.Service;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;
using Microsoft.EAIServer;


namespace Bankpro.EAI.BPM
{
    public abstract class BinaryBaseBpmAdapter : BaseBpmAdapter {


        protected BinaryBaseBpmAdapter() { 
        
        }

        public override bool IsXmlVersionImplemented { get { return false; } }

        public override bool IsBinaryVersionImplemented { get { return true; } }

        public override AppBinaryExecResult Run(EaiContext context, string correlationID, string txID, HostTxDef txDef, HostMessage requestMsg) {
            context.Set("WriteApRsStatus", false);//Ap��Status�v�Ѥl����নEAI�з�RS, �i�DBankproML.cs���n�A�g�@��
            return RunImpl(context, correlationID, txID, txDef, requestMsg);
        }



        protected abstract AppBinaryExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, HostMessage requestMsg);






    }
}
