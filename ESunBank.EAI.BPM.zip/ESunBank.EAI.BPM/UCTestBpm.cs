﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Net;
using System.IO;

using Microsoft.Service;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;
using Microsoft.EAIServer;

using Bankpro.EAI.BPM;
using Bankpro.EAI.Utility;
using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;
using Bankpro.EAI.Component.Utils;

namespace Bankpro.EAI.BPM
{
    public class UCTestBpm : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.UCTestBpm");
        public String DefineXmlPath = "D:/Middleware/UCTestXML/";
        public String filePath = "D:/Middleware/UCTestXML/file/";

        public UCTestBpm()
        {
        }


        /// <summary>
        /// timeout standard status code = 6005
        /// </summary>
        /// <param name="context"></param>
        /// <param name="correlationID"></param>
        /// <param name="txID"></param>
        /// <param name="txDef"></param>
        /// <param name="requestXml"></param>
        /// <returns></returns>
        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
              return DoDefaultProcess(context, correlationID, txID, txDef, requestXml); 
        }

        private AppXmlExecResult DoDefaultProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {

            m_log.Info("Doing TEST BPM Process");

            XmlDocument responseXml = null;
            UcControler m_ucControler = new UcControler();
            UcBody m_ucBody = new UcBody();

            Dictionary<string, string> rspDiy = new Dictionary<string, string>();
            String fileName = String.Empty;
            String fileFlag = String.Empty;
            StringBuilder afterRS = new StringBuilder();

            XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
            String ucReqData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();

            //取得Request header
            Dictionary<string, string> reqHeaderDiy = m_ucControler.UC2T24_Head(ucReqData);

            //取得Request要素集, 156 - 277
            String ucTypeStr = ucReqData.Substring(156, 123);

            //取得RESPONSE Body
            XmlDocument respXML = GetXmlDoc(txID);
            XmlHelper xmlRespHelper = XmlHelper.GetInstance(respXML);
            String rspStr = xmlRespHelper.GetXPath(respXML, "//Response").Trim();

            m_log.Info("rspStr = {0}", rspStr);

            //判斷是否為ENQ且需要上傳FTP
            int fileNameIdx = rspStr.IndexOf("zzzx");
            if (fileNameIdx > 0) {
                rspDiy = m_ucBody.ParserString(rspStr);
                rspDiy.TryGetValue("zzzx", out fileName);
                if (!String.IsNullOrEmpty(fileName))
                    UploadFTP(filePath, fileName);

                m_log.Info("fileName= {0}", fileName);
            }

            //組成Response Header
            StringBuilder headString = new StringBuilder();
            Dictionary<String, String> rs_healDataDiy = new Dictionary<String, String>(reqHeaderDiy);
            foreach (String keys in rs_healDataDiy.Keys)
            {           
                switch (keys)
                {
                    case "FCompany":
                        headString.Append(rs_healDataDiy["RCompany"]);
                        break;
                    case "RCompany":
                        headString.Append(rs_healDataDiy["FCompany"]);
                        break;
                    case "KeyCode":
                        headString.Append("SET010");
                        break;
                    case "NetType":
                        headString.Append(String.IsNullOrEmpty(fileFlag) ? "0" : "1");
                        break;
                    default:
                        headString.Append(rs_healDataDiy[keys]);
                        break;
                }
            }

            headString.Remove(headString.Length-1,1);

            m_log.Info("headString = " + headString.ToString());

            //Response Header + 要素集 + Body
            afterRS.Append(headString);
            afterRS.AppendFormat("{0}{1}", ucTypeStr, rspStr);

            responseXml = base.TransformCommMsg("0", "Info", "交易完成", afterRS.ToString());

            return base.BuildExecResult(context, responseXml);
        }

        /// <summary>
        ///抓取XML設定檔
        ///</summary>
        private XmlDocument GetXmlDoc(String xmlName)
        {
            XmlDocument defXML = new XmlDocument();
            defXML.Load(string.Format("{0}test_{1}.xml", DefineXmlPath, xmlName));

            return defXML;
        }

        /// <summary>
        ///上傳FTP
        ///</summary>
        public void UploadFTP(String filePath, String fileName)
        {

            m_log.Info("Upload File Start, file path = {0}", filePath);

            FtpWebRequest request = null;
            StreamReader sourceStream = null;
            Stream requestStream = null;
            FtpWebResponse response = null;

            //FTP path
            String ftpIP = ProjectConfig.GetInstance().UploadFtpIP;
            String ftpFld = ProjectConfig.GetInstance().UploadFtpFolder;
            String ftpPath = String.Concat(ftpIP, ftpFld);

            String fileFullPath = String.Concat(filePath, fileName);
            String ftpFullPath = String.Concat(ftpPath, fileName);

            //FTP userName, passWord
            String ftpUser = ProjectConfig.GetInstance().UploadFtpUser;
            String ftpPwd = Encoding.UTF8.GetString(Convert.FromBase64String(ProjectConfig.GetInstance().UploadFtpPassword));

            m_log.Info("Upload File Start, ftp path = {0}", ftpFullPath);

            try
            {
                // Get the object used to communicate with the server.
                request = (FtpWebRequest)WebRequest.Create(ftpFullPath);
                request.Method = WebRequestMethods.Ftp.UploadFile;

                // This example assumes the FTP site uses anonymous logon.
                request.Credentials = new NetworkCredential(ftpUser, ftpPwd);

                // Copy the contents of the file to the request stream.
                sourceStream = new StreamReader(fileFullPath);
                //byte[] fileContents = Encoding.UTF8.GetBytes(sourceStream.ReadToEnd());
                byte[] fileContents = Encoding.GetEncoding("GBK").GetBytes(sourceStream.ReadToEnd());

                sourceStream.Close();

                request.ContentLength = fileContents.Length;

                requestStream = request.GetRequestStream();
                requestStream.Write(fileContents, 0, fileContents.Length);
                requestStream.Close();

                response = (FtpWebResponse)request.GetResponse();

                m_log.Info("Upload File Complete, status = {0}", response.StatusDescription);

                response.Close();

            }
            catch (WebException ex)
            {
                m_log.Error("Upload File Error, status = {0}", ((FtpWebResponse)ex.Response).StatusDescription);
                throw new Exception(ex.Message);
            }
            finally
            {

            }

        }
        
    }
}
