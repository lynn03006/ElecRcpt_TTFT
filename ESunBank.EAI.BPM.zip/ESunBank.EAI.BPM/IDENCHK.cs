﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Text;

using Microsoft.Service;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;
using Microsoft.EAIServer;

using Bankpro.EAI.BPM;
using Bankpro.EAI.Utility;
using Bankpro.EAI.Component;

namespace Bankpro.EAI.BPM
{
    public class IDENCHK : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.IDENCHK");

        public IDENCHK()
        {

        }

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            XmlDocument responseXml = new XmlDocument();
            EaiResponse eaiRs = null;

            try
            {
                //獲取必要資訊 
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string strCUSTID = xmlHelper.GetXPath(requestXml, "//CUSTID");
                string strUserIDEN = xmlHelper.GetXPath(requestXml, "//IDEN");

                m_log.Info("CUSTID = [{0}] , UserIDEN = [{1}]", strCUSTID, strUserIDEN);

                // 發送ESCN.IB.IDEN.RECO.CHK取的密碼
                string strIDENCHKBody = GetIDENCHKbody(strCUSTID);
                XmlDocument xmlIDENCHK_Req = new XmlDocument();
                xmlIDENCHK_Req.LoadXml(SendToEAIProcess(strIDENCHKBody, "ESCN.IB.IDEN.RECO.CHK"));
                AppXmlExecResult result_IDENCHK = Send1Recv1ByAA(context, "ESCN.IB.IDEN.RECO.CHK", xmlIDENCHK_Req);

                XmlDocument xmlIDENCHK_Resp = new XmlDocument();
                xmlIDENCHK_Resp = result_IDENCHK.ResponseXml;
                if (result_IDENCHK.ErrCode != "0")
                    throw new ApplicationException("子交易ESCN.IB.IDEN.RECO.CHK發生錯誤。");

                xmlHelper = XmlHelper.GetInstance(result_IDENCHK.ResponseXml);
                string strHostIDENCHK = xmlHelper.GetXPath(xmlIDENCHK_Resp, "//IDEN ");

                //比對
                bool chkIDEN = strHostIDENCHK.Equals(strUserIDEN);
                string strT24DATA = chkIDEN ?
                    "<RSP_MSG_DATA><RETURN_CODE>E-000000</RETURN_CODE><RSP_PROC_RET>SUCC</RSP_PROC_RET></RSP_MSG_DATA>" ://True
                    "<RSP_MSG_DATA><RETURN_CODE>E-999999</RETURN_CODE><RSP_PROC_RET>FAIL</RSP_PROC_RET></RSP_MSG_DATA>";//False

                m_log.Info("UserIDEN = [{0}] , HostIDEN = [{1}] , Check Result = [{2}]", strUserIDEN, strHostIDENCHK, chkIDEN);
                responseXml = base.TransformCommMsg("0", "Info", "交易完成", strT24DATA);
                eaiRs = EaiResponse.GetInstance(true);
                eaiRs.SetRespXml(responseXml);
            }
            catch (Exception ex)
            {
                eaiRs = EaiResponse.GetInstance(false);
                eaiRs.SetEaiError(eaiRs.EaiErrCode, ex.ToString(), "");
                responseXml = TransformCommMsg("9999", "Error", ex.ToString(), "");
                m_log.ErrorException("Error executing Run():" + ex.ToString(), ex);
            }
            finally
            {
                m_log.Debug("Run end<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
            }

            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }

        private string GetIDENCHKbody(string strCUSTID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.Append("<SIGN_ON_ID></SIGN_ON_ID>");
            sb.Append("<SIGN_ON_PSWD></SIGN_ON_PSWD>");
            sb.Append("<SIGN_ON_BRH></SIGN_ON_BRH>");
            sb.Append("<PROC_FUNC>S</PROC_FUNC>");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.Append("<REQ_TXN_CODE>ESCN.IB.IDEN.RECO.CHK</REQ_TXN_CODE>");
            sb.Append("<REQ_TXN_CODE_S>INPUT</REQ_TXN_CODE_S>");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", strCUSTID);
            sb.Append("<ITF.MSGKEY op=\"EQ\">IB001.0004</ITF.MSGKEY>");
            sb.Append("<CHANNEL_ID op=\"EQ\">UC</CHANNEL_ID>");
            sb.Append("<TERM_NO op=\"EQ\">C01A000T01</TERM_NO>");
            sb.Append("<EXT_BUSS_DATE op=\"EQ\">20171109</EXT_BUSS_DATE>");
            sb.Append("<EXT_REFERENCE op=\"EQ\">0000000237</EXT_REFERENCE>");
            sb.Append("<EXT_TXN_TIME op=\"EQ\">20171109034852</EXT_TXN_TIME>");
            sb.Append("<IDEN sp=\"1\" mp=\"1\"></IDEN>");
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");

            return sb.ToString();
        }
    }
}
