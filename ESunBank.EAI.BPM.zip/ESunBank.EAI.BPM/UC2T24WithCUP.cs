﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

using Microsoft.Service;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;
using Microsoft.EAIServer;

using Bankpro.EAI.BPM;
using Bankpro.EAI.Utility;
using Bankpro.EAI.Component;

using System.Xml.Linq;
using System.Linq;
using Bankpro.EAI.Component.Xml;
using Bankpro.EAI.BPM.Common;

namespace Bankpro.EAI.BPM
{
    public class UC2T24WithCUP : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.UC2T24WithCUP");
        //private UcControler m_UcControler;
        private String m_SendURL = ProjectConfig.GetInstance().Send_URL;
        private Int32 m_PostTimeOut = ProjectConfig.GetInstance().PostTimerOut * 1000;
        private string bnknbr = "0345";
        private string bRNNO = "010002";

        //private XferVariables xv = XferVariables.GetInstance();

        public UC2T24WithCUP()
        {
        }




        /// <summary>
        /// timeout standard status code = 6005
        /// </summary>
        /// <param name="context"></param>
        /// <param name="correlationID"></param>
        /// <param name="txID"></param>
        /// <param name="txDef"></param>
        /// <param name="requestXml"></param>
        /// <returns></returns>
        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            switch (txID)
            {
                case "ES_2010504"://子帳戶信息查詢
                    return Do_2010504_Process(context, correlationID, txID, txDef, requestXml);
                case "ES_2010789":  //账户明细查询请求 
                    return DoES_2010789Process(context, correlationID, txID, txDef, requestXml);
                case "ES_2010766":  //行内转账请求
                    return DoES_2010766Process(context, correlationID, txID, txDef, requestXml);
                case "ES_2010767":  //跨行转账请求
                    return DoES_2010767Process(context, correlationID, txID, txDef, requestXml);
                case "ES_2010774":  //通知取款
                    return DoES_2010774Process(context, correlationID, txID, txDef, requestXml);
                case "ES_2010782":  //活期轉定期请求
                    return DoES_2010782Process(context, correlationID, txID, txDef, requestXml); 
                case "ES_2010783": //銀聯卡定轉活
                    return DoES_2010783Process(context, correlationID, txID, txDef, requestXml);
                case "ES_2010784": //活期轉通知存款
                    return DoES_2010784Process(context, correlationID, txID, txDef, requestXml);
                default:
                    return DoDefaultProcess(context, correlationID, txID, txDef, requestXml);
                    
            }
        }

        private AppXmlExecResult DoDefaultProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            EaiResponse eaiRs = null;
            XmlDocument responseXml = null;
            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }

        private AppXmlExecResult Do_2010504_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string rq_t24_data = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", rq_t24_data);

                #region 分析報文
                UcControler uCcontroler = new UcControler();
                UcBody ucBody = new UcBody();
                Dictionary<string, string> rqHeadDic = uCcontroler.UC2T24_Head(rq_t24_data);
                Dictionary<string, string> rqBodyDic = ucBody.ParserString(uCcontroler.m_ucbody);

                string AccNo = string.Empty;
                rqBodyDic.TryGetValue("4300", out AccNo);
                #endregion 分析報文

                if (AccNo.Length > 15)//Card
                {
                    return DoCUSTOACCTProcess(context, uCcontroler, xmlHelper, requestXml, rqHeadDic, rqBodyDic, txID, AccNo);
                }
                else //ACC
                {
                    XmlDocument subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                    return Send1Recv1(m_log, context, subRqXml);
                }
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("Do_2010504_Process Error TxID=[{0}] ", txID) + ex.ToString(), ex);
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                return base.BuildExecResult(context, responseXml);
            }
        }

        private AppXmlExecResult DoES_2010789Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            //判別某域符合時,發送到CUP,要不走原路的T24
            XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
            string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
            m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);
            UcControler m_UcControler = new UcControler();
            string t24Ofs = m_UcControler.UC2T24(ucData);

            string check = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4306", out check);

            m_log.Info("AppXmlExecResult RunImpl.UC.4306={0}", check);

            switch (check)
            {
                case "1":
                    //UC2CUP
                    string cardNo = string.Empty;
                    m_UcControler.m_ucBodyDiy.TryGetValue("4300", out cardNo);
                    string startData = string.Empty;
                    m_UcControler.m_ucBodyDiy.TryGetValue("4119", out startData);
                    string endData = string.Empty;
                    m_UcControler.m_ucBodyDiy.TryGetValue("4120", out endData);

                    m_log.Info("AppXmlExecResult RunImpl.UC.4300={0}&&4119={1}&&4120={2}", cardNo, startData, endData);

                    CMMControler m_CMMControler = new CMMControler();
                    string body = m_CMMControler.Get5626ContentMsg("5626", bnknbr, bRNNO, "000001", cardNo, "0", startData, endData);
                    AppXmlExecResult cup_result = SendMsgToEAIProcess(context, body, "5626");
                    //取得結果,存成DIC
                    Dictionary<string, List<string>> cupDic = m_CMMControler.GetXMLFieldValueCUP(cup_result.ResponseXml.OuterXml);
                    List<string> fileData = CUP2UC_File_5612(cupDic);
                    m_UcControler.CreateEnqFileToUC(fileData, true);//將DIC中的資料落成檔案
                    Dictionary<string, string> totalDic = CUP2UC_RS_5612(cupDic, m_UcControler.enqFileName);
                    string afterRS = m_UcControler.GetCUPToUCRS(totalDic); //需將UC的結果回傳回去(改變RS)
                    m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
                    XmlDocument rs_CUP = base.TransformCommMsg(cup_result.EaiRs.EaiErrCode, cup_result.EaiRs.EaiErrText, cup_result.EaiRs.EaiErrDetail, afterRS);
                    return base.BuildExecResult(context, rs_CUP);
                default:
                    XmlDocument subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                    return Send1Recv1(m_log, context, subRqXml);
            }
        }

        private AppXmlExecResult DoES_2010766Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            //判別某域符合時,發送到CUP,要不走原路的T24
            XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
            string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
            m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);
            UcControler m_UcControler = new UcControler();
            string t24Ofs = m_UcControler.UC2T24(ucData);

            #region Get UC Field
            string accType = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4306", out accType);
            string creditACC = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4161", out creditACC);
            string debitACC = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4157", out debitACC);
            string tranAMT = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4100", out tranAMT);
            string cURR = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4118", out cURR);
            string creditName = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4900", out creditName);

            string refContent = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4732", out refContent); //付款用途
            string remarks = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4658", out remarks); //交易附言
            string fifler = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4835", out fifler);  //备用字段 
            string transGate = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("Channel", out transGate);  //交易渠道 2019.08.22
            #endregion

            transGate = (transGate == "12") ? "PHONE" : "PIB";
            m_log.Info("AppXmlExecResult RunImpl.UC.4306(acType)={0}&&4161(credit)={1}&&4157(debit)={2}&&4100(amt)={3}&&4118(curr)={4}&&4900(creditName)={5}&&Channel={6}", accType, creditACC, debitACC, tranAMT, cURR, creditName, transGate);

            XmlDocument subRqXml;

            if (accType == "1") //Card VS ??
            {
                //Get Co.Code 
                string bodyCardEnq = GetT24_CardENQ_Content(debitACC);
                AppXmlExecResult cardEnq_result = SendMsgToEAIProcess(context, bodyCardEnq, "ESCN.CARD.CUSDATA.ENQ");
                XmlHelper xmlHelperCardEnq = XmlHelper.GetInstance(cardEnq_result.ResponseXml);
                string co_Code = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//CUS_CO_CODE").Trim();
                string checkCustNo = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//_x0040_ID").Trim();
                
                if (string.IsNullOrEmpty(co_Code))
                {
                    co_Code = "CN0010001"; //Default value, and check 
                    //Send Mail
                    new SendMail().Send("Do Enq Card Can not find Data From T24", "6", string.Format("Do Enq Card Can not find Data From T24, RQ:{0}", requestXml));
                }

                if (creditACC.Length > 15)// Card VS Card
                    return DoCardVsCardProcess(context, m_UcControler, debitACC, creditACC, tranAMT, cURR, creditName, refContent, remarks, fifler, co_Code, checkCustNo, transGate);
                else // Card VS ACC
                    return DoCardVsACCProcess(context, m_UcControler, debitACC, creditACC, tranAMT, cURR, creditName, refContent, remarks, fifler, co_Code, checkCustNo, transGate);
            }
            else if (accType == "2") //ACC VS ??
            {
                if (creditACC.Length > 15)
                {
                    string bodyCardEnq = GetT24_CardENQ_Content(creditACC);
                    AppXmlExecResult cardEnq_result = SendMsgToEAIProcess(context, bodyCardEnq, "ESCN.CARD.CUSDATA.ENQ");
                    XmlHelper xmlHelperCardEnq = XmlHelper.GetInstance(cardEnq_result.ResponseXml);
                    string co_Code = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//CUS_CO_CODE").Trim();
                    // ACC VS Card
                    return DoACCVsCardProcess(context, m_UcControler, debitACC, creditACC, tranAMT, cURR, creditName, refContent, remarks, fifler, co_Code, transGate);
                }
                else // ACC VS ACC
                {
                    subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                    return Send1Recv1(m_log, context, subRqXml);
                }
            }
            else // ACC VS ACC
            {
                subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                return Send1Recv1(m_log, context, subRqXml);
            }

        }

        private AppXmlExecResult DoES_2010767Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            //判別某域符合時,發送到CUP,要不走原路的T24
            XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
            string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
            m_log.Info("AppXmlExecResult RunImpl.UC.RQ2010767={0}", ucData);
            UcControler m_UcControler = new UcControler();
            string t24Ofs = m_UcControler.UC2T24(ucData);
            #region Get UC Field
            string creditACC = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4161", out creditACC);
            string debitACC = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4157", out debitACC);
            string tranAMT = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4100", out tranAMT);
            string cURR = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4118", out cURR);
            string debitName = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4900", out debitName);
            string creditName = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4733", out creditName);
            string paytype = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4026", out paytype); //轉帳方式
            string refContent = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4897", out refContent); //付款用途
            string remarks = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4734", out remarks); //交易附言
            string fifler = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4835", out fifler);  //备用字段
            string crt = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4112", out crt);  //收款行號
            string pmt = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4658", out pmt);  //收款行名
            string bnm = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("2021", out bnm);  //收款人联行号 
            #endregion
            m_log.Info("AppXmlExecResult RunImpl.UC.4733(creditName)={0}&&4161(credit)={1}&&4157(debit)={2}&&4100(amt)={3}&&4118(curr)={4}&&4900(debitName)={5}", creditName, creditACC, debitACC, tranAMT, cURR, debitName);

            XmlDocument subRqXml;

            if (debitACC.Length > 15) //Card 
            {
                //Get Co.Code 
                string bodyCardEnq = GetT24_CardENQ_Content(debitACC);
                AppXmlExecResult cardEnq_result = SendMsgToEAIProcess(context, bodyCardEnq, "ESCN.CARD.CUSDATA.ENQ");
                XmlHelper xmlHelperCardEnq = XmlHelper.GetInstance(cardEnq_result.ResponseXml);
                string co_Code = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//CUS_CO_CODE").Trim();
                string checkCustNo = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//_x0040_ID").Trim();

                if (string.IsNullOrEmpty(co_Code))
                {
                    co_Code = "CN0010001"; //Default value, and check 
                    //Send Mail
                    new SendMail().Send("Do Enq Card Can not find Data From T24", "6", string.Format("Do Enq Card Can not find Data From T24, RQ:{0}", requestXml));
                }

                return DoCardProcess(context, m_UcControler, debitACC, creditACC, tranAMT, cURR, debitName, creditName, paytype, refContent, remarks, fifler, crt, pmt, co_Code, bnm, checkCustNo);
            }
            else // ACC 
            {
                subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                return Send1Recv1(m_log, context, subRqXml);
            }
        }

        private AppXmlExecResult DoES_2010774Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            //判別某域符合時,發送到CUP,要不走原路的T24
            XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
            string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
            m_log.Info("AppXmlExecResult RunImpl.UC.RQ2010767={0}", ucData);
            UcControler m_UcControler = new UcControler();
            string t24Ofs = m_UcControler.UC2T24(ucData);
            #region Get UC Field
            string creditACC = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4300", out creditACC);
            string debitACC = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4322", out debitACC);
            string tranAMT = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4100", out tranAMT);
            string ntcFlag = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4053", out ntcFlag);
            string fullFlag = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4105", out fullFlag); 
            #endregion
            m_log.Info("AppXmlExecResult RunImpl.UC.4300(credit)={0}&&4322(debit)={1}&&4100(amt)={2}&&4053(amt)={3}&&4105(full)={4}", creditACC, debitACC, tranAMT, ntcFlag, fullFlag);

            XmlDocument subRqXml;

            if (creditACC.Length > 15) //Card 
            {
                //Get Co.Code 
                string co_Code = GetCoCode(debitACC);

                if (string.IsNullOrEmpty(co_Code))
                {
                    co_Code = "CN0010001"; //Default value, and check 
                    //Send Mail
                    new SendMail().Send("Do Enq Card Can not find Data From T24", "6", string.Format("Do Enq Card Can not find Data From T24, RQ:{0}", requestXml));
                }

                return DoNTCFTProcess(context, m_UcControler, debitACC, creditACC, tranAMT, ntcFlag, fullFlag, co_Code);
            }
            else // ACC 
            {
                subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                return Send1Recv1(m_log, context, subRqXml);
            }
        }

        private AppXmlExecResult DoES_2010782Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            //判別某域符合時,發送xml到CUP,要不走原路的T24
            XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
            string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
            m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);
            UcControler m_UcControler = new UcControler();
            string t24Ofs = m_UcControler.UC2T24(ucData);

            //將回傳回來的OFS資料存在集合裡,再從資料裡取得指定索引鍵相關聯的值
            #region Get UC Field //域代碼
            string accTYPE = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4329", out accTYPE);  //存款类型
            string wdwlACC = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4323", out wdwlACC); //转出账号
            string depAMT = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4100", out depAMT); //转存金额
            string cURR = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4118", out cURR); //币种
            string tERM = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4018", out tERM); //存期
            string rolloverFLAG = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4015", out rolloverFLAG); //自动转存标志 
            #endregion

            m_log.Info("AppXmlExecResult RunImpl.UC.4329(acType)={0}&&4323(debit)={1}&&4100(amt)={2}&&4118(curr)={3}&&4018(term)={4}&&4015(term)={5}", accTYPE, wdwlACC, depAMT, cURR, tERM, rolloverFLAG);

            XmlDocument subRqXml;

            if (wdwlACC.Length > 15) //Card 
            {

                //判斷是否「不轉存」，銀聯卡定存只接受「不轉存」
                if (!rolloverFLAG.Equals("0"))
                {
                    string failCode = "CO1MA999";
                    string rs_Code = "E-TDROLL";
                    string failDescription = ErrorCodeMapping("BPM", rs_Code);

                    Dictionary<string, string> expendDicERR = Get_2010782_Expend(wdwlACC, "0.00", "00000000", "00000000", tERM, accTYPE, "", "", "");
                    string afterRSERR = CheckUC_ResponseProcess(m_UcControler, expendDicERR, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRSERR);
                    XmlDocument rs_UCERR = base.TransformCommMsg("0", "", "", afterRSERR);
                    return base.BuildExecResult(context, rs_UCERR);
                }
                
                //Get Co.Code 
                string bodyCardEnq = GetT24_CardENQ_Content(wdwlACC); 
                AppXmlExecResult cardEnq_result = SendMsgToEAIProcess(context, bodyCardEnq, "ESCN.CARD.CUSDATA.ENQ"); 

                XmlHelper xmlHelperCardEnq = XmlHelper.GetInstance(cardEnq_result.ResponseXml); 
                string co_Code = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//CUS_CO_CODE").Trim();
                string proc_ret = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//_x0040_ID").Trim();

                if (string.IsNullOrEmpty(co_Code))
                {
                    co_Code = "CN0010001"; //Default value, and check
                    //Send Mail
                    new SendMail().Send("Do Enq Card Can not find Data From T24", "6", string.Format("Do Enq Card Can not find Data From T24, RQ:{0}", requestXml));
                }

                return DoCardVsTDAProcess(context, m_UcControler, accTYPE, wdwlACC, depAMT, cURR, tERM, rolloverFLAG, co_Code);
                
            }

            else // ACC
            {
                subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                return Send1Recv1(m_log, context, subRqXml);
            }

        }

        /// <summary>
        /// 銀聯卡定期轉活期
        /// </summary>
        /// <param name="context"></param>
        /// <param name="correlationID"></param>
        /// <param name="txID"></param>
        /// <param name="txDef"></param>
        /// <param name="requestXml"></param>
        private AppXmlExecResult DoES_2010783Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {

            //判別某域符合時,發送到CUP,要不走原路的T24
            XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
            string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
            m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);
            UcControler m_UcControler = new UcControler();
            string t24Ofs = m_UcControler.UC2T24(ucData);

            #region Get UC Field

            string debitACC = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4322", out debitACC); //ALSO ACCT CLOSURE的TRANSACTION ID
            string cURR = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4118", out cURR);
            string tranAMT = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4100", out tranAMT);
            string creditACC = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4321", out creditACC); //ALSO ACCT CLOSURE的SETTLEMENT_ACCT

            string origAcc = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4300", out origAcc);
            string wdwlType = string.Empty;
            m_UcControler.m_ucBodyDiy.TryGetValue("4156", out wdwlType);

            #endregion
            m_log.Info("AppXmlExecResult RunImpl.UC.4322(debitACC)={0}&&4321(creditACC)={1}&&4300(origAcc)={2}&&4156(wdwlType)={3}", debitACC, creditACC, origAcc, wdwlType);

            XmlDocument subRqXml;

            //判斷是否銀聯卡定期
            //檢查扣款跟入款帳戶是否同為T24或同為銀聯
            if (origAcc.Length > 15) //card
            {
                //判斷是否「全部部提(銷戶)」
                //if (!wdwlType.Equals("2"))
                //{
                //    string failCode = "CO1MA999";
                //    string rs_Code = "E-TDAWDL";
                //    string failDescription = ErrorCodeMapping("BPM", rs_Code);

                //    Dictionary<string, string> expendDicERR = Get_2010783_Expend(debitACC, creditACC, tranAMT, "0.00", "0.00");
                //    string afterRSERR = CheckUC_ResponseProcess(m_UcControler, expendDicERR, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                //    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRSERR);
                //    XmlDocument rs_UCERR = base.TransformCommMsg("0", "", "", afterRSERR);
                //    return base.BuildExecResult(context, rs_UCERR);
                //}

                //判斷是否皆為入帳也為銀聯
                if (creditACC.Length <= 15)
                {
                    string failCode = "CO1MA999";
                    string rs_Code = "E-TDSETC";
                    string failDescription = ErrorCodeMapping("BPM", rs_Code);

                    Dictionary<string, string> expendDicERR = Get_2010783_Expend(debitACC, creditACC, tranAMT, "0.00", "0.00");
                    string afterRSERR = CheckUC_ResponseProcess(m_UcControler, expendDicERR, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRSERR);
                    XmlDocument rs_UCERR = base.TransformCommMsg("0", "", "", afterRSERR);
                    return base.BuildExecResult(context, rs_UCERR);
                }

                //確認入帳銀聯卡的狀態
                string bodyCUP = Get5001_ENQ_Content(creditACC);
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "5001");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                string retCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RETCODE");
                string cardStat = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//CARD-STAT");
                string frzType = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FRZTYPE");

                m_log.Info("DoES_2010783Process CARD STATUS: Card id=" + creditACC + ", statusCode=" + retCode + ", Stat=" + cardStat + ", FrzType=" + frzType);

                if (!retCode.Equals("000000") || !cardStat.Equals("") || frzType.Equals("1"))
                {
                    //retCode為000000代表「正常」(以排除卡號不存在)，cardStat為空代表「正常」，frzType為1代表「活期不收不付凍結」
                    string failCode = "CO1MA999";
                    string rs_Code = "14"; //無效卡號
                    string failDescription = ErrorCodeMapping("CUP", rs_Code);

                    Dictionary<string, string> expendDicERR = Get_2010783_Expend(debitACC, creditACC, tranAMT, "0.00", "0.00");
                    string afterRSERR = CheckUC_ResponseProcess(m_UcControler, expendDicERR, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRSERR);
                    XmlDocument rs_UCERR = base.TransformCommMsg("0", "", "", afterRSERR);
                    return base.BuildExecResult(context, rs_UCERR);
                }

                return DoCardTDAtoCardProcess(context, m_UcControler, debitACC, creditACC, cURR, tranAMT, wdwlType);

            }
            else
            {
                //判斷是否入帳也為T24
                if (creditACC.Length > 15)
                {
                    string failCode = "CO1MA999";
                    string rs_Code = "E-TDSETT";
                    string failDescription = ErrorCodeMapping("BPM", rs_Code);

                    Dictionary<string, string> expendDicERR = Get_2010783_Expend(debitACC, creditACC, tranAMT, "0.00", "0.00");
                    string afterRSERR = CheckUC_ResponseProcess(m_UcControler, expendDicERR, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRSERR);
                    XmlDocument rs_UCERR = base.TransformCommMsg("0", "", "", afterRSERR);
                    return base.BuildExecResult(context, rs_UCERR);
                }
                
                subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                return Send1Recv1(m_log, context, subRqXml);
            }

            //T24定期
            //T24定期->T24活期：原路
            //T24定期->銀聯：BPM(1)扣T24(需區分部分還是全部-> 可否原路收到Send1Recv1之後，接著做銀聯)、入銀聯(CNY沒有入帳OK嗎)

            //銀聯卡定期
            //如為銀聯卡定期，確認是否全部支取

            //銀聯定期->T24活期：原路(CNY沒有扣帳OK嗎)
            //銀聯定期->銀聯活期：BPM(2)扣T24、入銀聯

        }

        private AppXmlExecResult DoES_2010784Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
            string rq_t24_data = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();

            m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", rq_t24_data);
            #region 分析報文
            UcControler m_UcControler = new UcControler();
            string debitACC = string.Empty;
            string cURR = string.Empty;
            string ntcCode = string.Empty;
            string tranAMT = string.Empty;
            string t24Ofs = m_UcControler.UC2T24(rq_t24_data);

            m_UcControler.m_ucBodyDiy.TryGetValue("4323", out debitACC);
            m_UcControler.m_ucBodyDiy.TryGetValue("4118", out cURR);
            m_UcControler.m_ucBodyDiy.TryGetValue("4060", out ntcCode);
            m_UcControler.m_ucBodyDiy.TryGetValue("4100", out tranAMT);
            m_log.Info("AppXmlExecResult RunImpl.UC.4323(debitACC)={0}&&4118(cURR)={1}&&4060(ntcCode)={2}&&4100(tranAMT)={3}", debitACC, cURR, ntcCode, tranAMT);
            #endregion

            if (debitACC.Length > 15)
            {
                #region 發ESCN.CARD.CUSDATA.ENQ(查CO.CODE和@ID)
                string bodyCardEnq = GetT24_CardENQ_Content(debitACC);
                AppXmlExecResult cardEnq_result = SendMsgToEAIProcess(context, bodyCardEnq, "ESCN.CARD.CUSDATA.ENQ");
                XmlHelper xmlHelperCardEnq = XmlHelper.GetInstance(cardEnq_result.ResponseXml);
                string co_Code = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//CUS_CO_CODE").Trim();
                string CustNO = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//_x0040_ID").Trim();
                #endregion

                return DoNTCOPENProcess(context, m_UcControler, debitACC, CustNO, cURR, tranAMT, ntcCode, co_Code);
            }
            else // ACC 
            {
                XmlDocument subRqXml = CopyToNewDocument(requestXml, txID.Replace("ES_", ""), Guid.NewGuid().ToString());
                return Send1Recv1(m_log, context, subRqXml);
            }

        }

        private List<string> CUP2UC_File_5612(Dictionary<string, List<string>> dic_ENQ)
        {
            int runDataTime = 0;
            List<string> enqKeyList = new List<string>(new string[] { "HS_INPD", "HS_INPT", "HS_TRNN", "TRN_CARD", "CUR_NUM", "BILL_AMT", "TRANTYPE", "BILL_AMS", "CRFLAG", "CTFLAG", "ACQCODE", "CURR_BAL", "DESLINE1", "DESLINE1", "FORCARDNBR", "RESERVED" });
            List<string> enqValueList = new List<string>();
            List<String> tempList = new List<string>();
            List<String> new_EnqList = new List<string>();

            foreach (KeyValuePair<string, List<string>> entry in dic_ENQ)
            {
                //m_log.Debug("AppXmlExecResult dic_ENQ.KEY.Name={0}&&Count:{1}", entry.Key, entry.Value.Count);
                if (entry.Key == "TRN_CARD")
                {
                    foreach (string d in entry.Value)
                    {
                        if (!string.IsNullOrEmpty(d))
                            runDataTime += 1;//取得資料筆數使用TRN_CARD(4305)
                    }
                }
            }

            for (int k = 0; k < runDataTime; k++)
            {
                for (int i = 0; i < enqKeyList.Count; i++)
                {
                    dic_ENQ.TryGetValue(enqKeyList[i], out enqValueList);
                    
                    string finalVal = enqValueList[k];
                    #region 需要有轉換,因為銀聯給的跟城商不一樣
                    if (enqKeyList[i] == "CUR_NUM")
                        finalVal = GetCURR_NUM(enqValueList[k]);

                    if (enqKeyList[i] == "BILL_AMT" || enqKeyList[i] == "CURR_BAL")
                        finalVal = GetAmtField(enqValueList[k]);
                    if (enqKeyList[i] == "BILL_AMS")
                        finalVal = GetAmtAMS(enqValueList[k]);

                    if (enqKeyList[i] == "HS_INPT")
                        finalVal = GetTimeField(enqValueList[k]);

                    if (enqKeyList[i] == "TRANTYPE")
                        finalVal = GetChannelField(enqValueList[k]);

                    if (enqKeyList[i] == "CRFLAG")
                        finalVal = GetCRFLAGField(enqValueList[k]);

                    if (enqKeyList[i] == "CTFLAG")
                        finalVal = GetCTFLAGField(enqValueList[k]); 
                    #endregion
                    tempList.Add(finalVal);
                }

                new_EnqList.Add(string.Join("|", tempList.ToArray()));
                tempList.Clear();
            }
            return new_EnqList;
        }

        private Dictionary<string, string> CUP2UC_RS_5612(Dictionary<string, List<string>> dic_ENQ, string fileName)
        {
            Dictionary<string, string> totalDic = new Dictionary<string, string>();
            int runDataTime = 0;
            List<int> inAmtList = new List<int>();
            decimal inAmt = 0;
            List<int> outAmtList = new List<int>();
            decimal outAmt = 0;
            foreach (KeyValuePair<string, List<string>> entry in dic_ENQ)
            {
                if (entry.Key == "TRN_CARD")
                {
                    foreach (string d in entry.Value)
                    {
                        if (!string.IsNullOrEmpty(d))
                            runDataTime += 1;//取得資料筆數4305,使用TRN_CARD
                    }
                }

                if (entry.Key == "BILL_AMS")  //BILL_AMS="+" 收入;BILL_AMS="-" 支出
                {
                    for (int i = 0; i < entry.Value.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(entry.Value[i]))
                        {
                            if (entry.Value[i].Trim() == "+")
                                inAmtList.Add(i);
                            else if (entry.Value[i].Trim() == "-")
                                outAmtList.Add(i);
                        }
                    }
                }
            }

            //計算總筆數,收入與支出
            totalDic.Add("4305", runDataTime.ToString());
            //文件名
            totalDic.Add("zzzx", fileName);
            //其中收入总笔数4342
            totalDic.Add("4342", inAmtList.Count.ToString());
            //其中收入总金额4701
            foreach (int count in inAmtList)
                inAmt += Convert.ToDecimal(dic_ENQ["BILL_AMT"][count]);
            totalDic.Add("4701", inAmt.ToString("F"));
            //其中支出总笔数4343
            totalDic.Add("4343", outAmtList.Count.ToString());
            //其中支出总金额4702
            foreach (int count in outAmtList)
                outAmt += Convert.ToDecimal(dic_ENQ["BILL_AMT"][count]);
            totalDic.Add("4702", outAmt.ToString("F"));

            return totalDic;
        }

        private string GetCoCode(String t24Account)
        {
            string subCode = t24Account.Substring(0, 4);
            return String.Format("CN001{0}", subCode);
        }

        private string GetCURR_NUM(string currNo)
        {
            switch (currNo)
            {
                case "156":
                    return "CNY";
                case "840":
                    return "USD";
                case "CNY":
                    return "156";
                case "USD":
                    return "840";
                default:
                    return "CNY";
            }
        }

        private string GetTERM_NUM(string Term)
        {
            switch (Term)
            {
                case "M3":
                    return "3M";
                case "M6":
                    return "6M";
                case "Y1":
                    return "12M";
                case "Y2":
                    return "24M";
                case "Y3":
                    return "36M";
                case "Y5":
                    return "60M";
                default:
                    return "0M";
            }
        }

        private string GetAmtField(string amt)
        {
            Decimal deAmt = Convert.ToDecimal(amt);
            return deAmt.ToString("F");
        }

        private string GetTimeField(string time)
        {
            return time.Substring(0, 6);
        }

        private string GetChannelField(string type)
        {
            List<string> atmLIST = new List<string> { 
                "2501", "2503", "2511", "2513", "2516", "2520", "2522", "2524", "2526", 
                "2601", "2603", "2611", "2613", "2616", 
                "4501", "4503", "4511", "4513", "4516", "4520", "4522", "4524", 
                "4601", "4603", "4611", "4613", "4616", 
                "4701", "4703", 
                "7501", "7503", "7511", "7513", "7516", 
                "7601", "7603", "7611", "7613", "7616", 
                "9501", "9503", "9511", "9513", 
                "9601", "9603", "9611", "9613", "9616"};
            List<string> beLIST = new List<string> { 
                "2599", "2699",
                "2500", "2502", "2510", "2512", "2515", 
                "2600", "2602", "2610", "2612", "2615", "2620",
                "4500", "4502", "4510", "4512", "4515", 
                "4600", "4602", "4610", "4612", "4615", "4620",
                "4700", "4702", 
                "7500", "7502", "7510", "7512", "7515", 
                "7600", "7602", "7610", "7612", "7615", 
                "9500", "9502", "9510", "9512", 
                "9600", "9602", "9610", "9612", "9615"};

            List<string> ibLIST = new List<string> { 
                "2604", "2608", "2618", "2621", 
                "4604", "4608", "4618", "4621", 
                "7608"};

            if (atmLIST.Contains(type))
                return "01"; //ATM
            else if (beLIST.Contains(type))
                return "02"; //櫃面
            else if (ibLIST.Contains(type))
                return "03"; //網上銀行
            else
                return "05"; //其它
        }
        private string GetAmtAMS(string tag)
        {
            switch (tag)
            {
                case "+":
                    return "0";
                case "-":
                    return "1";
                default:
                    return "0";
            }
        }

        private string GetCRFLAGField(string data)
        {
            switch (data)
            {
                case "0":
                    return "1";
                case "1":
                    return "2";
                default:
                    return "1";
            }
        }

        private string GetCTFLAGField(string data)
        {
            switch (data)
            {
                case "0":
                    return "1";
                case "1":
                    return "2";
                default:
                    return "3";
            }
        }

        private string Get_Acct_Status(string card_acct_Status)
        {
            switch (card_acct_Status)
            {
                case "":
                    return "0";
                case "Q":
                    return "6";
                case "C":
                    return "5";
                default:
                    return card_acct_Status;
            }
        }

        private AppXmlExecResult DoCUSTOACCTProcess(EaiContext context, UcControler uCcontroler, XmlHelper xmlHelper, XmlDocument requestXml, Dictionary<string, string> rqHeadDic, Dictionary<string, string> rqBodyDic, string txID, string AccNo)
        {
            UCCommonUtil ucComUtil = new UCCommonUtil();
            
            #region 1. 5001
            string bodyCUP = Get5001_ENQ_Content(AccNo);
            AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "5001");
            XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
            string retCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RETCODE");
            string cardStat = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//CARD_STAT");
            string frzType = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FRZTYPE");
            m_log.Info("DoES_2010504Process CARD STATUS: Card id=" + AccNo + ", statusCode=" + retCode + ", Stat=" + cardStat + ", FrzType=" + frzType);
            #endregion 1. 5001

            #region 2. CUS.TOACCT.ENQ.DTL
            string bodyCardEnq = GetT24_CardAcctENQ_Content(AccNo);
            AppXmlExecResult cardEnq_result = SendMsgToEAIProcess(context, bodyCardEnq, "CUS.TOACCT.ENQ.DTL");

            XmlHelper xmlHelperCardEnq = XmlHelper.GetInstance(cardEnq_result.ResponseXml);
            string acct_No = xmlHelperCardEnq.GetXPath(cardEnq_result.ResponseXml, "//ACCT_NO").Trim();
            #endregion 2. CUS.TOACCT.ENQ.DTL

            #region 3. 產生FileContentList落檔上傳FTP並回覆結果
            List<string> fileContentList = new List<string>();
            Dictionary<string, string> rs_succ_otherBodyDic = new Dictionary<string, string>();
            rs_succ_otherBodyDic.Add("2028", "CO1M0000");

            //retCode為000000代表「正常」(以排除卡號不存在)，cardStat為空代表「正常」
            if (!retCode.Equals("000000") || !cardStat.Equals("") && string.IsNullOrEmpty(acct_No))
            {
                fileContentList.Add("");
                rs_succ_otherBodyDic.Add("4305", "0");//總筆數
            }
            else//查有資料
            {
                fileContentList = CreateFileContentList(xmlHelperCUPRS, cup_result.ResponseXml, cardEnq_result.ResponseXml,
                                                                             fileContentList, AccNo, retCode, cardStat, acct_No);
                rs_succ_otherBodyDic.Add("4305", fileContentList.Count.ToString());//總筆數
            }
            uCcontroler.CreateEnqFileToUC(fileContentList, true);
            rs_succ_otherBodyDic.Add("zzzx", uCcontroler.enqFileName);//文件名
            string rs_succ_String = ucComUtil.GetRsStringFromRqDic(rqHeadDic, rqBodyDic, rs_succ_otherBodyDic);

            m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rs_succ_String);
            XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rs_succ_String);
            return base.BuildExecResult(context, rs);
            #endregion 3. 產生FileContentList落檔上傳FTP並回覆結果
        }

        private AppXmlExecResult DoCardVsACCProcess(EaiContext context, UcControler m_UcControler, string debitACC, string creditACC, string tranAMT, string cURR,
                                                            string creditName, string refContent, string remarks, string fifler, string co_Code, string checkCustNo, string transGate)
        {
            string status = string.Empty;
            string failCode = string.Empty;
            string failDescription = string.Empty;
            string debitAMT = "0.0";

            //Check Debit Limit
            string limitEnq = GetT24_LimitENQ_Content(debitACC);
            AppXmlExecResult limitEnq_result = SendMsgToEAIProcess(context, limitEnq, "ESCN.BP.DEB.LIM.ENQ");
            XmlHelper xmlHelperLimitEnq = XmlHelper.GetInstance(limitEnq_result.ResponseXml);
            //string rs_LimCode = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//ITF_RETURN_CODE");
            //string rs_LimMsg = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//ITF_RETURN_MSG");
            string rs_LimRes = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//RSP_PROC_RET");

            if (rs_LimRes == "SUCC")
            {                
                string checkAmount = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//TOTAL").Trim();
                string checkCount = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//COUNT").Trim();
                Decimal ckAMT = 0;
                Decimal ckCNT = 0;
                if (!string.IsNullOrEmpty(checkAmount))
                {
                    ckAMT = Convert.ToDecimal(checkAmount) - Convert.ToDecimal(tranAMT);
                }
                if (!string.IsNullOrEmpty(checkCount))
                {
                    ckCNT = Convert.ToDecimal(checkCount) - 1;
                }
                
                if (ckAMT < 0 || ckCNT < 0)
                {
                   status = "2"; 
                   failCode = "CO1MA999";
                   failDescription = "账户超过限额";

                   Dictionary<string, string> expendLimDic = Get_2010766_Expend(debitACC, debitAMT, creditACC, creditName, status);
                   string afterLimRS = CheckUC_ResponseProcess(m_UcControler, expendLimDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                   m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterLimRS);
                   XmlDocument rs_LimUC = base.TransformCommMsg(limitEnq_result.EaiRs.EaiErrCode, limitEnq_result.EaiRs.EaiErrText, limitEnq_result.EaiRs.EaiErrDetail, afterLimRS);
                   return base.BuildExecResult(context, rs_LimUC);
                }
            }

            //Send CUP.Card.Debit
            CMMControler m_CMMControler = new CMMControler();
            string bodyCUP = m_CMMControler.GetCard_Debit_ContentMsg(debitACC, creditACC, tranAMT, "D00000000", "6013", "03450000", "0X03", GetCURR_NUM(cURR), co_Code, "        07     ");
            AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Debit");
            XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
            string rs_Code = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");
            debitAMT = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ADD_AMT");

            if (string.IsNullOrEmpty(debitAMT))
                debitAMT = "0.0";
            else
                debitAMT = Convert.ToDecimal(string.Format("{0}.{1}", debitAMT.Substring(28, 10), debitAMT.Substring(38))).ToString();

            if (rs_Code == "00")
            {
                //Send T24.FT
                string bodyFT = GetT24_FT_Content(co_Code, "I", "", GetCURR_NUM(cURR), debitACC, creditACC, creditName, tranAMT, refContent, remarks, fifler, "ITF001.0044", debitACC, transGate);
                AppXmlExecResult t24_result = SendMsgToEAIProcess(context, bodyFT, "IB.IN.IND.TFR");
                XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
                rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
                string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

                if (rs_Code == "E-000000" && proc_ret == "SUCC")
                    status = "1";//SUCC
                else
                {
                    //R
                    status = "2"; //ERROR RS
                    string rtnMsg = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_MSG");
                    failCode = "CO1MA999";
                    failDescription = ErrorCodeMapping("T24", rs_Code);

                    string msgType = "0200";
                    string dateTime_Now = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//TRAN_TIME");
                    string traceNo = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//SYS_TRACE_NUM");
                    string acqCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ACQ_INST_ID_CO");
                    string forCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FOR_INT_ID_CO");

                    string oriData = string.Format("{0}{1}{2}{3}{4}", msgType, traceNo, dateTime_Now, acqCode.PadLeft(11, '0'), forCode.PadLeft(11, '0'));
                    string bodyCUP_EC = m_CMMControler.GetEC_Card_Debit_ContentMsg(debitACC, creditACC, tranAMT, "6013", "03450000", "0X03", GetCURR_NUM(cURR), oriData, co_Code, "        07     ");
                    AppXmlExecResult cup_EC_result = SendMsgToEAIProcess(context, bodyCUP_EC, "CUP.Card.Debit.EC");

                    XmlHelper xmlHelperCUPRS_EC = XmlHelper.GetInstance(cup_EC_result.ResponseXml);
                    rs_Code = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//RES_CO");
                    debitAMT = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//ISS_INS_RES");
                    if (string.IsNullOrEmpty(debitAMT))
                        debitAMT = "0.0";
                    else
                        debitAMT = Convert.ToDecimal(string.Format("{0}.{1}", debitAMT.Split('C')[1].Substring(0, 10), debitAMT.Split('C')[1].Substring(10, 2))).ToString();


                    if (rs_Code != "00")
                        //SEND MAIL
                        new SendMail().Send("Do ACC.Transfer(R) Error", "", string.Format("Do ACC.Transfer(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                }
            }
            else
            {
                status = "2";//ERROR RS
                failCode = "CO1MA999";
                failDescription = string.Format("类其它错误:Code={0}", rs_Code);
            }

            Dictionary<string, string> expendDic = Get_2010766_Expend(debitACC, debitAMT, creditACC, creditName, status);
            string afterRS = CheckUC_ResponseProcess(m_UcControler, expendDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
            m_log.Debug("AppXmlExecResult CARD.TO.ACC RunImpl.afterRS={0}", afterRS);
            XmlDocument rs_UC = base.TransformCommMsg(cup_result.EaiRs.EaiErrCode, cup_result.EaiRs.EaiErrText, cup_result.EaiRs.EaiErrDetail, afterRS);
            return base.BuildExecResult(context, rs_UC);

        }

        private AppXmlExecResult DoACCVsCardProcess(EaiContext context, UcControler m_UcControler, string debitACC, string creditACC, string tranAMT, string cURR,
                                                    string creditName, string refContent, string remarks, string fifler, string co_code, string transGate)
        {
            string status = string.Empty;
            
            //先傳送FT至T24
            string bodyFT = GetT24_FT_Content(GetCoCode(debitACC), "I", "", cURR, debitACC, creditACC, creditName, tranAMT, refContent, remarks, fifler, "ITF001.0044", creditACC, transGate);
            AppXmlExecResult t24_result = SendMsgToEAIProcess(context, bodyFT, "IB.IN.IND.TFR");
            //取得T24 Response判斷成功失敗
            XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
            string rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
            string rs_Msg = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_MSG");
            string failCode = string.Empty;
            string failDescription = string.Empty;
            string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

            if (rs_Code == "E-000000" && proc_ret == "SUCC")
            {
                 //T24扣款成功，送銀聯
                 CMMControler m_CMMControler = new CMMControler();
                 string bodyCUP = m_CMMControler.GetCard_Credit_ContentMsg(creditACC, debitACC, tranAMT, "6013", "03450000", GetCURR_NUM(cURR), co_code);
                 AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Credit");
                 XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                 rs_Code = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");

                 if (rs_Code == "00")
                     //判斷銀聯入款成功
                     status = "1";//SUCC
                 else
                 {
                     //銀聯入款如果失敗，T24做R
                     status = "2"; //ERROR RS
                     failCode = "CO1MA999";
                     failDescription = string.Format("类其它错误:Code={0}", rs_Code);

                     string ftRspId = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_TXN_ID");

                     string bodyRFT = GetT24_FT_Content(GetCoCode(debitACC), "R", ftRspId, cURR, debitACC, creditACC, creditName, tranAMT, refContent, remarks, fifler, "ITF001.0069", creditACC, transGate);
                     AppXmlExecResult t24_R_Result = SendMsgToEAIProcess(context, bodyRFT, "IB.IN.IND.TFR");

                     XmlHelper xmlHelperT24RS_R = XmlHelper.GetInstance(t24_R_Result.ResponseXml);
                     rs_Code = xmlHelperT24RS_R.GetXPath(t24_R_Result.ResponseXml, "//ITF_RETURN_CODE");
                     string proc_ret_R = xmlHelperT24RS.GetXPath(t24_R_Result.ResponseXml, "//RSP_PROC_RET");

                    if (!rs_Code.Equals("E-000000") || proc_ret_R != "SUCC")
                         //send mail
                         new SendMail().Send("Do ACC.to.CARD.Transfer(R) Error", "6", string.Format("Do ACC.Transfer(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                 }
             }
             else
            {
                status = "2"; //ERROR RS
                failCode = "CO1MA999";
                failDescription = ErrorCodeMapping("T24", rs_Code);
            }

            //取得交易後的餘額
            string bodyBalEnq = Get2010772_ENQ_Content(debitACC);
            AppXmlExecResult BalEnq_result = SendMsgToEAIProcess(context, bodyBalEnq, "ACC.CURR.BAL.ENQ");
            XmlHelper xmlHelperBalEnq = XmlHelper.GetInstance(BalEnq_result.ResponseXml);
            string balAmt = xmlHelperBalEnq.GetXPath(BalEnq_result.ResponseXml, "//WORKING_BALANCE").Trim();

            Dictionary<string, string> expendDic = Get_2010766_Expend(debitACC, balAmt, creditACC, creditName, status);
            string afterRS = CheckUC_ResponseProcess(m_UcControler, expendDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
            m_log.Info("AppXmlExecResult ACC.TO.CARD RunImpl.afterRS={0}", afterRS);
            XmlDocument rs_UC = base.TransformCommMsg(t24_result.EaiRs.EaiErrCode, t24_result.EaiRs.EaiErrText, t24_result.EaiRs.EaiErrDetail, afterRS);
            return base.BuildExecResult(context, rs_UC);

        }

        private AppXmlExecResult DoCardVsCardProcess(EaiContext context, UcControler m_UcControler, string debitACC, string creditACC, string tranAMT, string cURR,
                                                    string creditName, string refContent, string remarks, string fifler, string co_Code, string checkCustNo, string transGate)
        {

            string status = string.Empty;
            string debitAMT = "0.0";
            string failCode = string.Empty;
            string failDescription = string.Empty;

            //先傳送FT至T24
            string bodyFT = GetT24_FT_Content(co_Code, "I", "", GetCURR_NUM(cURR), debitACC, creditACC, creditName, tranAMT, refContent, remarks, fifler, "ITF001.0044", debitACC, transGate);
            AppXmlExecResult t24_result = SendMsgToEAIProcess(context, bodyFT, "IB.IN.IND.TFR");
            //取得T24 Response判斷成功失敗
            XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
            string rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
            string rs_Msg = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_MSG");
            string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

            if (rs_Code == "E-000000" && proc_ret == "SUCC")
            {
                //T24作帳成功，送銀聯
                CMMControler m_CMMControler = new CMMControler();
                string bodyCUP = m_CMMControler.GetCard_Transfer_ContentMsg(debitACC, creditACC, tranAMT, "6013", "03450000", "0X03", GetCURR_NUM(cURR), co_Code, "        07     ");
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Transfer");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                rs_Code = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");
                debitAMT = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ADD_AMT");
                if (string.IsNullOrEmpty(debitAMT))
                    debitAMT = "0.0";
                else
                    debitAMT = Convert.ToDecimal(string.Format("{0}.{1}", debitAMT.Substring(28, 10), debitAMT.Substring(38))).ToString();

                if (rs_Code == "00")
                    //判斷銀聯入款成功
                    status = "1";//SUCC
                else
                {
                    //銀聯入款如果失敗，T24做R
                    status = "2"; //ERROR RS
                    failCode = "CO1MA999";
                    failDescription = string.Format("类其它错误:Code={0}", rs_Code);

                    string ftRspId = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_TXN_ID");

                    string bodyRFT = GetT24_FT_Content(co_Code, "R", ftRspId, cURR, debitACC, creditACC, creditName, tranAMT, refContent, remarks, fifler, "ITF001.0069", creditACC, transGate);
                    AppXmlExecResult t24_R_Result = SendMsgToEAIProcess(context, bodyRFT, "IB.IN.IND.TFR");

                    XmlHelper xmlHelperT24RS_R = XmlHelper.GetInstance(t24_R_Result.ResponseXml);
                    rs_Code = xmlHelperT24RS_R.GetXPath(t24_R_Result.ResponseXml, "//ITF_RETURN_CODE");
                    string proc_ret_R = xmlHelperT24RS.GetXPath(t24_R_Result.ResponseXml, "//RSP_PROC_RET");

                    if (!rs_Code.Equals("E-000000") || proc_ret_R != "SUCC")
                        //send mail
                        new SendMail().Send("Do CARD.to.CARD.Transfer(R) Error", "6", string.Format("Do ACC.Transfer(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                    }
                }
                else
                {
                    status = "2"; //ERROR RS
                    failCode = "CO1MA999";
                    failDescription = ErrorCodeMapping("T24", rs_Code);
                }

            Dictionary<string, string> expendDic = Get_2010766_Expend(debitACC, debitAMT, creditACC, creditName, status);
            string afterRS = CheckUC_ResponseProcess(m_UcControler, expendDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
            m_log.Info("AppXmlExecResult CARD.TO.CARD RunImpl.afterRS={0}", afterRS);
            XmlDocument rs_UC = base.TransformCommMsg(t24_result.EaiRs.EaiErrCode, t24_result.EaiRs.EaiErrText, t24_result.EaiRs.EaiErrDetail, afterRS);
            return base.BuildExecResult(context, rs_UC);

            //string status = string.Empty;
            //string debitAMT = "0.0";
            //string failCode = string.Empty;
            //string failDescription = string.Empty;

            ////Check Debit Limit
            //string flag = "0";
            //string limitEnq = GetT24_LimitENQ_Content(debitACC);
            //AppXmlExecResult limitEnq_result = SendMsgToEAIProcess(context, limitEnq, "ESCN.BP.DEB.LIM.ENQ");
            //XmlHelper xmlHelperLimitEnq = XmlHelper.GetInstance(limitEnq_result.ResponseXml);
            ////string rs_LimCode = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//ITF_RETURN_CODE");
            ////string rs_LimMsg = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//ITF_RETURN_MSG");
            //string rs_LimRes = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//RSP_PROC_RET");

            //if (rs_LimRes == "SUCC")
            //{
            //    string checkAmount = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//TOTAL").Trim();
            //    string checkCount = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//COUNT").Trim();
            //    Decimal ckAMT = 0;
            //    Decimal ckCNT = 0;
            //    if (!string.IsNullOrEmpty(checkAmount))
            //    {
            //        ckAMT = Convert.ToDecimal(checkAmount) - Convert.ToDecimal(tranAMT);
            //    }
            //    if (!string.IsNullOrEmpty(checkCount))
            //    {
            //        ckCNT = Convert.ToDecimal(checkCount) - 1;
            //    }

            //    flag = "1";
            //    if (ckAMT < 0 || ckCNT < 0)
            //    {
            //       status = "2"; 
            //       failCode = "CO1MA999";
            //       failDescription = "账户超过限额";

            //       Dictionary<string, string> expendLimDic = Get_2010766_Expend(debitACC, debitAMT, creditACC, creditName, status);
            //       string afterLimRS = CheckUC_ResponseProcess(m_UcControler, expendLimDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
            //       m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterLimRS);
            //       XmlDocument rs_LimUC = base.TransformCommMsg(limitEnq_result.EaiRs.EaiErrCode, limitEnq_result.EaiRs.EaiErrText, limitEnq_result.EaiRs.EaiErrDetail, afterLimRS);
            //       return base.BuildExecResult(context, rs_LimUC);
            //   }
            //}

            
            //Check CreditAccount Name
            //string accEnq = GetT24_CardENQ_Content(creditACC);
            //AppXmlExecResult accEnq_result = SendMsgToEAIProcess(context, accEnq, "ESCN.CARD.CUSDATA.ENQ");
            //XmlHelper xmlHelperAccEnq = XmlHelper.GetInstance(accEnq_result.ResponseXml);
            //string checkAccountName = xmlHelperAccEnq.GetXPath(accEnq_result.ResponseXml, "//CUS_NAME").Trim();
            ////Check DebitAccount Name
            //string accDebitEnq = GetT24_CardENQ_Content(debitACC);
            //AppXmlExecResult accDebitEnq_result = SendMsgToEAIProcess(context, accDebitEnq, "ESCN.CARD.CUSDATA.ENQ");
            //XmlHelper xmlHelperAccDebitEnq = XmlHelper.GetInstance(accDebitEnq_result.ResponseXml);
            //string checkCARD_INVALID_FLAG = xmlHelperAccDebitEnq.GetXPath(accDebitEnq_result.ResponseXml, "//CARD_INVALID_FLAG").Trim();

            //if (checkCARD_INVALID_FLAG == "N")
            //{
            //    status = "2";//ERROR RS
            //    failCode = "CO1MA108";
            //    failDescription = "卡片标志错误";
            //}
            //else if (string.IsNullOrEmpty(checkAccountName) || checkAccountName != creditName)
            //{
            //    status = "2";//ERROR RS
            //    failCode = "CO1MA102";
            //    failDescription = "账号户名不符";
            //}
            //else
            //{
            //    //Send CUP.Card.Debit
            //    CMMControler m_CMMControler = new CMMControler();
            //    string bodyCUP = m_CMMControler.GetCard_Transfer_ContentMsg(debitACC, creditACC, tranAMT, "6013", "03450000", "0X03", GetCURR_NUM(cURR), co_Code, "        07     ");
            //    AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Transfer");
            //    XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
            //    string rs_Code = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");
            //    debitAMT = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//Add_AMT");
            //    if (string.IsNullOrEmpty(debitAMT))
            //        debitAMT = "0.0";
            //    else
            //        debitAMT = Convert.ToDecimal(string.Format("{0}.{1}", debitAMT.Substring(28, 10), debitAMT.Substring(38))).ToString();

            //    if (rs_Code == "00")
            //    {
            //        status = "1";

            //        //Record Debit Limit
            //        if (flag == "1")   
            //        {
            //           string DebLim = GetT24_DebLim_Content(co_Code, "I", debitACC, tranAMT, cURR, creditACC, checkCustNo);
            //            SendMsgToEAIProcess(context, DebLim, "ESCN.BP.DEBIT.LIMIT");
            //        }
            //    }
            //    else
            //    {
            //        status = "2";//ERROR RS
            //        failCode = "CO1MA999";
            //        failDescription = string.Format("类其它错误:Code={0}", rs_Code);
            //    }
            ////}

            //Dictionary<string, string> expendDic = Get_2010766_Expend(debitACC, debitAMT, creditACC, creditName, status);
            //string afterRS = CheckUC_ResponseProcess(m_UcControler, expendDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
            //m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
            //XmlDocument rs_UC = base.TransformCommMsg(accEnq_result.EaiRs.EaiErrCode, accEnq_result.EaiRs.EaiErrText, accEnq_result.EaiRs.EaiErrDetail, afterRS);
            //return base.BuildExecResult(context, rs_UC);

        }

        private AppXmlExecResult DoCardProcess(EaiContext context, UcControler m_UcControler, string debitACC, string creditACC, string tranAMT, string cURR,
                                                            string debitName, string creditName, string paytype, string refContent, string remarks, string fifler, string crt, string pmt, string co_Code, string bnm, string checkCustNo)
        {
            string status = string.Empty;
            string failCode = string.Empty;
            string failDescription = string.Empty;
            string debitAMT = "0.00";
            string CommFee = "0.00";

            //Check Debit Limit
            string limitEnq = GetT24_LimitENQ_Content(debitACC);
            AppXmlExecResult limitEnq_result = SendMsgToEAIProcess(context, limitEnq, "ESCN.BP.DEB.LIM.ENQ");
            XmlHelper xmlHelperLimitEnq = XmlHelper.GetInstance(limitEnq_result.ResponseXml);
            //string rs_LimCode = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//ITF_RETURN_CODE");
            //string rs_LimMsg = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//ITF_RETURN_MSG");
            string rs_LimRes = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//RSP_PROC_RET");

            if (rs_LimRes == "SUCC")
            {
                string checkAmount = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//TOTAL").Trim();
                string checkCount = xmlHelperLimitEnq.GetXPath(limitEnq_result.ResponseXml, "//COUNT").Trim();
                Decimal ckAMT = 0;
                Decimal ckCNT = 0;
                if (!string.IsNullOrEmpty(checkAmount))
                {
                    ckAMT = Convert.ToDecimal(checkAmount) - Convert.ToDecimal(tranAMT);
                }
                if (!string.IsNullOrEmpty(checkCount))
                {
                    ckCNT = Convert.ToDecimal(checkCount) - 1;
                }

                if (ckAMT < 0 || ckCNT < 0)
                {
                    status = "2";
                    failCode = "CO1MA999";
                    failDescription = "账户超过限额";

                    Dictionary<string, string> expendLimDic = Get_2010767_Expend(debitAMT, creditACC, creditName, status, CommFee);
                    string afterLimRS = CheckUC_ResponseProcess(m_UcControler, expendLimDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                    m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterLimRS);
                    XmlDocument rs_LimUC = base.TransformCommMsg(limitEnq_result.EaiRs.EaiErrCode, limitEnq_result.EaiRs.EaiErrText, limitEnq_result.EaiRs.EaiErrDetail, afterLimRS);
                    return base.BuildExecResult(context, rs_LimUC);
                }
            }

            //Get Commission 
            string bodyCardEnq = GetT24_CommENQ_Content(tranAMT, cURR);
            AppXmlExecResult commEnq_result = SendMsgToEAIProcess(context, bodyCardEnq, "IB.CHG.CHK.ENQ");
            XmlHelper xmlHelperCommEnq = XmlHelper.GetInstance(commEnq_result.ResponseXml);
            CommFee = xmlHelperCommEnq.GetXPath(commEnq_result.ResponseXml, "//CHG_AMT").Trim();
            string Fee = "WAIVE";

            //Send CUP.Card.Debit
            CMMControler m_CMMControler = new CMMControler();
            string tranFee = string.Format("D{0}{1}", Math.Truncate(Convert.ToDecimal(CommFee)).ToString().PadLeft(6, '0'), CommFee.Substring(CommFee.Length - 2));
            string bodyCUP = m_CMMControler.GetCard_Debit_ContentMsg(debitACC, creditACC, tranAMT, tranFee, "6013", "03450000", "0X04   1", GetCURR_NUM(cURR), co_Code, "        07     ");
            AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Debit");
            XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
            string rs_Code = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");
            debitAMT = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ADD_AMT");
            if (string.IsNullOrEmpty(debitAMT))
                debitAMT = "0.0";
            else
                debitAMT = Convert.ToDecimal(string.Format("{0}.{1}", debitAMT.Substring(28, 10), debitAMT.Substring(38))).ToString();

            if (rs_Code == "00")
            {
                //Send T24.FT
                string bodyFT = GetT24_CardFT_Content(co_Code, "I", "", GetCURR_NUM(cURR), debitACC, creditACC, debitName, creditName, tranAMT, Fee, crt, pmt, bnm, paytype, refContent, remarks, fifler, "ITF001.0045");
                AppXmlExecResult t24_result = SendMsgToEAIProcess(context, bodyFT, "IB.IN.IND.TFR");
                XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
                rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
                string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

                if (rs_Code == "E-000000" && proc_ret == "SUCC")
                    status = "1";//SUCC
                else if (rs_Code == string.Empty)
                {
                    status = "2"; //ERROR RS
                    failCode = "CO1MA999";
                    failDescription = ErrorCodeMapping("T24", rs_Code);
                    new SendMail().Send("Do ACC.Transfer(no ErrorCoe) Error", "", string.Format("Do ACC.Transfer(no ErrorCoe) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                }
                else
                {
                    //R
                    status = "2"; //ERROR RS
                    failCode = "CO1MA999";
                    failDescription = ErrorCodeMapping("T24", rs_Code);

                    string msgType = "0200";
                    string dateTime_Now = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//TRAN_TIME");
                    string traceNo = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//SYS_TRACE_NUM");
                    string acqCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ACQ_INST_ID_CO");
                    string forCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FOR_INT_ID_CO");

                    string oriData = string.Format("{0}{1}{2}{3}{4}", msgType, traceNo, dateTime_Now, acqCode.PadLeft(11, '0'), forCode.PadLeft(11, '0'));
                    string bodyCUP_EC = m_CMMControler.GetEC_Card_Debit_ContentMsg(debitACC, creditACC, tranAMT, "6013", "03450000", "0X04   1", GetCURR_NUM(cURR), oriData, co_Code, "        07     ");
                    AppXmlExecResult cup_EC_result = SendMsgToEAIProcess(context, bodyCUP_EC, "CUP.Card.Debit.EC");

                    XmlHelper xmlHelperCUPRS_EC = XmlHelper.GetInstance(cup_EC_result.ResponseXml);
                    rs_Code = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//RES_CO");
                    debitAMT = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//ISS_INS_RES");
                    if (string.IsNullOrEmpty(debitAMT))
                        debitAMT = "0.0";
                    else
                        debitAMT = Convert.ToDecimal(string.Format("{0}.{1}", debitAMT.Split('C')[1].Substring(0, 10), debitAMT.Split('C')[1].Substring(10, 2))).ToString();

                    if (rs_Code != "00")
                        //SEND MAIL
                        new SendMail().Send("Do ACC.Transfer(R) Error", "", string.Format("Do ACC.Transfer(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                }
            }
            else
            {
                status = "2";//ERROR RS
                failCode = "CO1MA999";
                failDescription = string.Format("类其它错误:Code={0}", rs_Code);
            }

            Dictionary<string, string> expendDic = Get_2010767_Expend(debitAMT, creditACC, creditName, status, CommFee);
            string afterRS = CheckUC_ResponseProcess(m_UcControler, expendDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
            m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
            XmlDocument rs_UC = base.TransformCommMsg(commEnq_result.EaiRs.EaiErrCode, commEnq_result.EaiRs.EaiErrText, commEnq_result.EaiRs.EaiErrDetail, afterRS);
            return base.BuildExecResult(context, rs_UC);
        }

        private AppXmlExecResult DoNTCFTProcess(EaiContext context, UcControler m_UcControler, string debitACC, string creditACC, string tranAMT, string ntcFlag, string fullFlag, string co_Code)                                                           
        {
            //先傳送FT至T24
            string bodyFT = GetT24_NTCFTOUT_Content(co_Code, "I", "", debitACC, creditACC, tranAMT, ntcFlag, "ITF001.0068");
            AppXmlExecResult t24_result = SendMsgToEAIProcess(context, bodyFT, "ESCN.IB.IND.CALL.WDWL");
            //取得T24 Response判斷成功失敗
            XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
            string rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
            string rs_Msg = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_MSG");
            string interest = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_INTEREST");
            string tax = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_TAX");
            string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");
            string failCode = string.Empty;
            string failDescription = string.Empty;
            string status = string.Empty;
            Double acctInt = 0.00;

            if (rs_Code == "E-000000" && proc_ret == "SUCC")
            {
                //T24扣款成功，送銀聯
                Double tranAMTDB = Double.TryParse(tranAMT, out tranAMTDB) ? tranAMTDB : 0.00;
                acctInt = Double.TryParse(interest, out acctInt) ? acctInt : 0.00;
                tax = (tax != "") ? tax : "0.00";

                string tranAMTAll = (tranAMTDB + acctInt).ToString();

                m_log.Info("tranAMT, acctInt" + tranAMT + ", " + acctInt);
                m_log.Info("tranAMTAll=" + tranAMTAll);

                CMMControler m_CMMControler = new CMMControler();
                string bodyCUP = m_CMMControler.GetCard_Credit_ContentMsg(creditACC, debitACC, tranAMTAll, "6013", "03450000", GetCURR_NUM("CNY"), co_Code);
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Credit");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                rs_Code = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");

                if (rs_Code == "00")
                    //判斷銀聯入款成功
                    status = "1";  //SUCC
                else
                {
                    //銀聯入款如果失敗
                    failCode = "CO1MA999";  //error RS
                    failDescription = string.Format("类其它错误:Code={0}", rs_Code);

                    if (fullFlag != "01") //非全額取款時T24做R
                    {
                        string ftRspId = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_TXN_ID");

                        string bodyRFT = GetT24_NTCFTOUT_Content(GetCoCode(debitACC), "R", ftRspId, debitACC, creditACC, tranAMT, "ITF001.0074", creditACC);
                        AppXmlExecResult t24_R_Result = SendMsgToEAIProcess(context, bodyRFT, "ESCN.IB.IND.CALL.WDWL");

                        XmlHelper xmlHelperT24RS_R = XmlHelper.GetInstance(t24_R_Result.ResponseXml);
                        rs_Code = xmlHelperT24RS_R.GetXPath(t24_R_Result.ResponseXml, "//ITF_RETURN_CODE");
                        string proc_ret_R = xmlHelperT24RS.GetXPath(t24_R_Result.ResponseXml, "//RSP_PROC_RET");

                        if (!rs_Code.Equals("E-000000") || proc_ret_R != "SUCC")
                            //send mail
                            new SendMail().Send("Do NTC.Transfer(R) Error", "6", string.Format("Do NTC.Transfer(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                    }
                    else
                        new SendMail().Send("Do NTC.Transfer(R) Error", "6", string.Format("Do NTC.Transfer(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                }
            }
            else
            {
                failCode = "CO1MA999"; //error RS
                failDescription = string.Format("类其它错误:Code={0}", rs_Code);
            }

            string depAmt = "0.00";
            string openDate = string.Empty;
            if (status != "1" || fullFlag != "01")
            {
                string bodyBalEnq = GetT24_AcctENQ_Content(debitACC);
                AppXmlExecResult BalEnq_result = SendMsgToEAIProcess(context, bodyBalEnq, "ACC.BAL.SINGLE.ENQ");
                XmlHelper xmlHelperBalEnq = XmlHelper.GetInstance(BalEnq_result.ResponseXml);
                depAmt = xmlHelperBalEnq.GetXPath(BalEnq_result.ResponseXml, "//DEP_AMT");
                openDate = xmlHelperBalEnq.GetXPath(BalEnq_result.ResponseXml, "//OPENING_DATE");
            }

            Dictionary<string, string> expendDic = Get_2010774_Expend(debitACC, creditACC, tranAMT, acctInt.ToString(), tax, depAmt, openDate);
            string afterRS = CheckUC_ResponseProcess(m_UcControler, expendDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
            m_log.Info("AppXmlExecResult ACC.TO.CARD RunImpl.afterRS={0}", afterRS);
            XmlDocument rs_UC = base.TransformCommMsg(t24_result.EaiRs.EaiErrCode, t24_result.EaiRs.EaiErrText, t24_result.EaiRs.EaiErrDetail, afterRS);
            return base.BuildExecResult(context, rs_UC);
        }

        private AppXmlExecResult DoCardVsTDAProcess(EaiContext context, UcControler m_UcControler, string accTYPE, string wdwlACC, string depAMT,
                                              string cURR, string tERM, string rolloverFLAG, string co_Code)
        {
            string failCode = string.Empty;
            string failDescription = string.Empty;
            string creditACC = string.Empty;
            string depVALDATE = string.Empty;
            string maturityDATE = string.Empty;
            string recID = string.Empty;
            string intRATE = string.Empty;
            string tdaID = string.Empty;
            string accBAL = "0.0";

            string status = string.Empty;

            //Send CUP.Card.Debit
            CMMControler m_CMMControler = new CMMControler();
            string bodyCUP = m_CMMControler.GetCard_Debit_ContentMsg(wdwlACC, creditACC, depAMT, "D00000000", "6013", "03450000", "0X03", GetCURR_NUM(cURR), co_Code, "        07     ");
            AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Debit");
            XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
            string rs_Code = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");
            accBAL = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ADD_AMT");
            string cardNo = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//PAN");

            if (string.IsNullOrEmpty(accBAL))
                accBAL = "0.0";
            else
                accBAL = Convert.ToDecimal(string.Format("{0}.{1}", accBAL.Substring(28, 10), accBAL.Substring(38))).ToString();

            if (rs_Code == "00") 
            {
                //Send T24.TDA 開定期帳戶
                string bodyFT = GetT24_TDA_Content(co_Code, "I", "", GetCURR_NUM(cURR), wdwlACC, depAMT, GetTERM_NUM(tERM), rolloverFLAG, "ITF001.0049", cardNo); //ITF_MSGKEY = ITF001.0049
                AppXmlExecResult t24_result = SendMsgToEAIProcess(context, bodyFT, "ESCN.IB.IND.TDA.INP");
                XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
                rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
                string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

                recID = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_TXN_ID ");
                tdaID = recID.Substring(5, 10);
                depVALDATE = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_DEP_VAL_DATE ");
                maturityDATE = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_MATURITY_DATE");
                intRATE = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_INT_RATE");

                if (rs_Code != "E-000000" || proc_ret != "SUCC")
                {
                    //R  
                    string rtnMsg = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_MSG");
                    failCode = "CO1MA999";
                    failDescription = ErrorCodeMapping("T24", rs_Code);

                    string msgType = "0200";
                    string dateTime_Now = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//TRAN_TIME");
                    string traceNo = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//SYS_TRACE_NUM");
                    string acqCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ACQ_INST_ID_CO");
                    string forCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FOR_INT_ID_CO");

                    string oriData = string.Format("{0}{1}{2}{3}{4}", msgType, traceNo, dateTime_Now, acqCode.PadLeft(11, '0'), forCode.PadLeft(11, '0'));
                    string bodyCUP_EC = m_CMMControler.GetEC_Card_Debit_ContentMsg(wdwlACC, creditACC, depAMT, "6013", "03450000", "0X03", GetCURR_NUM(cURR), oriData, co_Code, "        07     ");
                    AppXmlExecResult cup_EC_result = SendMsgToEAIProcess(context, bodyCUP_EC, "CUP.Card.Debit.EC");

                    XmlHelper xmlHelperCUPRS_EC = XmlHelper.GetInstance(cup_EC_result.ResponseXml);
                    rs_Code = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//RES_CO");
                    accBAL = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//ISS_INS_RES");

                    if (string.IsNullOrEmpty(accBAL))
                        accBAL = "0.0";
                    else
                        accBAL = Convert.ToDecimal(string.Format("{0}.{1}", accBAL.Split('C')[1].Substring(0, 10), accBAL.Split('C')[1].Substring(10, 2))).ToString();


                    if (rs_Code != "00")
                        //SEND MAIL
                        new SendMail().Send("Do CARD TO TDA(R) Error", "", string.Format("Do CARD TO TDA(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                }
            }
            else 
            {
                failCode = "CO1MA999";
                failDescription = string.Format("类其它错误:Code={0}", rs_Code);
            }

            Dictionary<string, string> expendDic = Get_2010782_Expend(wdwlACC, accBAL, tdaID, recID, tERM, accTYPE, depVALDATE, maturityDATE, intRATE);
            string afterRS = CheckUC_ResponseProcess(m_UcControler, expendDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
            m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
            XmlDocument rs_UC = base.TransformCommMsg(cup_result.EaiRs.EaiErrCode, cup_result.EaiRs.EaiErrText, cup_result.EaiRs.EaiErrDetail, afterRS);
            return base.BuildExecResult(context, rs_UC);

        }

        /// <summary>
        /// 銀聯卡定期轉活期
        /// </summary>
        /// <param name="context"></param>
        /// <param name="m_UcControler"></param>
        /// <param name="txnID"></param>
        /// <param name="settleAcct"></param>
        /// <param name="co_Code"></param>
        private AppXmlExecResult DoCardTDAtoCardProcess(EaiContext context, UcControler m_UcControler, string debitACC, string creditAcc, string cURR, string tranAMT, string wdwlType)
        {

            string bodyFT = string.Empty;
            AppXmlExecResult t24_result = null;

            string status = string.Empty;
            string failCode = string.Empty;
            string failDescription = string.Empty;

            string acctInt = string.Empty;
            string acctTax = string.Empty;
            Double acctIntDB = 0.00;
            Double acctTaxDB = 0.00;

            string co_code = GetCoCode(debitACC);

            //判斷是部提還是銷戶
            switch (wdwlType)
            {
                case "1":
                    //部提，傳送FT至T24
                    bodyFT = getCard_TDAFT_Content(co_code, "I", "", debitACC, cURR, tranAMT, creditAcc, "ITF001.0057", creditAcc);
                    t24_result = SendMsgToEAIProcess(context, bodyFT, "IB.IND.TDA.WDWL");
                    break;
                case "2":
                    //銷戶，傳送ACCOUNT CLOSURE至T24
                    bodyFT = GetCard_TDAClosure_Content(co_code, "I", debitACC, creditAcc, "ITF001.0058");
                    t24_result = SendMsgToEAIProcess(context, bodyFT, "IB.RT.TDW");
                    break;
                default:
                    break;
            }

            //取得T24 Response判斷成功失敗
            XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
            string rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
            string rs_Msg = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_MSG");
            string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

            if (rs_Code == "E-000000" && proc_ret == "SUCC")
            {

                switch (wdwlType)
                {
                    case "1":
                        acctInt = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_INTEREST");
                        acctTax = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_TAX");
                        break;
                    case "2":
                        acctInt = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//TOTAL_CR_INTEREST");
                        acctTax = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//TOTAL_TAX");
                        break;
                    default:
                        break;
                }

                Double tranAMTDB = Double.TryParse(tranAMT, out tranAMTDB) ? tranAMTDB : 0.00;
                acctIntDB = Double.TryParse(acctInt, out acctIntDB) ? acctIntDB : 0.00;
                //acctTaxDB = Double.TryParse(acctTax, out acctTaxDB) ? acctTaxDB : 0.00;

                //string tranAMTAll = (tranAMTDB + acctIntDB + acctTaxDB).ToString(); 
                string tranAMTAll = (tranAMTDB + acctIntDB).ToString();

                m_log.Info("tranAMT, acctInt" + tranAMT + ", " + acctInt);
                m_log.Info("tranAMTAll=" + tranAMTAll);

                //銀聯入帳
                CMMControler m_CMMControler = new CMMControler();
                string bodyCUP = m_CMMControler.GetCard_Credit_ContentMsg(creditAcc, debitACC, tranAMTAll, "6013", "03450000", GetCURR_NUM(cURR), co_code);
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Credit");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                rs_Code = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");

                if (rs_Code == "00")
                {
                    //判斷銀聯入款成功
                    status = "1";//SUCC
                }
                else
                {
                    m_log.Info("wdwlType=" + wdwlType);
                    
                    //部提做R，銷戶直接SEND MAIL
                    switch (wdwlType)
                    {
                        case "1":
                            status = "2"; //ERROR RS
                            failCode = "CO1MA999";
                            failDescription = string.Format("类其它错误:Code={0}", rs_Code);

                            string ftRspId = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_TXN_ID");
                            string bodyRFT = getCard_TDAFT_Content(co_code, "R", ftRspId, debitACC, cURR, tranAMT, creditAcc, "ITF001.0070", creditAcc);
                            AppXmlExecResult t24_R_Result = SendMsgToEAIProcess(context, bodyRFT, "IB.IND.TDA.WDWL");

                            m_log.Info("T24 OK, CUP ERROR, T24 R: bodyRFT=" + bodyRFT);

                            XmlHelper xmlHelperT24RS_R = XmlHelper.GetInstance(t24_R_Result.ResponseXml);
                            rs_Code = xmlHelperT24RS_R.GetXPath(t24_R_Result.ResponseXml, "//ITF_RETURN_CODE");
                            string proc_ret_R = xmlHelperT24RS.GetXPath(t24_R_Result.ResponseXml, "//RSP_PROC_RET");

                            if (!rs_Code.Equals("E-000000") || proc_ret_R != "SUCC")
                                //send mail
                                new SendMail().Send("银联卡定存转活期，银联卡入账失败", "6", string.Format("银联卡定存转活期，T24已扣帐，但银联卡入账失败, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                            break;
                        case "2":
                            //send mail
                            new SendMail().Send("银联卡定存转活期，银联卡入账失败", "6", string.Format("银联卡定存转活期，T24已销户，但银联卡入账失败, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                            break;
                        default:
                            break;
                    }
                }
                    

            }
            else
            {
                status = "2"; //ERROR RS
                failCode = "CO1MA999";
                failDescription = ErrorCodeMapping("T24", rs_Code);
            }

            //取得交易後的餘額
            string bodyBalEnq = Get2010772_ENQ_Content(debitACC);
            AppXmlExecResult BalEnq_result = SendMsgToEAIProcess(context, bodyBalEnq, "ACC.CURR.BAL.ENQ");
            XmlHelper xmlHelperBalEnq = XmlHelper.GetInstance(BalEnq_result.ResponseXml);
            string balAmt = xmlHelperBalEnq.GetXPath(BalEnq_result.ResponseXml, "//WORKING_BALANCE").Trim();

            Dictionary<string, string> expendDic = Get_2010783_Expend(debitACC, creditAcc, balAmt, acctIntDB.ToString(), acctTax);
            string afterRS = CheckUC_ResponseProcess(m_UcControler, expendDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
            m_log.Debug("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
            XmlDocument rs_UC = base.TransformCommMsg(t24_result.EaiRs.EaiErrCode, t24_result.EaiRs.EaiErrText, t24_result.EaiRs.EaiErrDetail, afterRS);
            return base.BuildExecResult(context, rs_UC);

        }

        private AppXmlExecResult DoNTCOPENProcess(EaiContext context, UcControler m_UcControler, string debitACC, string CustNO, string cURR, string tranAMT, string ntcCode, string co_Code)
        {
            string debitAMT = "0.0";
            string creditACC = string.Empty;
            string valDate = string.Empty;
            string matDate = string.Empty;
            string intRate = string.Empty;
            string failCode = string.Empty;
            string failDescription = string.Empty;

            #region 1.發ACCOUNT,ESCN.IB.NEW.RT.NDA至T24取開戶帳號creditACC
            string ntcCodetoT24 = (ntcCode == "1") ? "1D" : "7D";
            string bodyAC = GetT24_NTCOPEN_Content(co_Code, "I", "", CustNO, GetCURR_NUM(cURR), "ITF001.0064", tranAMT, ntcCodetoT24, debitACC);
            AppXmlExecResult t24_result = SendMsgToEAIProcess(context, bodyAC, "ESCN.IB.NEW.RT.NDA");
            XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
            string rs_Code = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
            string rs_Msg = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_MSG");
            string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

            if (rs_Code == "E-000000" && proc_ret == "SUCC")
            {
                creditACC = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_TXN_ID");
                valDate = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_DEP_VAL_DATE");
                matDate = string.IsNullOrEmpty(xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_MATURITY_DATE"))  ? "29991231" : xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_MATURITY_DATE");
                intRate = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_INT_RATE");

                #region 2.組電文發CUP.Card.Debit至銀聯
                CMMControler m_CMMControler = new CMMControler();
                string bodyCUP = m_CMMControler.GetCard_Debit_ContentMsg(debitACC, creditACC, tranAMT, "D00000000", "6013", "03450000", "0X03", GetCURR_NUM(cURR), co_Code, "        07     ");
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Debit");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                string cup_rs_Code = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");
                debitAMT = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ADD_AMT");
                #region debitAMT 取數
                if (string.IsNullOrEmpty(debitAMT))
                    debitAMT = "0.0";
                else
                    debitAMT = Convert.ToDecimal(string.Format("{0}.{1}", debitAMT.Substring(28, 10), debitAMT.Substring(38))).ToString();
                #endregion

                if (cup_rs_Code == "00")
                {
                    #region 3.發FUNDS.TRANSFER,ESCN.IB.IND.CALL.ACC[個人通知存款开户转账交易（網銀）]至T24
                    string bodyFT = GetT24_NTCFTIN_Content(co_Code, "I", "", debitACC, tranAMT, creditACC, "ITF001.0073");
                    AppXmlExecResult t24_FT_Result = SendMsgToEAIProcess(context, bodyFT, "ESCN.IB.IND.CALL.ACC");
                    XmlHelper xmlHelperT24FTRS = XmlHelper.GetInstance(t24_FT_Result.ResponseXml);
                    string t24_FT_RSCode = xmlHelperT24FTRS.GetXPath(t24_FT_Result.ResponseXml, "//ITF_RETURN_CODE");
                    string t24_FT_Proc = xmlHelperT24FTRS.GetXPath(t24_FT_Result.ResponseXml, "//RSP_PROC_RET");

                    if (t24_FT_RSCode != "E-000000" || t24_FT_Proc != "SUCC")
                    {
                        //失敗R掉
                        string rtnMsg = xmlHelperT24FTRS.GetXPath(t24_FT_Result.ResponseXml, "//ITF_RETURN_MSG");
                        failCode = "CO1MA999";
                        failDescription = string.Format("类其它错误:Code={0}", t24_FT_RSCode);

                        string msgType = "0200";
                        string dateTime_Now = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//TRAN_TIME");
                        string traceNo = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//SYS_TRACE_NUM");
                        string acqCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ACQ_INST_ID_CO");
                        string forCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FOR_INT_ID_CO");

                        string oriData = string.Format("{0}{1}{2}{3}{4}", msgType, traceNo, dateTime_Now, acqCode.PadLeft(11, '0'), forCode.PadLeft(11, '0'));
                        string bodyCUP_EC = m_CMMControler.GetEC_Card_Debit_ContentMsg(debitACC, creditACC, tranAMT, "6013", "03450000", "0X03", GetCURR_NUM(cURR), oriData, co_Code, "        07     ");
                        AppXmlExecResult cup_EC_result = SendMsgToEAIProcess(context, bodyCUP_EC, "CUP.Card.Debit.EC");
                        XmlHelper xmlHelperCUPRS_EC = XmlHelper.GetInstance(cup_EC_result.ResponseXml);
                        string cup_EC_RSCode = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//RES_CO");
                        debitAMT = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//ISS_INS_RES");
                        if (string.IsNullOrEmpty(debitAMT))
                            debitAMT = "0.0";
                        else
                            debitAMT = Convert.ToDecimal(string.Format("{0}.{1}", debitAMT.Split('C')[1].Substring(0, 10), debitAMT.Split('C')[1].Substring(10, 2))).ToString();

                        if (cup_EC_RSCode != "00")
                            //SEND MAIL
                            new SendMail().Send("Do ACC.Transfer(R) Error", "", string.Format("Do ACC.Transfer(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                    }
                    Dictionary<string, string> expendFT_Dic = Get_2010784_Expend(debitAMT, creditACC, valDate, matDate, ntcCode, tranAMT, intRate);
                    string afterRS = CheckUC_ResponseProcess(m_UcControler, expendFT_Dic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                    m_log.Info("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
                    XmlDocument rs_UC = base.TransformCommMsg(t24_FT_Result.EaiRs.EaiErrCode, t24_FT_Result.EaiRs.EaiErrText, t24_FT_Result.EaiRs.EaiErrDetail, afterRS);
                    return base.BuildExecResult(context, rs_UC);
                    #endregion
                }
                else
                {
                    failCode = "CO1MA999";
                    failDescription = string.Format("类其它错误:Code={0}", cup_rs_Code);
                    Dictionary<string, string> expendDic = Get_2010784_Expend(debitAMT, creditACC, valDate, matDate, ntcCode, tranAMT, intRate);
                    string afterCUP_RS = CheckUC_ResponseProcess(m_UcControler, expendDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                    m_log.Info("AppXmlExecResult RunImpl.afterCUPRS={0}", afterCUP_RS);
                    XmlDocument CUPrs_UC = base.TransformCommMsg(cup_result.EaiRs.EaiErrCode, cup_result.EaiRs.EaiErrText, cup_result.EaiRs.EaiErrDetail, afterCUP_RS);
                    return base.BuildExecResult(context, CUPrs_UC);
                }
                #endregion 2.組電文發CUP.Card.Debit至銀聯
            }
            else
            {
                failCode = "CO1MA999";
                failDescription = string.Format("类其它错误:Code={0}", rs_Code);

                Dictionary<string, string> expendDic = Get_2010784_Expend(debitAMT, creditACC, valDate, matDate, ntcCode, tranAMT, intRate);
                string afterRS = CheckUC_ResponseProcess(m_UcControler, expendDic, failCode, failDescription); //需將UC的結果回傳回去(改變RS)
                m_log.Info("AppXmlExecResult RunImpl.afterRS={0}", afterRS);
                XmlDocument rs_UC = base.TransformCommMsg(t24_result.EaiRs.EaiErrCode, t24_result.EaiRs.EaiErrText, t24_result.EaiRs.EaiErrDetail, afterRS);
                return base.BuildExecResult(context, rs_UC);
            }
            #endregion 1.發ACCOUNT,ESCN.IB.NEW.RT.NDA至T24取開戶帳號creditACC
        }

        private List<string> CreateFileContentList(XmlHelper xmlHelperCUPRS, XmlDocument CardxmlDocument,
                                                                 XmlDocument xmlDocument, List<string> fileContentList, string AccNo,
                                                                 string retCode, string cardStat, string acct_No)
        {
            try
            {
                #region 銀聯Response
                string car_acct_Seno = AccNo.Substring(AccNo.Length - 10);
                string car_acct_No = AccNo;
                string car_Currency = "CNY";
                string car_acct_Title = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//NAME");
                string car_acct_Type = "02";
                string car_Term = "D0";
                string car_c_Rollover_Amt = "";
                string car_c_Fcy_Type = "3";
                string car_opening_Date = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//OPEN_DATE");
                string car_c_Maturity_Date = "";
                string car_val_Date = "";
                string car_c_Dep_Amt = "";
                string car_y_Interest = "";
                string car_y_Tax = "";
                string car_working_Bal = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//BALANCE2");
                string car_onl_Cleared_Bal = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//BALANCE1");
                string car_account_Type = "1";
                string card_acct_Status = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//CARD_STAT");
                string car_acct_Status = Get_Acct_Status(card_acct_Status);
                string car_c_Int_Rate = "";
                string car_ac_Company = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//BRN_NO");
                string car_company_Name = xmlHelperCUPRS.GetXPath(CardxmlDocument, "//BRN_NO");
                string car_ntc_Status = "";
                string car_c_Remark = "";
                string car_ntc_Amt = "";
                string car_ntc_Bal = "";
                string car_ntc_Prsv_Amt = "";

                if (!retCode.Equals("000000") || !cardStat.Equals(""))
                {
                    fileContentList.Add("");
                }
                else
                {
                    StringBuilder sb_car = new StringBuilder();
                    sb_car.Append(car_acct_Seno).Append("|");//子账户序号
                    sb_car.Append(car_acct_No).Append("|");//子帐号账号
                    sb_car.Append(car_Currency).Append("|");//币种
                    sb_car.Append(car_acct_Title).Append("|");//账户名称
                    sb_car.Append(car_acct_Type).Append("|");//储种
                    sb_car.Append(car_Term).Append("|");//存期ㄍ
                    sb_car.Append(car_c_Rollover_Amt).Append("|");//转存标志
                    sb_car.Append(car_c_Fcy_Type).Append("|");//钞汇标志
                    sb_car.Append(car_opening_Date).Append("|");//开户日期
                    sb_car.Append(car_c_Maturity_Date).Append("|");//到期日期
                    sb_car.Append(car_val_Date).Append("|");//起息日期
                    sb_car.Append(car_c_Dep_Amt).Append("|");//本金
                    sb_car.Append(car_y_Interest).Append("|");//利息
                    sb_car.Append(car_y_Tax).Append("|");//利息税
                    sb_car.Append(car_working_Bal).Append("|");//可用余额
                    sb_car.Append(car_onl_Cleared_Bal).Append("|");//账户余额
                    sb_car.Append(car_account_Type).Append("|");//账户类型
                    sb_car.Append(car_acct_Status).Append("|");//账户状态
                    sb_car.Append(car_c_Int_Rate).Append("|");//利率
                    sb_car.Append(car_ac_Company).Append("|");//开户机构号
                    sb_car.Append(car_company_Name).Append("|");//开户机构名
                    sb_car.Append(car_ntc_Status).Append("|");//通知状态
                    sb_car.Append(car_c_Remark).Append("|");//摘要
                    sb_car.Append(car_ntc_Amt).Append("|");//已通知金额
                    sb_car.Append(car_ntc_Bal).Append("|");//未通知余额
                    sb_car.Append(car_ntc_Prsv_Amt).Append("|");//预约支取金额
                    fileContentList.Add(sb_car.ToString());
                }
                #endregion 銀聯Response

                #region T24Response
                XDocument xDocument = XDocument.Parse(xmlDocument.InnerXml);
                var enqDataLst = xDocument.Root
                                          .DescendantNodes().OfType<XElement>()
                                          .Where(p => p.Name.LocalName == "RSP_MSG_ROW")
                                          .ToList();

                if (string.IsNullOrEmpty(acct_No))
                {
                    fileContentList.Add("");
                }
                else
                {
                    foreach (XElement xE in enqDataLst)
                    {
                        StringBuilder sb = new StringBuilder();
                        IEnumerable<XElement> subXE = xE.DescendantNodes().OfType<XElement>();

                        string acct_Seno = subXE.Where(p => p.Name.LocalName == "ACCT_SENO").SingleOrDefault().Value.Trim();
                        sb.Append(acct_Seno).Append("|");//子账户序号

                        acct_No = subXE.Where(p => p.Name.LocalName == "ACCT_NO").SingleOrDefault().Value.Trim();
                        sb.Append(acct_No).Append("|");//子帐号账号

                        string Currency = subXE.Where(p => p.Name.LocalName == "CURRENCY").SingleOrDefault().Value.Trim();
                        sb.Append(Currency).Append("|");//币种

                        string acct_Title = subXE.Where(p => p.Name.LocalName == "ACCT_TITLE").SingleOrDefault().Value.Trim();
                        sb.Append(acct_Title).Append("|");//账户名称

                        string acct_Type = subXE.Where(p => p.Name.LocalName == "ACCT_TYPE").SingleOrDefault().Value.Trim();
                        sb.Append(acct_Type).Append("|");//储种

                        string Term = subXE.Where(p => p.Name.LocalName == "TERM").SingleOrDefault().Value.Trim();
                        sb.Append(Term).Append("|");//存期

                        string c_Rollover_Amt = subXE.Where(p => p.Name.LocalName == "C_ROLLOVER_AMT").SingleOrDefault().Value.Trim();
                        sb.Append(c_Rollover_Amt).Append("|");//转存标志

                        string c_Fcy_Type = subXE.Where(p => p.Name.LocalName == "C_FCY_TYPE").SingleOrDefault().Value.Trim();
                        sb.Append(c_Fcy_Type).Append("|");//钞汇标志

                        string opening_Date = subXE.Where(p => p.Name.LocalName == "OPENING_DATE").SingleOrDefault().Value.Trim();
                        sb.Append(opening_Date).Append("|");//开户日期

                        string c_Maturity_Date = subXE.Where(p => p.Name.LocalName == "C_MATURITY_DATE").SingleOrDefault().Value.Trim();
                        sb.Append(c_Maturity_Date).Append("|");//到期日期

                        string val_Date = subXE.Where(p => p.Name.LocalName == "VAL_DATE").SingleOrDefault().Value.Trim();
                        sb.Append(val_Date).Append("|");//起息日期

                        string c_Dep_Amt = subXE.Where(p => p.Name.LocalName == "C_DEP_AMT").SingleOrDefault().Value.Trim();
                        sb.Append(c_Dep_Amt).Append("|");//本金

                        string y_Interest = subXE.Where(p => p.Name.LocalName == "Y_INTEREST").SingleOrDefault().Value.Trim();
                        sb.Append(y_Interest).Append("|");//利息

                        string y_Tax = subXE.Where(p => p.Name.LocalName == "Y_TAX").SingleOrDefault().Value.Trim();
                        sb.Append(y_Tax).Append("|");//利息税

                        string working_Bal = subXE.Where(p => p.Name.LocalName == "WORKING_BAL").SingleOrDefault().Value.Trim();
                        sb.Append(working_Bal).Append("|");//可用余额

                        string onl_Cleared_Bal = subXE.Where(p => p.Name.LocalName == "ONL_CLEARED_BAL").SingleOrDefault().Value.Trim();
                        sb.Append(onl_Cleared_Bal).Append("|");//账户余额

                        string account_Type = subXE.Where(p => p.Name.LocalName == "ACCOUNT_TYPE").SingleOrDefault().Value.Trim();
                        sb.Append(account_Type).Append("|");//账户类型

                        string acct_Status = subXE.Where(p => p.Name.LocalName == "ACCT_STATUS").SingleOrDefault().Value.Trim();
                        sb.Append(acct_Status).Append("|");//账户状态

                        string c_Int_Rate = subXE.Where(p => p.Name.LocalName == "C_INT_RATE").SingleOrDefault().Value.Trim();
                        sb.Append(c_Int_Rate).Append("|");//利率

                        string ac_Company = subXE.Where(p => p.Name.LocalName == "AC_COMPANY").SingleOrDefault().Value.Trim();
                        sb.Append(ac_Company).Append("|");//开户机构号

                        string company_Name = subXE.Where(p => p.Name.LocalName == "COMPANY_NAME").SingleOrDefault().Value.Trim();
                        sb.Append(company_Name).Append("|");//开户机构名

                        string ntc_Status = subXE.Where(p => p.Name.LocalName == "NTC_STATUS").SingleOrDefault().Value.Trim();
                        sb.Append(ntc_Status).Append("|");//通知状态

                        string c_Remark = subXE.Where(p => p.Name.LocalName == "C_REMARK").SingleOrDefault().Value.Trim();
                        sb.Append(c_Remark).Append("|");//摘要

                        string ntc_Amt = subXE.Where(p => p.Name.LocalName == "NTC_AMT").SingleOrDefault().Value.Trim();
                        sb.Append(ntc_Amt).Append("|");//已通知金额

                        string ntc_Bal = subXE.Where(p => p.Name.LocalName == "NTC_BAL").SingleOrDefault().Value.Trim();
                        sb.Append(ntc_Bal).Append("|");//未通知余额

                        string ntc_Prsv_Amt = subXE.Where(p => p.Name.LocalName == "NTC_PRSV_AMT").SingleOrDefault().Value.Trim();
                        sb.Append(ntc_Prsv_Amt).Append("|");//预约支取金额

                        fileContentList.Add(sb.ToString());
                    }
                }
                #endregion T24Response

                return fileContentList;
            }
            catch (Exception ex)
            {
                m_log.ErrorException("CreateFileContentList Error!!!" + ex.ToString(), ex);
                return null;
            }
        }

        private Dictionary<string, string> Get_2010766_Expend(string debitACC, string debitAMT, string creditACC, string creditName, string status)
        {
            Dictionary<string, string> expendDic = new Dictionary<string, string>();

            expendDic.Add("4157", debitACC);  //付款账号
            expendDic.Add("4315", debitAMT);  //付款账户余额
            expendDic.Add("4161", creditACC);  //收款人账号
            expendDic.Add("4900", creditName);  //收款人姓名
            expendDic.Add("4345", status);  //交易状态

            return expendDic;
        }

        private Dictionary<string, string> Get_2010767_Expend(string debitAMT, string creditACC, string creditName, string status, string CommFee)
        {
            Dictionary<string, string> expendDic = new Dictionary<string, string>();

            expendDic.Add("4315", debitAMT);  //付款账户余额
            expendDic.Add("4161", creditACC);  //收款人账号
            expendDic.Add("4900", creditName);  //收款人姓名
            expendDic.Add("4345", status);  //交易状态
            expendDic.Add("4165", CommFee);  //汇款手续费

            return expendDic;
        }

        private Dictionary<string, string> Get_2010774_Expend(string debitACC, string creditACC, string debitAMT, string interest, string tax, string depAmt, string openDate)
        {
            Dictionary<string, string> expendDic = new Dictionary<string, string>();

            expendDic.Add("4322", debitACC);  //付款账号
            expendDic.Add("4300", creditACC);  //收款账号
            expendDic.Add("4141", depAmt);  //本金
            expendDic.Add("4123", interest);  //利息
            expendDic.Add("4033", tax);  //利息稅
            expendDic.Add("4179", openDate);  //開戶日期

            return expendDic;
        }

        private Dictionary<string, string> Get_2010782_Expend(string wdwlACC, string accBAL, string tdaID, string recID, string tERM,
                                                                                                 string accTYPE, string depVALDATE, string maturityDATE, string intRATE)
        {
            Dictionary<string, string> expendDic = new Dictionary<string, string>();

            expendDic.Add("4321", wdwlACC);  //活期账号
            expendDic.Add("4308", accBAL);  //活期账户余额DBACCT.WKBALANCE
            expendDic.Add("4010", tdaID);  //定期序號TADID
            expendDic.Add("4322", recID);  //子帳号RECID
            expendDic.Add("4018", tERM);  //存期
            expendDic.Add("4329", accTYPE);  //存款類型ACCT_TYPE
            expendDic.Add("4119", depVALDATE);  //起息日C.DEP.VAL.DATE
            expendDic.Add("4120", maturityDATE);  //到期日C.MATURITY.DATE
            expendDic.Add("4091", intRATE);  //年利率C.INT.RATE

            return expendDic;
        }

        private Dictionary<string, string> Get_2010783_Expend(string debitAcc, string creditAcc, string acctBal, string acctInt, string acctTax)
        {
            Dictionary<string, string> expendDic = new Dictionary<string, string>();

            expendDic.Add("4322", debitAcc);    // 定期帳戶
            expendDic.Add("4321", creditAcc);   //入帳活期帳戶
            expendDic.Add("4308", acctBal);     //定存帳戶餘額
            expendDic.Add("4123", acctInt);     //利息
            expendDic.Add("4033", acctTax);     //利息稅

            return expendDic;
        }

        private Dictionary<string, string> Get_2010784_Expend(string debitAMT, string creditACC, string valDate, string matDate, string ntcCode, string tranAMT, string intRate)
        {
            Dictionary<string, string> expendDic = new Dictionary<string, string>();

            expendDic.Add("4308", debitAMT);  //卡餘額
            expendDic.Add("4901", creditACC); //通知帳號
            expendDic.Add("4119", valDate);   //起息日
            expendDic.Add("4120", matDate);   //到期日
            expendDic.Add("4060", ntcCode);   //通知類型
            expendDic.Add("4317", tranAMT);   //通知餘額
            expendDic.Add("4100", tranAMT);   //轉存金額
            expendDic.Add("4091", intRate);   //年利率
            
            return expendDic;
        }

        private string GetT24_FT_Content(string co_Code, string proc_FUNC, string txnID,
                                        string cURR, string debitACC, string creditACC, string creditName, string tranAMT,
                                        string refContent, string remarks, string fifler, string itfID, string cardNO, string transGate)
        {
            StringBuilder sb = new StringBuilder();
            #region FT XML MSG
            sb.Append("<T24_DATA>"); 
            sb.Append("<T24_EAI>"); 
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "FUNDS.TRANSFER");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "IB.IN.IND.TFR");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<DEBIT_CURRENCY sp='1' mp='1'>{0}</DEBIT_CURRENCY>", cURR);
            sb.AppendFormat("<DEBIT_ACCT_NO sp='1' mp='1'>{0}</DEBIT_ACCT_NO>", debitACC);
            sb.AppendFormat("<CREDIT_CURRENCY sp='1' mp='1'>{0}</CREDIT_CURRENCY>", cURR);
            sb.AppendFormat("<CREDIT_ACCT_NO sp='1' mp='1'>{0}</CREDIT_ACCT_NO>", creditACC);
            sb.AppendFormat("<C_PAYEE_NAME sp='1' mp='1'>{0}</C_PAYEE_NAME>", creditName);
            sb.AppendFormat("<DEBIT_AMOUNT sp='1' mp='1'>{0}</DEBIT_AMOUNT>", tranAMT);
            sb.AppendFormat("<DEBIT_THEIR_REF sp='1' mp='1'>{0}</DEBIT_THEIR_REF>", refContent);
            sb.AppendFormat("<C_REMARKS sp='1' mp='1'>{0}</C_REMARKS>", remarks);
            sb.AppendFormat("<C_REMARK sp='1' mp='1'>{0}</C_REMARK>", refContent);
            sb.AppendFormat("<L_TRANS_GATE sp='1' mp='1'>{0}</L_TRANS_GATE>", transGate);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<L_IB_PMT_M sp='1' mp='1'>{0}</L_IB_PMT_M>", fifler);
            sb.AppendFormat("<L_CARD_NO sp='1' mp='1'>{0}</L_CARD_NO>", cardNO);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>"); 
            #endregion
            return sb.ToString();
        }

        private string GetT24_CardENQ_Content(string cardNo)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.CARD.CUSDATA.ENQ XML MSG
            sb.Append("<T24_DATA>"); 
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.CARD.CUSDATA.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "CUP001.0001");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<CARD_NO op='EQ'>{0}</CARD_NO>", cardNo);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>"); 
            #endregion
            return sb.ToString();
        }

        private string GetT24_LimitENQ_Content(string debitACC)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.BP.DEB.LIM.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.BP.DEB.LIM.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "IB001.0010");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<ACCOUNT_NUMBER op='EQ'>{0}</ACCOUNT_NUMBER>", debitACC);
            sb.AppendFormat("<VALUE_DATE op='EQ'>{0}</VALUE_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<TRANS_GATE op='EQ'>{0}</TRANS_GATE>", "01");
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_DebLim_Content(string co_Code, string proc_FUNC, string debitACC, string tranAMT, string cURR, string creditACC, string checkCustNo)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.BP.DEBIT.LIMIT XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "ESCN.BP.DEBIT.LIMIT");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", debitACC + "." + DateTime.Today.ToString("yyyyMMdd") + "." + DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<CURRENCY sp='1' mp='1'>{0}</CURRENCY>", cURR);
            sb.AppendFormat("<DEBIT_ACCT sp='1' mp='1'>{0}</DEBIT_ACCT>", debitACC);
            sb.AppendFormat("<AMOUNT sp='1' mp='1'>{0}</AMOUNT>", tranAMT);
            sb.AppendFormat("<CREDIT_ACCT sp='1' mp='1'>{0}</CREDIT_ACCT>", creditACC);
            sb.AppendFormat("<VALUE_DATE sp='1' mp='1'>{0}</VALUE_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<CARD_NO sp='1' mp='1'>{0}</CARD_NO>", debitACC);
            sb.AppendFormat("<REFERENCE sp='1' mp='1'>{0}</REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<CUSTOMER_NO sp='1' mp='1'>{0}</CUSTOMER_NO>", checkCustNo);
            sb.AppendFormat("<TRANS_GATE sp='1' mp='1'>{0}</TRANS_GATE>", "01");
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", "IB001.0011");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_CommENQ_Content(string tranAMT, string cURR)
        {
            StringBuilder sb = new StringBuilder();
            #region IB.CHG.CHK.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "IB.CHG.CHK.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0035");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<TXN_TYPE op='EQ'>{0}</TXN_TYPE>", "AC");
            sb.AppendFormat("<TXN_AMOUNT op='EQ'>{0}</TXN_AMOUNT>", tranAMT);
            sb.AppendFormat("<COMM_TYPE op='EQ'>{0}</COMM_TYPE>", "PIBCNYREMIT");
            sb.AppendFormat("<CURR op='EQ'>{0}</CURR>", cURR);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string Get2010772_ENQ_Content(string acctNo)
        {
            StringBuilder sb = new StringBuilder();
            #region 2010772 ACC.CURR.BAL.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ACC.CURR.BAL.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0040");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<ACCOUNT_NUMBER op='EQ'>{0}</ACCOUNT_NUMBER>", acctNo);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_CardFT_Content(string co_Code, string proc_FUNC, string txnID,
                                string cURR, string debitACC, string creditACC, string debitName, string creditName, string tranAMT, string Fee,
                                string crt, string pmt, string bnm, string paytype, string refContent, string remarks, string fifler, string itfID)
        {
            StringBuilder sb = new StringBuilder();
            #region CardFT XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "FUNDS.TRANSFER");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "IB.INTERBK.IND");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<DEBIT_CURRENCY sp='1' mp='1'>{0}</DEBIT_CURRENCY>", cURR);
            sb.AppendFormat("<DEBIT_ACCT_NO sp='1' mp='1'>{0}</DEBIT_ACCT_NO>", debitACC);
            sb.AppendFormat("<CREDIT_CURRENCY sp='1' mp='1'>{0}</CREDIT_CURRENCY>", cURR);
            sb.AppendFormat("<DEBIT_AMOUNT sp='1' mp='1'>{0}</DEBIT_AMOUNT>", tranAMT);
            sb.AppendFormat("<C_PAYER_NAME sp='1' mp='1'>{0}</C_PAYER_NAME>", debitName);
            sb.AppendFormat("<C_PAYEE_ACCT_NO sp='1' mp='1'>{0}</C_PAYEE_ACCT_NO>", creditACC);
            sb.AppendFormat("<C_PAYEE_NAME sp='1' mp='1'>{0}</C_PAYEE_NAME>", creditName);
            sb.AppendFormat("<L_IB_CRT_B sp='1' mp='1'>{0}</L_IB_CRT_B>", crt);
            sb.AppendFormat("<L_ESCN_IB_BK_NM sp='1' mp='1'>{0}</L_ESCN_IB_BK_NM>", pmt);
            sb.AppendFormat("<L_IB_PMT_M sp='1' mp='1'>{0}</L_IB_PMT_M>", paytype);
            sb.AppendFormat("<COMMISSION_CODE mp='1' sp='1'>{0}</COMMISSION_CODE>", Fee); 
            sb.AppendFormat("<C_REMARKS sp='1' mp='1'>{0}</C_REMARKS>", remarks);
            sb.AppendFormat("<L_TRANS_GATE sp='1' mp='1'>{0}</L_TRANS_GATE>", "PIB");
            sb.AppendFormat("<DEBIT_THEIR_REF sp='1' mp='1'>{0}</DEBIT_THEIR_REF>", refContent);
            sb.AppendFormat("<C_REMARK sp='1' mp='1'>{0}</C_REMARK>", refContent);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_NTCFTOUT_Content(string co_Code, string proc_FUNC, string txnID, string debitACC, string creditACC, string tranAMT, string ntcFlag, string itfID)                                                                               
        {
            StringBuilder sb = new StringBuilder();
            #region NTC FT XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "FUNDS.TRANSFER");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "ESCN.IB.IND.CALL.WDWL");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<DEBIT_ACCT_NO sp='1' mp='1'>{0}</DEBIT_ACCT_NO>", debitACC);
            sb.AppendFormat("<CREDIT_ACCT_NO sp='1' mp='1'>{0}</CREDIT_ACCT_NO>", creditACC);
            sb.AppendFormat("<DEBIT_AMOUNT sp='1' mp='1'>{0}</DEBIT_AMOUNT>", tranAMT);
            sb.AppendFormat("<DEBIT_CURRENCY sp='1' mp='1'>{0}</DEBIT_CURRENCY>", "CNY");
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<L_IB_NTC_FLAG sp='1' mp='1'>{0}</L_IB_NTC_FLAG>", ntcFlag);
            sb.AppendFormat("<L_CARD_NO sp='1' mp='1'>{0}</L_CARD_NO>", creditACC);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_AcctENQ_Content(string AccNo)
        {
            StringBuilder sb = new StringBuilder();
            #region ACC.BAL.SINGLE.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ACC.BAL.SINGLE.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0030");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<ACCOUNT_NUMBER op='EQ'>{0}</ACCOUNT_NUMBER>", AccNo);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_TDA_Content(string co_Code, string proc_FUNC, string txnID, string cURR,
                         string wdwlACC, string depAMT, string tERM, string rolloverFLAG, string itfID, string cardNo)
        {
            StringBuilder sb = new StringBuilder();
            #region TDA XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "ACCOUNT");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "ESCN.IB.IND.TDA.INP");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<CURRENCY sp='1' mp='1'>{0}</CURRENCY>", cURR);
            sb.AppendFormat("<C_WDWL_ACCT sp='1' mp='1'>{0}</C_WDWL_ACCT>", wdwlACC);
            sb.AppendFormat("<C_DEP_AMT sp='1' mp='1'>{0}</C_DEP_AMT>", depAMT);
            sb.AppendFormat("<C_TERM sp='1' mp='1'>{0}</C_TERM>", tERM);
            sb.AppendFormat("<C_ROLLOVER_FLAG sp='1' mp='1'>{0}</C_ROLLOVER_FLAG>", rolloverFLAG);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<L_CARD_NO op='EQ'>{0}</L_CARD_NO>", cardNo);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string getCard_TDAFT_Content(string co_Code, string proc_FUNC, string txnID, string debitACC, string cURR,
                                         string tranAMT, string creditACC, string itfID, string cardNO)
        {
            StringBuilder sb = new StringBuilder();

            #region 2010783 TDA FT XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "FUNDS.TRANSFER");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "ESCN.IB.IND.TDA.WDWL");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<DEBIT_ACCT_NO sp='1' mp='1'>{0}</DEBIT_ACCT_NO>", debitACC);
            sb.AppendFormat("<DEBIT_CURRENCY sp='1' mp='1'>{0}</DEBIT_CURRENCY>", cURR);           
            sb.AppendFormat("<CREDIT_CURRENCY sp='1' mp='1'>{0}</CREDIT_CURRENCY>", cURR);
            sb.AppendFormat("<DEBIT_AMOUNT sp='1' mp='1'>{0}</DEBIT_AMOUNT>", tranAMT);         
            sb.AppendFormat("<CREDIT_ACCT_NO sp='1' mp='1'>{0}</CREDIT_ACCT_NO>", creditACC);
            sb.AppendFormat("<L_TRANS_GATE sp='1' mp='1'>{0}</L_TRANS_GATE>", "PIB");
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<L_CARD_NO sp='1' mp='1'>{0}</L_CARD_NO>", cardNO);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>"); 

            #endregion
            return sb.ToString();
        }
        

        private string GetCard_TDAClosure_Content(string co_Code, string proc_FUNC, string txnID,
                                string settleAcct, string itfID)
        {
            StringBuilder sb = new StringBuilder();
            #region 2010783 TDA CLOSURE XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "ACCOUNT.CLOSURE");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "IB.RT.TDW");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<SETTLEMENT_ACCT sp='1' mp='1'>{0}</SETTLEMENT_ACCT>", settleAcct);
            sb.AppendFormat("<L_TRANS_GATE sp='1' mp='1'>{0}</L_TRANS_GATE>", "PIB");
            sb.AppendFormat("<C_CARD_NO sp='1' mp='1'>{0}</C_CARD_NO>", settleAcct);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string Get5001_ENQ_Content(string debitACC)
        {
            StringBuilder sb = new StringBuilder();
            #region 5001 ACC BAL XML MSG

            sb.AppendFormat("<TRXTYPE>{0}</TRXTYPE>", "5001");
            sb.AppendFormat("<RETCODE>{0}</RETCODE>", "");
            sb.AppendFormat("<BNKNBR>{0}</BNKNBR>", "0345");
            sb.AppendFormat("<SOURCE>{0}</SOURCE>", "CT");
            sb.AppendFormat("<BRN_NO>{0}</BRN_NO>", "010002");
            sb.AppendFormat("<OPE_NO>{0}</OPE_NO>", "000001");
            sb.AppendFormat("<SEQNO>{0}</SEQNO>", "100921");
            sb.AppendFormat("<CARDNO>{0}</CARDNO>", debitACC);
            sb.AppendFormat("<PINFLAG>{0}</PINFLAG>", "0");
            sb.AppendFormat("<PIN>{0}</PIN>", "");

            #endregion
            return sb.ToString();
        }

        private string GetT24_CardAcctENQ_Content(string AccNo)
        {
            StringBuilder sb = new StringBuilder();
            #region CUS.TOACCT.ENQ.DTL XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "CUS.TOACCT.ENQ.DTL");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0052");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<_x0040_ID op='EQ'>{0}</_x0040_ID>", AccNo);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_NTCOPEN_Content(string co_Code, string proc_FUNC, string txnID, string CustNO, string cURR, string itfID, string tranAMT, string ntcCode, string debitACC)
        {
            StringBuilder sb = new StringBuilder();
            #region ACCOUNT,ESCN.IB.NEW.RT.NDA XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "ACCOUNT");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "ESCN.IB.NEW.RT.NDA");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<CUSTOMER sp='1' mp='1'>{0}</CUSTOMER>", CustNO);
            sb.AppendFormat("<CURRENCY sp='1' mp='1'>{0}</CURRENCY>", cURR);
            sb.AppendFormat("<C_DEP_AMT sp='1' mp='1'>{0}</C_DEP_AMT>", tranAMT);
            sb.AppendFormat("<C_SUB_PRD sp='1' mp='1'>{0}</C_SUB_PRD>", ntcCode);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<L_CARD_NO sp='1' mp='1'>{0}</L_CARD_NO>", debitACC);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_NTCFTIN_Content(string co_Code, string proc_FUNC, string txnID, string debitACC, string tranAMT, string creditACC, string itfID)
        {
            StringBuilder sb = new StringBuilder();
            #region FUNDS.TRANSFER,ESCN.IB.IND.CALL.ACC XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "FUNDS.TRANSFER");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "ESCN.IB.IND.CALL.ACC");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<DEBIT_ACCT_NO sp='1' mp='1'>{0}</DEBIT_ACCT_NO>", debitACC);
            sb.AppendFormat("<DEBIT_AMOUNT sp='1' mp='1'>{0}</DEBIT_AMOUNT>", tranAMT);
            sb.AppendFormat("<CREDIT_ACCT_NO sp='1' mp='1'>{0}</CREDIT_ACCT_NO>", creditACC);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<L_CARD_NO sp='1' mp='1'>{0}</L_CARD_NO>", debitACC);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey)
        {
            string msgContent = base.SendToEAIProcess(body, eAI_MsgKey);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, msgContent);

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(msgContent);
            XmlDocument subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString());
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }

        private string CheckUC_ResponseProcess(UcControler m_UcControler, Dictionary<string, string> expendDic, string failCode, string failDescription)
        {
            if (string.IsNullOrEmpty(failCode))
                return m_UcControler.GetToUCRS(expendDic);
            else
                return m_UcControler.GetFailUcRS(expendDic, failCode, failDescription);
        }

        private string ErrorCodeMapping(string sourceName, string sourceStatus)
        {
            Bankpro.EAI.Component.StatusData status = Bankpro.EAI.Component.ProjectCache.GetInstance().GetStatusData(sourceName, sourceStatus);

            if (status != null)
                return status.m_statusDesc;
            else
                return sourceStatus;

        }
        
    }
}
