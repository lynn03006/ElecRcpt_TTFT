﻿using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

using System.Data;
using System.IO;
using System.Messaging;
using System.Net;
using System.Xml.Linq;

using Bankpro.EAI.Utility;
using Bankpro.EAI.Component;
using Bankpro.EAI.Component.Xml;

namespace Bankpro.EAI.BPM
{
    public class UPCSettle : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.UPCSettle");
        private const string spN_GW = "GW";
        private const string custId_GW = "GW";
        private string m_FilePath = Environment.ExpandEnvironmentVariables(ProjectConfig.GetInstance().DropFilesPath);

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            switch (txID)
            {
                case "ESCN.BP.UPC.SETTLE"://EAI
                    return Do_961675_Process(context, correlationID, txID, txDef, requestXml);
                case "ESCN.BP.UPC.SETTLE_GW"://GW
                    return Do_961675_GW_Process(context, correlationID, txID, txDef, requestXml);
                //case "ESCN.BP.UPC.SETTLE_Query"://EAI
                //    return Do_961675_Query_Process(context, correlationID, txID, txDef, requestXml);
                case "ESCN.BP.ACC.INFO":  //ACCT INFO EAI
                    return Do_ACCENQ_Process(context, correlationID, txID, txDef, requestXml);
                case "ESCN.BP.ACC.INFO_GW":  //ACCT INFO GW
                    return Do_ACCENQ_GW_Process(context, correlationID, txID, txDef, requestXml);
                default:
                    return null;
            }

        }
        private AppXmlExecResult Do_961675_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                bool sendtoGWSucc = false;
                string upcRS = string.Empty;

                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);

                string transSource = xmlHelper.GetXPath(requestXml, "//L_TRANS_SOURCE").Trim();//交易來源(大額HVPS／小額BEPS／同城szfs／中行IBPS)

                string startDate = xmlHelper.GetXPath(requestXml, "//L_START_DATE").Trim();//對帳起始日
                string endDate = xmlHelper.GetXPath(requestXml, "//L_END_DATE").Trim();//對帳截至日
                m_log.Info("Do_961675_Process txID = [{0}] L_TRANS_SOURCE=[{1}] L_START_DATE=[{2}] L_END_DATE=[{3}]",
                           txID, transSource, startDate, endDate);

                if (!string.IsNullOrEmpty(transSource) && !string.IsNullOrEmpty(startDate) && !string.IsNullOrEmpty(endDate))
                {
                    string fileName = BuileFileName(startDate, endDate);//產生檔名
                    string msgContent = Build_961675InfoXml_Content(fileName, transSource, startDate, endDate);//產生包含961675資訊的XML
                    string eaiMsg = BuildToGateWayMsg(msgContent, txID + "_GW");
                    TransportAdapter transport = TransportManager.GetInstance().Get(txDef.TransportAdapter);
                    context.Set("strTITA", eaiMsg);
                    Component.DB.DbLog.InsertMsgLog(context, correlationID, "2", eaiMsg, false);
                    EaiResponse toGatewayRS = transport.SendReceive(context, txDef, null);
                    Component.DB.DbLog.InsertMsgLog(context, correlationID, "5", toGatewayRS.Xml.OuterXml, false);
                    string receiveString = XmlHelper.GetInstance(toGatewayRS.Xml).GetXPath(toGatewayRS.Xml, "//T24_DATA");
                    sendtoGWSucc = receiveString == "Get Data";
                    upcRS = BuildupcRS(sendtoGWSucc, fileName);
                }

                m_log.Info("Do_961675_Process txID = [{0}] UPC_Response = [{1}]", txID, upcRS);
                XmlDocument responseXml = sendtoGWSucc
                                         ? base.TransformCommMsg("0", "Info", "交易完成", upcRS)
                                         : base.TransformCommMsg("9999", "Info", "交易失敗", upcRS);
                return base.BuildExecResult(context, responseXml);
            }
            catch (Exception ex)
            {
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                m_log.ErrorException("Do_961675_Process Error!!! " + ex.ToString(), ex);
                return base.BuildExecResult(context, responseXml);
            }
        }
        private string BuileFileName(string startDate, string endDate)
        {
            StringBuilder sb = new StringBuilder();
            string fileName = string.Format("UPC-[{0}]-[{1}]-{2}", startDate, endDate, DateTime.Now.ToString("HHmmss"));
            return fileName;
        }
        private string Build_961675InfoXml_Content(string fileName, string transSource, string startDate, string endDate)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<T24_DATA>");
            sb.AppendFormat("<FILENAME>{0}</FILENAME>", fileName);
            sb.AppendFormat("<L_TRANS_SOURCE>{0}</L_TRANS_SOURCE>", transSource);//交易來源(大額HVPS／小額BEPS／同城szfs／中行IBPS)
            sb.AppendFormat("<L_INIT_DATE_START>{0}</L_INIT_DATE_START>", startDate);//對帳起始日
            sb.AppendFormat("<L_INIT_DATE_END>{0}</L_INIT_DATE_END>", endDate);//對帳截至日
            sb.Append("</T24_DATA>");
            return sb.ToString();
        }
        private string BuildToGateWayMsg(string msgContent, string msgKey)
        {
            string eaiMsg = base.SendToEAIProcess(msgContent, msgKey);
            return eaiMsg;
        }

        private string BuildupcRS(bool sendMsmqSucc, string fileName)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("<FILE_CHK>{0}</FILE_CHK>", sendMsmqSucc ? "1" : "0");
            sb.AppendFormat("<FILE_DATE>{0}</FILE_DATE>", DateTime.Now.ToString("yyyyMMdd"));
            sb.AppendFormat("<FILE_NAME>{0}</FILE_NAME>", sendMsmqSucc ? fileName : string.Empty);
            return sb.ToString();
        }

        private AppXmlExecResult Do_961675_GW_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                SettleQuery dodo = new SettleQuery(DoSettleQuery);
                dodo.BeginInvoke(context, correlationID, txID, txDef, requestXml, null, null);

                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", "Get Data");
                return base.BuildExecResult(context, rs);
            }
            catch (Exception ex)
            {
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                m_log.ErrorException("Do_961675_GW_Process Error!!! " + ex.ToString(), ex);
                return base.BuildExecResult(context, responseXml);
            }
        }

        private AppXmlExecResult Do_ACCENQ_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                bool sendtoGWSucc = false;
                string upcRS = string.Empty;

                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);

                string transDATE = xmlHelper.GetXPath(requestXml, "//DATE").Trim();  //DATE為空表示查詢全部資料，有值表示查詢該日期有變動資料
                m_log.Info("Do_ACCENQ_Process txID = [{0}] DATE=[{1}] ", txID, transDATE);

                string fileName = BuileACCENQName(transDATE);//產生檔名
                string msgContent = Build_ACCInfoXml_Content(fileName, transDATE); //產生包含ACCENQ資訊的XML
                string eaiMsg = BuildToGateWayMsg(msgContent, txID + "_GW");
                TransportAdapter transport = TransportManager.GetInstance().Get(txDef.TransportAdapter);
                context.Set("strTITA", eaiMsg);
                Component.DB.DbLog.InsertMsgLog(context, correlationID, "2", eaiMsg, false);
                EaiResponse toGatewayRS = transport.SendReceive(context, txDef, null);
                Component.DB.DbLog.InsertMsgLog(context, correlationID, "5", toGatewayRS.Xml.OuterXml, false);
                string receiveString = XmlHelper.GetInstance(toGatewayRS.Xml).GetXPath(toGatewayRS.Xml, "//T24_DATA");
                sendtoGWSucc = receiveString == "Get Data";
                upcRS = BuildupcRS(sendtoGWSucc, fileName);


                m_log.Info("Do_ACCENQ_Process txID = [{0}] UPC_Response = [{1}]", txID, upcRS);
                XmlDocument responseXml = sendtoGWSucc
                                         ? base.TransformCommMsg("0", "Info", "交易完成", upcRS)
                                         : base.TransformCommMsg("9999", "Info", "交易失敗", upcRS);
                return base.BuildExecResult(context, responseXml);
            }
            catch (Exception ex)
            {
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                m_log.ErrorException("Do_ACCENQ_Process Error!!! " + ex.ToString(), ex);
                return base.BuildExecResult(context, responseXml);
            }
        }

        private string BuileACCENQName(string transDate)
        {
            StringBuilder sb = new StringBuilder();
            string fileName = string.Format("UPC-{0}-{1}", "ACC-INFO", DateTime.Now.ToString("yyyyMMddHHmmss"));
            return fileName;
        }

        private string Build_ACCInfoXml_Content(string fileName, string transDATE)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<T24_DATA>");
            sb.AppendFormat("<FILENAME>{0}</FILENAME>", fileName);
            sb.AppendFormat("<DATE>{0}</DATE>", transDATE);
            sb.Append("</T24_DATA>");
            return sb.ToString();
        }

        private AppXmlExecResult Do_ACCENQ_GW_Process(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                ACCENQQuery dodo = new ACCENQQuery(DoACCENQQuery);
                dodo.BeginInvoke(context, correlationID, txID, txDef, requestXml, null, null);

                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", "Get Data");
                return base.BuildExecResult(context, rs);
            }
            catch (Exception ex)
            {
                XmlDocument responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                m_log.ErrorException("Do_ACCENQ_GW_Process Error!!! " + ex.ToString(), ex);
                return base.BuildExecResult(context, responseXml);
            }
        }

        private string BuildQueryContent(string transSource, string chkStrDate, string chkEndDate, string enqPreLine = "")
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.BP.UPC.SETTLE.ENQ");//TODO
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "UPC001.0011");//TODO
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE>{0}</ITF_ENQ_PRE_LINE>", enqPreLine);
            sb.AppendFormat("<L_TRANS_SOURCE op='EQ'>{0}</L_TRANS_SOURCE>", transSource);
            sb.AppendFormat("<L_INIT_DATE_START op='EQ'>{0}</L_INIT_DATE_START>", chkStrDate);
            sb.AppendFormat("<L_INIT_DATE_END op='EQ'>{0}</L_INIT_DATE_END>", chkEndDate);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            string newQueryString = string.Format("<T24_DATA>{0}</T24_DATA>", sb.ToString());
            return newQueryString;
        }

        private string BuildACCENQContent(string transDATE, string enqPreLine = "")
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.BP.ACC.INFO.ENQ");//TODO
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "UPC001.0014");//TODO
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE>{0}</ITF_ENQ_PRE_LINE>", enqPreLine);
            sb.AppendFormat("<DATE op='EQ'>{0}</DATE>", transDATE);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            string newQueryString = string.Format("<T24_DATA>{0}</T24_DATA>", sb.ToString());
            return newQueryString;
        }

        AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey, bool SendToEAI)
        {
            string msgContent = string.Empty;
            if (SendToEAI)
            { msgContent = base.SendToEAIProcess(body, eAI_MsgKey, spN_GW, custId_GW); }
            else
            { msgContent = base.SendToEAIProcess(body, eAI_MsgKey); }

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(msgContent);
            XmlDocument subRqXml = null;
            if (SendToEAI)
            { subRqXml = CopyToNewDocument(rq, spN_GW, custId_GW, eAI_MsgKey, Guid.NewGuid().ToString()); }
            else
            { subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString()); }
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, subRqXml.InnerXml);
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml, SendToEAI);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }
        private List<string> CreateFileContentList(XmlDocument rsXmlDocument, string fileName, List<string> fileContentList)
        {
            try
            {
                XDocument xDocument = XDocument.Parse(rsXmlDocument.InnerXml);
                var enqDataLst = xDocument.Root
                                          .DescendantNodes().OfType<XElement>()
                                          .Where(p => p.Name.LocalName == "RSP_MSG_ROW")
                                          .ToList();

                foreach (XElement xE in enqDataLst)
                {
                    StringBuilder sb = new StringBuilder();
                    IEnumerable<XElement> subXE = xE.DescendantNodes().OfType<XElement>();

                    string transSource = subXE.Where(p => p.Name.LocalName == "L_TRANS_SOURCE").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0}|", transSource);//系統編號
                    if (transSource.StartsWith("No records")) { break; }

                    string initDate = subXE.Where(p => p.Name.LocalName == "L_INIT_DATE").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0}|", initDate);//平台日期

                    string originalRef = subXE.Where(p => p.Name.LocalName == "C_ORIGINAL_REF").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0}|", originalRef);//平台流水號

                    string debitAmount = subXE.Where(p => p.Name.LocalName == "DEBIT_AMOUNT").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0}|", debitAmount);//交易金額

                    sb.AppendFormat("{0}|", 1);//主機狀態 1.成功

                    sb.AppendFormat("{0}|", string.Empty);//記帳屬性

                    //string txnID = subXE.Where(p => p.Name.LocalName == "TXN_ID").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0}|", string.Empty);//業務受理編號

                    //string coCode = subXE.Where(p => p.Name.LocalName == "CO_CODE").SingleOrDefault().Value.Trim();
                    //sb.AppendFormat("{0}|", coCode);//開戶機構

                    string valueDate = subXE.Where(p => p.Name.LocalName == "VALUE_DATE").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0}|", valueDate);//主機日期

                    string txnID = subXE.Where(p => p.Name.LocalName == "TXN_ID").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0}|", txnID);//主機流水

                    fileContentList.Add(sb.ToString());
                }
                return fileContentList;
            }
            catch (Exception ex)
            {
                m_log.ErrorException("CreateFileContentList Error!!!" + ex.ToString(), ex);
                return null;
            }
        }

        private List<string> CreateACCTContentList(XmlDocument rsXmlDocument, string fileName, List<string> fileContentList)
        {
            try
            {
                XDocument xDocument = XDocument.Parse(rsXmlDocument.InnerXml);
                var enqDataLst = xDocument.Root
                                          .DescendantNodes().OfType<XElement>()
                                          .Where(p => p.Name.LocalName == "RSP_MSG_ROW")
                                          .ToList();

                foreach (XElement xE in enqDataLst)
                {
                    StringBuilder sb = new StringBuilder();
                    IEnumerable<XElement> subXE = xE.DescendantNodes().OfType<XElement>();

                    string acctID = subXE.Where(p => p.Name.LocalName == "ACCT_ID").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0},", acctID); //帳號
                    if (acctID.StartsWith("No records")) { break; }

                    string acctNAME = subXE.Where(p => p.Name.LocalName == "ACCT_TITLE").SingleOrDefault().Value;
                    sb.AppendFormat("{0},", acctNAME); //戶名

                    string openDATE = subXE.Where(p => p.Name.LocalName == "OPEN_DATE").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0},", openDATE); //開戶日期

                    string acTYPE = subXE.Where(p => p.Name.LocalName == "AC_TYPE").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0},", acTYPE); //變更方式

                    string acctSTATUS = subXE.Where(p => p.Name.LocalName == "ACCT_STATUS").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0},", acctSTATUS); //帳戶狀態

                    string coCODE = subXE.Where(p => p.Name.LocalName == "CO_CODE").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0},", coCODE); //分行號

                    string coNAME = subXE.Where(p => p.Name.LocalName == "CO_NAME").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0},", coNAME); //開戶機構行名

                    string cpsCode = subXE.Where(p => p.Name.LocalName == "CPS_CODE").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0},", cpsCode); //開戶機構行號

                    string cusTYPE = subXE.Where(p => p.Name.LocalName == "CUS_TYPE").SingleOrDefault().Value.Trim();
                    sb.AppendFormat("{0},", cusTYPE); //對公對私  0公1私

                    fileContentList.Add(sb.ToString());
                }
                return fileContentList;
            }
            catch (Exception ex)
            {
                m_log.ErrorException("CreateACCTContentList Error!!!" + ex.ToString(), ex);
                return null;
            }
        }

        public bool WriteFile(string savePath, string writeData)
        {
            FileStream fs = new FileStream(savePath, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs, Encoding.UTF8);

            sw.Write(writeData);
            sw.Flush();
            sw.Close();
            fs.Close();
            return true;
        }
        private bool UploadFTP(string filePath, string fileName)
        {
            m_log.Info("Upload File Start, file path = {0}", filePath);

            FtpWebRequest request = null;
            StreamReader sourceStream = null;
            Stream requestStream = null;
            FtpWebResponse response = null;

            //FTP path
            String ftpIP = ProjectConfig.GetInstance().UPC_UploadFtpIP;
            String ftpFld = ProjectConfig.GetInstance().UPC_UploadFtpFolder;
            String ftpPath = String.Concat(ftpIP, ftpFld);

            //FTP userName, passWord
            String ftpUser = ProjectConfig.GetInstance().UPC_UploadFtpUser;
            String ftpPwd = Encoding.UTF8.GetString(Convert.FromBase64String(ProjectConfig.GetInstance().UPC_UploadFtpPassword));
            m_log.Info("ftpIP = {0} ftpFld = {1} ftpUser = {2}", ftpIP, ftpFld, ftpUser);
            String ftpFullPath = String.Concat(ftpPath, fileName);



            m_log.Info("Upload File To Ftp, ftpFullPath = {0}", ftpFullPath);
            try
            {
                // Get the object used to communicate with the server.
                request = (FtpWebRequest)WebRequest.Create(ftpFullPath);
                request.Method = WebRequestMethods.Ftp.UploadFile;

                // This example assumes the FTP site uses anonymous logon.
                request.Credentials = new NetworkCredential(ftpUser, ftpPwd);

                // Copy the contents of the file to the request stream.
                sourceStream = new StreamReader(filePath);
                //byte[] fileContents = Encoding.UTF8.GetBytes(sourceStream.ReadToEnd());
                byte[] fileContents = Encoding.GetEncoding("GBK").GetBytes(sourceStream.ReadToEnd());
                //byte[] fileContents = Encoding.GetEncoding("GBK").GetBytes(string.Empty);

                sourceStream.Close();

                request.ContentLength = fileContents.Length;

                requestStream = request.GetRequestStream();
                requestStream.Write(fileContents, 0, fileContents.Length);
                requestStream.Close();

                response = (FtpWebResponse)request.GetResponse();

                m_log.Info("Upload File Complete, status = {0}", response.StatusDescription);

                response.Close();
            }
            catch (WebException ex)
            {
                m_log.Error("Upload File Error, status = {0}", ((FtpWebResponse)ex.Response).StatusDescription);
                throw new Exception(ex.Message);
            }
            return true;
        }



        delegate void SettleQuery(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml);
        void DoSettleQuery(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                AppXmlExecResult result = null;

                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string fileName = xmlHelper.GetXPath(requestXml, "//FILENAME").Trim();
                string transSource = xmlHelper.GetXPath(requestXml, "//L_TRANS_SOURCE").Trim();
                string startDate = xmlHelper.GetXPath(requestXml, "//L_INIT_DATE_START").Trim();
                string endDate = xmlHelper.GetXPath(requestXml, "//L_INIT_DATE_END").Trim();
                m_log.Info("DoSettleQuery txID = [{0}] FILENAME=[{1}] L_TRANS_SOURCE=[{2}] L_INIT_DATE_START=[{3}] L_INIT_DATE_END=[{4}]"
                          , txID, fileName, transSource, startDate, endDate);

                List<string> fileContentList = new List<string>();
                string enqPreLine = string.Empty, enqLineNo = string.Empty, enqEndPage = string.Empty;

                do
                {
                    enqPreLine = enqLineNo;
                    string queryString = BuildQueryContent(transSource, startDate, endDate, enqPreLine);
                    string newTxID = "ESCN.BP.UPC.SETTLE.ENQ";
                    Component.DB.DbLog.InsertMsgLog(context, correlationID, "2", queryString, false);
                    result = SendMsgToEAIProcess(context, queryString, newTxID, true);
                    Component.DB.DbLog.InsertMsgLog(context, correlationID, "5", result.ResponseXml, false);
                    enqLineNo = XmlHelper.GetInstance(result.ResponseXml).GetXPath(result.ResponseXml, "//ITF_ENQ_LINENO");
                    enqEndPage = XmlHelper.GetInstance(result.ResponseXml).GetXPath(result.ResponseXml, "//ITF_ENQ_ENDPAGE");
                    fileContentList = CreateFileContentList(result.ResponseXml, fileName, fileContentList);
                } while (enqEndPage == "N");

                string fileContent = string.Join(Environment.NewLine, fileContentList.ToArray());

                var filePath = Path.Combine(m_FilePath, fileName);
                bool fileProcSucc = WriteFile(filePath, fileContent);

                if (fileProcSucc)
                { UploadFTP(filePath, fileName); }

                m_log.Info("DoSettleQuery FileName:[[0]]" + " Data:[{1}]Rows", fileName, fileContentList.Count);
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("DoSettleQuery Error ! : {0}", ex.Message), ex);
            }
        }


        delegate void ACCENQQuery(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml);
        void DoACCENQQuery(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            try
            {
                AppXmlExecResult result = null;

                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string fileName = xmlHelper.GetXPath(requestXml, "//FILENAME").Trim();
                string transDATE = xmlHelper.GetXPath(requestXml, "//DATE").Trim();
                m_log.Info("DoACCENQQuery txID = [{0}] FILENAME=[{1}] DATE=[{2}] " , txID, fileName, transDATE);

                List<string> fileContentList = new List<string>();
                string enqPreLine = string.Empty, enqLineNo = string.Empty, enqEndPage = string.Empty;

                do
                {
                    enqPreLine = enqLineNo;
                    string queryString = BuildACCENQContent(transDATE, enqPreLine);
                    string newTxID = "ESCN.BP.ACC.INFO.ENQ";
                    Component.DB.DbLog.InsertMsgLog(context, correlationID, "2", queryString, false);
                    result = SendMsgToEAIProcess(context, queryString, newTxID, true);
                    Component.DB.DbLog.InsertMsgLog(context, correlationID, "5", result.ResponseXml, false);
                    enqLineNo = XmlHelper.GetInstance(result.ResponseXml).GetXPath(result.ResponseXml, "//ITF_ENQ_LINENO");
                    enqEndPage = XmlHelper.GetInstance(result.ResponseXml).GetXPath(result.ResponseXml, "//ITF_ENQ_ENDPAGE");
                    fileContentList = CreateACCTContentList(result.ResponseXml, fileName, fileContentList);
                } while (enqEndPage == "N");

                string fileContent = string.Join(Environment.NewLine, fileContentList.ToArray());

                var filePath = Path.Combine(m_FilePath, fileName);
                bool fileProcSucc = WriteFile(filePath, fileContent);

                if (fileProcSucc)
                { UploadFTP(filePath, fileName); }

                m_log.Info("DoACCENQQuery FileName:[[0]]" + " Data:[{1}]Rows", fileName, fileContentList.Count);
            }
            catch (Exception ex)
            {
                m_log.ErrorException(string.Format("DoACCENQQuery Error ! : {0}", ex.Message), ex);
            }
        }



    }
}
