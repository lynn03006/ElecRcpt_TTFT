﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Text;

using Microsoft.Service;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;
using Microsoft.EAIServer;

using Bankpro.EAI.BPM;
using Bankpro.EAI.Utility;
using Bankpro.EAI.Component;

namespace Bankpro.EAI.BPM
{
    public class ES_2020580 : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.ES_2020580");

        public ES_2020580()
        {

        }

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            UC2UPCControler controlerUC2UPC = new UC2UPCControler();
            XmlDocument responseXml = new XmlDocument();
            EaiResponse eaiRs = null;
            try
            {
                /******************************
                 * 剖析UCString並獲取必要資訊 *
                 ******************************/
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);
                UcControler m_UcControler = new UcControler();
                string t24Ofs = m_UcControler.UC2T24(ucData);
                #region Get UC Field
                string rcvbkID = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("2021", out rcvbkID);   // 收款行行号
                string acctLVL = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4052", out acctLVL);   // 客户级别
                string operNO = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4102", out operNO);   // 交易柜员
                string tranAMT = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4100", out tranAMT);
                string cURR = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4118", out cURR);
                string debitName = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4900", out debitName);
                string rcvaccBKID = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4186", out rcvaccBKID);   // 收款人开户行号
                string creditACC = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4161", out creditACC);
                string debitACC = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4157", out debitACC);
                string remitPUR = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4349", out remitPUR);  // 付款用途
                string vouNO = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4901", out vouNO);   // 凭证号码
                string creditName = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4732", out creditName);
                string remitWAY = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4026", out remitWAY); // 普通or加急
                string remarks = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("4658", out remarks); //交易附言
                string seq = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("2039", out seq); //sequence number
                string transGate = string.Empty;
                m_UcControler.m_ucBodyDiy.TryGetValue("Channel", out transGate); //交易渠道 2019.08.22
                #endregion
                
                /* removal test scenario
                //*temp test for msg 101 
                if (debitACC == "000281000000026")
                {
                    rcvbkID = "710584000001";
                    rcvaccBKID = "710584000001";
                }    
                //*
                */

                m_log.Info("AppXmlExecResult RunImpl.UC.2021(rcvbkID)={0}&&4052(acctLVL)={1}&&4102(operNO)={2}&&4100(amt)={3}&&4118(curr)={4}&&4900(debitName)={5}", rcvbkID, acctLVL, operNO, tranAMT, cURR, debitName);
                m_log.Info("AppXmlExecResult RunImpl.UC.4186(rcvaccBKID)={0}&&4161(creditACC)={1}&&4157(debitACC)={2}&&4349(remitPUR)={3}&&4901(vouNO)={4}&&4732(creditName)={5}", rcvaccBKID, creditACC, debitACC, remitPUR, vouNO, creditName);
                m_log.Info("AppXmlExecResult RunImpl.UC.4026(remitWAY)={0}&&4658(remarks)={1}&&2039(seq)={2}&&Channel={3}", remitWAY, remarks, seq, transGate);

                /************************************************
                 * 發送ESCN.BP.ACCT.ENQ向T24要銀行名稱資訊 *
                 ************************************************/
                //string co_Code = string.Format("CN001{0}", debitACC.Substring(0, 4));
                string strpayBknmEnqBody = controlerUC2UPC.GetT24_paybknmENQ_Content(debitACC);
                XmlDocument xmlBKnmEnq = new XmlDocument();
                xmlBKnmEnq.LoadXml(SendToEAIProcess(strpayBknmEnqBody, "ESCN.BP.ACCT.ENQ"));
                AppXmlExecResult resultpayBknmEnq = Send1Recv1ByAA(context, "ESCN.BP.ACCT.ENQ", xmlBKnmEnq);

                if (resultpayBknmEnq.ErrCode != "0")
                    throw new ApplicationException("子交易ESCN.BP.ACCT.ENQ發生錯誤。");

                XmlHelper xmlHelperpaybknmEnq = XmlHelper.GetInstance(resultpayBknmEnq.ResponseXml);
                string co_Code = xmlHelperpaybknmEnq.GetXPath(resultpayBknmEnq.ResponseXml, "//CO_CODE").Trim();
                string paybkID = xmlHelperpaybknmEnq.GetXPath(resultpayBknmEnq.ResponseXml, "//CO_NUM").Trim();
                string paybkNM = xmlHelperpaybknmEnq.GetXPath(resultpayBknmEnq.ResponseXml, "//CO_NAME").Trim();
                m_log.Info("Co_Code = [{0}] , PayBkID = [{1}] , PayBkNM = [{2}]", co_Code, paybkID, paybkNM);

                //CORP PARAMETER SETTING
                string personFlag = "1";
                transGate = (transGate == "12") ? "103" : "102";
                //string busiType = string.Empty;
                //string busiKind = string.Empty;
                string busiType = "A100";
                string busiKind = "02102";

                //if (remitWAY == "0")
                //{
                //    busiType = "C100";
                //    busiKind = "09001";
                //}
                //else
                //{
                //    busiType = "A100";
                //    busiKind = "02102";
                //}

                //if (remitWAY == "2")
                //{
                //    remitWAY = "1";
                //} 

                /************************************************
                 * 發送ESCN.IB.BANK.CODE.ENQ向T24要銀行名稱資訊 *
                 ************************************************/
                //string strBknmEnqBody = controlerUC2UPC.GetT24_bknmENQ_Content(rcvbkID);
                string strBknmEnqBody = controlerUC2UPC.GetT24_bknmENQ_Content(rcvaccBKID);
                XmlDocument xmlBnmEnq = new XmlDocument();
                xmlBnmEnq.LoadXml(SendToEAIProcess(strBknmEnqBody, "ESCN.IB.BANK.CODE.ENQ"));
                AppXmlExecResult resultBknmEnq = Send1Recv1ByAA(context, "ESCN.IB.BANK.CODE.ENQ", xmlBnmEnq);

                if (resultBknmEnq.ErrCode != "0")
                    throw new ApplicationException("子交易ESCN.IB.BANK.CODE.ENQ發生錯誤。");

                XmlHelper xmlHelperbknmEnq = XmlHelper.GetInstance(resultBknmEnq.ResponseXml);
                string rcvbkNM = xmlHelperbknmEnq.GetXPath(resultBknmEnq.ResponseXml, "//DESCRIPTION").Trim();

                /***************************
                 * 發送968101至UPC執行交易 *
                 ***************************/
                string str968101Body = controlerUC2UPC.Get_SendXml_Content(rcvbkID, acctLVL, operNO, tranAMT, cURR, debitName, rcvaccBKID, creditACC,
                                                          debitACC, remitPUR, vouNO, creditName, remitWAY, remarks, co_Code, paybkID,
                                                          paybkNM, rcvbkNM, seq, personFlag, transGate, busiType, busiKind);
                XmlDocument xml968101 = new XmlDocument();
                xml968101.LoadXml(SendToEAIProcess(str968101Body, "968101"));
                AppXmlExecResult result968101 = Send1Recv1ByAA(context, "968101", xml968101);

                XmlHelper xmlHelperINDEnq = XmlHelper.GetInstance(result968101.ResponseXml);
                bool boolCommFee = xmlHelperINDEnq.GetXPath(result968101.ResponseXml, "//feeamt").Length != 0;
                string CommFee = boolCommFee ? xmlHelperINDEnq.GetXPath(result968101.ResponseXml, "//feeamt").Substring(3).Trim() : "0.00";
                string Code = xmlHelperINDEnq.GetXPath(result968101.ResponseXml, "//respcode");                
                string failDescription = string.Empty;
                string failCode = string.Empty;

                string status = "3";
                if (Code == "000000")
                    status = "1";
                else
                {
                    status = "2";
                    failDescription = xmlHelperINDEnq.GetXPath(result968101.ResponseXml, "//respmsg");
                    failCode = "CO1MA999";
                }

                /**************************************
                 * 發送ACC.CURR.BAL.ENQ取得交易後餘額 *
                 **************************************/
                string strBalEnqBody = controlerUC2UPC.Get2010772_ENQ_Content(debitACC);
                XmlDocument xmlBalEnq = new XmlDocument();
                xmlBalEnq.LoadXml(SendToEAIProcess(strBalEnqBody, "ACC.CURR.BAL.ENQ"));
                AppXmlExecResult resultBalEnq = Send1Recv1ByAA(context, "ACC.CURR.BAL.ENQ", xmlBalEnq);

                XmlHelper xmlHelperBalEnq = XmlHelper.GetInstance(resultBalEnq.ResponseXml);
                string balAmt = resultBalEnq.ErrCode.Equals("0") ? xmlHelperBalEnq.GetXPath(resultBalEnq.ResponseXml, "//WORKING_BALANCE").Trim() : "0";

                /****************
                 * 重組UCString *
                 ****************/
                Dictionary<string, string> expendDic = controlerUC2UPC.Get_UPCtoUC_Expend(balAmt, creditACC, creditName, status, CommFee);
                string strUCString = string.IsNullOrEmpty(failCode) ? m_UcControler.GetToUCRS(expendDic) : m_UcControler.GetFailUcRS(expendDic, failCode, failDescription);
                m_log.Debug("AppXmlExecResult RunImpl Response={0}", strUCString);
                responseXml = controlerUC2UPC.TransformCommMsg(strUCString);
                eaiRs = EaiResponse.GetInstance(true);
                eaiRs.SetRespXml(responseXml);
            }
            catch (Exception ex)
            {
                eaiRs = EaiResponse.GetInstance(false);
                eaiRs.SetEaiError(eaiRs.EaiErrCode, ex.ToString(), "");
                responseXml = TransformCommMsg("9999", "Error", ex.Message, "");
                m_log.ErrorException("Error executing Run():" + ex.ToString(), ex);
            }
            finally
            {
                m_log.Debug("Run end<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
            }

            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }
    }
}
