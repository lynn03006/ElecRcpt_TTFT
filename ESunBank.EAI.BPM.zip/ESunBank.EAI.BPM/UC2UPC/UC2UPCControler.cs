﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Text;

using Bankpro.EAI.Component;
using Bankpro.EAI.Utility;

namespace Bankpro.EAI.BPM
{
    public class UC2UPCControler
    {
        public UC2UPCControler()
        {

        }

        /// <summary>
        /// 取得交易ESCN.BP.ACCT.ENQ的Body(付款行名行號查詢)
        /// </summary>
        internal string GetT24_paybknmENQ_Content(string debitACC)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.CARD.CUSDATA.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.BP.ACCT.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "UPC001.0005");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<ACCOUNT_NUMBER op='EQ'>{0}</ACCOUNT_NUMBER>", debitACC);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        /// <summary>
        /// 取得交易ESCN.IB.BANK.CODE.ENQ的Body(行名查詢)
        /// </summary>
        internal string GetT24_bknmENQ_Content(string rcvBKID)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.CARD.CUSDATA.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.IB.BANK.CODE.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "IB001.0012");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<FIN_CODE op='EQ'>{0}</FIN_CODE>", rcvBKID);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        /// <summary>
        /// 取得交易ESCN.CARD.CUSDATA.ENQ的Body(銀聯卡查詢)
        /// </summary>
        internal string GetT24_CardENQ_Content(string cardNo)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.CARD.CUSDATA.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.CARD.CUSDATA.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "CUP001.0001");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<CARD_NO op='EQ'>{0}</CARD_NO>", cardNo);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        /// <summary>
        /// 取得交易968101的Body(单笔资金汇划往账)
        /// </summary>
        internal string Get_SendXml_Content(string rcvbkID, string acctLVL, string operNO, string tranAMT,
                                        string cURR, string debitName, string rcvaccBKID, string creditACC, string debitACC, string remitPUR, string vouNO,
                                        string creditName, string remitWAY, string remarks, string co_Code, string paybkID, string paybkNM, string rcvbkNM, string seq, string personFlag, string transGate, string busiType, string busiKind)
        {
            StringBuilder sb = new StringBuilder();
            #region UPC XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<root>");
            sb.Append("<pub>");
            sb.AppendFormat("<appid>{0}</appid>", "upps");
            sb.AppendFormat("<transcode>{0}</transcode>", "968101");
            //101/PIB：個網銀  102/CIB：企網銀  201/BRANCH：櫃面  103/PHONE：手機網銀
            sb.AppendFormat("<channelid>{0}</channelid>", transGate);  
            sb.AppendFormat("<channeldt>{0}</channeldt>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<channeltm>{0}</channeltm>", DateTime.Now.ToString("HHmmss"));
            sb.AppendFormat("<channelseq>{0}</channelseq>", seq);
            sb.AppendFormat("<termnum>{0}</termnum>", "");
            sb.AppendFormat("<orgno>{0}</orgno>", co_Code); //fitting for before switch to all branch
            sb.AppendFormat("<inputoper>{0}</inputoper>", operNO);
            sb.Append("</pub>");
            sb.Append("<req>");
            sb.AppendFormat("<syscd>{0}</syscd>", "");
            sb.AppendFormat("<busitype>{0}</busitype>", busiType);
            sb.AppendFormat("<busikind>{0}</busikind>", busiKind); 
            sb.AppendFormat("<flowctrl>{0}</flowctrl>", "11001");
            sb.AppendFormat("<personflg>{0}</personflg>", personFlag);
            sb.AppendFormat("<voutp>{0}</voutp>", "");
            sb.AppendFormat("<vouno>{0}</vouno>", vouNO);
            sb.AppendFormat("<ptcid>{0}</ptcid>", "");
            sb.AppendFormat("<voudt>{0}</voudt>", "");
            sb.AppendFormat("<issueamt>{0}</issueamt>", "");
            sb.AppendFormat("<remnamt>{0}</remnamt>", "");
            sb.AppendFormat("<amt>{0}</amt>", tranAMT);
            sb.AppendFormat("<ccy>{0}</ccy>", cURR);
            sb.AppendFormat("<amtpayflg>{0}</amtpayflg>", "0");
            sb.AppendFormat("<branbkid>{0}</branbkid>", co_Code);
            sb.AppendFormat("<acctlvl>{0}</acctlvl>", acctLVL);
            sb.AppendFormat("<payeraccno>{0}</payeraccno>", debitACC);
            sb.AppendFormat("<payername>{0}</payername>", debitName);
            sb.AppendFormat("<payeraddr>{0}</payeraddr>", "");
            sb.AppendFormat("<payaccbkid>{0}</payaccbkid>", paybkID);
            sb.AppendFormat("<payaccbknm>{0}</payaccbknm>", paybkNM);
            sb.AppendFormat("<paybkid>{0}</paybkid>", paybkID);
            sb.AppendFormat("<paybknm>{0}</paybknm>", paybkNM);
            sb.AppendFormat("<rcverprop>{0}</rcverprop>", "");
            sb.AppendFormat("<rcveraccno>{0}</rcveraccno>", creditACC);
            sb.AppendFormat("<rcvertrackinfo>{0}</rcvertrackinfo >", "");
            sb.AppendFormat("<rcvername>{0}</rcvername>", creditName);
            sb.AppendFormat("<rcveraddr>{0}</rcveraddr>", "");
            sb.AppendFormat("<rcvaccbkid>{0}</rcvaccbkid>", rcvaccBKID);
            sb.AppendFormat("<rcvaccbknm>{0}</rcvaccbknm>", "");
            //sb.AppendFormat("<rcvbkid>{0}</rcvbkid>", rcvbkID);
            sb.AppendFormat("<rcvbkid>{0}</rcvbkid>", rcvaccBKID);
            sb.AppendFormat("<rcvbknm>{0}</rcvbknm>", rcvbkNM);
            sb.AppendFormat("<realpayeraccno>{0}</realpayeraccno>", "");
            sb.AppendFormat("<realpayername>{0}</realpayername>", "");
            sb.AppendFormat("<agentidtype>{0}</agentidtype>", "");
            sb.AppendFormat("<agentidno>{0}</agentidno>", "");
            sb.AppendFormat("<agentaddr>{0}</agentaddr>", "");
            sb.AppendFormat("<addword>{0}</addword>", remarks);
            sb.AppendFormat("<abstract>{0}</abstract>", remitPUR);
            sb.AppendFormat("<passflag>{0}</passflag>", "");
            sb.AppendFormat("<routecode>{0}</routecode>", "");
            sb.AppendFormat("<resflag>{0}</resflag>", remitWAY);  // 0加急  1普通(2小時)  2次日
            sb.AppendFormat("<rests>{0}</rests>", "");
            sb.Append("</req>");
            sb.Append("</root>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        /// <summary>
        /// 取得交易ACC.CURR.BAL.ENQ的Body(活期余额查询)
        /// </summary>
        internal string Get2010772_ENQ_Content(string debitACC)
        {
            StringBuilder sb = new StringBuilder();
            #region 2010772 ACC.CURR.BAL.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ACC.CURR.BAL.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0040");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<ACCOUNT_NUMBER op='EQ'>{0}</ACCOUNT_NUMBER>", debitACC);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        /// <summary>
        /// 取得交易5001的Body(銀聯卡基本账户查询)
        /// </summary>
        internal string Get5001_ENQ_Content(string debitACC)
        {
            StringBuilder sb = new StringBuilder();
            #region 5001 ACC BAL XML MSG

            sb.AppendFormat("<TRXTYPE>{0}</TRXTYPE>", "5001");
            sb.AppendFormat("<RETCODE>{0}</RETCODE>", "");
            sb.AppendFormat("<BNKNBR>{0}</BNKNBR>", "0345");
            sb.AppendFormat("<SOURCE>{0}</SOURCE>", "CT");
            sb.AppendFormat("<BRN_NO>{0}</BRN_NO>", "010002");
            sb.AppendFormat("<OPE_NO>{0}</OPE_NO>", "000001");
            sb.AppendFormat("<SEQNO>{0}</SEQNO>", "100921");
            sb.AppendFormat("<CARDNO>{0}</CARDNO>", debitACC);
            sb.AppendFormat("<PINFLAG>{0}</PINFLAG>", "0");
            sb.AppendFormat("<PIN>{0}</PIN>", "");

            #endregion
            return sb.ToString();
        }

        /// <summary>
        /// Error Code Mapping
        /// </summary>
        private string ErrorCodeMapping(string sourceName, string sourceStatus)
        {
            Bankpro.EAI.Component.StatusData status = Bankpro.EAI.Component.ProjectCache.GetInstance().GetStatusData(sourceName, sourceStatus);

            if (status != null)
                return status.m_statusCode;
            else
                return sourceStatus;

        }

        /// <summary>
        /// 存入UPC資訊
        /// </summary>
        internal Dictionary<string, string> Get_UPCtoUC_Expend(string balAmt, string creditACC, string creditName, string status, string CommFee)
        {
            Dictionary<string, string> expendDic = new Dictionary<string, string>();

            expendDic.Add("4315", balAmt);  //付款账户余额
            expendDic.Add("4161", creditACC);  //收款人账号
            expendDic.Add("4900", creditName);  //收款人姓名
            expendDic.Add("4345", status);  //交易状态
            expendDic.Add("4165", CommFee);  //汇款手续费

            return expendDic;
        }

        /// <summary>
        /// 組UC格式的CommMsg
        /// </summary>
        internal XmlDocument TransformCommMsg(string strTOTA)
        {
            StringBuilder sbXml = new StringBuilder();
            sbXml.Append("<BankproML xmlns=\"urn:schema-bankpro-com:multichannel\">");
            sbXml.Append("<CommMsg>");
            sbXml.Append("<T24_DATA>");
            sbXml.Append(strTOTA);
            sbXml.Append("</T24_DATA>");
            sbXml.Append("</CommMsg>");
            sbXml.Append("</BankproML>");
            XmlDocument xmlRs = new XmlDocument();
            xmlRs.LoadXml(sbXml.ToString());
            return xmlRs;
        }
    }
}
