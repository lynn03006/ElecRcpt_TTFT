﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

using Microsoft.Service;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;
using Microsoft.EAIServer;

using Bankpro.EAI.BPM;
using Bankpro.EAI.Utility;


namespace Bankpro.EAI.BPM
{


    public class N23 : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.N23");

        //private XferVariables xv = XferVariables.GetInstance();

        public N23()
        {

        }




        /// <summary>
        /// timeout standard status code = 6005
        /// </summary>
        /// <param name="context"></param>
        /// <param name="correlationID"></param>
        /// <param name="txID"></param>
        /// <param name="txDef"></param>
        /// <param name="requestXml"></param>
        /// <returns></returns>
        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            EaiResponse eaiRs = null;
            XmlDocument respXml = new XmlDocument();

            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, respXml, eaiRs);
        }
    }

}

