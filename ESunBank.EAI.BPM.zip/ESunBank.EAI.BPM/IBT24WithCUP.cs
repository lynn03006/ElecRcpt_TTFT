﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

using Microsoft.Service;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;
using Microsoft.EAIServer;

using Bankpro.EAI.BPM;
using Bankpro.EAI.Utility;
using Bankpro.EAI.Component;

namespace Bankpro.EAI.BPM
{
    public class IBT24WithCUP : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.IBT24WithCUP");
        //private UcControler m_UcControler;
        private String m_SendURL = ProjectConfig.GetInstance().Send_URL;
        private Int32 m_PostTimeOut = ProjectConfig.GetInstance().PostTimerOut * 1000;

        //private XferVariables xv = XferVariables.GetInstance();

        public IBT24WithCUP()
        {
        }




        /// <summary>
        /// timeout standard status code = 6005
        /// </summary>
        /// <param name="context"></param>
        /// <param name="correlationID"></param>
        /// <param name="txID"></param>
        /// <param name="txDef"></param>
        /// <param name="requestXml"></param>
        /// <returns></returns>
        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            switch (txID)
            {
                case "IND.TDA.OPEN":  //個人活轉定 
                    return DoTDAOpenProcess(context, correlationID, txID, txDef, requestXml);
                case "IND.TDA.WDWL":  //個人定轉活部提
                    return DoTDAWdwlProcess(context, correlationID, txID, txDef, requestXml);
                case "IND.TDA.CLOSE":  //個人定轉活全提
                    return DoTDACloseProcess(context, correlationID, txID, txDef, requestXml);
                case "IND.NDA.OPEN":  //個人活轉通知
                    return DoNDAOpenProcess(context, correlationID, txID, txDef, requestXml);
                case "IND.NDA.WDWL":  //個人通知支取
                    return DoNDAWdwlProcess(context, correlationID, txID, txDef, requestXml);
                default :
                    return DoDefault(context, correlationID, txID, txDef, requestXml);
                    
            }
        }

        private string GetCURR_NUM(string currNo)
        {
            switch (currNo)
            {
                case "156":
                    return "CNY";
                case "840":
                    return "USD";
                case "CNY":
                    return "156";
                case "USD":
                    return "840";
                default:
                    return "CNY";
            }
        }

        private AppXmlExecResult DoDefault(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            EaiResponse eaiRs = null;
            XmlDocument responseXml = null;
            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }

        private AppXmlExecResult DoTDAOpenProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {           
            XmlHelper xmlHelperIBRQ = XmlHelper.GetInstance(requestXml);
            string CoCode = xmlHelperIBRQ.GetXPath(requestXml, "//SIGN_ON_BRH");
            string WdwlAcc = xmlHelperIBRQ.GetXPath(requestXml, "//C_WDWL_ACCT");
            string Curr = xmlHelperIBRQ.GetXPath(requestXml, "//CURRENCY");
            string tranAMT = xmlHelperIBRQ.GetXPath(requestXml, "//C_DEP_AMT");
            string RollFlag = xmlHelperIBRQ.GetXPath(requestXml, "//C_ROLLOVER_FLAG");

            requestXml = CopyToNewDocument(requestXml, txID.Replace("IND.TDA.OPEN", "ESCN.IB.IND.TDA.INP"), Guid.NewGuid().ToString());

            if (WdwlAcc.Length > 15) //Card 
            {
                //判斷是否「不轉存」，銀聯卡定存只接受「不轉存」
                if (RollFlag.Equals("Y"))
                {
                    string failCode = "E-5000";
                    string failDescription = "银联卡不接受续存交易";

                    string afterRS = GetT24_ErrorRS("", failCode, "", failDescription);
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRS);
                    XmlDocument rs_ERR = base.TransformCommMsg("0", "", "", afterRS);
                    return base.BuildExecResult(context, rs_ERR);
                }

                xmlHelperIBRQ.SetMultipleXPath(requestXml, "//L_CARD_NO", WdwlAcc);
                return DoCardToTDAProcess(context, requestXml, WdwlAcc, tranAMT, Curr, RollFlag, CoCode);
            }
            else // ACC
                return Send1Recv1(m_log, context, requestXml);        
        }

        private AppXmlExecResult DoCardToTDAProcess(EaiContext context, XmlDocument requestXml, string WdwlACC, string tranAMT,
                                              string Curr, string RollFlag, string CoCode)
        {
            string failCode = string.Empty;
            string failDescription = string.Empty;

            //Send CUP.Card.Debit
            CMMControler m_CMMControler = new CMMControler();
            string bodyCUP = m_CMMControler.GetCard_Debit_ContentMsg(WdwlACC, "", tranAMT, "D00000000", "6013", "03450000", "0X03", GetCURR_NUM(Curr), CoCode, "        07     ");
            AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Debit");
            XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
            failCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");

            if (failCode == "00")
            {
                //Send T24.TDA 開定期帳戶
                AppXmlExecResult t24_result = Send1Recv1(m_log, context, requestXml);

                XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);

                failCode = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
                string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

                if (failCode != "E-000000" || proc_ret != "SUCC")
                {
                    //R  
                    string msgType = "0200";
                    string dateTime_Now = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//TRAN_TIME");
                    string traceNo = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//SYS_TRACE_NUM");
                    string acqCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ACQ_INST_ID_CO");
                    string forCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FOR_INT_ID_CO");

                    string oriData = string.Format("{0}{1}{2}{3}{4}", msgType, traceNo, dateTime_Now, acqCode.PadLeft(11, '0'), forCode.PadLeft(11, '0'));
                    string bodyCUP_EC = m_CMMControler.GetEC_Card_Debit_ContentMsg(WdwlACC, "", tranAMT, "6013", "03450000", "0X03", GetCURR_NUM(Curr), oriData, CoCode, "        07     ");
                    AppXmlExecResult cup_EC_result = SendMsgToEAIProcess(context, bodyCUP_EC, "CUP.Card.Debit.EC");

                    XmlHelper xmlHelperCUPRS_EC = XmlHelper.GetInstance(cup_EC_result.ResponseXml);
                    string rs_Code = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//RES_CO");

                    if (rs_Code != "00")
                        //SEND MAIL
                        new SendMail().Send("Do CARD TO TDA(R) Error", "", string.Format("Do CARD TO TDA(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                }
                
                return base.BuildExecResult(context, t24_result.ResponseXml);
            }
            else
            {
                failDescription = ErrorCodeMapping("CUP", failCode); ;

                string afterRS = GetT24_ErrorRS("", failCode, "", failDescription);
                m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRS);
                XmlDocument rs_ERR = base.TransformCommMsg("0", "", "", afterRS);
                return base.BuildExecResult(context, rs_ERR);
            }
        }

        private AppXmlExecResult DoTDAWdwlProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            XmlHelper xmlHelperIBRQ = XmlHelper.GetInstance(requestXml);
            string CoCode = xmlHelperIBRQ.GetXPath(requestXml, "//SIGN_ON_BRH");
            string CreditAcc = xmlHelperIBRQ.GetXPath(requestXml, "//CREDIT_ACCT_NO");
            string DebitAcc = xmlHelperIBRQ.GetXPath(requestXml, "//DEBIT_ACCT_NO");
            string Curr = xmlHelperIBRQ.GetXPath(requestXml, "//DEBIT_CURRENCY");
            string tranAMT = xmlHelperIBRQ.GetXPath(requestXml, "//DEBIT_AMOUNT");

            requestXml = CopyToNewDocument(requestXml, txID.Replace("IND.TDA.WDWL", "IB.IND.TDA.WDWL"), Guid.NewGuid().ToString());

            if (CreditAcc.Length > 15) //card
            {
                //確認入帳銀聯卡的狀態
                string bodyCUP = Get5001_ENQ_Content(CreditAcc);
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "5001");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                string retCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RETCODE");
                string cardStat = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//CARD-STAT");
                string frzType = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FRZTYPE");

                m_log.Info("DoTDAWdwlProcess CARD STATUS: Card id=" + CreditAcc + ", statusCode=" + retCode + ", Stat=" + cardStat + ", FrzType=" + frzType);

                if (!retCode.Equals("000000") || !cardStat.Equals("") || frzType.Equals("1"))
                {
                    //retCode為000000代表「正常」(以排除卡號不存在)，cardStat為空代表「正常」，frzType為1代表「活期不收不付凍結」
                    string failCode = "14"; //無效卡號
                    string failDescription = ErrorCodeMapping("CUP", failCode);

                    string afterRS = GetT24_ErrorRS("", failCode, "", failDescription);
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRS);
                    XmlDocument rs_ERR = base.TransformCommMsg("0", "", "", afterRS);
                    return base.BuildExecResult(context, rs_ERR);
                }

                xmlHelperIBRQ.SetMultipleXPath(requestXml, "//L_CARD_NO", CreditAcc);
                return DoTDAWdwltoCardProcess(context, requestXml, DebitAcc, CreditAcc, Curr, tranAMT, CoCode);

            }
            else //ACC
                return Send1Recv1(m_log, context, requestXml);
        }

        private AppXmlExecResult DoTDAWdwltoCardProcess(EaiContext context, XmlDocument requestXml, string DebitAcc, string CreditAcc, string Curr, string tranAMT, string CoCode)
        {
            AppXmlExecResult t24_result = Send1Recv1(m_log, context, requestXml);
            XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
            string failCode = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
            string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");
            string acctInt = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_INTEREST");

            if (failCode == "E-000000" && proc_ret == "SUCC")
            {
                //get new amount
                Double tranAMTDB = Double.TryParse(tranAMT, out tranAMTDB) ? tranAMTDB : 0.00;
                Double acctIntDB = Double.TryParse(acctInt, out acctIntDB) ? acctIntDB : 0.00;
                string tranAMTAll = (tranAMTDB + acctIntDB).ToString();
                m_log.Info("tranAMT, acctInt" + tranAMT + ", " + acctInt);
                m_log.Info("tranAMTAll=" + tranAMTAll);

                //銀聯入帳
                CMMControler m_CMMControler = new CMMControler();
                string bodyCUP = m_CMMControler.GetCard_Credit_ContentMsg(CreditAcc, DebitAcc, tranAMTAll, "6013", "03450000", GetCURR_NUM(Curr), CoCode);
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Credit");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                failCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");

                if (failCode != "00")
                {
                    string failDescription = ErrorCodeMapping("CUP", failCode);

                    string ftRspId = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_TXN_ID");
                    string bodyRFT = GetT24_RFT_Content("FUNDS.TRANSFER", "IB.IND.TDA.WDWL", CoCode, "R", ftRspId, "ITF001.0070");
                    AppXmlExecResult t24_R_Result = SendMsgToEAIProcess(context, bodyRFT, "IB.IND.TDA.WDWL");

                    m_log.Info("T24 OK, CUP ERROR, T24 R: bodyRFT=" + bodyRFT);

                    XmlHelper xmlHelperT24RS_R = XmlHelper.GetInstance(t24_R_Result.ResponseXml);
                    string rs_Code = xmlHelperT24RS_R.GetXPath(t24_R_Result.ResponseXml, "//ITF_RETURN_CODE");
                    string proc_ret_R = xmlHelperT24RS.GetXPath(t24_R_Result.ResponseXml, "//RSP_PROC_RET");

                    if (!rs_Code.Equals("E-000000") || proc_ret_R != "SUCC")
                    {
                        new SendMail().Send("银联卡定存转活期，银联卡入账失败", "6", string.Format("银联卡定存转活期，T24已扣帐，但银联卡入账失败, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                    }

                    string afterRS = GetT24_ErrorRS("", failCode, "", failDescription);
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRS);
                    XmlDocument rs_ERR = base.TransformCommMsg("0", "", "", afterRS);
                    return base.BuildExecResult(context, rs_ERR);
                 }                
            }

            return base.BuildExecResult(context, t24_result.ResponseXml);
        }

        private AppXmlExecResult DoTDACloseProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {

            XmlHelper xmlHelperIBRQ = XmlHelper.GetInstance(requestXml);
            string CoCode = xmlHelperIBRQ.GetXPath(requestXml, "//SIGN_ON_BRH");
            string CreditAcc = xmlHelperIBRQ.GetXPath(requestXml, "//SETTLEMENT_ACCT");
            string DebitAcc = xmlHelperIBRQ.GetXPath(requestXml, "//REQ_TXN_ID");

            requestXml = CopyToNewDocument(requestXml, txID.Replace("IND.TDA.CLOSE", "IB.RT.TDW"), Guid.NewGuid().ToString());

            if (CreditAcc.Length > 15) //card
            {
                //確認入帳銀聯卡的狀態
                string bodyCUP = Get5001_ENQ_Content(CreditAcc);
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "5001");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                string retCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RETCODE");
                string cardStat = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//CARD-STAT");
                string frzType = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FRZTYPE");

                m_log.Info("DoTDAWdwlProcess CARD STATUS: Card id=" + CreditAcc + ", statusCode=" + retCode + ", Stat=" + cardStat + ", FrzType=" + frzType);

                if (!retCode.Equals("000000") || !cardStat.Equals("") || frzType.Equals("1"))
                {
                    //retCode為000000代表「正常」(以排除卡號不存在)，cardStat為空代表「正常」，frzType為1代表「活期不收不付凍結」
                    string failCode = "14"; //無效卡號
                    string failDescription = ErrorCodeMapping("CUP", failCode);

                    string afterRS = GetT24_ErrorRS("", failCode, "", failDescription);
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRS);
                    XmlDocument rs_ERR = base.TransformCommMsg("0", "", "", afterRS);
                    return base.BuildExecResult(context, rs_ERR);
                }

                xmlHelperIBRQ.SetMultipleXPath(requestXml, "//L_CARD_NO", CreditAcc);
                return DoTDAClosetoCardProcess(context, requestXml, DebitAcc, CreditAcc, CoCode);

            }
            else //ACC
                return Send1Recv1(m_log, context, requestXml);
        }

        private AppXmlExecResult DoTDAClosetoCardProcess(EaiContext context, XmlDocument requestXml, string DebitAcc, string CreditAcc, string CoCode)
        {
            AppXmlExecResult t24_result = Send1Recv1(m_log, context, requestXml);

            XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);

            string failCode = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
            string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");
            string acctInt = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//TOTAL_CR_INTEREST");
            string tranAMT = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//TOTAL_ACC_AMT");
            string Curr = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//CURRENCY");

            if (failCode == "E-000000" && proc_ret == "SUCC")
            {
                //get new amount
                Double tranAMTDB = Double.TryParse(tranAMT, out tranAMTDB) ? tranAMTDB : 0.00;
                Double acctIntDB = Double.TryParse(acctInt, out acctIntDB) ? acctIntDB : 0.00;
                string tranAMTAll = (tranAMTDB + acctIntDB).ToString();
                m_log.Info("tranAMT, acctInt" + tranAMT + ", " + acctInt);
                m_log.Info("tranAMTAll=" + tranAMTAll);

                //銀聯入帳
                CMMControler m_CMMControler = new CMMControler();
                string bodyCUP = m_CMMControler.GetCard_Credit_ContentMsg(CreditAcc, DebitAcc, tranAMTAll, "6013", "03450000", GetCURR_NUM(Curr), CoCode);
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Credit");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                failCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");

                if (failCode != "00")
                {
                    string failDescription = ErrorCodeMapping("CUP", failCode);

                    new SendMail().Send("银联卡定存转活期，银联卡入账失败", "6", string.Format("银联卡定存转活期，T24已销户，但银联卡入账失败, PLS Check RQ:{0}", context.RequestXml.OuterXml));

                    string afterRS = GetT24_ErrorRS("", failCode, "", failDescription);
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRS);
                    XmlDocument rs_ERR = base.TransformCommMsg("0", "", "", afterRS);
                    return base.BuildExecResult(context, rs_ERR);
                }
            }

            return base.BuildExecResult(context, t24_result.ResponseXml);
        }

        private AppXmlExecResult DoNDAOpenProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            XmlHelper xmlHelperIBRQ = XmlHelper.GetInstance(requestXml);
            string CoCode = xmlHelperIBRQ.GetXPath(requestXml, "//SIGN_ON_BRH");
            string DebitAcc = xmlHelperIBRQ.GetXPath(requestXml, "//C_WDWL_ACCT");
            string Curr = xmlHelperIBRQ.GetXPath(requestXml, "//CURRENCY");
            string tranAMT = xmlHelperIBRQ.GetXPath(requestXml, "//C_DEP_AMT");

            requestXml = CopyToNewDocument(requestXml, txID.Replace("IND.NDA.OPEN", "ESCN.IB.NEW.RT.NDA"), Guid.NewGuid().ToString());

            if (DebitAcc.Length > 15)
            {
                xmlHelperIBRQ.SetMultipleXPath(requestXml, "//L_CARD_NO", DebitAcc);
                return DoCardToNDAProcess(context, requestXml, DebitAcc, Curr, tranAMT, CoCode);
            }
            else // ACC 
                return Send1Recv1(m_log, context, requestXml);
        }

        private AppXmlExecResult DoCardToNDAProcess(EaiContext context, XmlDocument requestXml, string DebitAcc, string Curr, string tranAMT, string CoCode)
        {
            string creditACC = string.Empty;
            string failDescription = string.Empty;

            //開通知存款帳戶
            AppXmlExecResult t24_result = Send1Recv1(m_log, context, requestXml);
            XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
            string failCode = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
            string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

            if (failCode == "E-000000" && proc_ret == "SUCC")
            {
                creditACC = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_TXN_ID");

                //組電文發CUP.Card.Debit至銀聯
                CMMControler m_CMMControler = new CMMControler();
                string bodyCUP = m_CMMControler.GetCard_Debit_ContentMsg(DebitAcc, creditACC, tranAMT, "D00000000", "6013", "03450000", "0X03", GetCURR_NUM(Curr), CoCode, "        07     ");
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Debit");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                failCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");

                if (failCode == "00")
                {
                    //發FUNDS.TRANSFER,ESCN.IB.IND.CALL.ACC[個人通知存款开户转账交易（網銀）]至T24
                    string bodyFT = GetT24_NTCFTIN_Content(CoCode, "I", "", DebitAcc, tranAMT, creditACC, "ITF001.0073");
                    AppXmlExecResult t24_FT_Result = SendMsgToEAIProcess(context, bodyFT, "ESCN.IB.IND.CALL.ACC");
                    XmlHelper xmlHelperT24FTRS = XmlHelper.GetInstance(t24_FT_Result.ResponseXml);
                    failCode = xmlHelperT24FTRS.GetXPath(t24_FT_Result.ResponseXml, "//ITF_RETURN_CODE");
                    string t24_FT_Proc = xmlHelperT24FTRS.GetXPath(t24_FT_Result.ResponseXml, "//RSP_PROC_RET");

                    if (failCode != "E-000000" || t24_FT_Proc != "SUCC")
                    {
                        //失敗R掉
                        string msgType = "0200";
                        string dateTime_Now = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//TRAN_TIME");
                        string traceNo = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//SYS_TRACE_NUM");
                        string acqCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//ACQ_INST_ID_CO");
                        string forCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//FOR_INT_ID_CO");

                        string oriData = string.Format("{0}{1}{2}{3}{4}", msgType, traceNo, dateTime_Now, acqCode.PadLeft(11, '0'), forCode.PadLeft(11, '0'));
                        string bodyCUP_EC = m_CMMControler.GetEC_Card_Debit_ContentMsg(DebitAcc, creditACC, tranAMT, "6013", "03450000", "0X03", GetCURR_NUM(Curr), oriData, CoCode, "        07     ");
                        AppXmlExecResult cup_EC_result = SendMsgToEAIProcess(context, bodyCUP_EC, "CUP.Card.Debit.EC");
                        XmlHelper xmlHelperCUPRS_EC = XmlHelper.GetInstance(cup_EC_result.ResponseXml);
                        string cup_EC_RSCode = xmlHelperCUPRS_EC.GetXPath(cup_EC_result.ResponseXml, "//RES_CO");

                        if (cup_EC_RSCode != "00")
                            //SEND MAIL
                            new SendMail().Send("Do ACC.Transfer(R) Error", "", string.Format("Do ACC.Transfer(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                        
                        return base.BuildExecResult(context, t24_FT_Result.ResponseXml);
                    }

                    return base.BuildExecResult(context, t24_result.ResponseXml);
                }
                else
                {
                    failDescription = ErrorCodeMapping("CUP", failCode);
                    string afterRS = GetT24_ErrorRS("", failCode, "", failDescription);
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRS);
                    XmlDocument rs_ERR = base.TransformCommMsg("0", "", "", afterRS);
                    return base.BuildExecResult(context, rs_ERR);
                }
            }
            else
                return base.BuildExecResult(context, t24_result.ResponseXml);
        }

        private AppXmlExecResult DoNDAWdwlProcess(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            XmlHelper xmlHelperIBRQ = XmlHelper.GetInstance(requestXml);
            string CoCode = xmlHelperIBRQ.GetXPath(requestXml, "//SIGN_ON_BRH");
            string DebitAcc = xmlHelperIBRQ.GetXPath(requestXml, "//DEBIT_ACCT_NO");
            string CreditAcc = xmlHelperIBRQ.GetXPath(requestXml, "//CREDIT_ACCT_NO");
            string Curr = xmlHelperIBRQ.GetXPath(requestXml, "//DEBIT_CURRENCY");
            string tranAMT = xmlHelperIBRQ.GetXPath(requestXml, "//DEBIT_AMOUNT");
            string WdwlType = xmlHelperIBRQ.GetXPath(requestXml, "//WDWL_TYPE");

            requestXml = CopyToNewDocument(requestXml, txID.Replace("IND.NDA.WDWL", "ESCN.IB.IND.CALL.WDWL"), Guid.NewGuid().ToString());
            xmlHelperIBRQ.SetMultipleXPath(requestXml, "//WDWL_TYPE", "");

            if (CreditAcc.Length > 15) //Card 
            {
                xmlHelperIBRQ.SetMultipleXPath(requestXml, "//L_CARD_NO", CreditAcc);
                return DoNDAToCardProcess(context, requestXml, DebitAcc, CreditAcc, tranAMT, WdwlType, Curr, CoCode);
            }
            else // ACC 
            {
                xmlHelperIBRQ.SetMultipleXPath(requestXml, "//CREDIT_ACCT_NO", "");
                return Send1Recv1(m_log, context, requestXml);
            }
        }

        private AppXmlExecResult DoNDAToCardProcess(EaiContext context, XmlDocument requestXml, string DebitAcc, string CreditAcc, string tranAMT, string WdwlType, string Curr, string CoCode)
        {
            //先傳送FT至T24
            AppXmlExecResult t24_result = Send1Recv1(m_log, context, requestXml);
            XmlHelper xmlHelperT24RS = XmlHelper.GetInstance(t24_result.ResponseXml);
            string failCode = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//ITF_RETURN_CODE");
            string proc_ret = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_PROC_RET");

            if (failCode == "E-000000" && proc_ret == "SUCC")
            {
                //T24扣款成功，送銀聯
                string interest = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//C_INTEREST");

                Double tranAMTDB = Double.TryParse(tranAMT, out tranAMTDB) ? tranAMTDB : 0.00;
                Double acctInt = Double.TryParse(interest, out acctInt) ? acctInt : 0.00;
                string tranAMTAll = (tranAMTDB + acctInt).ToString();

                m_log.Info("tranAMT, acctInt" + tranAMT + ", " + acctInt);
                m_log.Info("tranAMTAll=" + tranAMTAll);

                CMMControler m_CMMControler = new CMMControler();
                string bodyCUP = m_CMMControler.GetCard_Credit_ContentMsg(CreditAcc, DebitAcc, tranAMTAll, "6013", "03450000", GetCURR_NUM(Curr), CoCode);
                AppXmlExecResult cup_result = SendMsgToEAIProcess(context, bodyCUP, "CUP.Card.Credit");
                XmlHelper xmlHelperCUPRS = XmlHelper.GetInstance(cup_result.ResponseXml);
                failCode = xmlHelperCUPRS.GetXPath(cup_result.ResponseXml, "//RES_CO");

                if (failCode == "00")
                    return base.BuildExecResult(context, t24_result.ResponseXml);
                else
                {
                    //銀聯入款失敗
                    string failDescription = ErrorCodeMapping("CUP", failCode);

                    if (WdwlType != "01") //非全額取款時T24做R
                    {
                        string ftRspId = xmlHelperT24RS.GetXPath(t24_result.ResponseXml, "//RSP_TXN_ID");

                        string bodyRFT = GetT24_RFT_Content("FUNDS.TRANSFER", "ESCN.IB.IND.CALL.WDWL", CoCode, "R", ftRspId, "ITF001.0074");
                        AppXmlExecResult t24_R_Result = SendMsgToEAIProcess(context, bodyRFT, "ESCN.IB.IND.CALL.WDWL");

                        XmlHelper xmlHelperT24RS_R = XmlHelper.GetInstance(t24_R_Result.ResponseXml);
                        string rs_Code = xmlHelperT24RS_R.GetXPath(t24_R_Result.ResponseXml, "//ITF_RETURN_CODE");
                        string proc_ret_R = xmlHelperT24RS.GetXPath(t24_R_Result.ResponseXml, "//RSP_PROC_RET");

                        if (!rs_Code.Equals("E-000000") || proc_ret_R != "SUCC")
                            //send mail
                            new SendMail().Send("Do NTC.Transfer(R) Error", "6", string.Format("Do NTC.Transfer(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));
                    }
                    else
                        new SendMail().Send("Do NTC.Transfer(R) Error", "6", string.Format("Do NTC.Transfer(R) Error, PLS Check RQ:{0}", context.RequestXml.OuterXml));

                    string afterRS = GetT24_ErrorRS("", failCode, "", failDescription);
                    m_log.Debug("AppXmlExecResult RunImpl.afterRSERR={0}", afterRS);
                    XmlDocument rs_ERR = base.TransformCommMsg("0", "", "", afterRS);
                    return base.BuildExecResult(context, rs_ERR);
                }
            }
            else
                return base.BuildExecResult(context, t24_result.ResponseXml);
        }

        private string GetT24_RFT_Content(string Appl, string ApplName, string CoCode, string proc_FUNC, string txnID, string itfID)
        {
            StringBuilder sb = new StringBuilder();
            #region FT XML MSG
            sb.Append("<T24_DATA>"); 
            sb.Append("<T24_EAI>"); 
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", CoCode);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", Appl);
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", ApplName);
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>"); 
            #endregion
            return sb.ToString();
        }

        private string GetT24_ErrorRS(string txnID, string itfID, string extREF, string failDescription)
        {
            StringBuilder sb = new StringBuilder();
            #region ERROR XML MSG
            //sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<RSP_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<RSP_PROC_SYS/>");
            sb.Append("<PROC_RESULT/>");
            sb.Append("<DATE_TIME_REQ/>");
            sb.Append("<DATE_TIME_RSP/>");
            sb.Append("</RSP_PROC_INFO>");
            sb.Append("<RSP_MSG_GRP>");
            sb.Append("<RSP_MSG_DATA no='1'>");
            sb.Append("<RSP_TXN_CODE/>");
            sb.Append("<RSP_TXN_CODE_S/>");
            sb.AppendFormat("<RSP_TXN_ID>{0}</RSP_TXN_ID>", txnID);
            sb.AppendFormat("<RSP_PROC_RET>{0}</RSP_PROC_RET>", "FAIL");
            sb.AppendFormat("<ITF_RETURN_CODE mp='1' sp='1'>{0}</ITF_RETURN_CODE>", itfID);
            sb.AppendFormat("<ITF_RETURN_MSG mp='1' sp='1'>{0}</ITF_RETURN_MSG>", failDescription);
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", extREF);
            sb.Append("</RSP_MSG_DATA>");
            sb.Append("</RSP_MSG_GRP>");  
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            //sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_CardENQ_Content(string debitACC)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.CARD.CUSDATA.ENQ XML MSG
            sb.Append("<T24_DATA>"); 
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.CARD.CUSDATA.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "CUP001.0001");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<CARD_NO op='EQ'>{0}</CARD_NO>", debitACC);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>"); 
            #endregion
            return sb.ToString();
        }

        private string GetT24_CommENQ_Content(string tranAMT, string cURR, string CommType)
        {
            StringBuilder sb = new StringBuilder();
            #region IB.CHG.CHK.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "IB.CHG.CHK.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "ITF001.0035");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<TXN_TYPE op='EQ'>{0}</TXN_TYPE>", "AC");
            sb.AppendFormat("<TXN_AMOUNT op='EQ'>{0}</TXN_AMOUNT>", tranAMT);
            sb.AppendFormat("<COMM_TYPE op='EQ'>{0}</COMM_TYPE>", CommType);
            sb.AppendFormat("<CURR op='EQ'>{0}</CURR>", cURR);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_LimitENQ_Content(string debitACC, string gate)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.BP.DEB.LIM.ENQ XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", "");
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_ENQ_CODE>{0}</REQ_ENQ_CODE>", "ESCN.BP.DEB.LIM.ENQ");
            sb.AppendFormat("<ITF.MSGKEY op='EQ'>{0}</ITF.MSGKEY>", "IB001.0010");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'>{0}</TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<ITF_ENQ_PRE_LINE></ITF_ENQ_PRE_LINE>");
            sb.AppendFormat("<ACCOUNT_NUMBER op='EQ'>{0}</ACCOUNT_NUMBER>", debitACC);
            sb.AppendFormat("<VALUE_DATE op='EQ'>{0}</VALUE_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<TRANS_GATE op='EQ'>{0}</TRANS_GATE>", gate);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_DebLim_Content(string co_Code, string proc_FUNC, string debitACC, string tranAMT, string cURR, string creditACC)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.BP.DEBIT.LIMIT XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "ESCN.BP.DEBIT.LIMIT");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", debitACC + "." + DateTime.Today.ToString("yyyyMMdd") + "." + DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<CURRENCY sp='1' mp='1'>{0}</CURRENCY>", cURR);
            sb.AppendFormat("<DEBIT_ACCT sp='1' mp='1'>{0}</DEBIT_ACCT>", debitACC);
            sb.AppendFormat("<AMOUNT sp='1' mp='1'>{0}</AMOUNT>", tranAMT);
            sb.AppendFormat("<CREDIT_ACCT sp='1' mp='1'>{0}</CREDIT_ACCT>", creditACC);
            sb.AppendFormat("<VALUE_DATE sp='1' mp='1'>{0}</VALUE_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<CARD_NO sp='1' mp='1'>{0}</CARD_NO>", debitACC);
            sb.AppendFormat("<REFERENCE sp='1' mp='1'>{0}</REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<TRANS_GATE sp='1' mp='1'>{0}</TRANS_GATE>", "01");
            //sb.AppendFormat("<CUSTOMER_NO sp='1' mp='1'>{0}</CUSTOMER_NO>", checkCustNo);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", "IB001.0011");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private string GetT24_ECDebLim_Content(string co_Code, string proc_FUNC, string debitACC, string tranAMT, string cURR, string creditACC)
        {
            StringBuilder sb = new StringBuilder();
            #region ESCN.BP.DEBIT.LIMIT XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "ESCN.BP.DEBIT.LIMIT");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", debitACC + "." + DateTime.Today.ToString("yyyyMMdd") + "." + DateTime.Now.ToString("yyyyMMddHHmmss") + "R");
            sb.AppendFormat("<CURRENCY sp='1' mp='1'>{0}</CURRENCY>", cURR);
            sb.AppendFormat("<DEBIT_ACCT sp='1' mp='1'>{0}</DEBIT_ACCT>", debitACC);
            sb.AppendFormat("<AMOUNT sp='1' mp='1'>{0}</AMOUNT>", tranAMT);
            sb.AppendFormat("<CREDIT_ACCT sp='1' mp='1'>{0}</CREDIT_ACCT>", creditACC);
            sb.AppendFormat("<VALUE_DATE sp='1' mp='1'>{0}</VALUE_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<CARD_NO sp='1' mp='1'>{0}</CARD_NO>", debitACC);
            sb.AppendFormat("<REFERENCE sp='1' mp='1'>{0}</REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            //sb.AppendFormat("<CUSTOMER_NO sp='1' mp='1'>{0}</CUSTOMER_NO>", checkCustNo);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", "IB001.0011");
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        public string GetCard_Debit(string pAN, string creditACC, string tranAMT, string tranFee, string merType, string pos_entry, string bankCUPCode, string addResData, string cURR, string co_Code, string msg_Rea)
        {
            StringBuilder sb = new StringBuilder();
            #region Card_Debit
            string dateTime_Now = DateTime.Now.ToString("MMddHHmmss");

            sb.AppendFormat("<PAN>{0}</PAN>", pAN);
            sb.AppendFormat("<AMT_OF_TRAN>{0}</AMT_OF_TRAN>", tranAMT);
            sb.AppendFormat("<TRAN_TIME>{0}</TRAN_TIME>", dateTime_Now);
            sb.AppendFormat("<L_TRAN_TIME>{0}</L_TRAN_TIME>", dateTime_Now.Substring(4));
            sb.AppendFormat("<L_TRAN_DATE>{0}</L_TRAN_DATE>", dateTime_Now.Substring(0, 4));
            sb.AppendFormat("<MER_TYPE>{0}</MER_TYPE>", merType);
            sb.AppendFormat("<POS_ENTRY_MO>{0}</POS_ENTRY_MO>", pos_entry);
            sb.AppendFormat("<POS_CONDITION_CO>{0}</POS_CONDITION_CO>", "00");
            sb.AppendFormat("<POS_PIN_CAPTURE_CO>{0}</POS_PIN_CAPTURE_CO>", "06");
            sb.AppendFormat("<TRAN_FEE_AMT>{0}</TRAN_FEE_AMT>", tranFee);
            sb.AppendFormat("<ACQ_INST_ID_CO>{0}</ACQ_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<FOR_INT_ID_CO>{0}</FOR_INT_ID_CO>", bankCUPCode);
            sb.AppendFormat("<C_ACC_TERMINAL_ID>{0}</C_ACC_TERMINAL_ID>", co_Code.Substring(1, 8));
            sb.AppendFormat("<C_ACC_ID_CO>{0}</C_ACC_ID_CO>", "100000000000000");
            sb.AppendFormat("<ADD_RES_DATA>{0}</ADD_RES_DATA>", addResData);
            sb.AppendFormat("<C_ACC_NAME_LO>{0}</C_ACC_NAME_LO>", "UPPC");
            sb.AppendFormat("<ADD_DATA>{0}</ADD_DATA>", "");
            sb.AppendFormat("<TRAN_CURR_CODE>{0}</TRAN_CURR_CODE>", cURR);
            sb.AppendFormat("<MSG_REA_CO>{0}</MSG_REA_CO>", msg_Rea);
            sb.AppendFormat("<REC_INST_ID_CO>{0}</REC_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<ACC_IDE_1>{0}</ACC_IDE_1>", pAN);
            sb.AppendFormat("<ACC_IDE_2>{0}</ACC_IDE_2>", creditACC);
            #endregion
            return sb.ToString();
        }

        public string GetCard_Credit(string pAN, string debitACC, string tranAMT, string merType, string bankCUPCode, string cURR, string co_Code)
        {
            StringBuilder sb = new StringBuilder();
            #region Card_Credit
            string dateTime_Now = DateTime.Now.ToString("MMddHHmmss");

            sb.AppendFormat("<PAN>{0}</PAN>", pAN);
            sb.AppendFormat("<AMT_OF_TRAN>{0}</AMT_OF_TRAN>", tranAMT);
            sb.AppendFormat("<TRAN_TIME>{0}</TRAN_TIME>", dateTime_Now);
            sb.AppendFormat("<L_TRAN_TIME>{0}</L_TRAN_TIME>", dateTime_Now.Substring(4));
            sb.AppendFormat("<L_TRAN_DATE>{0}</L_TRAN_DATE>", dateTime_Now.Substring(0, 4));
            sb.AppendFormat("<MER_TYPE>{0}</MER_TYPE>", merType);
            sb.AppendFormat("<POS_ENTRY_MO>{0}</POS_ENTRY_MO>", "012");
            sb.AppendFormat("<POS_CONDITION_CO>{0}</POS_CONDITION_CO>", "00");
            sb.AppendFormat("<ACQ_INST_ID_CO>{0}</ACQ_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<FOR_INT_ID_CO>{0}</FOR_INT_ID_CO>", bankCUPCode);
            sb.AppendFormat("<C_ACC_TERMINAL_ID>{0}</C_ACC_TERMINAL_ID>", co_Code.Substring(1, 8));
            sb.AppendFormat("<C_ACC_ID_CO>{0}</C_ACC_ID_CO>", "100000000000000");
            sb.AppendFormat("<ADD_RES_DATA>{0}</ADD_RES_DATA>", "0       1");
            sb.AppendFormat("<C_ACC_NAME_LO>{0}</C_ACC_NAME_LO>", "汇入汇款");
            sb.AppendFormat("<ADD_DATA>{0}</ADD_DATA>", "ABCDEFGAAA");
            sb.AppendFormat("<TRAN_CURR_CODE>{0}</TRAN_CURR_CODE>", cURR);
            sb.AppendFormat("<REC_INST_ID_CO>{0}</REC_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<ACC_IDE_1>{0}</ACC_IDE_1>", debitACC);
            sb.AppendFormat("<ACC_IDE_2>{0}</ACC_IDE_2>", pAN);
            #endregion
            return sb.ToString();
        }

        public string Get_Card_EC(string pAN, string debitACC, string creditACC, string tranAMT, string merType, string pos_entry, string bankCUPCode, string addResData, string cURR,
                                           string oriData, string co_Code, string msg_Rea)
        {
            StringBuilder sb = new StringBuilder();
            #region Card_EC
            string dateTime_Now = DateTime.Now.ToString("MMddHHmmss");

            sb.AppendFormat("<PAN>{0}</PAN>", pAN);
            sb.AppendFormat("<AMT_OF_TRAN>{0}</AMT_OF_TRAN>", tranAMT);
            sb.AppendFormat("<TRAN_TIME>{0}</TRAN_TIME>", dateTime_Now);
            sb.AppendFormat("<SYS_TRACE_NUM>{0}</SYS_TRACE_NUM>", "");
            sb.AppendFormat("<L_TRAN_TIME>{0}</L_TRAN_TIME>", dateTime_Now.Substring(4));
            sb.AppendFormat("<L_TRAN_DATE>{0}</L_TRAN_DATE>", dateTime_Now.Substring(0, 4));
            sb.AppendFormat("<MER_TYPE>{0}</MER_TYPE>", merType);
            sb.AppendFormat("<POS_ENTRY_MO>{0}</POS_ENTRY_MO>", pos_entry);
            sb.AppendFormat("<POS_CONDITION_CO>{0}</POS_CONDITION_CO>", "00");
            sb.AppendFormat("<POS_PIN_CAPTURE_CO>{0}</POS_PIN_CAPTURE_CO>", "06");
            sb.AppendFormat("<ACQ_INST_ID_CO>{0}</ACQ_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<FOR_INT_ID_CO>{0}</FOR_INT_ID_CO>", bankCUPCode);
            sb.AppendFormat("<RET_REF_NUM>{0}</RET_REF_NUM>", "");
            sb.AppendFormat("<C_ACC_TERMINAL_ID>{0}</C_ACC_TERMINAL_ID>", co_Code.Substring(1, 8));
            sb.AppendFormat("<C_ACC_ID_CO>{0}</C_ACC_ID_CO>", "100000000000000");
            sb.AppendFormat("<C_ACC_NAME_LO>{0}</C_ACC_NAME_LO>", "UPPC");
            sb.AppendFormat("<ADD_RES_DATA>{0}</ADD_RES_DATA>", addResData);
            sb.AppendFormat("<TRAN_CURR_CODE>{0}</TRAN_CURR_CODE>", cURR);
            sb.AppendFormat("<MSG_REA_CO>{0}</MSG_REA_CO>", msg_Rea); 
            sb.AppendFormat("<ORI_DATA_ELE>{0}</ORI_DATA_ELE>", oriData);
            sb.AppendFormat("<REC_INST_ID_CO>{0}</REC_INST_ID_CO>", bankCUPCode);
            sb.AppendFormat("<ACC_IDE_1>{0}</ACC_IDE_1>", debitACC);
            sb.AppendFormat("<ACC_IDE_2>{0}</ACC_IDE_2>", creditACC);
            #endregion
            return sb.ToString();
        }

        private string GetT24_NTCFTIN_Content(string co_Code, string proc_FUNC, string txnID, string debitACC, string tranAMT, string creditACC, string itfID)
        {
            StringBuilder sb = new StringBuilder();
            #region FUNDS.TRANSFER,ESCN.IB.IND.CALL.ACC XML MSG
            sb.Append("<T24_DATA>");
            sb.Append("<T24_EAI>");
            sb.Append("<T24_EAI_HDR>");
            sb.Append("<MSG_SYS_ID/>");
            sb.Append("<HDR_MD5_DES/>");
            sb.Append("</T24_EAI_HDR>");
            sb.Append("<T24_EAI_MSG>");
            sb.Append("<REQ_MSG_GRP>");
            sb.Append("<REQ_MSG_OPT>");
            sb.AppendFormat("<SIGN_ON_ID>{0}</SIGN_ON_ID>", ProjectConfig.GetInstance().OfsUser);
            sb.AppendFormat("<SIGN_ON_PSWD>{0}</SIGN_ON_PSWD>", ProjectConfig.GetInstance().OfsPwd);
            sb.AppendFormat("<SIGN_ON_BRH>{0}</SIGN_ON_BRH>", co_Code);
            sb.AppendFormat("<PROC_FUNC>{0}</PROC_FUNC>", proc_FUNC);
            sb.Append("</REQ_MSG_OPT>");
            sb.Append("<REQ_MSG_DATA>");
            sb.AppendFormat("<REQ_TXN_CODE>{0}</REQ_TXN_CODE>", "FUNDS.TRANSFER");
            sb.AppendFormat("<REQ_TXN_CODE_S>{0}</REQ_TXN_CODE_S>", "ESCN.IB.IND.CALL.ACC");
            sb.AppendFormat("<REQ_TXN_ID>{0}</REQ_TXN_ID>", txnID);
            sb.AppendFormat("<DEBIT_ACCT_NO sp='1' mp='1'>{0}</DEBIT_ACCT_NO>", debitACC);
            sb.AppendFormat("<DEBIT_AMOUNT sp='1' mp='1'>{0}</DEBIT_AMOUNT>", tranAMT);
            sb.AppendFormat("<CREDIT_ACCT_NO sp='1' mp='1'>{0}</CREDIT_ACCT_NO>", creditACC);
            sb.AppendFormat("<ITF_MSGKEY op='EQ'>{0}</ITF_MSGKEY>", itfID);
            sb.AppendFormat("<CHANNEL_ID op='EQ'>{0}</CHANNEL_ID>", ProjectConfig.GetInstance().ITFChannelID);
            sb.AppendFormat("<TERM_NO op='EQ'></TERM_NO>", System.Environment.MachineName);
            sb.AppendFormat("<EXT_BUSS_DATE op='EQ'>{0}</EXT_BUSS_DATE>", DateTime.Today.ToString("yyyyMMdd"));
            sb.AppendFormat("<EXT_REFERENCE op='EQ'>{0}</EXT_REFERENCE>", SeqNoMgr.GetInstance().GetNextSeqNo("ITF", 10));
            sb.AppendFormat("<EXT_TXN_TIME op='EQ'>{0}</EXT_TXN_TIME>", DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.AppendFormat("<L_CARD_NO sp='1' mp='1'>{0}</L_CARD_NO>", debitACC);
            sb.Append("</REQ_MSG_DATA>");
            sb.Append("</REQ_MSG_GRP>");
            sb.Append("<REQ_PROC_INFO>");
            sb.Append("<UNQ_REF_ID/>");
            sb.Append("<REQ_PROC_SYS/>");
            sb.Append("</REQ_PROC_INFO>");
            sb.Append("</T24_EAI_MSG>");
            sb.Append("</T24_EAI>");
            sb.Append("</T24_DATA>");
            #endregion
            return sb.ToString();
        }

        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey)
        {
            string msgContent = base.SendToEAIProcess(body, eAI_MsgKey);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, msgContent);

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(msgContent);
            XmlDocument subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString());
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }

        private string Get5001_ENQ_Content(string debitACC)
        {
            StringBuilder sb = new StringBuilder();
            #region 5001 ACC BAL XML MSG

            sb.AppendFormat("<TRXTYPE>{0}</TRXTYPE>", "5001");
            sb.AppendFormat("<RETCODE>{0}</RETCODE>", "");
            sb.AppendFormat("<BNKNBR>{0}</BNKNBR>", "0345");
            sb.AppendFormat("<SOURCE>{0}</SOURCE>", "CT");
            sb.AppendFormat("<BRN_NO>{0}</BRN_NO>", "010002");
            sb.AppendFormat("<OPE_NO>{0}</OPE_NO>", "000001");
            sb.AppendFormat("<SEQNO>{0}</SEQNO>", "100921");
            sb.AppendFormat("<CARDNO>{0}</CARDNO>", debitACC);
            sb.AppendFormat("<PINFLAG>{0}</PINFLAG>", "0");
            sb.AppendFormat("<PIN>{0}</PIN>", "");

            #endregion
            return sb.ToString();
        }

        private string ErrorCodeMapping(string sourceName, string sourceStatus)
        {
            Bankpro.EAI.Component.StatusData status = Bankpro.EAI.Component.ProjectCache.GetInstance().GetStatusData(sourceName, sourceStatus);

            if (status != null)
                return status.m_statusDesc;
            else
                return sourceStatus;

        }
        
    }
}
