﻿using Microsoft.EAIServer;
using Microsoft.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace Bankpro.EAI.BPM
{
    internal class RDBCommQuery : XmlBaseBpmAdapter
    {

        internal string GetT24Date(EaiContext context, Logger logger)
        {
            string txid = "RDB_DATES";

            T24QueryInfo t24QI = new T24QueryInfo();
            t24QI.TableName = "F_DATES";
            t24QI.TransColumnLst = new List<TransColumn>();
            TransColumn tc = new TransColumn();
            tc.Column = "TODAY";
            tc.NewColNm = RDBCommInfo.Y_TODAY;
            var tc_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tc.ColMapLst = new List<ColumnMapping>() { tc_CM_1 };
            t24QI.TransColumnLst.Add(tc);
            t24QI.ReturnColumnLst = t24QI.TransColumnLst.Select(t => string.IsNullOrEmpty(t.NewColNm) ? t.Column : t.NewColNm).Distinct().ToList();
            t24QI.QInfo = new QueryInfo();
            t24QI.QInfo.AON = "AND";
            t24QI.QInfo.FieldCriLst = new List<FieldCriteria>();
            FieldCriteria fc = new FieldCriteria();
            fc.FieldNm = "@ID";
            fc.Operator = "=";
            fc.Value = "CN0010001";
            t24QI.QInfo.FieldCriLst.Add(fc);


            var msgContent_Tt = RDBUtil.GetRdbMsgContent(txid, t24QI.TableName.Replace('#', '_'), t24QI);
            var postResult = SendMsgToEAIProcess(context, msgContent_Tt, txid, logger);

            List<Record> tt_LiveRecordLst = RDBUtil.GetRdbRsList<RDBCommInfo.DT_XMLRECORD>(postResult.ResponseXml.InnerXml);
            if (tt_LiveRecordLst == null || tt_LiveRecordLst.Count == 0)
            { return null; }
            var curr = (tt_LiveRecordLst[0].XMLRECORD as RDBCommInfo.DT_XMLRECORD).Y_TODAY;
            return curr;
        }
        //...
        //...
        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey, Logger logger)
        {
            logger.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, body);

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(body);
            XmlDocument subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString());
            AppXmlExecResult result = Send1Recv1(logger, context, subRqXml);
            logger.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            throw new NotImplementedException();
        }
    }

    internal class RDBCommInfo
    {
        internal static string Y_TODAY = "Y_TODAY";
        public class DT_XMLRECORD : IXMLRECORD
        {
            public string Y_TODAY { get; set; }
        }
    }
}
