﻿#define func
using Bankpro.EAI.BPM.Common;
using Bankpro.EAI.Component;
using Microsoft.EAIServer;
using Microsoft.Service;
using Microsoft.Service.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace Bankpro.EAI.BPM
{
    public class ElecRcpt_TTFT : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.ElecRcpt_TTFT");
        private readonly string m_2040501_txid = "2040501";
        //private readonly string m_2040501xml_txid = "ELEC.RCPT.QUERY";
        private readonly string m_2040506_txid = "2040506";
        private readonly string m_RdbMsgid_TT = "RDB_TT";
        private readonly string m_RdbMsgid_TT_HIS = "RDB_TT_HIS";
        private readonly string m_RdbMsgid_FT = "RDB_FT";
        private readonly string m_RdbMsgid_FT_HIS = "RDB_FT_HIS";
        private string m_TODAY;

        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            XmlDocument responseXml = new XmlDocument();
            EaiResponse eaiRs = null;
            try
            {
                UcControler ucControler = new UcControler();
                UCCommonUtil ucComUtil = new UCCommonUtil();
                /******************************
                 * 剖析UCString並獲取必要資訊 *
                 ******************************/
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);
                Dictionary<string, string> ucHeadDic, ucBodyDic;
                UCCommonUtil.ParseUcToDic(ucControler, ucData, out ucHeadDic, out ucBodyDic);
                string customer_ID, start_Date, end_Date, account_ID;
                ucBodyDic.TryGetValue("4001", out customer_ID);   // 客戶號
                ucBodyDic.TryGetValue("4119", out start_Date);   // 開始日期
                ucBodyDic.TryGetValue("4120", out end_Date);   // 結束日期
                ucBodyDic.TryGetValue("4300", out account_ID);   // 帳號
                m_log.Info("AppXmlExecResult RunImpl.UC.4001(customer_ID)={0}&&4119(start_Date)={1}&&4120(end_Date)={2}&&4300(account_ID)={3}", customer_ID, start_Date, end_Date, account_ID);

                using (RDBCommQuery datesRdb = new RDBCommQuery())
                {
                    m_TODAY = datesRdb.GetT24Date(context, m_log);
                    if (string.IsNullOrEmpty(m_TODAY))
                    { throw new ApplicationException("Get T24Dates Error!"); }
                    m_log.Info("T24 CurrentDate : [{0}]", m_TODAY);
                }

#if func
                List<ElecRcpt_TTFT_Info.ReturnFileContent> rfcLst = new List<ElecRcpt_TTFT_Info.ReturnFileContent>();
                Func<List<ElecRcpt_TTFT_Info.ReturnFileContent>> ttFunc = () =>
                {
                    var recordList_TT = GetRecordList_TT(context, txID, customer_ID, account_ID, start_Date, end_Date);
                    return recordList_TT != null ? GetReturnFileContent_TT(recordList_TT) : new List<ElecRcpt_TTFT_Info.ReturnFileContent>();
                };
                IAsyncResult ttAR = ttFunc.BeginInvoke(null, null);
                Func<List<ElecRcpt_TTFT_Info.ReturnFileContent>> ftFunc = () =>
                {
                    var recordList_FT = GetRecordList_FT(context, txID, customer_ID, account_ID, start_Date, end_Date);
                    return recordList_FT != null ? GetReturnFileContent_FT(recordList_FT) : new List<ElecRcpt_TTFT_Info.ReturnFileContent>();
                };
                IAsyncResult ftAR = ftFunc.BeginInvoke(null, null);
                rfcLst.AddRange(ttFunc.EndInvoke(ttAR));
                rfcLst.AddRange(ftFunc.EndInvoke(ftAR));
#else
                List<ElecRcpt_TTFT_Info.ReturnFileContent> rfcLst = new List<ElecRcpt_TTFT_Info.ReturnFileContent>();
                var recordList_TT = GetRecordList_TT(context, txID, customer_ID, account_ID, start_Date, end_Date);
                List<ElecRcpt_TTFT_Info.ReturnFileContent> fc_TT = recordList_TT != null ? GetReturnFileContent_TT(recordList_TT) : new List<ElecRcpt_TTFT_Info.ReturnFileContent>();
                var recordList_FT = GetRecordList_FT(context, txID, customer_ID, account_ID, start_Date, end_Date);
                List<ElecRcpt_TTFT_Info.ReturnFileContent> fc_FT = recordList_FT != null ? GetReturnFileContent_FT(recordList_FT) : new List<ElecRcpt_TTFT_Info.ReturnFileContent>();
                rfcLst.AddRange(fc_TT);
                rfcLst.AddRange(fc_FT);
#endif
                rfcLst = rfcLst.OrderBy(r => r.TxnDate).ThenBy(r => r.TxnTime).ThenBy(r => r.STMTNO).ToList();
                var fileContentLst = CreateFileContent(rfcLst, txID);
                ucControler.CreateEnqFileToUC(fileContentLst, true);


                //Dictionary<string, string> totalDic = new Dictionary<string, string>();
                //totalDic.Add("2028", "CO1M0000");
                //totalDic.Add("zzzx", ucControler.enqFileName);//文件名
                //totalDic.Add("4305", fileContentLst.Count.ToString());//總筆數
                //string rsString = ucComUtil.GetRsStringFromRqDic(ucHeadDic, ucBodyDic, totalDic);
                string rsString = fileContentLst[0].ToString();

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);
            }
            catch (Exception ex)
            {
                eaiRs = EaiResponse.GetInstance(false);
                eaiRs.SetEaiError(eaiRs.EaiErrCode, ex.ToString(), "");
                responseXml = TransformCommMsg("9999", "Error", ex.ToString(), "");
                m_log.ErrorException("Error executing Run():" + ex.ToString(), ex);
            }
            finally
            {
                m_log.Debug("Run end<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
            }

            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }





        private List<ElecRcpt_TTFT_Info.ReturnFileContent> GetReturnFileContent_TT(List<Record> dsgsdg)
        {
            List<ElecRcpt_TTFT_Info.ReturnFileContent> rfcLst = new List<ElecRcpt_TTFT_Info.ReturnFileContent>();
            foreach (var live in dsgsdg)
            {
                var xmlrecord = live.XMLRECORD as ElecRcpt_TTFT_Info.TT_XMLRECORD;
                ElecRcpt_TTFT_Info.ReturnFileContent rfc = new ElecRcpt_TTFT_Info.ReturnFileContent();
                rfc.TxnDate = xmlrecord.Y_VALUE_DATE_1;
                rfc.TxnTime = xmlrecord.Y_DATE_TIME.Substring(xmlrecord.Y_DATE_TIME.Length - 4) + "00";
                rfc.TxnAmt = xmlrecord.Y_AMOUNT_LOCAL_1;
                rfc.Channel = "02";
                rfc.PayerAcct = xmlrecord.Y_ACCOUNT_1;
                rfc.PayerName = xmlrecord.Y_ACCT_1_TITLE_1 + xmlrecord.Y_ACCT_1_TITLE_2;
                rfc.PayeeAcct = xmlrecord.Y_ACCOUNT_2;
                rfc.PayeeName = xmlrecord.Y_ACCT_2_TITLE_1 + xmlrecord.Y_ACCT_2_TITLE_2; ;
                rfc.TxnType = "0";
                rfc.TxnSerNo = xmlrecord.Y_TT_RECID.Split(';')[0];


                rfc.PayerBankNo = xmlrecord.Y_ACCT_1_COMP_CODE;
                rfc.PayerBankName = xmlrecord.Y_ACCT_1_COMP_NAME;
                rfc.PayeeBankNo = xmlrecord.Y_ACCT_2_COMP_CODE;
                rfc.PayeeBankName = xmlrecord.Y_ACCT_2_COMP_NAME;
                rfc.Currency = xmlrecord.Y_CURRENCY_1;
                rfc.ChargeAmt = string.IsNullOrEmpty(xmlrecord.Y_CHRG_AMT_LOCAL) ?
                                "0.00" :
                                xmlrecord.Y_CHRG_AMT_LOCAL.Substring(3).Trim();
                string narrative_1 = RDBUtil.GetFieldString(xmlrecord.Y_NARRATIVE_1, true);
                rfc.Narrative = narrative_1;
                rfc.Remarks = narrative_1;
                rfc.VerCode = xmlrecord.Y_STMT_NO.Substring(11, 4);

                rfc.STMTNO = xmlrecord.Y_STMT_NO;
                rfc.PrintCount = rfc.Channel == "02" ? "1" : null;
                rfcLst.Add(rfc);
            }
            return rfcLst;
        }
        private List<ElecRcpt_TTFT_Info.ReturnFileContent> GetReturnFileContent_FT(List<Record> dsgsdg)
        {
            List<ElecRcpt_TTFT_Info.ReturnFileContent> rfcLst = new List<ElecRcpt_TTFT_Info.ReturnFileContent>();
            foreach (var live in dsgsdg)
            {
                var xmlrecord = live.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD;
                ElecRcpt_TTFT_Info.ReturnFileContent rfc = new ElecRcpt_TTFT_Info.ReturnFileContent();
                rfc.TxnDate = xmlrecord.Y_DEBIT_VALUE_DATE;
                rfc.TxnTime = xmlrecord.Y_DATE_TIME.Substring(xmlrecord.Y_DATE_TIME.Length - 4) + "00";
                rfc.TxnAmt = xmlrecord.Y_DEBIT_AMOUNT;
                rfc.Channel = xmlrecord.Y_L_TRANS_GATE == "CNAPS" ? "05" : xmlrecord.Y_L_TRANS_GATE == "CIB" ? "03" : (xmlrecord.Y_L_TRANS_GATE == "BRANCH" || string.IsNullOrEmpty(xmlrecord.Y_L_TRANS_GATE)) ? "02" : null;
                rfc.TxnSerNo = xmlrecord.Y_FT_RECID.Split(';')[0];
                rfc.Currency = xmlrecord.Y_DEBIT_CURRENCY;
                rfc.ChargeAmt = string.IsNullOrEmpty(xmlrecord.Y_TOTAL_CHARGE_AMT) ?
                                "0.00" :
                                xmlrecord.Y_TOTAL_CHARGE_AMT.Substring(3).Trim();
                string c_remark = RDBUtil.GetFieldString(xmlrecord.Y_C_REMARK, true);
                rfc.Narrative = string.IsNullOrEmpty(c_remark) ? xmlrecord.Y_DEBIT_THEIR_REF : c_remark;
                rfc.Remarks = xmlrecord.Y_C_REMARKS;
                rfc.VerCode = xmlrecord.Y_STMT_NOS.Substring(11, 4);

                rfc.STMTNO = xmlrecord.Y_STMT_NOS;
                if (xmlrecord.Y_TRANSACTION_TYPE == "AC")
                {
                    if (xmlrecord.Y_L_TRANS_GATE == "CIB")
                    {
                        rfc.PayerAcct = xmlrecord.Y_DEBIT_ACCT_NO;
                        rfc.PayerName = xmlrecord.Y_DEBIT_ACCT_TITLE_1 + xmlrecord.Y_DEBIT_ACCT_TITLE_2;
                        rfc.PayerBankNo = xmlrecord.Y_DEBIT_COMPANY_CODE;
                        rfc.PayerBankName = xmlrecord.Y_DEBIT_COMPANY_NAME;
                        rfc.PayeeName = xmlrecord.Y_C_PAYEE_NAME;
                        if (string.IsNullOrEmpty(xmlrecord.Y_L_IB_CRT_B))
                        {
                            rfc.PayeeAcct = xmlrecord.Y_CREDIT_ACCT_NO;
                            rfc.TxnType = "0";
                            rfc.PayeeBankNo = xmlrecord.Y_CREDIT_COMP_CODE;
                            rfc.PayeeBankName = xmlrecord.Y_CREDIT_COMP_NAME;
                        }
                        else
                        {
                            rfc.PayeeAcct = xmlrecord.Y_C_PAYEE_ACCT_NO;
                            rfc.TxnType = "1";
                            rfc.PayeeBankNo = xmlrecord.Y_L_IB_CRT_B;
                            rfc.PayeeBankName = xmlrecord.Y_L_IB_CRT_B_NAME;
                        }
                    }
                    else if (xmlrecord.Y_L_TRANS_GATE == "BRANCH" || xmlrecord.Y_L_TRANS_GATE == "CNAPS")
                    {
                        //判斷是來帳還是往帳

                        string c_in_out_type = xmlrecord.Y_C_IN_OUT_TYPE;
                        
                        rfc.PayerAcct = xmlrecord.Y_C_PAYER_ACCT_NO;
                        rfc.PayerName = xmlrecord.Y_C_PAYER_NAME;
                        rfc.PayeeAcct = xmlrecord.Y_C_PAYEE_ACCT_NO;
                        rfc.PayeeName = xmlrecord.Y_C_PAYEE_NAME;


                        //當往帳時，付款人行名抓實際開戶行；當來帳時，收款人行名抓實際開戶行
                        switch (c_in_out_type)
                        {
                            case "OUT":
                                rfc.PayerBankNo = xmlrecord.Y_DEBIT_COMPANY_CODE;
                                rfc.PayerBankName = xmlrecord.Y_DEBIT_COMPANY_NAME;
                                rfc.PayeeBankNo = xmlrecord.Y_L_IB_CRT_B;
                                rfc.PayeeBankName = xmlrecord.Y_L_ESCN_IB_BK_NM;
                                break;
                            case "IN":
                                rfc.PayerBankNo = xmlrecord.Y_L_OR_BANK_NO;
                                rfc.PayerBankName = xmlrecord.Y_L_OR_BANK_NM;
                                rfc.PayeeBankNo = xmlrecord.Y_CREDIT_COMP_CODE;
                                rfc.PayeeBankName = xmlrecord.Y_CREDIT_COMP_NAME;
                                break;
                            default:                          
                                rfc.PayerBankNo = xmlrecord.Y_L_OR_BANK_NO;
                                rfc.PayerBankName = xmlrecord.Y_L_OR_BANK_NM;
                                rfc.PayeeBankNo = xmlrecord.Y_L_IB_CRT_B;
                                rfc.PayeeBankName = xmlrecord.Y_L_ESCN_IB_BK_NM;
                                break;
                        }
                        rfc.TxnType = "1";
                    }
                    else
                    {
                        rfc.PayerAcct = xmlrecord.Y_DEBIT_ACCT_NO;
                        rfc.PayerName = xmlrecord.Y_DEBIT_ACCT_TITLE_1 + xmlrecord.Y_DEBIT_ACCT_TITLE_2;
                        rfc.PayerBankNo = xmlrecord.Y_DEBIT_COMPANY_CODE;
                        rfc.PayerBankName = xmlrecord.Y_DEBIT_COMPANY_NAME;
                        rfc.PayeeAcct = xmlrecord.Y_CREDIT_ACCT_NO;
                        rfc.PayeeName = xmlrecord.Y_CREDIT_ACCT_TITLE_1 + xmlrecord.Y_CREDIT_ACCT_TITLE_2;
                        rfc.PayeeBankNo = xmlrecord.Y_CREDIT_COMP_CODE;
                        rfc.PayeeBankName = xmlrecord.Y_CREDIT_COMP_NAME;
                        rfc.TxnType = "0";
                    }
                }
                else if (xmlrecord.Y_TRANSACTION_TYPE == "ACRI")
                {
                    rfc.PayerAcct = xmlrecord.Y_C_PAYER_ACCT_NO;
                    rfc.PayerName = xmlrecord.Y_C_PAYER_NAME;
                    rfc.TxnAmt = xmlrecord.Y_CREDIT_AMOUNT;
                    rfc.PayerBankNo = xmlrecord.Y_L_INIT_BANK_NO;
                    rfc.PayerBankName = xmlrecord.Y_L_INIT_BANK_NM;
                    rfc.PayeeAcct = xmlrecord.Y_CREDIT_ACCT_NO;
                    rfc.PayeeName = xmlrecord.Y_C_PAYEE_NAME;
                    rfc.PayeeBankNo = xmlrecord.Y_CREDIT_COMP_CODE;
                    rfc.PayeeBankName = xmlrecord.Y_CREDIT_COMP_NAME;
                    rfc.Remarks = RDBUtil.GetFieldString(xmlrecord.Y_PAYMENT_DETAILS, true);
                    rfc.TxnType = "1";
                }
                else if (xmlrecord.Y_TRANSACTION_TYPE == "ACRO")
                {
                    rfc.PayerAcct = xmlrecord.Y_DEBIT_ACCT_NO;
                    rfc.PayerName = xmlrecord.Y_C_PAYER_NAME;
                    rfc.PayerBankNo = xmlrecord.Y_DEBIT_COMPANY_CODE;
                    rfc.PayerBankName = xmlrecord.Y_DEBIT_COMPANY_NAME;
                    rfc.PayeeAcct = xmlrecord.Y_C_PAYEE_ACCT_NO;
                    rfc.PayeeName = xmlrecord.Y_C_PAYEE_NAME;
                    rfc.PayeeBankNo = xmlrecord.Y_L_IB_CRT_B;
                    rfc.PayeeBankName = xmlrecord.Y_L_ESCN_IB_BK_NM;
                    rfc.Remarks = RDBUtil.GetFieldString(xmlrecord.Y_PAYMENT_DETAILS, true);
                    rfc.TxnType = "1";
                }
                rfc.PrintCount = rfc.Channel == "02" ? "1" : null;
                rfcLst.Add(rfc);
            }
            return rfcLst;
        }


        private List<string> CreateFileContent(List<ElecRcpt_TTFT_Info.ReturnFileContent> oo, string txid)
        {
            List<string> dataLst = new List<string>();
            if (txid == m_2040501_txid)
            {
                foreach (var x in oo)
                {
                    dataLst.Add(
                    string.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}",
                                    x.TxnDate,
                                    x.TxnTime,
                                    x.TxnAmt,
                                    x.Channel,
                                    x.PayerAcct,
                                    x.PayerName,
                                    x.PayeeAcct,
                                    x.PayeeName,
                                    x.TxnType,
                                    x.TxnSerNo));

                }
            }
            else if (txid == m_2040506_txid)
            {
                foreach (var x in oo)
                {
                    dataLst.Add(
                    string.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}|{10}|{11}|{12}|{13}|{14}|{15}|{16}|{17}|{18}|{19}|{20}",
                                    x.TxnDate,
                                    x.TxnTime,
                                    x.Channel,
                                    x.TxnType,
                                    x.PayerAcct,
                                    x.PayerName,
                                    x.TxnAmt,
                                    x.PayerBankNo,
                                    x.PayerBankName,
                                    x.PayeeAcct,
                                    x.PayeeName,
                                    x.PayeeBankNo,
                                    x.PayeeBankName,
                                    x.Currency,
                                    x.ChargeAmt,
                                    x.Narrative,
                                    x.Remarks,
                                    x.TxnSerNo,
                                    x.VerCode,
                                    x.PrintMan,
                                    x.PrintCount
                                    ));
                }
            }
            return dataLst;
        }




        #region Business
        #region TT
        private List<Record> GetRecordList_TT(EaiContext context, string txid, string customerID, string acctNo, string startDate, string endDate)
        {
            List<Record> recordLst = new List<Record>();
            string today = m_TODAY; // DateTime.Now.ToString("yyyyMMdd");
            m_log.Info("T24 Date:[{0}] UC StartDate:[{1}] UC EndDate:[{2}]", today, startDate, endDate);
            //startDate < today and endDate >= today
            if (string.Compare(startDate, today) < 0 && (string.Compare(endDate, today) == 0 || string.Compare(endDate, today) > 0))
            {
                m_log.Info("Query TELLER LIVE HIS");
#if func
                Func<List<Record>> ttLiveFunc = () =>
                { return GetRecordList_TT_Live(context, txid, customerID, acctNo, startDate, endDate); };
                IAsyncResult ttLiveAR = ttLiveFunc.BeginInvoke(null, null);
                Func<List<Record>> ttHisFunc = () =>
                { return GetRecordList_TT_His(context, txid, customerID, acctNo, startDate, endDate); };
                IAsyncResult ttHisAR = ttHisFunc.BeginInvoke(null, null);
                recordLst.AddRange(ttLiveFunc.EndInvoke(ttLiveAR));
                recordLst.AddRange(ttHisFunc.EndInvoke(ttHisAR));
#else
                recordLst.AddRange(GetRecordList_TT_Live(context, txid, customerID, acctNo, startDate, endDate));
                recordLst.AddRange(GetRecordList_TT_His(context, txid, customerID, acctNo, startDate, endDate));
#endif
            }
            //startDate = today
            else if (string.Compare(startDate, today) == 0)
            {
                m_log.Info("Query TELLER LIVE");
                recordLst.AddRange(GetRecordList_TT_Live(context, txid, customerID, acctNo, startDate, endDate));
            }
            //endDate < today
            else if (string.Compare(endDate, today) < 0)
            {
                m_log.Info("Query TELLER HIS");
                recordLst.AddRange(GetRecordList_TT_His(context, txid, customerID, acctNo, startDate, endDate));
            }
            return recordLst;
        }
        private List<Record> GetRecordList_TT_Live(EaiContext context, string txid, string customerID, string acctNo, string startDate, string endDate)
        {
            QueryInfo qi = GetQueryInfo_TT_Live(customerID, acctNo, startDate, endDate);
            List<TransColumn> transColLst = GetTransColumnLst_TT();
            List<string> rcLst = transColLst.Select(tc => string.IsNullOrEmpty(tc.NewColNm) ? tc.Column : tc.NewColNm).Distinct().ToList();
            rcLst.Add(ElecRcpt_TTFT_Info.NARRATIVE_1);
            T24QueryInfo t24QI = new T24QueryInfo()
            {
                TableName = "FBNK_TELLER",
                QInfo = qi,
                TransColumnLst = transColLst,
                ReturnColumnLst = rcLst
            };
            //var postResult = RDBUtil.PostToRDB(eaiUrl, "Test_JSON", t24QI.TableName, t24QI);
            var msgContent_Tt = RDBUtil.GetRdbMsgContent(m_RdbMsgid_TT, t24QI.TableName.Replace('#', '_'), t24QI);
            var ttResult = SendMsgToEAIProcess(context, msgContent_Tt, m_RdbMsgid_TT);
            List<Record> tt_LiveRecordLst = RDBUtil.GetRdbRsList<ElecRcpt_TTFT_Info.TT_XMLRECORD>(ttResult.ResponseXml.InnerXml);
            return tt_LiveRecordLst;
        }
        private List<Record> GetRecordList_TT_His(EaiContext context, string txid, string customerID, string acctNo, string startDate, string endDate)
        {
            QueryInfo qi = GetQueryInfo_TT_His(customerID, acctNo, startDate, endDate);
            List<TransColumn> transColLst = GetTransColumnLst_TT();
            List<string> rcLst = transColLst.Select(tc => string.IsNullOrEmpty(tc.NewColNm) ? tc.Column : tc.NewColNm).Distinct().ToList();
            rcLst.Add(ElecRcpt_TTFT_Info.NARRATIVE_1);
            T24QueryInfo t24QI = new T24QueryInfo()
            {
                TableName = "FBNK_TELLER#HIS",
                QInfo = qi,
                TransColumnLst = transColLst,
                ReturnColumnLst = rcLst
            };
            //var postResult = RDBUtil.PostToRDB(eaiUrl, "Test_JSON", t24QI.TableName, t24QI);
            var msgContent_Tt_His = RDBUtil.GetRdbMsgContent(m_RdbMsgid_TT_HIS, t24QI.TableName.Replace('#', '_'), t24QI);
            var ttHisResult = SendMsgToEAIProcess(context, msgContent_Tt_His, m_RdbMsgid_TT_HIS);
            List<Record> tt_HisRecordLst = RDBUtil.GetRdbRsList<ElecRcpt_TTFT_Info.TT_XMLRECORD>(ttHisResult.ResponseXml.InnerXml);
            return tt_HisRecordLst;
        }
        private QueryInfo GetQueryInfo_TT_Live(string customerID, string acctNo, string startDate, string endDate)
        {
            QueryInfo qi = GetQueryInfo_TT(customerID, acctNo);

            string today = m_TODAY; // DateTime.Now.ToString("yyyyMMdd");
            var fc_Value_Date = new FieldCriteria() { FieldNm = "VALUE.DATE.1", Operator = "=", Value = today };
            qi.FieldCriLst.Add(fc_Value_Date);
            return qi;
        }
        private QueryInfo GetQueryInfo_TT_His(string customerID, string acctNo, string startDate, string endDate)
        {
            QueryInfo qi = GetQueryInfo_TT(customerID, acctNo);

            var fc_Value_Date_1 = new FieldCriteria() { FieldNm = "VALUE.DATE.1", Operator = ">=", Value = startDate };
            var fc_Value_Date_2 = new FieldCriteria() { FieldNm = "VALUE.DATE.1", Operator = "<=", Value = endDate };
            var fc_Record_Status = new FieldCriteria() { FieldNm = "RECORD.STATUS", Operator = "=", Value = "MAT" };
            qi.FieldCriLst.Add(fc_Value_Date_1);
            qi.FieldCriLst.Add(fc_Value_Date_2);
            qi.FieldCriLst.Add(fc_Record_Status);
            return qi;
        }
        private QueryInfo GetQueryInfo_TT(string customerID, string acctNo)
        {
            QueryInfo qinfo = new QueryInfo();
            qinfo.AON = "AND";
            qinfo.FieldCriLst = new List<FieldCriteria>();
            qinfo.SubQueryInfoLst = new List<QueryInfo>();
            {//Customer
                var fc_Customer_1 = new FieldCriteria() { FieldNm = "CUSTOMER.1", Operator = "=", Value = customerID };
                var fc_Customer_2 = new FieldCriteria() { FieldNm = "CUSTOMER.2", Operator = "=", Value = customerID };
                var fcLst_Customer = new List<FieldCriteria>() { fc_Customer_1, fc_Customer_2 };
                QueryInfo qu_Customer = new QueryInfo() { AON = "OR", FieldCriLst = fcLst_Customer };
                qinfo.SubQueryInfoLst.Add(qu_Customer);
            }
            if (!string.IsNullOrEmpty(acctNo))
            {//Account
                var fc_Account_1 = new FieldCriteria() { FieldNm = "ACCOUNT.1", Operator = "=", Value = acctNo };
                var fc_Account_2 = new FieldCriteria() { FieldNm = "ACCOUNT.2", Operator = "=", Value = acctNo };
                var fcLst_Account = new List<FieldCriteria>() { fc_Account_1, fc_Account_2 };
                QueryInfo qu_Account = new QueryInfo() { AON = "OR", FieldCriLst = fcLst_Account };
                qinfo.SubQueryInfoLst.Add(qu_Account);
            }
            {//TRANSACTION.CODE
                var fc_Transaction_Code = new FieldCriteria() { FieldNm = "TRANSACTION.CODE", Operator = "=", Value = "135" };
                qinfo.FieldCriLst.Add(fc_Transaction_Code);
            }
            return qinfo;
        }
        private List<TransColumn> GetTransColumnLst_TT()
        {
            var tcLst = new List<TransColumn>();

            var tcTt_Recid = new TransColumn();
            tcTt_Recid.Column = "@ID";
            tcTt_Recid.NewColNm = ElecRcpt_TTFT_Info.Y_TT_RECID;
            var tcTt_Recid_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcTt_Recid.ColMapLst = new List<ColumnMapping>() { tcTt_Recid_CM_1 };
            tcLst.Add(tcTt_Recid);

            var tcValue_Date_1 = new TransColumn(); // ---------------------
            tcValue_Date_1.Column = "VALUE.DATE.1";
            tcValue_Date_1.NewColNm = ElecRcpt_TTFT_Info.Y_VALUE_DATE_1;
            var tcValue_Date_1_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcValue_Date_1.ColMapLst = new List<ColumnMapping>() { tcValue_Date_1_CM_1 };
            tcLst.Add(tcValue_Date_1);

            var tcDate_Time = new TransColumn();
            tcDate_Time.Column = "DATE.TIME";
            tcDate_Time.NewColNm = ElecRcpt_TTFT_Info.Y_DATE_TIME;
            var tcDate_Time_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcDate_Time.ColMapLst = new List<ColumnMapping>() { tcDate_Time_CM_1 };
            tcLst.Add(tcDate_Time);

            var tcAmount_Local_1 = new TransColumn(); // ---------------------
            tcAmount_Local_1.Column = "AMOUNT.LOCAL.1";
            tcAmount_Local_1.NewColNm = ElecRcpt_TTFT_Info.Y_AMOUNT_LOCAL_1;
            var tcAmount_Local_1_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcAmount_Local_1.ColMapLst = new List<ColumnMapping>() { tcAmount_Local_1_CM_1 };
            tcLst.Add(tcAmount_Local_1);

            var tcAccount_1 = new TransColumn(); // ---------------------
            tcAccount_1.Column = "ACCOUNT.1";
            tcAccount_1.NewColNm = ElecRcpt_TTFT_Info.Y_ACCOUNT_1;
            tcAccount_1.ColumnMp = "1";
            var tcAccount_1_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcAccount_1.ColMapLst = new List<ColumnMapping>() { tcAccount_1_CM_1 };
            tcLst.Add(tcAccount_1);

            var tcACCT_1_TITLE_1 = new TransColumn(); // ---------------------
            tcACCT_1_TITLE_1.Column = "ACCOUNT.1";
            tcACCT_1_TITLE_1.NewColNm = ElecRcpt_TTFT_Info.Y_ACCT_1_TITLE_1;
            tcACCT_1_TITLE_1.ColumnMp = "1";
            var tcACCT_1_TITLE_1_CM_1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "ACCOUNT.TITLE.1" };
            tcACCT_1_TITLE_1.ColMapLst = new List<ColumnMapping>() { tcACCT_1_TITLE_1_CM_1 };
            tcLst.Add(tcACCT_1_TITLE_1);

            var tcACCT_1_TITLE_2 = new TransColumn(); // ---------------------
            tcACCT_1_TITLE_2.Column = "ACCOUNT.1";
            tcACCT_1_TITLE_2.NewColNm = ElecRcpt_TTFT_Info.Y_ACCT_1_TITLE_2;
            tcACCT_1_TITLE_2.ColumnMp = "1";
            var tcACCT_1_TITLE_2_CM_1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "ACCOUNT.TITLE.2" };
            tcACCT_1_TITLE_2.ColMapLst = new List<ColumnMapping>() { tcACCT_1_TITLE_2_CM_1 };
            tcLst.Add(tcACCT_1_TITLE_2);

            var tcAccount_2 = new TransColumn(); // ---------------------
            tcAccount_2.Column = "ACCOUNT.2";
            tcAccount_2.NewColNm = ElecRcpt_TTFT_Info.Y_ACCOUNT_2;
            tcAccount_2.ColumnMp = "1";
            var tcAccount_2_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcAccount_2.ColMapLst = new List<ColumnMapping>() { tcAccount_2_CM_1 };
            tcLst.Add(tcAccount_2);

            var tcACCT_2_TITLE_1 = new TransColumn(); // ---------------------
            tcACCT_2_TITLE_1.Column = "ACCOUNT.2";
            tcACCT_2_TITLE_1.NewColNm = ElecRcpt_TTFT_Info.Y_ACCT_2_TITLE_1;
            tcACCT_2_TITLE_1.ColumnMp = "1";
            var tcACCT_2_TITLE_1_CM_1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "ACCOUNT.TITLE.1" };
            tcACCT_2_TITLE_1.ColMapLst = new List<ColumnMapping>() { tcACCT_2_TITLE_1_CM_1 };
            tcLst.Add(tcACCT_2_TITLE_1);

            var tcACCT_2_TITLE_2 = new TransColumn(); // ---------------------
            tcACCT_2_TITLE_2.Column = "ACCOUNT.2";
            tcACCT_2_TITLE_2.NewColNm = ElecRcpt_TTFT_Info.Y_ACCT_2_TITLE_2;
            tcACCT_2_TITLE_2.ColumnMp = "1";
            var tcACCT_2_TITLE_2_CM_1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "ACCOUNT.TITLE.2" };
            tcACCT_2_TITLE_2.ColMapLst = new List<ColumnMapping>() { tcACCT_2_TITLE_2_CM_1 };
            tcLst.Add(tcACCT_2_TITLE_2);



            //#region 2040506
            ////if (txid == "2040506")
            ////{
            var tcACCT_1_COMP_CODE = new TransColumn(); // ---------------------
            tcACCT_1_COMP_CODE.Column = "ACCOUNT.1";
            tcACCT_1_COMP_CODE.NewColNm = ElecRcpt_TTFT_Info.Y_ACCT_1_COMP_CODE;
            tcACCT_1_COMP_CODE.ColumnMp = "1";
            var tcACCT_1_COMP_CODE_CM_1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "CO.CODE" };
            var tcACCT_1_COMP_CODE_CM_2 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "C.CPS.CODE" };
            tcACCT_1_COMP_CODE.ColMapLst = new List<ColumnMapping>() { tcACCT_1_COMP_CODE_CM_1, tcACCT_1_COMP_CODE_CM_2 };
            tcLst.Add(tcACCT_1_COMP_CODE);

            var tcACCT_1_COMP_NAME = new TransColumn(); // ---------------------
            tcACCT_1_COMP_NAME.Column = "ACCOUNT.1";
            tcACCT_1_COMP_NAME.NewColNm = ElecRcpt_TTFT_Info.Y_ACCT_1_COMP_NAME;
            tcACCT_1_COMP_NAME.ColumnMp = "1";
            var tcACCT_1_COMP_NAME_CM_1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "CO.CODE" };
            var tcACCT_1_COMP_NAME_CM_2 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "COMPANY.NAME", TransColMp = "2" };
            tcACCT_1_COMP_NAME.ColMapLst = new List<ColumnMapping>() { tcACCT_1_COMP_NAME_CM_1, tcACCT_1_COMP_NAME_CM_2 };
            tcLst.Add(tcACCT_1_COMP_NAME);

            var tcACCT_2_COMP_CODE = new TransColumn(); // ---------------------
            tcACCT_2_COMP_CODE.Column = "ACCOUNT.2";
            tcACCT_2_COMP_CODE.NewColNm = ElecRcpt_TTFT_Info.Y_ACCT_2_COMP_CODE;
            tcACCT_2_COMP_CODE.ColumnMp = "1";
            var tcACCT_2_COMP_CODE_CM_1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "CO.CODE" };
            var tcACCT_2_COMP_CODE_CM_2 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "C.CPS.CODE" };
            tcACCT_2_COMP_CODE.ColMapLst = new List<ColumnMapping>() { tcACCT_2_COMP_CODE_CM_1, tcACCT_2_COMP_CODE_CM_2 };
            tcLst.Add(tcACCT_2_COMP_CODE);

            var tcACCT_2_COMP_NAME = new TransColumn(); // ---------------------
            tcACCT_2_COMP_NAME.Column = "ACCOUNT.2";
            tcACCT_2_COMP_NAME.NewColNm = ElecRcpt_TTFT_Info.Y_ACCT_2_COMP_NAME;
            tcACCT_2_COMP_NAME.ColumnMp = "1";
            var tcACCT_2_COMP_NAME_CM_1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "CO.CODE" };
            var tcACCT_2_COMP_NAME_CM_2 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "COMPANY.NAME", TransColMp = "2" };
            tcACCT_2_COMP_NAME.ColMapLst = new List<ColumnMapping>() { tcACCT_2_COMP_NAME_CM_1, tcACCT_2_COMP_NAME_CM_2 };
            tcLst.Add(tcACCT_2_COMP_NAME);

            var tcCURRENCY_1 = new TransColumn(); // ---------------------
            tcCURRENCY_1.Column = "CURRENCY.1";
            tcCURRENCY_1.NewColNm = ElecRcpt_TTFT_Info.Y_CURRENCY_1;
            var tcCurrency_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcCURRENCY_1.ColMapLst = new List<ColumnMapping>() { tcCurrency_CM_1 };
            tcLst.Add(tcCURRENCY_1);

            var tcCHRG_AMT_LOCAL = new TransColumn();
            tcCHRG_AMT_LOCAL.Column = "CHRG.AMT.LOCAL";
            tcCHRG_AMT_LOCAL.NewColNm = ElecRcpt_TTFT_Info.Y_CHRG_AMT_LOCAL;
            var tcCHRG_AMT_LOCAL_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcCHRG_AMT_LOCAL.ColMapLst = new List<ColumnMapping>() { tcCHRG_AMT_LOCAL_CM_1 };
            tcLst.Add(tcCHRG_AMT_LOCAL);

            //var tcNARRATIVE_1 = new TransColumn();
            //tcNARRATIVE_1.Column = "NARRATIVE.1";
            //tcNARRATIVE_1.NewColNm = ElecRcpt_TTFT_Info.Y_NARRATIVE_1;
            //var tcNARRATIVE_1_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            //tcNARRATIVE_1.ColMapLst = new List<ColumnMapping>() { tcNARRATIVE_1_CM_1 };
            //tcLst.Add(tcNARRATIVE_1);

            var tcSTMT_NO = new TransColumn();
            tcSTMT_NO.Column = "STMT.NO";
            tcSTMT_NO.NewColNm = ElecRcpt_TTFT_Info.Y_STMT_NO;
            tcSTMT_NO.ColumnMp = "1";
            var tcSTMT_NO_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcSTMT_NO.ColMapLst = new List<ColumnMapping>() { tcSTMT_NO_CM_1 };
            tcLst.Add(tcSTMT_NO);
            ////}
            //#endregion 2040506
            return tcLst;
        }
        #endregion TT
        #region FT
        private List<Record> GetRecordList_FT(EaiContext context, string txid, string customerID, string acctNo, string startDate, string endDate)
        {
            //要扣掉的FT
            m_log.Info("Query FUNDS.TRANSFER LIVE_CANCEL");
            List<Record> recordLstCancel = GetRecordList_FT_Live_Cancel(context, txid, customerID, acctNo, startDate, endDate);
            List<string> ftCancelLst = recordLstCancel.Select(f => (f.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_C_ORG_FT_REF_NO).ToList();

            List<Record> recordLst = new List<Record>();
            string today = m_TODAY; // DateTime.Now.ToString("yyyyMMdd");
            m_log.Info("T24 Date:[{0}] UC StartDate:[{1}] UC EndDate:[{2}]", today, startDate, endDate);
            //startDate < today and endDate >= today
            if (string.Compare(startDate, today) < 0 && (string.Compare(endDate, today) == 0 || string.Compare(endDate, today) > 0))
            {
                m_log.Info("Query FUNDS.TRANSFER LIVE HIS(&CANCEL)");
#if func
                Func<List<Record>> ftLiveFunc = () =>
                { return GetRecordList_FT_Live(context, txid, customerID, acctNo, startDate, endDate, ftCancelLst); };
                IAsyncResult ftLiveAR = ftLiveFunc.BeginInvoke(null, null);
                Func<List<Record>> ftHisFunc = () =>
                { return GetRecordList_FT_His(context, txid, customerID, acctNo, startDate, endDate, ftCancelLst); };
                IAsyncResult ftHisAR = ftHisFunc.BeginInvoke(null, null);
                recordLst.AddRange(ftLiveFunc.EndInvoke(ftLiveAR));
                recordLst.AddRange(ftHisFunc.EndInvoke(ftHisAR));
#else
                recordLst.AddRange(GetRecordList_FT_Live(context, txid, customerID, acctNo, startDate, endDate, ftCancelLst));
                recordLst.AddRange(GetRecordList_FT_His(context, txid, customerID, acctNo, startDate, endDate, ftCancelLst));
#endif
            }
            //startDate = today
            else if (string.Compare(startDate, today) == 0)
            {
                m_log.Info("Query FUNDS.TRANSFER LIVE");
                recordLst.AddRange(GetRecordList_FT_Live(context, txid, customerID, acctNo, startDate, endDate, ftCancelLst));
            }
            //endDate < today
            else if (string.Compare(endDate, today) < 0)
            {
                m_log.Info("Query FUNDS.TRANSFER HIS(&CANCEL)");
                recordLst.AddRange(GetRecordList_FT_His(context, txid, customerID, acctNo, startDate, endDate, ftCancelLst));
            }
            return recordLst;
        }
        private List<Record> GetRecordList_FT_Live_Cancel(EaiContext context, string txid, string customerID, string acctNo, string startDate, string endDate)
        {
            QueryInfo qi = GetQueryInfo_FT_Live_Cancel(customerID, acctNo, startDate, endDate);
            List<TransColumn> transColLst = GetTransColumnLst_FT_Live_Cancel();
            List<string> rcLst = transColLst.Select(tc => string.IsNullOrEmpty(tc.NewColNm) ? tc.Column : tc.NewColNm).Distinct().ToList();
            T24QueryInfo t24QI = new T24QueryInfo()
            {
                TableName = "FBNK_FUNDS_TRANSFER",
                QInfo = qi,
                TransColumnLst = transColLst,
                ReturnColumnLst = rcLst
            };
            //var postResult = RDBUtil.PostToRDB(eaiUrl, "Test_JSON", t24QI.TableName, t24QI);
            var msgContent_Ft = RDBUtil.GetRdbMsgContent(m_RdbMsgid_FT, t24QI.TableName.Replace('#', '_'), t24QI);
            var ftResult = SendMsgToEAIProcess(context, msgContent_Ft, m_RdbMsgid_FT);
            List<Record> ft_LiveCancelRecordLst = RDBUtil.GetRdbRsList<ElecRcpt_TTFT_Info.FT_XMLRECORD>(ftResult.ResponseXml.InnerXml);
            return ft_LiveCancelRecordLst;
        }
        private List<Record> GetRecordList_FT_Live(EaiContext context, string txid, string customerID, string acctNo, string startDate, string endDate, List<string> ftCancelLst)
        {
            QueryInfo qi = GetQueryInfo_FT_Live(customerID, acctNo, startDate, endDate);
            List<TransColumn> transColLst = GetTransColumnLst_FT();
            List<string> rcLst = transColLst.Select(tc => string.IsNullOrEmpty(tc.NewColNm) ? tc.Column : tc.NewColNm).Distinct().ToList();
            rcLst.Add(ElecRcpt_TTFT_Info.C_REMARK);
            rcLst.Add(ElecRcpt_TTFT_Info.PAYMENT_DETAILS);
            T24QueryInfo t24QI = new T24QueryInfo()
            {
                TableName = "FBNK_FUNDS_TRANSFER",
                QInfo = qi,
                TransColumnLst = transColLst,
                ReturnColumnLst = rcLst
            };
            //var postResult = RDBUtil.PostToRDB(eaiUrl, "Test_JSON", t24QI.TableName, t24QI);
            var msgContent_Ft = RDBUtil.GetRdbMsgContent(m_RdbMsgid_FT, t24QI.TableName.Replace('#', '_'), t24QI);
            var ftResult = SendMsgToEAIProcess(context, msgContent_Ft, m_RdbMsgid_FT);
            List<Record> ft_LiveRecordLst = RDBUtil.GetRdbRsList<ElecRcpt_TTFT_Info.FT_XMLRECORD>(ftResult.ResponseXml.InnerXml);
            List<Record> returnRecordLst = ft_LiveRecordLst.Where(r => !ftCancelLst.Contains(r.RECID)).ToList();
            return returnRecordLst;
        }
        private List<Record> GetRecordList_FT_His(EaiContext context, string txid, string customerID, string acctNo, string startDate, string endDate, List<string> ftCancelLst)
        {
            QueryInfo qi = GetQueryInfo_FT_His(customerID, acctNo, startDate, endDate);
            List<TransColumn> transColLst = GetTransColumnLst_FT();
            List<string> rcLst = transColLst.Select(tc => string.IsNullOrEmpty(tc.NewColNm) ? tc.Column : tc.NewColNm).Distinct().ToList();
            rcLst.Add(ElecRcpt_TTFT_Info.C_REMARK);
            rcLst.Add(ElecRcpt_TTFT_Info.PAYMENT_DETAILS);
            T24QueryInfo t24QI = new T24QueryInfo()
            {
                TableName = "FBNK_FUNDS_TRANSFER#HIS",
                QInfo = qi,
                TransColumnLst = transColLst,
                ReturnColumnLst = rcLst
            };
            //var postResult = RDBUtil.PostToRDB(eaiUrl, "Test_JSON", t24QI.TableName.Replace('#', '_'), t24QI);
            var msgContent_FtHis = RDBUtil.GetRdbMsgContent(m_RdbMsgid_FT_HIS, t24QI.TableName.Replace('#', '_'), t24QI);
            var ftHisResult = SendMsgToEAIProcess(context, msgContent_FtHis, m_RdbMsgid_FT_HIS);
            List<Record> ft_HisAllRecordLst = RDBUtil.GetRdbRsList<ElecRcpt_TTFT_Info.FT_XMLRECORD>(ftHisResult.ResponseXml.InnerXml);
            IEnumerable<Record> ft_HisCancelRecordLst = ft_HisAllRecordLst.Where(r => !string.IsNullOrEmpty((r.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_C_ORG_FT_REF_NO));
            List<string> ftHisCancelLst = ft_HisCancelRecordLst.Select(r => (r.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_C_ORG_FT_REF_NO).ToList();
            List<Record> ft_HisRecordLst = ft_HisAllRecordLst.Where(r => string.IsNullOrEmpty((r.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_C_ORG_FT_REF_NO))
                                                             .Where(r => !ftCancelLst.Contains(r.RECID.Split(';')[0]))
                                                             .Where(r => !ftHisCancelLst.Contains(r.RECID.Split(';')[0]))
                                                             .Where(r => string.Compare((r.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_DEBIT_VALUE_DATE, endDate) <= 0)
                                                             .Where(r => (r.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_TRANSACTION_TYPE == "ACRO" ||
                                                                         (r.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_TRANSACTION_TYPE == "ACRI" ||
                                                                         ((r.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_TRANSACTION_TYPE == "AC" && ((r.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_L_TRANS_GATE != "" ||
                                                                                                                                                        (r.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_L_TRANS_GATE != "AR" ||
                                                                                                                                                        (r.XMLRECORD as ElecRcpt_TTFT_Info.FT_XMLRECORD).Y_C_VER_NAME == "FUNDS.TRANSFER,ESCN.ACCT.TFR.FCY"
                                                                                                                                                       )
                                                                        )).ToList();


            return ft_HisRecordLst;
        }
        private QueryInfo GetQueryInfo_FT_Live_Cancel(string customerID, string acctNo, string startDate, string endDate)
        {
            string today = m_TODAY; // DateTime.Now.ToString("yyyyMMdd");
            QueryInfo qi = GetQueryInfo_FT_M(customerID, acctNo);
            FieldCriteria fc_Value_Date = new FieldCriteria() { FieldNm = "DEBIT.VALUE.DATE", Operator = "=", Value = today };
            FieldCriteria fc_Org_Ft_Ref = new FieldCriteria() { FieldNm = "C.ORG.FT.REF.NO", Operator = "!=", Value = "" };
            qi.FieldCriLst.Add(fc_Value_Date);
            qi.FieldCriLst.Add(fc_Org_Ft_Ref);
            return qi;
        }
        private QueryInfo GetQueryInfo_FT_Live(string customerID, string acctNo, string startDate, string endDate)
        {
            string today = m_TODAY; // DateTime.Now.ToString("yyyyMMdd");
            QueryInfo qi = GetQueryInfo_FT_M(customerID, acctNo);
            FieldCriteria fc_Value_Date = new FieldCriteria() { FieldNm = "DEBIT.VALUE.DATE", Operator = "=", Value = today };
            FieldCriteria fc_Org_Ft_Ref = new FieldCriteria() { FieldNm = "C.ORG.FT.REF.NO", Operator = "=", Value = "" };
            qi.FieldCriLst.Add(fc_Value_Date);
            qi.FieldCriLst.Add(fc_Org_Ft_Ref);
            {
                QueryInfo qi_sub_1 = new QueryInfo() { FieldCriLst = new List<FieldCriteria>(), SubQueryInfoLst = new List<QueryInfo>() };
                qi_sub_1.AON = "OR";
                FieldCriteria fc_Transaction_Type_1 = new FieldCriteria() { FieldNm = "TRANSACTION.TYPE", Operator = "=", Value = "ACRO" };
                FieldCriteria fc_Transaction_Type_2 = new FieldCriteria() { FieldNm = "TRANSACTION.TYPE", Operator = "=", Value = "ACRI" };
                qi_sub_1.FieldCriLst.Add(fc_Transaction_Type_1);
                qi_sub_1.FieldCriLst.Add(fc_Transaction_Type_2);
                {
                    QueryInfo qi_sub_2 = new QueryInfo() { FieldCriLst = new List<FieldCriteria>(), SubQueryInfoLst = new List<QueryInfo>() };
                    qi_sub_2.AON = "AND";
                    FieldCriteria fc_Transaction_Type_3 = new FieldCriteria() { FieldNm = "TRANSACTION.TYPE", Operator = "=", Value = "AC" };
                    qi_sub_2.FieldCriLst.Add(fc_Transaction_Type_3);
                    {
                        QueryInfo qi_sub_3 = new QueryInfo() { FieldCriLst = new List<FieldCriteria>(), SubQueryInfoLst = new List<QueryInfo>() };
                        qi_sub_3.AON = "OR";
                        FieldCriteria fc_Trans_Gate_1 = new FieldCriteria() { FieldNm = "L.TRANS.GATE", Operator = "!=", Value = "" };
                        FieldCriteria fc_Trans_Gate_2 = new FieldCriteria() { FieldNm = "L.TRANS.GATE", Operator = "!=", Value = "AR" };
                        FieldCriteria fc_Ver_Name = new FieldCriteria() { FieldNm = "C.VER.NAME", Operator = "=", Value = "FUNDS.TRANSFER,ESCN.ACCT.TFR.FCY" };
                        qi_sub_3.FieldCriLst.Add(fc_Trans_Gate_1);
                        qi_sub_3.FieldCriLst.Add(fc_Trans_Gate_2);
                        qi_sub_3.FieldCriLst.Add(fc_Ver_Name);
                        qi_sub_2.SubQueryInfoLst.Add(qi_sub_3);
                    }
                    qi_sub_1.SubQueryInfoLst.Add(qi_sub_2);
                }
                qi.SubQueryInfoLst.Add(qi_sub_1);
            }
            return qi;
        }
        private QueryInfo GetQueryInfo_FT_His(string customerID, string acctNo, string startDate, string endDate)
        {
            string today = m_TODAY; // DateTime.Now.ToString("yyyyMMdd");
            QueryInfo qi = GetQueryInfo_FT_M(customerID, acctNo);
            FieldCriteria fc_Value_Date_1 = new FieldCriteria() { FieldNm = "DEBIT.VALUE.DATE", Operator = ">=", Value = startDate };
            FieldCriteria fc_Value_Date_2 = new FieldCriteria() { FieldNm = "DEBIT.VALUE.DATE", Operator = "<", Value = today };
            FieldCriteria fc_Record_Status = new FieldCriteria() { FieldNm = "RECORD.STATUS", Operator = "=", Value = "MAT" };
            qi.FieldCriLst.Add(fc_Value_Date_1);
            qi.FieldCriLst.Add(fc_Value_Date_2);
            qi.FieldCriLst.Add(fc_Record_Status);
            return qi;
        }
        private QueryInfo GetQueryInfo_FT_M(string customerID, string acctNo)
        {
            QueryInfo qinfo = new QueryInfo() { FieldCriLst = new List<FieldCriteria>(), SubQueryInfoLst = new List<QueryInfo>() };
            qinfo.AON = "AND";
            {//Customer
                var fc_Customer_1 = new FieldCriteria() { FieldNm = "DEBIT.CUSTOMER", Operator = "=", Value = customerID };
                var fc_Customer_2 = new FieldCriteria() { FieldNm = "CREDIT.CUSTOMER", Operator = "=", Value = customerID };
                var fcLst_Customer = new List<FieldCriteria>() { fc_Customer_1, fc_Customer_2 };
                QueryInfo qu_Customer = new QueryInfo() { AON = "OR", FieldCriLst = fcLst_Customer };
                qinfo.SubQueryInfoLst.Add(qu_Customer);
            }
            if (!string.IsNullOrEmpty(acctNo))
            {//Account
                var fc_Account_1 = new FieldCriteria() { FieldNm = "DEBIT.ACCT.NO", Operator = "=", Value = acctNo };
                var fc_Account_2 = new FieldCriteria() { FieldNm = "CREDIT.ACCT.NO", Operator = "=", Value = acctNo };
                var fcLst_Account = new List<FieldCriteria>() { fc_Account_1, fc_Account_2 };
                QueryInfo qu_Account = new QueryInfo() { AON = "OR", FieldCriLst = fcLst_Account };
                qinfo.SubQueryInfoLst.Add(qu_Account);
            }
            return qinfo;
        }




        private List<TransColumn> GetTransColumnLst_FT_Live_Cancel()
        {
            var tcLst = new List<TransColumn>();

            var tcC_ORG_FT_REF_NO = new TransColumn();
            tcC_ORG_FT_REF_NO.Column = "C.ORG.FT.REF.NO";
            tcC_ORG_FT_REF_NO.NewColNm = ElecRcpt_TTFT_Info.Y_C_ORG_FT_REF_NO;
            var tcC_ORG_FT_REF_NO_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_ORG_FT_REF_NO.ColMapLst = new List<ColumnMapping>() { tcC_ORG_FT_REF_NO_CM_1 };
            tcLst.Add(tcC_ORG_FT_REF_NO);

            return tcLst;
        }


        private List<TransColumn> GetTransColumnLst_FT()
        {
            var tcLst = new List<TransColumn>();

            var tcFt_Recid = new TransColumn();
            tcFt_Recid.Column = "@ID";
            tcFt_Recid.NewColNm = ElecRcpt_TTFT_Info.Y_FT_RECID;
            var tcFt_Recid_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcFt_Recid.ColMapLst = new List<ColumnMapping>() { tcFt_Recid_CM_1 };
            tcLst.Add(tcFt_Recid);

            var tcL_Trans_Gate = new TransColumn();
            tcL_Trans_Gate.Column = "L.TRANS.GATE";
            tcL_Trans_Gate.NewColNm = ElecRcpt_TTFT_Info.Y_L_TRANS_GATE;
            var tcL_Trans_Gate_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcL_Trans_Gate.ColMapLst = new List<ColumnMapping>() { tcL_Trans_Gate_CM_1 };
            tcLst.Add(tcL_Trans_Gate);

            var tcValue_Date = new TransColumn(); // ---------------------
            tcValue_Date.Column = "DEBIT.VALUE.DATE";
            tcValue_Date.NewColNm = ElecRcpt_TTFT_Info.Y_DEBIT_VALUE_DATE;
            var tcValue_Date_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcValue_Date.ColMapLst = new List<ColumnMapping>() { tcValue_Date_CM_1 };
            tcLst.Add(tcValue_Date);

            var tcDate_Time = new TransColumn();
            tcDate_Time.Column = "DATE.TIME";
            tcDate_Time.NewColNm = ElecRcpt_TTFT_Info.Y_DATE_TIME;
            var tcDate_Time_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcDate_Time.ColMapLst = new List<ColumnMapping>() { tcDate_Time_CM_1 };
            tcLst.Add(tcDate_Time);

            var tcDebit_Amount = new TransColumn(); // ---------------------
            tcDebit_Amount.Column = "DEBIT.AMOUNT";
            tcDebit_Amount.NewColNm = ElecRcpt_TTFT_Info.Y_DEBIT_AMOUNT;
            var tcDebit_Amount_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcDebit_Amount.ColMapLst = new List<ColumnMapping>() { tcDebit_Amount_CM_1 };
            tcLst.Add(tcDebit_Amount);

            var tcCredit_Amount = new TransColumn(); // ---------------------
            tcCredit_Amount.Column = "CREDIT.AMOUNT";
            tcCredit_Amount.NewColNm = ElecRcpt_TTFT_Info.Y_CREDIT_AMOUNT;
            var tcCredit_Amount_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcCredit_Amount.ColMapLst = new List<ColumnMapping>() { tcCredit_Amount_CM_1 };
            tcLst.Add(tcCredit_Amount);

            var tcDebit_Acct_No = new TransColumn(); // ---------------------
            tcDebit_Acct_No.Column = "DEBIT.ACCT.NO";
            tcDebit_Acct_No.NewColNm = ElecRcpt_TTFT_Info.Y_DEBIT_ACCT_NO;
            var tcDebit_Acct_No_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcDebit_Acct_No.ColMapLst = new List<ColumnMapping>() { tcDebit_Acct_No_CM_1 };
            tcLst.Add(tcDebit_Acct_No);

            //var tcAc_Recid = new TransColumn(); // ---------------------
            //tcAc_Recid.Column = "DEBIT.ACCT.NO";
            //tcAc_Recid.NewColNm = ElecRcpt_STMT_Info.Y_AC_RECID;
            //var tcAc_Recid_CM1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "@ID" };
            //tcAc_Recid.ColMapLst = new List<ColumnMapping>() { tcAc_Recid_CM1 };
            //tcLst.Add(tcAc_Recid);

            var tcDebit_Acct_Title_1 = new TransColumn();
            tcDebit_Acct_Title_1.Column = "DEBIT.ACCT.NO";
            tcDebit_Acct_Title_1.NewColNm = ElecRcpt_TTFT_Info.Y_DEBIT_ACCT_TITLE_1;
            var tcDebit_Acct_Title_1_CM1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "ACCOUNT.TITLE.1" };
            tcDebit_Acct_Title_1.ColMapLst = new List<ColumnMapping>() { tcDebit_Acct_Title_1_CM1 };
            tcLst.Add(tcDebit_Acct_Title_1);

            var tcDebit_Acct_Title_2 = new TransColumn();
            tcDebit_Acct_Title_2.Column = "DEBIT.ACCT.NO";
            tcDebit_Acct_Title_2.NewColNm = ElecRcpt_TTFT_Info.Y_DEBIT_ACCT_TITLE_2;
            var tcDebit_Acct_Title_2_CM1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "ACCOUNT.TITLE.2" };
            tcDebit_Acct_Title_2.ColMapLst = new List<ColumnMapping>() { tcDebit_Acct_Title_2_CM1 };
            tcLst.Add(tcDebit_Acct_Title_2);

            var tcCredit_Acct_No = new TransColumn();
            tcCredit_Acct_No.Column = "CREDIT.ACCT.NO";
            tcCredit_Acct_No.NewColNm = ElecRcpt_TTFT_Info.Y_CREDIT_ACCT_NO;
            var tcCredit_Acct_No_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcCredit_Acct_No.ColMapLst = new List<ColumnMapping>() { tcCredit_Acct_No_CM_1 };
            tcLst.Add(tcCredit_Acct_No);

            var tcCredit_Acct_Title_1 = new TransColumn();
            tcCredit_Acct_Title_1.Column = "CREDIT.ACCT.NO";
            tcCredit_Acct_Title_1.NewColNm = ElecRcpt_TTFT_Info.Y_CREDIT_ACCT_TITLE_1;
            var tcCredit_Acct_Title_1_CM_1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "ACCOUNT.TITLE.1" };
            tcCredit_Acct_Title_1.ColMapLst = new List<ColumnMapping>() { tcCredit_Acct_Title_1_CM_1 };
            tcLst.Add(tcCredit_Acct_Title_1);

            var tcCredit_Acct_Title_2 = new TransColumn();
            tcCredit_Acct_Title_2.Column = "CREDIT.ACCT.NO";
            tcCredit_Acct_Title_2.NewColNm = ElecRcpt_TTFT_Info.Y_CREDIT_ACCT_TITLE_2;
            var tcCredit_Acct_Title_2_CM_1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "ACCOUNT.TITLE.2" };
            tcCredit_Acct_Title_2.ColMapLst = new List<ColumnMapping>() { tcCredit_Acct_Title_2_CM_1 };
            tcLst.Add(tcCredit_Acct_Title_2);

            var tcC_Payee_Name = new TransColumn(); // ---------------------
            tcC_Payee_Name.Column = "C.PAYEE.NAME";
            tcC_Payee_Name.NewColNm = ElecRcpt_TTFT_Info.Y_C_PAYEE_NAME;
            var tcC_Payee_Name_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_Payee_Name.ColMapLst = new List<ColumnMapping>() { tcC_Payee_Name_CM_1 };
            tcLst.Add(tcC_Payee_Name);

            var tcC_Payee_Acct_No = new TransColumn();
            tcC_Payee_Acct_No.Column = "C.PAYEE.ACCT.NO";
            tcC_Payee_Acct_No.NewColNm = ElecRcpt_TTFT_Info.Y_C_PAYEE_ACCT_NO;
            var tcC_Payee_Acct_No_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_Payee_Acct_No.ColMapLst = new List<ColumnMapping>() { tcC_Payee_Acct_No_CM_1 };
            tcLst.Add(tcC_Payee_Acct_No);

            var tcC_Payer_Acct_No = new TransColumn();
            tcC_Payer_Acct_No.Column = "C.PAYER.ACCT.NO";
            tcC_Payer_Acct_No.NewColNm = ElecRcpt_TTFT_Info.Y_C_PAYER_ACCT_NO;
            var tcC_Payer_Acct_No_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_Payer_Acct_No.ColMapLst = new List<ColumnMapping>() { tcC_Payer_Acct_No_CM_1 };
            tcLst.Add(tcC_Payer_Acct_No);

            var tcC_Payer_Name = new TransColumn();
            tcC_Payer_Name.Column = "C.PAYER.NAME";
            tcC_Payer_Name.NewColNm = ElecRcpt_TTFT_Info.Y_C_PAYER_NAME;
            var tcC_Payer_Name_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_Payer_Name.ColMapLst = new List<ColumnMapping>() { tcC_Payer_Name_CM_1 };
            tcLst.Add(tcC_Payer_Name);

            var tcL_Ib_Crt_B = new TransColumn();
            tcL_Ib_Crt_B.Column = "L.IB.CRT.B";
            tcL_Ib_Crt_B.NewColNm = ElecRcpt_TTFT_Info.Y_L_IB_CRT_B;
            var tcL_Ib_Crt_B_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcL_Ib_Crt_B.ColMapLst = new List<ColumnMapping>() { tcL_Ib_Crt_B_CM_1 };
            tcLst.Add(tcL_Ib_Crt_B);

            var tcC_In_Out_Type = new TransColumn();
            tcC_In_Out_Type.Column = "C.IN.OUT.TYPE";
            tcC_In_Out_Type.NewColNm = ElecRcpt_TTFT_Info.Y_C_IN_OUT_TYPE;
            var tcC_In_Out_Type_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_In_Out_Type.ColMapLst = new List<ColumnMapping>() { tcC_In_Out_Type_CM_1 };
            tcLst.Add(tcC_In_Out_Type);

            #region 2040506
            //if (txid == "2040506")
            //{
            var tcDebit_Company_Code = new TransColumn(); // ---------------------
            tcDebit_Company_Code.Column = "DEBIT.COMP.CODE";
            tcDebit_Company_Code.NewColNm = ElecRcpt_TTFT_Info.Y_DEBIT_COMPANY_CODE;
            var tcDebit_Company_Code_CM_1 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "C.CPS.CODE" };
            tcDebit_Company_Code.ColMapLst = new List<ColumnMapping>() { tcDebit_Company_Code_CM_1, };
            tcLst.Add(tcDebit_Company_Code);

            var tcDebit_Company_Name = new TransColumn(); // ---------------------
            tcDebit_Company_Name.Column = "DEBIT.COMP.CODE";
            tcDebit_Company_Name.NewColNm = ElecRcpt_TTFT_Info.Y_DEBIT_COMPANY_NAME;
            var tcDebit_Company_Name_CM_1 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "COMPANY.NAME", TransColMp = "2" };
            tcDebit_Company_Name.ColMapLst = new List<ColumnMapping>() { tcDebit_Company_Name_CM_1 };
            tcLst.Add(tcDebit_Company_Name);

            var tcCredit_Comp_Code = new TransColumn();
            tcCredit_Comp_Code.Column = "CREDIT.COMP.CODE";
            tcCredit_Comp_Code.NewColNm = ElecRcpt_TTFT_Info.Y_CREDIT_COMP_CODE;
            var tcCredit_Comp_Code_CM_1 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "C.CPS.CODE" };
            tcCredit_Comp_Code.ColMapLst = new List<ColumnMapping>() { tcCredit_Comp_Code_CM_1 };
            tcLst.Add(tcCredit_Comp_Code);

            var tcCredit_Comp_Name = new TransColumn();
            tcCredit_Comp_Name.Column = "CREDIT.COMP.CODE";
            tcCredit_Comp_Name.NewColNm = ElecRcpt_TTFT_Info.Y_CREDIT_COMP_NAME;
            var tcCredit_Comp_Name_CM_1 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "COMPANY.NAME", TransColMp = "2" };
            tcCredit_Comp_Name.ColMapLst = new List<ColumnMapping>() { tcCredit_Comp_Name_CM_1 };
            tcLst.Add(tcCredit_Comp_Name);

            var tcL_Ib_Crt_B_Name = new TransColumn();
            tcL_Ib_Crt_B_Name.Column = "L.IB.CRT.B";
            tcL_Ib_Crt_B_Name.NewColNm = ElecRcpt_TTFT_Info.Y_L_IB_CRT_B_NAME;
            var tcL_Ib_Crt_B_Name_CM_1 = new ColumnMapping() { TransTb = "F_ESCN_FIN_BANK_CODE", TransCol = "DESCRIPTION" };
            tcL_Ib_Crt_B_Name.ColMapLst = new List<ColumnMapping>() { tcL_Ib_Crt_B_Name_CM_1 };
            tcLst.Add(tcL_Ib_Crt_B_Name);

            var tcL_Escn_Ib_Bk_Nm = new TransColumn();
            tcL_Escn_Ib_Bk_Nm.Column = "L.ESCN.IB.BK.NM";
            tcL_Escn_Ib_Bk_Nm.NewColNm = ElecRcpt_TTFT_Info.Y_L_ESCN_IB_BK_NM;
            var tcL_Escn_Ib_Bk_Nm_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcL_Escn_Ib_Bk_Nm.ColMapLst = new List<ColumnMapping>() { tcL_Escn_Ib_Bk_Nm_CM_1 };
            tcLst.Add(tcL_Escn_Ib_Bk_Nm);

            var tcL_Or_Bank_No = new TransColumn();
            tcL_Or_Bank_No.Column = "L.OR.BANK.NO";
            tcL_Or_Bank_No.NewColNm = ElecRcpt_TTFT_Info.Y_L_OR_BANK_NO;
            var tcL_Or_Bank_No_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcL_Or_Bank_No.ColMapLst = new List<ColumnMapping>() { tcL_Or_Bank_No_CM_1 };
            tcLst.Add(tcL_Or_Bank_No);

            var tcL_Or_Bank_Nm = new TransColumn();
            tcL_Or_Bank_Nm.Column = "L.OR.BANK.NM";
            tcL_Or_Bank_Nm.NewColNm = ElecRcpt_TTFT_Info.Y_L_OR_BANK_NM;
            var tcL_Or_Bank_Nm_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcL_Or_Bank_Nm.ColMapLst = new List<ColumnMapping>() { tcL_Or_Bank_Nm_CM_1 };
            tcLst.Add(tcL_Or_Bank_Nm);

            var tcL_Init_Bank_No = new TransColumn();
            tcL_Init_Bank_No.Column = "L.INIT.BANK.NO";
            tcL_Init_Bank_No.NewColNm = ElecRcpt_TTFT_Info.Y_L_INIT_BANK_NO;
            var tcL_Init_Bank_No_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcL_Init_Bank_No.ColMapLst = new List<ColumnMapping>() { tcL_Init_Bank_No_CM_1 };
            tcLst.Add(tcL_Init_Bank_No);

            var tcL_Init_Bank_Nm = new TransColumn();
            tcL_Init_Bank_Nm.Column = "L.INIT.BANK.NM";
            tcL_Init_Bank_Nm.NewColNm = ElecRcpt_TTFT_Info.Y_L_INIT_BANK_NM;
            var tcL_Init_Bank_Nm_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcL_Init_Bank_Nm.ColMapLst = new List<ColumnMapping>() { tcL_Init_Bank_Nm_CM_1 };
            tcLst.Add(tcL_Init_Bank_Nm);

            var tcCurrency = new TransColumn(); // ---------------------
            tcCurrency.Column = "DEBIT.CURRENCY";
            tcCurrency.NewColNm = ElecRcpt_TTFT_Info.Y_DEBIT_CURRENCY;
            var tcCurrency_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcCurrency.ColMapLst = new List<ColumnMapping>() { tcCurrency_CM_1 };
            tcLst.Add(tcCurrency);

            var tcTotal_Charge_Amt = new TransColumn();
            tcTotal_Charge_Amt.Column = "TOTAL.CHARGE.AMT";
            tcTotal_Charge_Amt.NewColNm = ElecRcpt_TTFT_Info.Y_TOTAL_CHARGE_AMT;
            var tcTotal_Charge_Amt_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcTotal_Charge_Amt.ColMapLst = new List<ColumnMapping>() { tcTotal_Charge_Amt_CM_1 };
            tcLst.Add(tcTotal_Charge_Amt);

            var tcDebit_Their_Ref = new TransColumn(); // ---------------------
            tcDebit_Their_Ref.Column = "DEBIT.THEIR.REF";
            tcDebit_Their_Ref.NewColNm = ElecRcpt_TTFT_Info.Y_DEBIT_THEIR_REF;
            var tcDebit_Their_Ref_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcDebit_Their_Ref.ColMapLst = new List<ColumnMapping>() { tcDebit_Their_Ref_CM_1 };
            tcLst.Add(tcDebit_Their_Ref);

            //var tcC_Remark = new TransColumn(); // ---------------------
            //tcC_Remark.Column = "C.REMARK";
            //tcC_Remark.NewColNm = ElecRcpt_TTFT_Info.Y_C_REMARK;
            //var tcC_Remark_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            //tcC_Remark.ColMapLst = new List<ColumnMapping>() { tcC_Remark_CM_1 };
            //tcLst.Add(tcC_Remark);

            var tcC_Remarks = new TransColumn(); // ---------------------
            tcC_Remarks.Column = "C.REMARKS";
            tcC_Remarks.NewColNm = ElecRcpt_TTFT_Info.Y_C_REMARKS;
            var tcC_Remarks_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_Remarks.ColMapLst = new List<ColumnMapping>() { tcC_Remarks_CM_1 };
            tcLst.Add(tcC_Remarks);

            var tcSTMT_NOS = new TransColumn();
            tcSTMT_NOS.Column = "STMT.NOS";
            tcSTMT_NOS.NewColNm = ElecRcpt_TTFT_Info.Y_STMT_NOS;
            tcSTMT_NOS.ColumnMp = "1";
            var tcSTMT_NOS_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcSTMT_NOS.ColMapLst = new List<ColumnMapping>() { tcSTMT_NOS_CM_1 };
            tcLst.Add(tcSTMT_NOS);

            var tcTRANSACTION_TYPE = new TransColumn();
            tcTRANSACTION_TYPE.Column = "TRANSACTION.TYPE";
            tcTRANSACTION_TYPE.NewColNm = ElecRcpt_TTFT_Info.Y_TRANSACTION_TYPE;
            var tcTRANSACTION_TYPE_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcTRANSACTION_TYPE.ColMapLst = new List<ColumnMapping>() { tcTRANSACTION_TYPE_CM_1 };
            tcLst.Add(tcTRANSACTION_TYPE);

            //var tcPAYMENT_DETAILS = new TransColumn();
            //tcPAYMENT_DETAILS.Column = "PAYMENT.DETAILS";
            //tcPAYMENT_DETAILS.NewColNm = ElecRcpt_TTFT_Info.Y_PAYMENT_DETAILS;
            //var tcPAYMENT_DETAILS_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            //tcPAYMENT_DETAILS.ColMapLst = new List<ColumnMapping>() { tcPAYMENT_DETAILS_CM_1 };
            //tcLst.Add(tcPAYMENT_DETAILS);

            var tcC_VER_NAME = new TransColumn();
            tcC_VER_NAME.Column = "C.VER.NAME";
            tcC_VER_NAME.NewColNm = ElecRcpt_TTFT_Info.Y_C_VER_NAME;
            var tcC_VER_NAME_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_VER_NAME.ColMapLst = new List<ColumnMapping>() { tcC_VER_NAME_CM_1 };
            tcLst.Add(tcC_VER_NAME);


            var tcC_ORG_FT_REF_NO = new TransColumn();
            tcC_ORG_FT_REF_NO.Column = "C.ORG.FT.REF.NO";
            tcC_ORG_FT_REF_NO.NewColNm = ElecRcpt_TTFT_Info.Y_C_ORG_FT_REF_NO;
            tcC_ORG_FT_REF_NO.ColumnMp = "1";
            var tcC_ORG_FT_REF_NO_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_ORG_FT_REF_NO.ColMapLst = new List<ColumnMapping>() { tcC_ORG_FT_REF_NO_CM_1 };
            tcLst.Add(tcC_ORG_FT_REF_NO);
            //}
            #endregion 2040506
            return tcLst;
        }
        #endregion FT


        #endregion Business

        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey)
        {
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, body);

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(body);
            XmlDocument subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString());
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }
    }
}
