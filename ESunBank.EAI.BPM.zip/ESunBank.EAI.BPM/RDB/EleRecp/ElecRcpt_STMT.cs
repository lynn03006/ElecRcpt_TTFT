﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Text;

using Microsoft.Service;
using Microsoft.Service.Xml;
using Microsoft.Service.Parallel;
using Microsoft.EAIServer;

using Bankpro.EAI.BPM;
using Bankpro.EAI.Utility;
using Bankpro.EAI.Component;
using Bankpro.EAI.BPM.Common;
using System.IO;

namespace Bankpro.EAI.BPM
{
    public class ElecRcpt_STMT : XmlBaseBpmAdapter
    {
        private static readonly Logger m_log = LogManager.GetLogger("Bankpro.EAI.BPM.ElecRcpt_STMT");
        private readonly string m_2040501_txid = "2040501"; // "2040501_RDB_STMT";
        private readonly string m_2040506_txid = "2040506"; // "2040506_RDB_STMT";
        private readonly string m_RdbMsgid_STMT = "RDB_STMT";
        private readonly string m_RdbMsgid_FT = "RDB_FT";
        private readonly string m_RdbMsgid_FT_HIS = "RDB_FT_HIS";
        protected override AppXmlExecResult RunImpl(EaiContext context, string correlationID, string txID, HostTxDef txDef, XmlDocument requestXml)
        {
            XmlDocument responseXml = new XmlDocument();
            EaiResponse eaiRs = null;

            try
            {
                UcControler ucControler = new UcControler();
                UCCommonUtil ucComUtil = new UCCommonUtil();
                /******************************
                 * 剖析UCString並獲取必要資訊 *
                 ******************************/
                XmlHelper xmlHelper = XmlHelper.GetInstance(requestXml);
                string ucData = xmlHelper.GetXPath(requestXml, "//T24_DATA").Trim();
                m_log.Info("AppXmlExecResult RunImpl.UC.RQ={0}", ucData);
                Dictionary<string, string> ucHeadDic, ucBodyDic;
                UCCommonUtil.ParseUcToDic(ucControler, ucData, out ucHeadDic, out ucBodyDic);
                string customer_ID, start_Date, end_Date, account_ID;
                ucBodyDic.TryGetValue("4001", out customer_ID);   // 客戶號
                ucBodyDic.TryGetValue("4119", out start_Date);   // 開始日期
                ucBodyDic.TryGetValue("4120", out end_Date);   // 結束日期
                ucBodyDic.TryGetValue("4300", out account_ID);   // 帳號
                m_log.Info("AppXmlExecResult RunImpl.UC.4001(customer_ID)={0}&&4119(start_Date)={1}&&4120(end_Date)={2}&&4300(account_ID)={3}", customer_ID, start_Date, end_Date, account_ID);


                var recordList_STMT = GetRecordList_STMT(context, txID, customer_ID, start_Date, end_Date, account_ID);

                List<ElecRcpt_STMT_Info.ReturnFileContent> rfcLst = recordList_STMT != null ? GetReturnFileContent(txID, recordList_STMT) : new List<ElecRcpt_STMT_Info.ReturnFileContent>();
                rfcLst = rfcLst.OrderBy(r => r.TxnDate).ThenBy(r => r.TxnTime).ThenBy(r => r.STMTNO).ToList();
                var fileContentLst = CreateFileContent(rfcLst, txID);
                ucControler.CreateEnqFileToUC(fileContentLst, true);


                Dictionary<string, string> totalDic = new Dictionary<string, string>();
                totalDic.Add("2028", "CO1M0000");
                totalDic.Add("zzzx", ucControler.enqFileName);//文件名
                totalDic.Add("4305", fileContentLst.Count.ToString());//總筆數
                string rsString = ucComUtil.GetRsStringFromRqDic(ucHeadDic, ucBodyDic, totalDic);

                m_log.Info("RunImpl txID = [{0}] UC_Response = [{1}]", txID, rsString);
                XmlDocument rs = base.TransformCommMsg("0", "Info", "交易完成", rsString);
                return base.BuildExecResult(context, rs);

            }
            catch (Exception ex)
            {
                eaiRs = EaiResponse.GetInstance(false);
                eaiRs.SetEaiError(eaiRs.EaiErrCode, ex.ToString(), "");
                responseXml = TransformCommMsg("9999", "Error", ex.ToString(), "");
                m_log.ErrorException("Error executing Run():" + ex.ToString(), ex);
            }
            finally
            {
                m_log.Debug("Run end<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
            }

            return AppXmlExecResult.GetInstance(correlationID, txID, requestXml, responseXml, eaiRs);
        }



        private List<Record> GetRecordList_STMT(EaiContext context, string txid, string customerID, string startDate, string endDate, string acctNo)
        {
            QueryInfo queryInfo = GetQueryInfo(txid, customerID, startDate, endDate, acctNo);
            List<TransColumn> transColumnLst = GetTransColumnLst_STMT_ENTRY();// GetTransColumnLst(txid);
            var rcLst = transColumnLst.Select(tc => string.IsNullOrEmpty(tc.NewColNm) ? tc.Column : tc.NewColNm).Distinct().ToList();
            T24QueryInfo tqf = new T24QueryInfo()
            {
                TableName = "FBNK_STMT_ENTRY",
                ReturnColumnLst = rcLst,
                QInfo = queryInfo,
                TransColumnLst = transColumnLst
            };
            var msgContent_STMT = RDBUtil.GetRdbMsgContent(m_RdbMsgid_STMT, tqf.TableName.Replace('#', '_'), tqf);
            var stmtResult = SendMsgToEAIProcess(context, msgContent_STMT, m_RdbMsgid_STMT);
            List<Record> stmt_entryRecordLst = RDBUtil.GetRdbRsList<ElecRcpt_STMT_Info.STMT_XMLRECORD>(stmtResult.ResponseXml.InnerXml);
            if (stmt_entryRecordLst == null || stmt_entryRecordLst.Count == 0)
            {
                m_log.Info("No Record Found From STMT");
                return null;
            }



            List<Record> ft_FinalRecordLst = new List<Record>();
            #region ToGetFtLive
            var toLiveFtIdLst = stmt_entryRecordLst.Select(r => (r.XMLRECORD as ElecRcpt_STMT_Info.STMT_XMLRECORD).Y_TRANS_REFERENCE).ToList();
            if (toLiveFtIdLst.Count > 0)
            {
                QueryInfo toLiveFtQi = new QueryInfo();
                toLiveFtQi.AON = "OR";
                toLiveFtQi.FieldCriLst = new List<FieldCriteria>();
                List<TransColumn> toLiveFtTcLst = GetTransColumnLst_FUNDS_TRANSFER(txid);
                var toLiveFtRcLst = toLiveFtTcLst.Select(tc => string.IsNullOrEmpty(tc.NewColNm) ? tc.Column : tc.NewColNm).Distinct().ToList();
                foreach (var trans_reference in toLiveFtIdLst)
                {
                    FieldCriteria fc = new FieldCriteria();
                    fc.FieldNm = "@ID";
                    fc.Operator = "=";
                    fc.Value = trans_reference;
                    toLiveFtQi.FieldCriLst.Add(fc);
                }
                T24QueryInfo toLiveFtT24Qi = new T24QueryInfo()
                {
                    TableName = "FBNK_FUNDS_TRANSFER",
                    ReturnColumnLst = toLiveFtRcLst,
                    QInfo = toLiveFtQi,
                    TransColumnLst = toLiveFtTcLst
                };
                var msgContent_FT_Live = RDBUtil.GetRdbMsgContent(m_RdbMsgid_FT, toLiveFtT24Qi.TableName.Replace('#', '_'), toLiveFtT24Qi);
                var ftLiveResult = SendMsgToEAIProcess(context, msgContent_FT_Live, m_RdbMsgid_FT);
                ft_FinalRecordLst.AddRange(RDBUtil.GetRdbRsList<ElecRcpt_STMT_Info.FT_XMLRECORD>(ftLiveResult.ResponseXml.InnerXml));
            }
            #endregion ToGetFtLive
            List<string> ft_Live_IdLst = ft_FinalRecordLst.Select(f => f.RECID).ToList();
            //--------------------------------------------------------------
            //--------------------------------------------------------------
            //--------------------------------------------------------------
            #region ToGetFtHis
            var toHisFtIdLst = stmt_entryRecordLst.Where(h => !ft_Live_IdLst.Contains((h.XMLRECORD as ElecRcpt_STMT_Info.STMT_XMLRECORD).Y_TRANS_REFERENCE))
                                                  .Select(h => (h.XMLRECORD as ElecRcpt_STMT_Info.STMT_XMLRECORD).Y_TRANS_REFERENCE).ToList();
            if (toHisFtIdLst.Count > 0)
            {
                QueryInfo toHisFtQi = new QueryInfo();
                toHisFtQi.AON = "OR";
                toHisFtQi.FieldCriLst = new List<FieldCriteria>();
                List<TransColumn> toHisFtTcLst = GetTransColumnLst_FUNDS_TRANSFER(txid);
                var toHisFtRcLst = toHisFtTcLst.Select(tc => string.IsNullOrEmpty(tc.NewColNm) ? tc.Column : tc.NewColNm).Distinct().ToList();
                foreach (var trans_reference in toHisFtIdLst)
                {
                    FieldCriteria fc = new FieldCriteria();
                    fc.FieldNm = "@ID";
                    fc.Operator = "LIKE";
                    fc.Value = trans_reference + "...";
                    toHisFtQi.FieldCriLst.Add(fc);
                }
                T24QueryInfo toHisFtT24Qi = new T24QueryInfo()
                {
                    TableName = "FBNK_FUNDS_TRANSFER#HIS",
                    ReturnColumnLst = toHisFtRcLst,
                    QInfo = toHisFtQi,
                    TransColumnLst = toHisFtTcLst
                };
                var msgContent_FT_His = RDBUtil.GetRdbMsgContent(m_RdbMsgid_FT_HIS, toHisFtT24Qi.TableName.Replace('#', '_'), toHisFtT24Qi);
                var ftHisResult = SendMsgToEAIProcess(context, msgContent_FT_His, m_RdbMsgid_FT_HIS);
                ft_FinalRecordLst.AddRange(RDBUtil.GetRdbRsHisList<ElecRcpt_STMT_Info.FT_XMLRECORD>(ftHisResult.ResponseXml.InnerXml));
            }
            #endregion ToGetFtHis
            // 只是測試用
            var returnLst = ft_FinalRecordLst.Where(p => (p.XMLRECORD as ElecRcpt_STMT_Info.FT_XMLRECORD).Y_TRANS_GATE == "CIB").ToList();
            m_log.Debug("Get [{0}] Records", returnLst == null ? 0 : returnLst.Count);
            return returnLst;
        }


        private List<ElecRcpt_STMT_Info.ReturnFileContent> GetReturnFileContent(string txid, List<Record> recordLst)
        {
            m_log.Debug("recordLst:[{0}]Records", recordLst.Count);
            List<ElecRcpt_STMT_Info.ReturnFileContent> rfcLst = new List<ElecRcpt_STMT_Info.ReturnFileContent>();

            foreach (var live in recordLst)
            {
                var xmlrecord = live.XMLRECORD as ElecRcpt_STMT_Info.FT_XMLRECORD;

                ElecRcpt_STMT_Info.ReturnFileContent rfc = new ElecRcpt_STMT_Info.ReturnFileContent();
                rfc.TxnDate = xmlrecord.Y_VALUE_DATE;
                rfc.TxnTime = xmlrecord.Y_DATE_TIME.Substring(xmlrecord.Y_DATE_TIME.Length - 4) + "00";
                rfc.TxnAmt = xmlrecord.Y_DEBIT_AMOUNT;
                rfc.Channel = xmlrecord.Y_TRANS_GATE == "CIB" ? "03" : (xmlrecord.Y_TRANS_GATE == "BRANCH" || string.IsNullOrEmpty(xmlrecord.Y_TRANS_GATE) ? "02" : "");
                rfc.PayerAcct = xmlrecord.Y_DEBIT_ACCT_NO;
                //***
                rfc.PayerName = xmlrecord.Y_DEBIT_ACCT_TITLE_1 + xmlrecord.Y_DEBIT_ACCT_TITLE_2;
                //***
                rfc.PayeeAcct = string.IsNullOrEmpty(xmlrecord.Y_L_IB_CRT_B) ?
                                  xmlrecord.Y_CREDIT_ACCT_NO :
                                  xmlrecord.Y_C_PAYEE_ACCT_NO;
                rfc.PayeeName = xmlrecord.Y_C_PAYEE_NAME;
                rfc.TxnType = string.IsNullOrEmpty(xmlrecord.Y_L_IB_CRT_B) ?
                                "0" :
                                "1";
                rfc.TxnSerNo = xmlrecord.Y_FT_RECID.Split(';')[0];

                rfc.STMTNO = xmlrecord.Y_STMT_NOS;

                if (txid == m_2040506_txid)
                {
                    rfc.PayerBankNo = xmlrecord.Y_DEBIT_COMPANY_CODE;
                    rfc.PayerBankName = xmlrecord.Y_DEBIT_COMPANY_NAME;
                    rfc.PayeeBankNo = string.IsNullOrEmpty(xmlrecord.Y_L_IB_CRT_B) ?
                                      xmlrecord.Y_CREDIT_COMP_CODE :
                                      xmlrecord.Y_L_IB_CRT_B;
                    rfc.PayeeBankName = string.IsNullOrEmpty(xmlrecord.Y_L_IB_CRT_B) ?
                                        xmlrecord.Y_CREDIT_COMP_NAME :
                                        xmlrecord.Y_L_IB_CRT_B_NAME;
                    rfc.Currency = xmlrecord.Y_DEBIT_CURRENCY;
                    rfc.ChargeAmt = string.IsNullOrEmpty(xmlrecord.Y_TOTAL_CHARGE_AMT) ?
                                    "0.00" :
                                    xmlrecord.Y_TOTAL_CHARGE_AMT.Substring(3).Trim();
                    rfc.Narrative = xmlrecord.Y_DEBIT_THEIR_REF;
                    rfc.Remarks = xmlrecord.Y_C_REMARKS;
                    rfc.VerCode = xmlrecord.Y_STMT_NOS.Substring(11, 4);


                }
                rfcLst.Add(rfc);
            }

            return rfcLst;
        }

        private List<string> CreateFileContent(List<ElecRcpt_STMT_Info.ReturnFileContent> oo, string txid)
        {
            List<string> dataLst = new List<string>();
            if (txid == m_2040501_txid)
            {
                foreach (var x in oo)
                {
                    dataLst.Add(
                    string.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}",
                                    x.TxnDate,
                                    x.TxnTime,
                                    x.TxnAmt,
                                    x.Channel,
                                    x.PayerAcct,
                                    x.PayerName,
                                    x.PayeeAcct,
                                    x.PayeeName,
                                    x.TxnType,
                                    x.TxnSerNo));

                }
            }
            else if (txid == m_2040506_txid)
            {
                foreach (var x in oo)
                {
                    dataLst.Add(
                    string.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}|{10}|{11}|{12}|{13}|{14}|{15}|{16}|{17}|{18}|{19}|{20}",
                                    x.TxnDate,
                                    x.TxnTime,
                                    x.Channel,
                                    x.TxnType,
                                    x.PayerAcct,
                                    x.PayerName,
                                    x.TxnAmt,
                                    x.PayerBankNo,
                                    x.PayerBankName,
                                    x.PayeeAcct,
                                    x.PayeeName,
                                    x.PayeeBankNo,
                                    x.PayeeBankName,
                                    x.Currency,
                                    x.ChargeAmt,
                                    x.Narrative,
                                    x.Remarks,
                                    x.TxnSerNo,
                                    x.VerCode,
                                    x.PrintMan,
                                    x.PrintCount
                                    ));

                }
            }
            return dataLst;
        }





        #region Business
        private QueryInfo GetQueryInfo(string txid, string customerID, string startDate, string endDate, string acctNo)
        {
            var fcCUSTOMER_ID = new FieldCriteria() { FieldNm = "CUSTOMER.ID", Operator = "=", Value = customerID };
            var fcVALUE_DATE_1 = new FieldCriteria() { FieldNm = "VALUE.DATE", Operator = ">=", Value = startDate };
            var fcVALUE_DATE_2 = new FieldCriteria() { FieldNm = "VALUE.DATE", Operator = "<=", Value = endDate };
            var fcTRANS_REFERENCE = new FieldCriteria() { FieldNm = "TRANS.REFERENCE", Operator = "LIKE", Value = "FT..." };
            var fcAMOUNT_LCY = new FieldCriteria() { FieldNm = "AMOUNT.LCY", Operator = "<=", Value = "0" };
            var fcRECORD_STATUS = new FieldCriteria() { FieldNm = "RECORD.STATUS", Operator = "=", Value = "" };
            var fcTRANSACTION_CODE = new FieldCriteria() { FieldNm = "TRANSACTION.CODE", Operator = "=", Value = "213" };
            var fcList = new List<FieldCriteria>() { fcCUSTOMER_ID, fcVALUE_DATE_1, fcVALUE_DATE_2, fcTRANS_REFERENCE, fcAMOUNT_LCY, fcRECORD_STATUS, fcTRANSACTION_CODE };
            if (txid == m_2040506_txid && !string.IsNullOrEmpty(acctNo))
            {
                var fcACCOUNT_NUMBER = new FieldCriteria() { FieldNm = "ACCOUNT.NUMBER", Operator = "=", Value = acctNo };
                fcList.Add(fcACCOUNT_NUMBER);
            }
            QueryInfo qinfo = new QueryInfo() { AON = "AND", FieldCriLst = fcList };
            return qinfo;
        }
        private List<TransColumn> GetTransColumnLst_STMT_ENTRY()
        {
            var tcLst = new List<TransColumn>();

            var tcTrans_Reference = new TransColumn();
            tcTrans_Reference.Column = "TRANS.REFERENCE";
            tcTrans_Reference.NewColNm = ElecRcpt_STMT_Info.Y_TRANS_REFERENCE;
            var tcTrans_Reference_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcTrans_Reference.ColMapLst = new List<ColumnMapping>() { tcTrans_Reference_CM_1 };
            tcLst.Add(tcTrans_Reference);

            return tcLst;
        }
        private List<TransColumn> GetTransColumnLst_FUNDS_TRANSFER(string txid)
        {
            var tcLst = new List<TransColumn>();

            var tcFt_Recid = new TransColumn();
            tcFt_Recid.Column = "@ID";
            tcFt_Recid.NewColNm = ElecRcpt_STMT_Info.Y_FT_RECID;
            var tcFt_Recid_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcFt_Recid.ColMapLst = new List<ColumnMapping>() { tcFt_Recid_CM_1 };
            tcLst.Add(tcFt_Recid);

            var tcTrans_Gate = new TransColumn();
            tcTrans_Gate.Column = "L.TRANS.GATE";
            tcTrans_Gate.NewColNm = ElecRcpt_STMT_Info.Y_TRANS_GATE;
            var tcTrans_Gate_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcTrans_Gate.ColMapLst = new List<ColumnMapping>() { tcTrans_Gate_CM_1 };
            tcLst.Add(tcTrans_Gate);

            var tcValue_Date = new TransColumn(); // ---------------------
            tcValue_Date.Column = "DEBIT.VALUE.DATE";
            tcValue_Date.NewColNm = ElecRcpt_STMT_Info.Y_VALUE_DATE;
            var tcValue_Date_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcValue_Date.ColMapLst = new List<ColumnMapping>() { tcValue_Date_CM_1 };
            tcLst.Add(tcValue_Date);

            var tcDate_Time = new TransColumn();
            tcDate_Time.Column = "DATE.TIME";
            tcDate_Time.NewColNm = ElecRcpt_STMT_Info.Y_DATE_TIME;
            var tcDate_Time_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcDate_Time.ColMapLst = new List<ColumnMapping>() { tcDate_Time_CM_1 };
            tcLst.Add(tcDate_Time);

            var tcDebit_Amount = new TransColumn(); // ---------------------
            tcDebit_Amount.Column = "DEBIT.AMOUNT";
            tcDebit_Amount.NewColNm = ElecRcpt_STMT_Info.Y_DEBIT_AMOUNT;
            var tcDebit_Amount_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcDebit_Amount.ColMapLst = new List<ColumnMapping>() { tcDebit_Amount_CM_1 };
            tcLst.Add(tcDebit_Amount);

            var tcDebit_Acct_No = new TransColumn(); // ---------------------
            tcDebit_Acct_No.Column = "DEBIT.ACCT.NO";
            tcDebit_Acct_No.NewColNm = ElecRcpt_STMT_Info.Y_DEBIT_ACCT_NO;
            var tcDebit_Acct_No_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcDebit_Acct_No.ColMapLst = new List<ColumnMapping>() { tcDebit_Acct_No_CM_1 };
            tcLst.Add(tcDebit_Acct_No);

            var tcAc_Recid = new TransColumn(); // ---------------------
            tcAc_Recid.Column = "DEBIT.ACCT.NO";
            tcAc_Recid.NewColNm = ElecRcpt_STMT_Info.Y_AC_RECID;
            var tcAc_Recid_CM1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "@ID" };
            tcAc_Recid.ColMapLst = new List<ColumnMapping>() { tcAc_Recid_CM1 };
            tcLst.Add(tcAc_Recid);

            var tcDebit_Acct_Title_1 = new TransColumn();
            tcDebit_Acct_Title_1.Column = "DEBIT.ACCT.NO";
            tcDebit_Acct_Title_1.NewColNm = ElecRcpt_STMT_Info.Y_DEBIT_ACCT_TITLE_1;
            var tcDebit_Acct_Title_1_CM1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "ACCOUNT.TITLE.1" };
            tcDebit_Acct_Title_1.ColMapLst = new List<ColumnMapping>() { tcDebit_Acct_Title_1_CM1 };
            tcLst.Add(tcDebit_Acct_Title_1);

            var tcDebit_Acct_Title_2 = new TransColumn();
            tcDebit_Acct_Title_2.Column = "DEBIT.ACCT.NO";
            tcDebit_Acct_Title_2.NewColNm = ElecRcpt_STMT_Info.Y_DEBIT_ACCT_TITLE_2;
            var tcDebit_Acct_Title_2_CM1 = new ColumnMapping() { TransTb = "FBNK_ACCOUNT", TransCol = "ACCOUNT.TITLE.2" };
            tcDebit_Acct_Title_2.ColMapLst = new List<ColumnMapping>() { tcDebit_Acct_Title_2_CM1 };
            tcLst.Add(tcDebit_Acct_Title_2);

            var tcCredit_Acct_No = new TransColumn();
            tcCredit_Acct_No.Column = "CREDIT.ACCT.NO";
            tcCredit_Acct_No.NewColNm = ElecRcpt_STMT_Info.Y_CREDIT_ACCT_NO;
            var tcCredit_Acct_No_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcCredit_Acct_No.ColMapLst = new List<ColumnMapping>() { tcCredit_Acct_No_CM_1 };
            tcLst.Add(tcCredit_Acct_No);

            var tcC_Payee_Name = new TransColumn(); // ---------------------
            tcC_Payee_Name.Column = "C.PAYEE.NAME";
            tcC_Payee_Name.NewColNm = ElecRcpt_STMT_Info.Y_C_PAYEE_NAME;
            var tcC_Payee_Name_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_Payee_Name.ColMapLst = new List<ColumnMapping>() { tcC_Payee_Name_CM_1 };
            tcLst.Add(tcC_Payee_Name);

            var tcC_Payee_Acct_No = new TransColumn();
            tcC_Payee_Acct_No.Column = "C.PAYEE.ACCT.NO";
            tcC_Payee_Acct_No.NewColNm = ElecRcpt_STMT_Info.Y_C_PAYEE_ACCT_NO;
            var tcC_Payee_Acct_No_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcC_Payee_Acct_No.ColMapLst = new List<ColumnMapping>() { tcC_Payee_Acct_No_CM_1 };
            tcLst.Add(tcC_Payee_Acct_No);

            var tcL_Ib_Crt_B = new TransColumn();
            tcL_Ib_Crt_B.Column = "L.IB.CRT.B";
            tcL_Ib_Crt_B.NewColNm = ElecRcpt_STMT_Info.Y_L_IB_CRT_B;
            var tcL_Ib_Crt_B_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcL_Ib_Crt_B.ColMapLst = new List<ColumnMapping>() { tcL_Ib_Crt_B_CM_1 };
            tcLst.Add(tcL_Ib_Crt_B);

            #region 2040506
            if (txid == m_2040506_txid)
            {
                var tcDebit_Company_Code = new TransColumn(); // ---------------------
                tcDebit_Company_Code.Column = "DEBIT.COMP.CODE";
                tcDebit_Company_Code.NewColNm = ElecRcpt_STMT_Info.Y_DEBIT_COMPANY_CODE;
                var tcDebit_Company_Code_CM_1 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "C.CPS.CODE" };
                tcDebit_Company_Code.ColMapLst = new List<ColumnMapping>() { tcDebit_Company_Code_CM_1, };
                tcLst.Add(tcDebit_Company_Code);

                var tcDebit_Company_Name = new TransColumn(); // ---------------------
                tcDebit_Company_Name.Column = "DEBIT.COMP.CODE";
                tcDebit_Company_Name.NewColNm = ElecRcpt_STMT_Info.Y_DEBIT_COMPANY_NAME;
                var tcDebit_Company_Name_CM_1 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "COMPANY.NAME", TransColMp = "2" };
                tcDebit_Company_Name.ColMapLst = new List<ColumnMapping>() { tcDebit_Company_Name_CM_1 };
                tcLst.Add(tcDebit_Company_Name);

                var tcCredit_Comp_Code = new TransColumn();
                tcCredit_Comp_Code.Column = "CREDIT.COMP.CODE";
                tcCredit_Comp_Code.NewColNm = ElecRcpt_STMT_Info.Y_CREDIT_COMP_CODE;
                var tcCredit_Comp_Code_CM_1 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "C.CPS.CODE" };
                tcCredit_Comp_Code.ColMapLst = new List<ColumnMapping>() { tcCredit_Comp_Code_CM_1 };
                tcLst.Add(tcCredit_Comp_Code);

                var tcCredit_Comp_Name = new TransColumn();
                tcCredit_Comp_Name.Column = "CREDIT.COMP.CODE";
                tcCredit_Comp_Name.NewColNm = ElecRcpt_STMT_Info.Y_CREDIT_COMP_NAME;
                var tcCredit_Comp_Name_CM_1 = new ColumnMapping() { TransTb = "F_COMPANY", TransCol = "COMPANY.NAME", TransColMp = "2" };
                tcCredit_Comp_Name.ColMapLst = new List<ColumnMapping>() { tcCredit_Comp_Name_CM_1 };
                tcLst.Add(tcCredit_Comp_Name);

                var tcL_Ib_Crt_B_Name = new TransColumn();
                tcL_Ib_Crt_B_Name.Column = "L.IB.CRT.B";
                tcL_Ib_Crt_B_Name.NewColNm = ElecRcpt_STMT_Info.Y_L_IB_CRT_B_NAME;
                var tcL_Ib_Crt_B_Name_CM_1 = new ColumnMapping() { TransTb = "F_ESCN_FIN_BANK_CODE", TransCol = "DESCRIPTION" };
                tcL_Ib_Crt_B_Name.ColMapLst = new List<ColumnMapping>() { tcL_Ib_Crt_B_Name_CM_1 };
                tcLst.Add(tcL_Ib_Crt_B_Name);

                var tcCurrency = new TransColumn(); // ---------------------
                tcCurrency.Column = "DEBIT.CURRENCY";
                tcCurrency.NewColNm = ElecRcpt_STMT_Info.Y_DEBIT_CURRENCY;
                var tcCurrency_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
                tcCurrency.ColMapLst = new List<ColumnMapping>() { tcCurrency_CM_1 };
                tcLst.Add(tcCurrency);

                var tcTotal_Charge_Amt = new TransColumn();
                tcTotal_Charge_Amt.Column = "TOTAL.CHARGE.AMT";
                tcTotal_Charge_Amt.NewColNm = ElecRcpt_STMT_Info.Y_TOTAL_CHARGE_AMT;
                var tcTotal_Charge_Amt_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
                tcTotal_Charge_Amt.ColMapLst = new List<ColumnMapping>() { tcTotal_Charge_Amt_CM_1 };
                tcLst.Add(tcTotal_Charge_Amt);

                var tcDebit_Their_Ref = new TransColumn(); // ---------------------
                tcDebit_Their_Ref.Column = "DEBIT.THEIR.REF";
                tcDebit_Their_Ref.NewColNm = ElecRcpt_STMT_Info.Y_DEBIT_THEIR_REF;
                var tcDebit_Their_Ref_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
                tcDebit_Their_Ref.ColMapLst = new List<ColumnMapping>() { tcDebit_Their_Ref_CM_1 };
                tcLst.Add(tcDebit_Their_Ref);

                var tcC_Remarks = new TransColumn(); // ---------------------
                tcC_Remarks.Column = "C.REMARKS";
                tcC_Remarks.NewColNm = ElecRcpt_STMT_Info.Y_C_REMARKS;
                var tcC_Remarks_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
                tcC_Remarks.ColMapLst = new List<ColumnMapping>() { tcC_Remarks_CM_1 };
                tcLst.Add(tcC_Remarks);
            }
            var tcSTMT_NOS = new TransColumn();
            tcSTMT_NOS.Column = "STMT.NOS";
            tcSTMT_NOS.NewColNm = ElecRcpt_STMT_Info.Y_STMT_NOS;
            tcSTMT_NOS.ColumnMp = "1";
            var tcSTMT_NOS_CM_1 = new ColumnMapping() { TransTb = "", TransCol = "" };
            tcSTMT_NOS.ColMapLst = new List<ColumnMapping>() { tcSTMT_NOS_CM_1 };
            tcLst.Add(tcSTMT_NOS);

            #endregion 2040506
            return tcLst;
        }
        #endregion Business



        private AppXmlExecResult SendMsgToEAIProcess(EaiContext context, string body, string eAI_MsgKey)
        {
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RQ={1}", eAI_MsgKey, body);

            XmlDocument rq = new XmlDocument();
            rq.LoadXml(body);
            XmlDocument subRqXml = CopyToNewDocument(rq, eAI_MsgKey, Guid.NewGuid().ToString());
            AppXmlExecResult result = Send1Recv1(m_log, context, subRqXml);
            m_log.Debug("AppXmlExecResult RunImpl.{0}.RS={1}", eAI_MsgKey, result.ResponseXml.InnerXml);

            return result;
        }






    }
}
