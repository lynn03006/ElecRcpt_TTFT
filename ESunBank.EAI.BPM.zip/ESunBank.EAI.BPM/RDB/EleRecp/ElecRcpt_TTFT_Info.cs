﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bankpro.EAI.BPM
{
    public class ElecRcpt_TTFT_Info
    {
        internal static string Y_DATE_TIME = "Y_DATE_TIME";
        #region TT
        internal static string Y_TT_RECID = "Y_TT_RECID";
        internal static string Y_VALUE_DATE_1 = "Y_VALUE_DATE_1";
        internal static string Y_AMOUNT_LOCAL_1 = "Y_AMOUNT_LOCAL_1";
        internal static string Y_ACCOUNT_1 = "Y_ACCOUNT_1";
        internal static string Y_ACCT_1_TITLE_1 = "Y_ACCT_1_TITLE_1";
        internal static string Y_ACCT_1_TITLE_2 = "Y_ACCT_1_TITLE_2";
        internal static string Y_ACCOUNT_2 = "Y_ACCOUNT_2";
        internal static string Y_ACCT_2_TITLE_1 = "Y_ACCT_2_TITLE_1";
        internal static string Y_ACCT_2_TITLE_2 = "Y_ACCT_2_TITLE_2";
        internal static string Y_ACCT_1_COMP_CODE = "Y_ACCT_1_COMP_CODE";
        internal static string Y_ACCT_1_COMP_NAME = "Y_ACCT_1_COMP_NAME";
        internal static string Y_ACCT_2_COMP_CODE = "Y_ACCT_2_COMP_CODE";
        internal static string Y_ACCT_2_COMP_NAME = "Y_ACCT_2_COMP_NAME";
        internal static string Y_CURRENCY_1 = "Y_CURRENCY_1";
        internal static string Y_CHRG_AMT_LOCAL = "Y_CHRG_AMT_LOCAL";
        internal static string NARRATIVE_1 = "NARRATIVE.1";
        internal static string Y_STMT_NO = "Y_STMT_NO";
        #endregion TT

        //internal static string Y_TRANS_REFERENCE = "Y_TRANS_REFERENCE";
        internal static string Y_FT_RECID = "Y_FT_RECID";
        internal static string Y_L_TRANS_GATE = "Y_L_TRANS_GATE";
        internal static string Y_DEBIT_VALUE_DATE = "Y_DEBIT_VALUE_DATE";
        internal static string Y_DEBIT_AMOUNT = "Y_DEBIT_AMOUNT";
        internal static string Y_CREDIT_AMOUNT = "Y_CREDIT_AMOUNT";
        internal static string Y_DEBIT_ACCT_NO = "Y_DEBIT_ACCT_NO";
        //internal static string Y_AC_RECID = "Y_AC_RECID";
        internal static string Y_DEBIT_ACCT_TITLE_1 = "Y_DEBIT_ACCT_TITLE_1";
        internal static string Y_DEBIT_ACCT_TITLE_2 = "Y_DEBIT_ACCT_TITLE_2";
        internal static string Y_CREDIT_ACCT_NO = "Y_CREDIT_ACCT_NO";
        internal static string Y_CREDIT_ACCT_TITLE_1 = "Y_CREDIT_ACCT_TITLE_1";
        internal static string Y_CREDIT_ACCT_TITLE_2 = "Y_CREDIT_ACCT_TITLE_2";
        internal static string Y_DEBIT_COMPANY_CODE = "Y_DEBIT_COMPANY_CODE";
        internal static string Y_DEBIT_COMPANY_NAME = "Y_DEBIT_COMPANY_NAME";
        internal static string Y_CREDIT_COMP_CODE = "Y_CREDIT_COMP_CODE";
        internal static string Y_CREDIT_COMP_NAME = "Y_CREDIT_COMP_NAME";
        internal static string Y_L_OR_BANK_NO = "Y_L_OR_BANK_NO";
        internal static string Y_L_OR_BANK_NM = "Y_L_OR_BANK_NM";
        internal static string Y_L_INIT_BANK_NO = "Y_L_INIT_BANK_NO";
        internal static string Y_L_INIT_BANK_NM = "Y_L_INIT_BANK_NM";
        internal static string Y_DEBIT_CURRENCY = "Y_DEBIT_CURRENCY";
        internal static string Y_DEBIT_THEIR_REF = "Y_DEBIT_THEIR_REF";
        internal static string Y_TOTAL_CHARGE_AMT = "Y_TOTAL_CHARGE_AMT";
        internal static string Y_STMT_NOS = "Y_STMT_NOS";
        internal static string Y_C_PAYEE_NAME = "Y_C_PAYEE_NAME";
        internal static string Y_C_PAYEE_ACCT_NO = "Y_C_PAYEE_ACCT_NO";
        internal static string Y_C_PAYER_ACCT_NO = "Y_C_PAYER_ACCT_NO";
        internal static string Y_C_PAYER_NAME = "Y_C_PAYER_NAME";
        internal static string Y_L_IB_CRT_B = "Y_L_IB_CRT_B";
        internal static string Y_L_IB_CRT_B_NAME = "Y_L_IB_CRT_B_NAME";
        internal static string Y_L_ESCN_IB_BK_NM = "Y_L_ESCN_IB_BK_NM";
        internal static string C_REMARK = "C.REMARK";
        internal static string Y_C_REMARKS = "Y_C_REMARKS";
        internal static string Y_TRANSACTION_TYPE = "Y_TRANSACTION_TYPE";
        internal static string PAYMENT_DETAILS = "PAYMENT.DETAILS";
        internal static string Y_C_VER_NAME = "Y_C_VER_NAME";
        internal static string Y_C_ORG_FT_REF_NO = "Y_C_ORG_FT_REF_NO";
        internal static string Y_C_IN_OUT_TYPE = "Y_C_IN_OUT_TYPE";

        public class TT_XMLRECORD : IXMLRECORD
        {
            public string Y_TT_RECID { get; set; }
            public string Y_VALUE_DATE_1 { get; set; }
            public string Y_DATE_TIME { get; set; }
            public string Y_AMOUNT_LOCAL_1 { get; set; }
            public string Y_ACCOUNT_1 { get; set; }
            public string Y_ACCT_1_TITLE_1 { get; set; }
            public string Y_ACCT_1_TITLE_2 { get; set; }
            public string Y_ACCOUNT_2 { get; set; }
            public string Y_ACCT_2_TITLE_1 { get; set; }
            public string Y_ACCT_2_TITLE_2 { get; set; }
            public string Y_ACCT_1_COMP_CODE { get; set; }
            public string Y_ACCT_1_COMP_NAME { get; set; }
            public string Y_ACCT_2_COMP_CODE { get; set; }
            public string Y_ACCT_2_COMP_NAME { get; set; }
            public string Y_CURRENCY_1 { get; set; }
            public string Y_CHRG_AMT_LOCAL { get; set; }
            [JsonProperty(PropertyName = "NARRATIVE.1")]
            public object Y_NARRATIVE_1 { get; set; }
            public string Y_STMT_NO { get; set; }
        }
        public class FT_XMLRECORD : IXMLRECORD
        {
            //public string Y_TRANS_REFERENCE { get; set; }
            public string Y_FT_RECID { get; set; }
            public string Y_L_TRANS_GATE { get; set; }
            public string Y_DEBIT_VALUE_DATE { get; set; }
            public string Y_DATE_TIME { get; set; }
            public string Y_DEBIT_AMOUNT { get; set; }
            public string Y_CREDIT_AMOUNT { get; set; }
            public string Y_DEBIT_ACCT_NO { get; set; }
            //public string Y_AC_RECID { get; set; }
            public string Y_DEBIT_ACCT_TITLE_1 { get; set; }
            public string Y_DEBIT_ACCT_TITLE_2 { get; set; }
            public string Y_CREDIT_ACCT_NO { get; set; }
            public string Y_CREDIT_ACCT_TITLE_1 { get; set; }
            public string Y_CREDIT_ACCT_TITLE_2 { get; set; }
            public string Y_DEBIT_COMPANY_CODE { get; set; }
            public string Y_DEBIT_COMPANY_NAME { get; set; }
            public string Y_CREDIT_COMP_CODE { get; set; }
            public string Y_CREDIT_COMP_NAME { get; set; }
            public string Y_L_OR_BANK_NO { get; set; }
            public string Y_L_OR_BANK_NM { get; set; }
            public string Y_L_INIT_BANK_NO { get; set; }
            public string Y_L_INIT_BANK_NM { get; set; }
            public string Y_DEBIT_CURRENCY { get; set; }
            public string Y_DEBIT_THEIR_REF { get; set; }
            public string Y_TOTAL_CHARGE_AMT { get; set; }
            public string Y_STMT_NOS { get; set; }
            public string Y_C_PAYEE_NAME { get; set; }
            public string Y_C_PAYEE_ACCT_NO { get; set; }
            public string Y_C_PAYER_ACCT_NO { get; set; }
            public string Y_C_PAYER_NAME { get; set; }
            public string Y_L_IB_CRT_B { get; set; }
            public string Y_L_IB_CRT_B_NAME { get; set; }
            public string Y_L_ESCN_IB_BK_NM { get; set; }
            [JsonProperty(PropertyName = "C.REMARK")]
            public object Y_C_REMARK { get; set; }
            public string Y_C_REMARKS { get; set; }
            public string Y_TRANSACTION_TYPE { get; set; }
            [JsonProperty(PropertyName = "PAYMENT.DETAILS")]
            public object Y_PAYMENT_DETAILS { get; set; }
            public string Y_C_VER_NAME { get; set; }
            public string Y_C_ORG_FT_REF_NO { get; set; }

            public string Y_C_IN_OUT_TYPE { get; set; }
        }

        public class ReturnFileContent
        {
            /// <summary>
            /// 交易日期
            /// </summary>
            public string TxnDate { get; set; }
            /// <summary>
            /// 交易時間
            /// </summary>
            public string TxnTime { get; set; }
            /// <summary>
            /// 交易金額(付款金額)
            /// </summary>
            public string TxnAmt { get; set; }
            /// <summary>
            /// 渠道標識
            /// </summary>
            public string Channel { get; set; }
            /// <summary>
            /// 付款人帳號
            /// </summary>
            public string PayerAcct { get; set; }
            /// <summary>
            /// 付款人名稱
            /// </summary>
            public string PayerName { get; set; }
            /// <summary>
            /// 收款人帳號
            /// </summary>
            public string PayeeAcct { get; set; }
            /// <summary>
            /// 收款人名稱
            /// </summary>
            public string PayeeName { get; set; }
            /// <summary>
            /// 交易類型
            /// </summary>
            public string TxnType { get; set; }
            /// <summary>
            /// 交易流水
            /// </summary>
            public string TxnSerNo { get; set; }



            /// <summary>
            /// 付款人行號
            /// </summary>
            public string PayerBankNo { get; set; }
            /// <summary>
            /// 付款人行名
            /// </summary>
            public string PayerBankName { get; set; }
            /// <summary>
            /// 收款人行號
            /// </summary>
            public string PayeeBankNo { get; set; }
            /// <summary>
            /// 收款人行名
            /// </summary>
            public string PayeeBankName { get; set; }
            /// <summary>
            /// 幣種
            /// </summary>
            public string Currency { get; set; }
            /// <summary>
            /// 手續費
            /// </summary>
            public string ChargeAmt { get; set; }
            /// <summary>
            /// 付款用途
            /// </summary>
            public string Narrative { get; set; }
            /// <summary>
            /// 交易付言
            /// </summary>
            public string Remarks { get; set; }
            /// <summary>
            /// 驗證碼
            /// </summary>
            public string VerCode { get; set; }
            /// <summary>
            /// 打印人員
            /// </summary>
            public string PrintMan { get; set; }
            /// <summary>
            /// 打印次數
            /// </summary>
            public string PrintCount { get; set; }

            /// <summary>
            /// tmp
            /// </summary>
            public string STMTNO { get; set; }
        }
    }
}
