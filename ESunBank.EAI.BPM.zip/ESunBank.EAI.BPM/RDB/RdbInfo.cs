﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bankpro.EAI.BPM
{
    class RdbInfo
    {
    }
    internal class T24QueryInfo
    {
        public string TableName { get; set; }
        public QueryInfo QInfo { get; set; }
        public List<TransColumn> TransColumnLst { get; set; }
        public List<string> ReturnColumnLst { get; set; }
        public bool Group { get; set; }
        public string SkipRows { get; set; }
        public string TakeRows { get; set; }
        public string QueryCnt { get; set; }
    }

    internal class QueryInfo
    {
        public string AON { get; set; }
        public List<QueryInfo> SubQueryInfoLst { get; set; }
        public List<FieldCriteria> FieldCriLst { get; set; }
    }

    internal class FieldCriteria
    {
        public string FieldNm { get; set; }
        public string Mp { get; set; }
        public string Sp { get; set; }
        public string Operator { get; set; }
        public string Value { get; set; }
    }

    internal class TransColumn
    {
        public string Column { get; set; }
        public string NewColNm { get; set; }
        public string ColumnMp { get; set; }
        public List<ColumnMapping> ColMapLst { get; set; }
    }

    internal class ColumnMapping
    {
        public string TransTb { get; set; }
        public string TransCol { get; set; }
        public string TransColMp { get; set; }
    }


    public interface IXMLRECORD { }
    public class Record
    {
        public string RECID { get; set; }
        public IXMLRECORD XMLRECORD { get; set; }
    }
}
